# Databricks notebook source
# from pyspark import SparkContext, SparkConf , StorageLevel
# from pyspark.sql import SparkSession, HiveContext
# from pyspark.sql.functions import *
# from pyspark.sql.types import *
# import logging
# from dateutil.rrule import rrule, MONTHLY
# from datetime import datetime
# import json
# from pyspark.sql import functions
# import sys
# class main() :
#     def __init__(self):
#          try :
#              spark = SparkSession.builder \
#                  .enableHiveSupport() \
#                  .config('hive.exec.dynamic.partition', 'true') \
#                  .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
#                  .config('hive.exec.max.dynamic.partitions', '10000') \
#                  .getOrCreate()
#              log4j = spark._jvm.org.apache.log4j
#              log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
#              spark.sql('SET hive.warehouse.data.skiptrash=true;')
#              spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
#              spark.conf.set('spark.sql.cbo.enabled', True)
#              spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
#              spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
#              spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
#              spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
#              spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
#              spark.sql("set spark.sql.adaptive.enabled=false")

#              dbutils.widgets.text("Custom_Settings", "")
#              dbutils.widgets.text("RUN_DATE", "")

#              Settings = dbutils.widgets.get("Custom_Settings")
#              RUN_DATE = dbutils.widgets.get("RUN_DATE")

#              Set_list = Settings.split(',')
#              if len(Set_list)>0:
#                  for i in Set_list:
#                      if i != "":
#                          print("spark.sql(+i+)")
#                          spark.sql("""{i}""".format(i=i))

#              spark.sql(""" USE b2b_stg """)
#              spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
#              spark.sql(""" SET hive.execution.engine = mr """)
#              spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
#              spark.sql(""" drop table if exists b2b_stg.stg_xd_member_guid_data """)
#              spark.sql(""" create table  b2b_stg.stg_xd_member_guid_data AS
# SELECT
# DISTINCT
# CASE WHEN fuat.partition_date>=DATE_SUB('{RUN_DATE}',90) AND fuat.partition_date<='{RUN_DATE}' THEN fuat.member_guid ELSE NULL END AS qau_member_guid,
# CASE WHEN fuat.partition_date>=DATE_SUB('{RUN_DATE}',27) AND fuat.partition_date<='{RUN_DATE}' THEN fuat.member_guid ELSE NULL  END AS mau_member_guid,
# CASE WHEN fuat.partition_date>=DATE_SUB('{RUN_DATE}',55) AND fuat.partition_date<=DATE_SUB('{RUN_DATE}',28) THEN fuat.member_guid ELSE NULL  END AS rmau_member_guid,
# CASE WHEN fuat.partition_date<=DATE_SUB('{RUN_DATE}',29) THEN fuat.member_guid ELSE NULL END AS new_member_guid
# FROM
# (
# SELECT 
# DISTINCT
# CASE WHEN act.member_guid=t2e.t2_guid THEN t2e.t1_guid ELSE act.member_guid END AS member_guid,
# act.partition_date
# FROM
# (
# SELECT 
# DISTINCT
# f.member_guid,
# f.partition_date
# FROM 
# ocf_analytics.fact_user_activity f
# JOIN 
# b2b.ent_product_map_cce mp
# ON UPPER(mp.product_code) = UPPER(f.product) AND UPPER(mp.category_code) = UPPER(f.category)
# WHERE mp.product = 'XD'
# AND f.partition_date <='{RUN_DATE}'
# ) act 
# LEFT JOIN 
# (
# SELECT DISTINCT auth_id AS t1_guid,profile_id AS t2_guid FROM ocf_analytics.vw_type2e_profile_reference WHERE SUBSTRING(end_dts,1,10)<='{RUN_DATE}'
# ) t2e
# ON act.member_guid = t2e.t2_guid
# ) fuat """.format(RUN_DATE = RUN_DATE))
#              spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
#              spark.sql(""" SET hive.execution.engine = mr """)
#              spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
#              spark.sql(""" WITH orgid_acct_type AS (
# SELECT
# org_id,
# CASE WHEN 
# CONCAT_WS('+',collect_list(DISTINCT drv_account_type)) IN ('ENT+NON_ENT','NON_ENT+ENT') THEN 'ENT' ELSE CONCAT_WS('+',collect_list(DISTINCT drv_account_type))
# END AS account_type
# FROM
# (
# SELECT
# DISTINCT
# org_id,
# CASE WHEN ent_account='CC_DC_SIGN_ENT' THEN 'ENT' ELSE 'NON_ENT' END AS drv_account_type
# FROM b2b.snapshot_all_dme_business_users
# WHERE 
# asofdate ='{RUN_DATE}' AND 
# (ent_account='CC_DC_SIGN_ENT' OR contract_type='ETLA')
# ) b
# GROUP BY
# org_id
# )
# INSERT overwrite TABLE b2b.all_xd_user_activity PARTITION (as_of_date)
# SELECT
# a.parent_id,
# a.parent_name,
# a.org_id,
# a.org_name,
# a.org_country,
# a.org_geo,
# a.contract_id,
# a.contract_type,
# a.free_paid,
# a.market_segment,
# a.industry,
# a.account_type,
# COUNT(DISTINCT b.mau_member_guid) AS tot_mau,
# COUNT(DISTINCT b.new_member_guid) AS new_mau,
# COUNT(DISTINCT b.rmau_member_guid) AS repeat_mau,
# (COUNT(DISTINCT b.mau_member_guid)-NVL(COUNT(DISTINCT b.new_member_guid),0)-NVL(COUNT(DISTINCT b.rmau_member_guid),0)) AS reactivated_mau,
# COUNT(DISTINCT b.qau_member_guid) AS qau,
# a.as_of_date
# FROM
# ( 
# SELECT
# ecp_parent_id AS parent_id,
# ecp_parent_name AS parent_name,
# a.org_id,
# org_name,
# org_country,
# org_geo,
# contract_id,
# contract_type,
# CASE WHEN (
# CONCAT_WS('+',COLLECT_LIST
# (DISTINCT
#  CASE WHEN upper(offering_name) LIKE '%ALL%' AND delegation_status = 'ACCEPTED' THEN 'PAID'
#      WHEN upper(offering_name) LIKE '%XD%' AND delegation_status = 'ACCEPTED' THEN 'PAID'
#      WHEN upper(offering_name) LIKE '%CCLE%' THEN 'PAID'
#      WHEN upper(offering_name) LIKE '%CCSN%' THEN 'PAID'
#  ELSE 'FREE' END))) IN ('FREE+PAID','PAID+FREE') THEN 'PAID' ELSE 
# CONCAT_WS('+',COLLECT_LIST(DISTINCT
#  CASE WHEN upper(offering_name) LIKE '%ALL%' AND delegation_status = 'ACCEPTED' THEN 'PAID'
#      WHEN upper(offering_name) LIKE '%XD%' AND delegation_status = 'ACCEPTED' THEN 'PAID'
#      WHEN upper(offering_name) LIKE '%CCLE%' THEN 'PAID'
#      WHEN upper(offering_name) LIKE '%CCSN%' THEN 'PAID'
#  ELSE 'FREE' END)) 
# END AS free_paid,
# market_segment,
# industry,
# b.account_type,
# CASE WHEN a.org_id=t2e.org_id  and a.member_guid=t2e.t2_guid THEN t2e.t1_guid ELSE a.member_guid END AS member_guid,
# asofdate AS as_of_date
# FROM
# b2b.snapshot_all_dme_business_users a
# LEFT JOIN
# (
# SELECT DISTINCT auth_id AS t1_guid,profile_id AS t2_guid,split(org_id,'@')[0] as org_id FROM ocf_analytics.vw_type2e_profile_reference WHERE SUBSTRING(end_dts,1,10)<='{RUN_DATE}'
# ) t2e
# ON 
# a.org_id=t2e.org_id
# AND a.member_guid = t2e.t2_guid
# LEFT JOIN
# orgid_acct_type b
# ON a.org_id=b.org_id
# WHERE 
# asofdate ='{RUN_DATE}' AND 
# (ent_account='CC_DC_SIGN_ENT' OR contract_type='ETLA')
# GROUP BY ecp_parent_id,ecp_parent_name,a.org_id,org_name,org_country,org_geo,contract_id,contract_type,market_segment,industry,b.account_type,CASE WHEN a.org_id=t2e.org_id  and a.member_guid=t2e.t2_guid THEN t2e.t1_guid ELSE a.member_guid END,asofdate
# ) a
# INNER JOIN
# (
# SELECT
# DISTINCT
# qmr.qau_member_guid,
# qmr.mau_member_guid,
# CASE WHEN qmr.mau_member_guid=qmr.rmau_member_guid THEN qmr.mau_member_guid ELSE NULL END AS rmau_member_guid,
# CASE WHEN qmr.mau_member_guid=n.new_member_guid THEN NULL ELSE qmr.mau_member_guid END AS new_member_guid
# FROM
# (
# SELECT
# qau_member_guid,
# COLLECT_SET(mau_member_guid)[0] AS mau_member_guid,
# COLLECT_SET(rmau_member_guid)[0] AS rmau_member_guid
# FROM b2b_stg.stg_xd_member_guid_data
# GROUP BY qau_member_guid
# ) qmr
# LEFT JOIN
# (SELECT DISTINCT new_member_guid FROM b2b_stg.stg_xd_member_guid_data WHERE new_member_guid IS NOT NULL) n
# ON  qmr.mau_member_guid=n.new_member_guid
# ) b
# ON a.member_guid=b.qau_member_guid
# GROUP BY a.parent_id,a.parent_name,a.org_id,a.org_name,a.org_country,a.org_geo,a.contract_id,a.contract_type,a.free_paid,a.market_segment,a.industry,a.account_type,a.as_of_date """.format(RUN_DATE = RUN_DATE))

#              try:
#                  dbutils.notebook.exit("SUCCESS")
#              except Exception as e:
#                  print("exception:",e)
#          except Exception as e:
#              dbutils.notebook.exit(e)

# if __name__ == '__main__':
#         main()

dbutils.notebook.exit("SUCCESS")