# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET mapred.output.compression.type=BLOCK """)
             spark.sql(""" SET hive.exec.reducers.bytes.per.reducer=268435456 """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" set hive.support.concurrency=false """)
             spark.sql(""" drop table if exists b2b.smb_zero_deployment_cohort_data """)
             spark.sql(""" create  table b2b.smb_zero_deployment_cohort_data AS
SELECT period.fiscal_yr_and_wk_desc,
       period.fiscal_yr_and_qtr_desc,
       TO_DATE(period.fiscal_wk_ending_date) AS contract_week_ending_date,
       period.fiscal_currnt_qtd AS contract_current_quarter_flag,
       contracts.contract_type,
       contracts.contract_id,
       contracts.enrollee_id,
       TO_DATE(contracts.contract_modified_date) AS contract_modified_date, 
       TO_DATE(contracts.contract_created_date) AS contract_created_date,
       TO_DATE(contracts.anniversary_date) AS anniversary_date,
       TO_DATE(contracts.previous_anniversary_date) AS previous_anniversary_date,
       TO_DATE(contracts.next_anniversary_date) AS next_anniversary_date,
       contracts.external_contract_id,
       contracts.owner_id,
       contracts.owner_identity_id,
       contracts.reseller_owner_id,
       contracts.billing_frequency,
       contracts.billing_status,
       contracts.billing_payment_category,
       IF(UPPER(contracts.contract_type) = "DIRECT_ORGANIZATION", subscription_account_guid ,if(UPPER(contracts.contract_type) = "INDIRECT_ORGANIZATION",contracts.contract_id,NULL)) as pivot_key_contract_id,
       CASE WHEN seat.route_to_market = 'RESELER' THEN COALESCE(SUBSTR(UPPER(lvt_indirect.pers_email), INSTR(UPPER(lvt_indirect.pers_email), '@') + 1), SUBSTR(UPPER(scd_indirect.email), INSTR(UPPER(scd_indirect.email), '@') + 1), 'UNKNOWN')
         ELSE COALESCE(SUBSTR(UPPER(lvt.pers_email), INSTR(UPPER(lvt.pers_email), '@') + 1), SUBSTR(UPPER(scd.email), INSTR(UPPER(scd.email), '@') + 1), 'UNKNOWN') END AS org_domain,
       datediff(date_sub(CURRENT_DATE(),2),TO_DATE(seat_payment.first_contract_startdate)) AS tenure,
       TO_DATE(seat_payment.first_contract_startdate) AS first_contract_startdate,
       IF(all_contract.seat_count-all_contract.seat_cancelled = 0, 'Y', 'N') AS is_inactive_contract,
       IF(all_contract.seat_count-all_contract.all_unassigned_seats = 0, 'Y', 'N') AS is_zd_contract_current,
       IF(contract_deployed_dates.first_contract_deployment_date is NULL, 'Y','N') AS is_zd_contract_from_start,
       countries.geo_code,
       countries.market_area_code,
       countries.market_area_description AS market_area_description,
       CASE WHEN contracts.country_code in ('AU','NZ') then contracts.country_code else countries.market_area_code end as market_area,
       s_period.fiscal_yr_and_qtr_desc as seat_creation_fiscal_yr_and_qtr_desc,
       s_period.fiscal_yr_and_wk_desc AS seat_creation_fiscal_yr_and_wk_desc,
       TO_DATE(s_period.fiscal_wk_ending_date) AS seat_week_ending_date,
       s_period.fiscal_currnt_qtd AS seat_current_quarter_flag,
       a_period.fiscal_yr_and_qtr_desc AS anniv_fiscal_yr_and_qtr_desc,
       a_period.fiscal_yr_and_wk_desc AS anniv_fiscal_yr_and_wk_desc,
       TO_DATE(a_period.fiscal_wk_ending_date) AS contract_anniv_week_ending_date,
       a_period.fiscal_currnt_qtd AS contract_anniv_current_quarter_flag,
       d_period.fiscal_yr_and_qtr_desc as deployment_start_fiscal_quarter,
       d_period.fiscal_yr_and_wk_desc as deployment_start_fiscal_week,
       TO_DATE(d_period.fiscal_wk_ending_date) AS deployment_week_ending_date,
       d_period.fiscal_currnt_qtd AS deployment_current_quarter_flag,
       seat.purchasedentitlement_id,
       seat.market_segment,
       seat.entitlement_period,
       seat.entitlement_type,
       seat.route_to_market,
       seat.product_name,
       seat.regular_vs_promotion,
       seat.seat_id,
       seat.subscription_account_guid,
       seat.seat_status,
       seat.seat_delegation_status,
       seat.cloud_type,
       TO_DATE(seat.seat_last_modifieddate) AS seat_last_modifieddate,
       seat.member_guid as current_assigned_member_guid,
       scd_member.subs_offer,
       CASE WHEN scd_member.subs_offer rlike 'CCE' THEN 'CCE VIP' ELSE 'CCT' END AS cct_vs_ccevip,
       seat_provisioning.member_guid as first_assigned_member_guid,
       seat_provisioning.seat_creation_date,
       seat_provisioning.seat_invited_date,
       seat_provisioning.seat_assigned_date,
        seat_deployed_dates.first_seat_creation_date,
        seat_deployed_dates.first_seat_invite_date,
        seat_deployed_dates.first_seat_deployment_date,
       TO_DATE(contract_deployed_dates.first_contract_deployment_date) AS first_contract_deployment_date,
       TO_DATE(contract_deployed_dates.first_contract_creation_date) AS first_contract_creation_date,
       TO_DATE(contract_deployed_dates.first_contract_invite_date) AS first_contract_invite_date,
       TO_DATE(seat_provisioning.seat_cancelled_date) AS seat_cancel_date,
       TO_DATE(first_seat_pay.first_seat_payment_dt) as seat_first_payment_dt,
       TO_DATE(contract_cancel.contract_cancelled_date) as contract_cancelled_date,
       all_contract.seat_count,
       all_contract.seat_cancelled,
       all_contract.seat_purchased, 
       all_contract.seat_deployed,
       all_contract.seat_not_deployed,
       dm.job,
       dm.skill
FROM (select * from ocf_analytics.dim_contract_jem where contract_type != 'DIRECT_INDIVIDUAL') contracts
LEFT OUTER JOIN (select min(term_startdate) as first_contract_startdate, contract_id from ocf_analytics.scd_seat_payment where payment_status = 'PAID SEAT' group by contract_id) seat_payment ON contracts.contract_id = seat_payment.contract_id
LEFT OUTER JOIN
  ( SELECT contract_id,
    COUNT(DISTINCT seat_id) seat_count,
    COUNT(DISTINCT(CASE WHEN seat_status != 'ACTIVE SEAT' THEN seat_id ELSE NULL END)) seat_cancelled,
    COUNT(DISTINCT(CASE WHEN seat_status = 'ACTIVE SEAT' THEN seat_id ELSE NULL END)) seat_purchased,
    COUNT(DISTINCT(CASE WHEN seat_status = 'ACTIVE SEAT'and seat_delegation_status='ASSIGNED' THEN seat_id ELSE NULL END)) seat_deployed,
    COUNT(DISTINCT(CASE WHEN seat_status = 'ACTIVE SEAT'and seat_delegation_status='UNASSIGNED' THEN seat_id ELSE NULL END)) seat_not_deployed,
    COUNT(DISTINCT(CASE WHEN seat_delegation_status='UNASSIGNED' THEN seat_id ELSE NULL END)) all_unassigned_seats
    FROM ocf_analytics.dim_seat where contract_type != 'DIRECT_INDIVIDUAL' 
    GROUP BY contract_id
)all_contract ON contracts.contract_id = all_contract.contract_id
LEFT OUTER JOIN ocf_analytics.dim_seat seat ON contracts.contract_id = seat.contract_id
LEFT OUTER JOIN (
                 Select
                         min(seat_creation_date) as first_seat_creation_date,
                         min(seat_invited_date) as first_seat_invite_date,
                         min(seat_assigned_date) AS first_seat_deployment_date,
                         seat_id
                         FROM b2b.team_seats_by_provisioning_cc_dc
                         where contract_type != 'DIRECT_INDIVIDUAL'
                         Group By seat_id
               )seat_deployed_dates ON seat.seat_id = seat_deployed_dates.seat_id
LEFT JOIN 
(Select * from 
(SELECT member_guid,
		   product_sku, 
 		   start_dttm,
 		   end_dttm,
           subs_offer,
           ROW_NUMBER() OVER(PARTITION BY member_guid ORDER BY start_dttm desc) AS rownum                      
            FROM ocf_analytics.scd_member_subscription
   )sku 
   where rownum = 1
   )scd_member
ON seat.member_guid = scd_member.member_guid 
AND seat.material_number=scd_member.product_sku
LEFT OUTER JOIN (select min(startdate_dttm) as first_seat_payment_dt, seat_id
                 from ocf_analytics.scd_seat_payment
                 where payment_status = 'PAID SEAT'
                 group by seat_id) first_seat_pay ON seat.seat_id = first_seat_pay.seat_id
LEFT OUTER JOIN b2b.team_seats_by_provisioning_cc_dc seat_provisioning ON seat.seat_id = seat_provisioning.seat_id
LEFT OUTER JOIN (
                 Select
                         min(seat_creation_date) as first_contract_creation_date,
                         min(seat_invited_date) as first_contract_invite_date,
                         min(seat_assigned_date) AS first_contract_deployment_date,
                         contract_id
                         FROM b2b.team_seats_by_provisioning_cc_dc
                         where contract_type != 'DIRECT_INDIVIDUAL'
                         Group By contract_id
               )contract_deployed_dates ON contracts.contract_id = contract_deployed_dates.contract_id
LEFT OUTER JOIN 
                (Select Contract_id,
                        max(last_seat_cancelled_date) as contract_cancelled_date
                FROM 
                    (
                      Select max(seat_cancelled_date) AS last_seat_cancelled_date ,
                      contract_id,
                      seat_id from b2b.team_seats_by_provisioning_cc_dc group by contract_id,seat_id
                    )seat_cancel 
                Group By contract_id
                )contract_cancel
                ON contracts.contract_id = contract_cancel.contract_id
    left outer join ocf_analytics.dim_user_lvt_profile lvt
      on upper(contracts.enrollee_id) = upper(lvt.user_guid)
    left join
        (
            Select * from
            (
                Select ep.* , row_number() over(partition by user_guid order by email_permission_date DESC) as rownum 
                 from
                    (
                      Select * from mdpd_target.ww_email_permission_history_w_guid
                    )ep
            )ep_row
            where rownum = 1
        )scd on upper(contracts.enrollee_id)=upper(scd.user_guid)
    left outer join ocf_analytics.dim_user_lvt_profile lvt_indirect
      on upper(seat.member_guid) = upper(lvt_indirect.user_guid)
    left join
        (
            Select * from
            (
                Select ep.* , row_number() over(partition by user_guid order by email_permission_date DESC) as rownum 
                 from
                    (
                      Select * from mdpd_target.ww_email_permission_history_w_guid
                    )ep
            )ep_row
            where rownum = 1
        )scd_indirect on upper(seat.member_guid)=upper(scd_indirect.user_guid)
LEFT OUTER JOIN Ids_coredata.dim_date a_period on to_date(contracts.previous_anniversary_date) = to_date(a_period.date_date)
INNER JOIN Ids_coredata.dim_date period on to_date(contracts.contract_created_date) = to_date(period.date_date)
INNER JOIN Ids_coredata.dim_date s_period on to_date(seat_provisioning.seat_creation_date) =to_date(s_period.date_date)
LEFT OUTER JOIN Ids_coredata.dim_date d_period on to_date(seat_provisioning.seat_assigned_date) = to_date(d_period.date_date)
LEFT OUTER JOIN Ids_coredata.dim_country countries ON contracts.country_code = countries.country_code_iso2
LEFT OUTER JOIN ocf_analytics.dim_member_cc dm ON upper(seat_provisioning.member_guid) = upper(dm.member_guid)
WHERE period.fiscal_yr_and_qtr_desc >='2017-Q1' """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()