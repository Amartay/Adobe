# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET mapred.output.compression.type=BLOCK """)
             spark.sql(""" SET hive.exec.reducers.bytes.per.reducer=268435456 """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" set hive.support.concurrency=false """)
             spark.sql(""" drop table if exists b2b.agg_zero_deployment_metrics """)
             spark.sql(""" create table b2b.agg_zero_deployment_metrics AS
Select 
con.fiscal_yr_and_wk_desc,
con.fiscal_yr_and_qtr_desc,
con.contract_week_ending_date,
period.fiscal_yr_and_wk_desc as contract_cancel_fiscal_wk,
period.fiscal_yr_and_qtr_desc as contract_cancel_fiscal_qtr,
con.contract_type,
con.billing_status,
con.is_inactive_contract,
con.is_zd_contract_current,
con.is_zd_contract_from_start,
con.geo_code,
con.market_area_code,
con.market_area_description,
CASE
      WHEN con.seat_count = 1                 THEN '1'
      WHEN con.seat_count BETWEEN   2 AND   4 THEN '2 to 4'
      WHEN con.seat_count BETWEEN   5 AND   9 THEN '5 to 9'
      WHEN con.seat_count BETWEEN  10 AND  49 THEN '10 to 49'
      WHEN con.seat_count BETWEEN  50 AND  99 THEN '50 to 99'
      WHEN con.seat_count BETWEEN 100 AND 199 THEN '100 to 199'
      WHEN con.seat_count BETWEEN 200 AND 299 THEN '200 to 299'
      WHEN con.seat_count BETWEEN 300 AND 999 THEN '300 to 999'
      WHEN con.seat_count >=1000              THEN '1000+' ELSE '0'
END AS total_seat_band,
con_agg.seat_status,
con_agg.seat_delegation_status,
con_agg.market_segment,
con_agg.entitlement_period,
con_agg.entitlement_type,
con_agg.route_to_market,
con_agg.product_name,
con_agg.regular_vs_promotion,
con_agg.cloud_type,
con_agg.job,
con_agg.skill,
IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 15,"0% Deployment Day 15","> 0% Deployment Day 15") as is_day_15_zd_contracts,
IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 30,"0% Deployment Day 30","> 0% Deployment Day 30") as is_day_30_zd_contracts,
IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 60,"0% Deployment Day 60","> 0% Deployment Day 60") as is_day_60_zd_contracts,
count(distinct con.contract_id) as contracts,
count(distinct con.seat_id) as seat_count,
COUNT(DISTINCT(CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END)) seat_deployed,
count(distinct (CASE WHEN is_zd_contract_current = 'Y'and is_inactive_contract='N' THEN con.contract_id ELSE NULL END)) AS  contracts_in_zd_current,
count(distinct (CASE WHEN is_zd_contract_from_start = 'Y'and is_inactive_contract='N' THEN con.contract_id ELSE NULL END)) AS contracts_in_zd_since_start,
count(distinct (CASE WHEN is_zd_contract_current = 'Y'and is_inactive_contract='N' THEN con.seat_id ELSE NULL END)) AS  seats_in_zd_current,
count(distinct (CASE WHEN is_zd_contract_from_start = 'Y'and is_inactive_contract='N' THEN con.seat_id ELSE NULL END)) AS seats_in_zd_since_start,
count(distinct (CASE WHEN is_inactive_contract='Y' THEN con.contract_id ELSE NULL END)) AS inactive_contracts,
count(distinct (CASE WHEN is_zd_contract_from_start = 'Y' and is_inactive_contract='Y' THEN con.contract_id ELSE NULL END)) contracts_cancelled_in_zd,
count(distinct (CASE WHEN is_zd_contract_from_start = 'Y' and is_inactive_contract='Y' THEN con.seat_id ELSE NULL END)) seats_cancelled_in_zd,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 15,con.contract_id,NULL)) as day_15_zd_contracts,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 60,con.contract_id,NULL)) as day_60_zd_contracts,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 90,con.contract_id,NULL)) as day_90_zd_contracts,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 180,con.contract_id,NULL)) as day_180_zd_contracts,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 365,con.contract_id,NULL)) as day_365_zd_contracts,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 15,con.seat_id,NULL)) as day_15_zd_seats,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 60,con.seat_id,NULL)) as day_60_zd_seats,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 90,con.seat_id,NULL)) as day_90_zd_seats,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 180,con.seat_id,NULL)) as day_180_zd_seats,
count(distinct IF(is_zd_contract_from_start='Y' OR datediff(first_contract_deployment_date,first_contract_creation_date) > 365,con.seat_id,NULL)) as day_365_zd_seats,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) > 60) THEN con.contract_id ELSE NULL END)) as day_60_after_zd_cancelled_contracts,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) < 60) THEN con.contract_id ELSE NULL END)) as day_60_before_zd_cancelled_contracts,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 0 AND 15) THEN con.contract_id ELSE NULL END)) as day_0_to_15_zd_cancelled_contracts,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 16 AND 60) THEN con.contract_id ELSE NULL END)) as day_16_to_60_zd_cancelled_contracts,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 61 AND 90) THEN con.contract_id ELSE NULL END)) as day_61_to_90_zd_cancelled_contracts,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 91 AND 180) THEN con.contract_id ELSE NULL END)) as day_91_to_180_zd_cancelled_contracts,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 181 AND 365) THEN con.contract_id ELSE NULL END)) as day_181_to_360_zd_cancelled_contracts,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 0 AND 15) THEN con.seat_id ELSE NULL END)) as day_0_to_15_zd_cancelled_seats,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 16 AND 60) THEN con.seat_id ELSE NULL END)) as day_16_to_60_zd_cancelled_seats,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 61 AND 90) THEN con.seat_id ELSE NULL END)) as day_61_to_90_zd_cancelled_seats,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 91 AND 180) THEN con.seat_id ELSE NULL END)) as day_91_to_180_zd_cancelled_seats,
count(distinct (CASE WHEN is_zd_contract_from_start='Y' AND is_inactive_contract='Y' AND (datediff(contract_cancelled_date,first_contract_creation_date) BETWEEN 181 AND 365) THEN con.seat_id ELSE NULL END)) as day_181_to_360_zd_cancelled_seats,
count(distinct IF(date_add(first_contract_creation_date,15) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_15_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,30) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_30_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,60) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_60_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,92) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_92_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,184) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_184_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,365) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_365_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,397) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_397_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,430) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_430_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,544) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_544_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,725) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_725_active_contracts,
count(distinct IF(date_add(first_contract_creation_date,760) BETWEEN substr(status.startdate_dttm,1,10) AND substr(status.enddate_dttm,1,10),con.contract_id,NULL)) as day_760_active_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) < 15,con.contract_id,NULL)) as day_0_15_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) BETWEEN 15 AND 30,con.contract_id,NULL)) as day_15_30_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) BETWEEN 31 AND 60,con.contract_id,NULL)) as day_31_60_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) BETWEEN 61 AND 90,con.contract_id,NULL))as day_61_90_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) BETWEEN 91 AND 180,con.contract_id,NULL)) as day_91_180_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) BETWEEN 181 AND 365,con.contract_id,NULL)) as day_181_365_deployed_contracts,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) < 15,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_0_15_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) BETWEEN 15 AND 30,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_15_30_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) BETWEEN 31 AND 60,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_31_60_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) BETWEEN 61 AND 90,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL))as day_61_90_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) BETWEEN 91 AND 180,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_91_180_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) BETWEEN 181 AND 365,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as  day_181_365_deployed_seats,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) < 15,con.contract_id,NULL)) as day_15_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) < 30,con.contract_id,NULL)) as day_30_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) < 60,con.contract_id,NULL)) as day_60_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) < 90,con.contract_id,NULL))as day_90_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) < 180,con.contract_id,NULL)) as day_180_deployed_contracts,
count(distinct IF(datediff(first_contract_deployment_date,first_contract_creation_date) < 365,con.contract_id,NULL)) as day_365_deployed_contracts,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) < 15,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_15_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) < 30,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_30_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) < 60,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_60_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) < 90,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL))as day_90_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) < 180,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_180_deployed_seats,
count(distinct IF(datediff(first_seat_deployment_date,first_seat_creation_date) < 365,CASE WHEN con.seat_status = 'ACTIVE SEAT'and con.seat_delegation_status='ASSIGNED' THEN con.seat_id ELSE NULL END,NULL)) as day_365_deployed_seats
From b2b.smb_zero_deployment_cohort_data con 
JOIN
(
      SELECT contract_id,
            sort_array(collect_set(job)) AS job,
            sort_array(collect_set(skill)) AS skill,
            sort_array(collect_set(market_segment)) AS market_segment,
            sort_array(collect_set(entitlement_period)) AS entitlement_period,
            sort_array(collect_set(entitlement_type)) AS entitlement_type,
            sort_array(collect_set(route_to_market)) AS route_to_market,
            sort_array(collect_set(product_name)) AS product_name,
            sort_array(collect_set(regular_vs_promotion)) AS regular_vs_promotion,
            sort_array(collect_set(cloud_type)) AS cloud_type,
            sort_array(collect_set(seat_delegation_status)) AS seat_delegation_status,
            sort_array(collect_set(seat_status)) AS seat_status
      FROM b2b.smb_zero_deployment_cohort_data 
      GROUP BY 1
) con_agg
ON con.contract_id = con_agg.contract_id
LEFT JOIN mdpd_stage.scd_seat_provisioning status
ON con.contract_id = status.contract_id
AND con.seat_id = status.seat_id
AND status.seat_status = "ACTIVE"
LEFT JOIN ids_coredata.dim_date period on to_date(con.contract_cancelled_date) = to_date(period.date_date)
where con.fiscal_yr_and_qtr_desc>='2020-Q1'
Group By
      1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28 """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()