# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.conf.set('spark.sql.legacy.timeParserPolicy','LEGACY')
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.b2b_tm_addon_metrics """)
             spark.sql(""" create table b2b.b2b_tm_addon_metrics AS
Select 
	pvt.fiscal_yr_desc,
    pvt.fiscal_yr_and_qtr_desc,
    pvt.fiscal_yr_and_wk_desc,
	period.fiscal_wk_in_yr,
	period.fiscal_wk_in_qtr,
	period.fiscal_qtr_id,
	period.fiscal_wk_ending_date,
    IF(pvt.fiscal_yr_and_wk_desc = curr.fiscal_yr_and_wk_desc, 'Y', 'N') CW_flag,
    IF(pvt.fiscal_yr_and_qtr_desc = curr.fiscal_yr_and_qtr_desc, 'Y', 'N') CQ_QTD_flag,
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc, 'Y', 'N') CY_YTD_flag,
    IF(pvt.fiscal_yr_and_wk_desc = prev_week.p_fiscal_yr_and_wk_desc, 'Y', 'N') PW_flag,
    IF(pvt.fiscal_yr_and_qtr_desc = prev_qtr.p_fiscal_yr_and_qtr_desc, 'Y', 'N') PQ_flag,
    IF(pvt.fiscal_yr_and_qtr_desc = prev_qtr.p_fiscal_yr_and_qtr_desc and period.fiscal_wk_in_qtr = curr.fiscal_wk_in_qtr, 'Y', 'N') PQ_CW_flag,
    IF(pvt.fiscal_yr_and_qtr_desc = prev_qtr.p_fiscal_yr_and_qtr_desc and period.fiscal_wk_in_qtr <= curr.fiscal_wk_in_qtr, 'Y', 'N') PQ_QTD_flag,
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc - 1, 'Y', 'N') PY_flag,
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc - 1 and period.fiscal_wk_in_yr = curr.fiscal_wk_in_yr, 'Y', 'N') PY_CW_flag,
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc - 1 and period.fiscal_qtr_id = curr.fiscal_qtr_id and period.fiscal_wk_in_qtr <= curr.fiscal_wk_in_qtr, 'Y', 'N') PY_CQ_QTD_flag,
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc - 1 and period.fiscal_wk_in_yr <= curr.fiscal_wk_in_yr, 'Y', 'N') PY_YTD_flag,
    COALESCE(jem.contract_id,pvt.vip_contract) contract_id,
	contracts.contract_type,
	contracts.contract_created_date as first_contract_start_date,
	period2.fiscal_yr_desc as first_contract_start_yr,
	period2.fiscal_yr_and_qtr_desc as first_contract_start_yr_and_qtr,
	period2.fiscal_yr_and_wk_desc as first_contract_start_yr_and_wk,
	period2.fiscal_wk_in_yr as first_contract_start_wk_in_yr,
	period2.fiscal_wk_in_qtr as first_contract_start_wk_in_qtr,
    pvt.geo,
    pvt.geo_description,
    pvt.market_area,
    pvt.market_area_description,
    pvt.market_segment,
	pvt.cloud_type_filter,
    pvt.route_to_market,
    pvt.cc_phone_vs_web as phone_vs_web,
	pvt.gtm_acct_segment,
    pvt.cc_segment,
    pvt.cc_segment_offer,  
    pvt.subs_offer, 
    pvt.product_category,  
    pvt.product_name,  
    pvt.product_name_description,	
    pvt.promotion,
    pvt.promo_type,
	pvt.offer_type_desc as offer_type_description,  
	SUM(jem.active_seats) as current_active_seat_count,
	CASE
		WHEN SUM(jem.active_seats) = 1 THEN '1'
		WHEN SUM(jem.active_seats) BETWEEN   2 AND   4 THEN '2 to 4'
		WHEN SUM(jem.active_seats) BETWEEN   5 AND   9 THEN '5 to 9'
		WHEN SUM(jem.active_seats) BETWEEN  10 AND  49 THEN '10 to 49'
		WHEN SUM(jem.active_seats) BETWEEN  50 AND  99 THEN '50 to 99'
		WHEN SUM(jem.active_seats) BETWEEN 100 AND 199 THEN '100 to 199'
		WHEN SUM(jem.active_seats) BETWEEN 200 AND 299 THEN '200 to 299'
		WHEN SUM(jem.active_seats) BETWEEN 300 AND 999 THEN '300 to 999'
		WHEN SUM(jem.active_seats) >=1000 THEN '1000+' ELSE '0'
		END AS current_seat_band,
    sum(coalesce(pvt.fyr_begin_active,0)) fyr_begin_active,
    sum(coalesce(pvt.fyr_end_active,0)) fyr_end_active,
    sum(coalesce(pvt.fqtr_begin_active,0)) fqtr_begin_active,
    sum(coalesce(pvt.fqtr_end_active,0)) fqtr_end_active,
    sum(coalesce(pvt.addl_purchase_diff,0)) addl_purchase_diff,
    sum(coalesce(pvt.addl_purchase_same,0)) addl_purchase_same,
    sum(coalesce(pvt.addl_purchase_same,0) + coalesce(pvt.addl_purchase_diff,0)) addl_purchase,
    sum(coalesce(pvt.net_new_subs,0)) net_new_subs,
    sum(coalesce(pvt.fyr_begin_arr_cfx,0)) fyr_begin_arr_cfx,
    sum(coalesce(pvt.fyr_end_arr_cfx,0)) fyr_end_arr_cfx,
    sum(coalesce(pvt.fqtr_begin_arr_cfx,0)) fqtr_begin_arr_cfx,
    sum(coalesce(pvt.fqtr_end_arr_cfx,0)) fqtr_end_arr_cfx,
    sum(CASE WHEN coalesce(pvt.addl_purchase_diff,0) > 0 THEN coalesce(pvt.gross_new_arr_cfx,0) - coalesce(pvt.init_purchase_arr_cfx,0) ELSE 0 END) addl_purchase_diff_arr_cfx,
    sum(CASE WHEN coalesce(pvt.addl_purchase_same,0) > 0 THEN coalesce(pvt.gross_new_arr_cfx,0) - coalesce(pvt.init_purchase_arr_cfx,0) ELSE 0 END) addl_purchase_same_arr_cfx,
    sum(coalesce(pvt.gross_new_arr_cfx,0) - coalesce(pvt.init_purchase_arr_cfx,0)) addl_purchase_arr_cfx,
    sum(coalesce(pvt.net_new_arr_cfx,0)) net_new_arr_cfx
from (
	SELECT
		fiscal_yr_desc,
		fiscal_yr_and_qtr_desc,
		fiscal_yr_and_wk_desc,
		date_key,
		vip_contract,
		subscription_account_guid,
		sales_document,
		sales_document_item,
		geo,
		geo_description,
		market_area,
		market_area_description,
		market_segment,
		IF(cloud_type_filter = 'Document Cloud','Acro+Sign',
			IF(NOT ISNULL(cloud_type_filter) AND UPPER(product_category) like '%ACROBAT%', 'Acro+Sign',
			IF(UPPER(cloud_type_filter) like '%CREATIVE%', 'Creative Cloud', NULL ))) as cloud_type_filter,
		route_to_market,
		cc_phone_vs_web,
		gtm_acct_segment,
		cc_segment,
		cc_segment_offer,  
		subs_offer, 
		product_category,  
		product_name,  
		product_name_description,	
		promotion,
		promo_type,
		offer_type_desc,  
		sum(coalesce(fyr_begin_active,0)) fyr_begin_active,
		sum(coalesce(fyr_end_active,0)) fyr_end_active,
		sum(coalesce(fqtr_begin_active,0)) fqtr_begin_active,
		sum(coalesce(fqtr_end_active,0)) fqtr_end_active,
		sum(coalesce(addl_purchase_diff,0)) addl_purchase_diff,
		sum(coalesce(addl_purchase_same,0)) addl_purchase_same,
		sum(coalesce(net_new_subs,0)) net_new_subs,
		sum(coalesce(fyr_begin_arr_cfx,0)) fyr_begin_arr_cfx,
		sum(coalesce(fyr_end_arr_cfx,0)) fyr_end_arr_cfx,
		sum(coalesce(fqtr_begin_arr_cfx,0)) fqtr_begin_arr_cfx,
		sum(coalesce(fqtr_end_arr_cfx,0)) fqtr_end_arr_cfx,
		sum(coalesce(gross_new_arr_cfx,0)) gross_new_arr_cfx,
		sum(coalesce(init_purchase_arr_cfx,0)) init_purchase_arr_cfx,
		sum(coalesce(net_new_arr_cfx,0)) net_new_arr_cfx
	from csmb.vw_ccm_pivot4_all
	where 1=1
		and source_type = 'TM'
	group by 
		fiscal_yr_desc,
		fiscal_yr_and_qtr_desc,
		fiscal_yr_and_wk_desc,
		date_key,
		vip_contract,
		subscription_account_guid,
		sales_document,
		sales_document_item,
		geo,
		geo_description,
		market_area,
		market_area_description,
		market_segment,
		IF(cloud_type_filter = 'Document Cloud','Acro+Sign',
			IF(NOT ISNULL(cloud_type_filter) AND UPPER(product_category) like '%ACROBAT%', 'Acro+Sign',
			IF(UPPER(cloud_type_filter) like '%CREATIVE%', 'Creative Cloud', NULL ))),
		route_to_market,
		cc_phone_vs_web,
		gtm_acct_segment,
		cc_segment,
		cc_segment_offer,  
		subs_offer, 
		product_category,  
		product_name,  
		product_name_description,	
		promotion,
		promo_type,
		offer_type_desc)	pvt
left outer join  (
    Select DISTINCT
		fiscal_yr_and_wk_desc,
		fiscal_wk_in_yr,
		fiscal_wk_in_qtr,
		fiscal_qtr_id,
		fiscal_wk_ending_date
    from ids_coredata.dim_date) period
	on pvt.fiscal_yr_and_wk_desc = period.fiscal_yr_and_wk_desc
cross join (
	Select
		date_key,
		fiscal_yr_desc,
		fiscal_yr_and_qtr_desc,
		fiscal_qtr_id,
		fiscal_yr_and_wk_desc,
		fiscal_wk_in_qtr,
		fiscal_wk_in_yr
    from ids_coredata.dim_date 
    where date_key = regexp_replace(date_sub(current_date(),((cast(date_format(current_date(), 'u') as INT)+1)%7)+1),'-','')) curr
left outer join (
    Select
        fiscal_yr_and_wk_desc,
        LAG(fiscal_yr_and_wk_desc,1) over(order by fiscal_yr_and_wk_desc) p_fiscal_yr_and_wk_desc
    from ids_coredata.dim_date
    group by 
        fiscal_yr_and_wk_desc) prev_week
on prev_week.fiscal_yr_and_wk_desc = curr.fiscal_yr_and_wk_desc
left outer join (
    Select
        fiscal_yr_and_qtr_desc,
        LAG(fiscal_yr_and_qtr_desc,1) over(order by fiscal_yr_and_qtr_desc) p_fiscal_yr_and_qtr_desc
    from ids_coredata.dim_date
    group by 
        fiscal_yr_and_qtr_desc) prev_qtr
on prev_qtr.fiscal_yr_and_qtr_desc = curr.fiscal_yr_and_qtr_desc

LEFT OUTER JOIN (
	Select upper(subscription_account_guid) subs_guid, 
        upper(contract_id) contract_id,
	    count(distinct case when seat_status='ACTIVE SEAT' then seat_id end) as active_seats
    from ocf_analytics.dim_seat
    where contract_id is not null
    and contract_id != ''
    and subscription_account_guid is not null
    and subscription_account_guid != ''
    group by upper(subscription_account_guid), upper(contract_id) )jem
on pvt.subscription_account_guid = jem.subs_guid

left outer join (
    Select
        contract_id,
		contract_type,
        date(cast(min(contract_created_date) as TIMESTAMP)) contract_created_date
    from ocf_analytics.dim_contract
    where contract_id is not null 
		and contract_id != ''
		and contract_type != 'DIRECT_INDIVIDUAL'
	group by contract_id,
		contract_type) contracts
on COALESCE(jem.contract_id,pvt.vip_contract) = contracts.contract_id
left outer join  (
    Select *
    from ids_coredata.dim_date ) period2 
	on contracts.contract_created_date = date(period2.date_date)
where 1=1
	and pvt.date_key <= curr.date_key
	and curr.fiscal_yr_desc - pvt.fiscal_yr_desc between 0 and 3
group by 
	pvt.fiscal_yr_desc,
    pvt.fiscal_yr_and_qtr_desc,
    pvt.fiscal_yr_and_wk_desc,
	period.fiscal_wk_in_yr,
	period.fiscal_wk_in_qtr,
	period.fiscal_qtr_id,
	period.fiscal_wk_ending_date,
    IF(pvt.fiscal_yr_and_wk_desc = curr.fiscal_yr_and_wk_desc, 'Y', 'N'),
    IF(pvt.fiscal_yr_and_qtr_desc = curr.fiscal_yr_and_qtr_desc, 'Y', 'N'),
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc, 'Y', 'N'),
    IF(pvt.fiscal_yr_and_wk_desc = prev_week.p_fiscal_yr_and_wk_desc, 'Y', 'N'),
    IF(pvt.fiscal_yr_and_qtr_desc = prev_qtr.p_fiscal_yr_and_qtr_desc, 'Y', 'N'),
    IF(pvt.fiscal_yr_and_qtr_desc = prev_qtr.p_fiscal_yr_and_qtr_desc and period.fiscal_wk_in_qtr = curr.fiscal_wk_in_qtr, 'Y', 'N'),
    IF(pvt.fiscal_yr_and_qtr_desc = prev_qtr.p_fiscal_yr_and_qtr_desc and period.fiscal_wk_in_qtr <= curr.fiscal_wk_in_qtr, 'Y', 'N'),
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc - 1, 'Y', 'N'),
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc - 1 and period.fiscal_wk_in_yr = curr.fiscal_wk_in_yr, 'Y', 'N'),
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc - 1 and period.fiscal_qtr_id = curr.fiscal_qtr_id and period.fiscal_wk_in_qtr <= curr.fiscal_wk_in_qtr, 'Y', 'N'),
    IF(pvt.fiscal_yr_desc = curr.fiscal_yr_desc - 1 and period.fiscal_wk_in_yr <= curr.fiscal_wk_in_yr, 'Y', 'N'),
    COALESCE(jem.contract_id,pvt.vip_contract),
	contracts.contract_type,
	contracts.contract_created_date,
	period2.fiscal_yr_desc,
	period2.fiscal_yr_and_qtr_desc,
	period2.fiscal_yr_and_wk_desc,
	period2.fiscal_wk_in_yr,
	period2.fiscal_wk_in_qtr,
    pvt.geo,
    pvt.geo_description,
    pvt.market_area,
    pvt.market_area_description,
    pvt.market_segment,
	pvt.cloud_type_filter,
    pvt.route_to_market,
    pvt.cc_phone_vs_web,
	pvt.gtm_acct_segment,
    pvt.cc_segment,
    pvt.cc_segment_offer,  
    pvt.subs_offer, 
    pvt.product_category,  
    pvt.product_name,  
    pvt.product_name_description,	
    pvt.promotion,
    pvt.promo_type,
	pvt.offer_type_desc
having sum(coalesce(pvt.fyr_begin_active,0)) != 0
    or sum(coalesce(pvt.fyr_end_active,0)) != 0
    or sum(coalesce(pvt.fqtr_begin_active,0)) != 0
    or sum(coalesce(pvt.fqtr_end_active,0)) != 0
    or sum(coalesce(pvt.addl_purchase_diff,0)) != 0
    or sum(coalesce(pvt.addl_purchase_same,0)) != 0
    or sum(coalesce(pvt.net_new_subs,0)) != 0
    or sum(coalesce(pvt.fyr_begin_arr_cfx,0)) != 0
    or sum(coalesce(pvt.fyr_end_arr_cfx,0)) != 0
    or sum(coalesce(pvt.fqtr_begin_arr_cfx,0)) != 0
    or sum(coalesce(pvt.fqtr_end_arr_cfx,0)) != 0
    or sum(coalesce(pvt.gross_new_arr_cfx,0) - coalesce(pvt.init_purchase_arr_cfx,0)) != 0
	or sum(coalesce(pvt.net_new_arr_cfx,0)) != 0 """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)   

if __name__ == '__main__':
        main()