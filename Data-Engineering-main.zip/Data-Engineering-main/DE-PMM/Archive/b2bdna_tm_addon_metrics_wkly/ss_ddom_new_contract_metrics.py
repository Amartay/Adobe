# Databricks notebook source
# MAGIC %sql
# MAGIC refresh table ocf_analytics.dim_contract;
# MAGIC refresh table ocf_analytics.dim_seat;
# MAGIC refresh table csmb_app.fact_csmb_subscription_detail;
# MAGIC refresh table csmb_app.dim_gtm_acct_segment;
# MAGIC refresh table csmb_app.dim_subscription;
# MAGIC refresh table ids_coredata.dim_date;
# MAGIC refresh table ids_coredata.dim_country;

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             
             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')
                          
             spark.conf.set('spark.sql.legacy.timeParserPolicy','LEGACY')
             #spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             #spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             #spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.ss_ddom_new_contract_metrics """)
             spark.sql("""
CREATE TABLE b2b.ss_ddom_new_contract_metrics AS
with team_seat_provisioning_temp as (
    select 
        seat.seat_id,
        seat.subscription_account_guid,
        UPPER(seat.product_name) product_name,
		prov.contract_id,
        prov.seat_creation_date,
        prov.seat_cancelled_date
    from b2b.team_seats_by_provisioning prov
	inner join ocf_analytics.dim_seat seat 
	on prov.seat_id = seat.seat_id ),
	
	jem_seat_pivot_mapping as (
	SELECT prov.contract_id,
		prov.seat_id,
		(pivot.gross_new_arr/pivot.gross_new_subs) as seat_level_pivot_arr,
		pivot.subs_offer,
		pivot.cc_segment,
		pivot.cc_segment_offer,
		pivot.cloud_type_filter,
		pivot.promotion,
		pivot.promo_type,
		pivot.product_category,
		pivot.product_name,
		pivot.product_name_description,
		pivot.market_segment,
		pivot.route_to_market,
		pivot.cc_phone_vs_web as phones_vs_web,
		pivot.gtm_acct_segment,
		pivot.offer_type_desc,
		pivot.surface,
		prov.seat_creation_date,
		prov.seat_cancelled_date,
		ROW_NUMBER() OVER(PARTITION BY prov.seat_id ORDER BY TO_DATE(pivot.date_date) asc) as rownum
	FROM team_seat_provisioning_temp prov
	INNER JOIN (
		select 
			subscription_account_guid,
			upper(product_name) as product_name,
			date_date,
			subs_offer,
			cc_segment,
			cc_segment_offer,
			cloud_type_filter,
			promotion,
			promo_type,
			product_category,
			product_name_description,
			market_segment,
			route_to_market,
			cc_phone_vs_web,
			gtm_acct_segment,
			offer_type_desc,
			IF(UPPER(surface.surface) = 'TBD' or ISNULL(surface.surface),'UNKNOWN',surface.surface) surface,
			COALESCE(gross_new_arr_cfx, migrated_to_arr_cfx, renewal_to_arr_cfx, fwk_begin_arr_cfx) as gross_new_arr,
			COALESCE(gross_new_subs, migrated_to, renewal_to, fwk_begin_active) as gross_new_subs,
			ROW_NUMBER() OVER(PARTITION BY subscription_account_guid,product_name ORDER BY TO_DATE(date_date) asc) as rownum
		from csmb.vw_ccm_pivot4_all pivot 
		left outer join b2b.surface_attribution_mapping surface
		on pivot.store_ui = surface.store_ui
		where source_type = 'TM'
		and (gross_new_arr_cfx > 0 or migrated_to_arr_cfx > 0 or renewal_to_arr_cfx > 0 or fwk_begin_arr_cfx > 0)) pivot 
	on pivot.subscription_account_guid = prov.subscription_account_guid 
	and pivot.product_name = prov.product_name 
	and pivot.rownum = 1	)


--INSERT OVERWRITE TABLE b2b.ss_ddom_new_contract_metrics

SELECT 
	contracts.contract_id,
	contracts.contract_type,
	TO_DATE(contracts.contract_created_date) AS contract_created_date,
	
	period.fiscal_yr_and_wk_desc as contract_start_fiscal_week,
    period.fiscal_yr_and_qtr_desc as contract_start_fiscal_quarter,
    period.fiscal_yr_desc as contract_start_fiscal_year,
	period.fiscal_wk_in_qtr as contract_start_wk_in_qtr,
	period.fiscal_wk_in_yr as contract_start_wk_in_yr,
	period.fiscal_qtr_id as contract_start_qtr_id,
    
	curr.fiscal_yr_and_wk_desc as last_week,
	curr.fiscal_yr_and_qtr_desc as current_qtr,
	curr.fiscal_yr_desc as current_yr,
	curr.fiscal_wk_in_qtr as current_wk_in_qtr,
	curr.fiscal_wk_in_yr as current_wk_in_yr,
	curr.fiscal_qtr_id as current_qtr_id,
	
	prev_qtr.p_fiscal_yr_and_qtr_desc as previous_qtr,
	substr(cast(round(curr.fiscal_yr_desc - 1) as string),1,4) as previous_yr,
		
	TO_DATE(contracts.anniversary_date) AS anniversary_date,
	
	countries.geo_code,
	countries.geo_description,
	countries.market_area_code,
	countries.market_area_description AS market_area_description,
	
	pvt.market_segment,
	pvt.route_to_market,
	pvt.product_name,
	pvt.promotion as regular_vs_promotion,	
	pvt.promo_type,
	pvt.product_category,
	pvt.subs_offer,
	pvt.cc_segment,
	pvt.cc_segment_offer,
	pvt.cloud_type_filter,
	pvt.phones_vs_web,
	pvt.gtm_acct_segment,
	pvt.offer_type_desc,
	pvt.product_name_description,
	pvt.surface,
	pvt.seat_creation_date,
	
	seat_period.fiscal_yr_and_wk_desc as seat_start_fiscal_week,
	seat_period.fiscal_yr_and_qtr_desc as seat_start_fiscal_quarter,
    seat_period.fiscal_yr_desc as seat_start_fiscal_year,
	seat_period.fiscal_wk_in_qtr as seat_start_wk_in_qtr,
	seat_period.fiscal_wk_in_yr as seat_start_wk_in_yr,
	seat_period.fiscal_qtr_id as seat_start_qtr_id,
	
	pvt.seat_cancelled_date AS seat_cancel_date,
	
	count(distinct pvt.seat_id) as seats,
	
	sum(pvt.seat_level_pivot_arr) as seat_purchase_arr

-- Contract Dimensional View
FROM (
	select * 
	from ocf_analytics.dim_contract 
	where contract_type != 'DIRECT_INDIVIDUAL') contracts

-- Contract Start Fiscal Weeks/Quarters
INNER JOIN ids_coredata.dim_date period 
on to_date(contracts.contract_created_date) = period.date_date

--last week as current week
cross join (
	Select
		date_key,
		fiscal_yr_desc,
		fiscal_yr_and_qtr_desc,
		fiscal_qtr_id,
		fiscal_yr_and_wk_desc,
		fiscal_wk_in_qtr,
		fiscal_wk_in_yr
    from ids_coredata.dim_date 
    where date_key = regexp_replace(date_sub(current_date(),((cast(date_format(current_date()+1, 'F') as INT)+1)%7)+1),'-','')) curr

--previous quarter
left outer join (
    Select
        fiscal_yr_and_qtr_desc,
        LAG(fiscal_yr_and_qtr_desc,1) over(order by fiscal_yr_and_qtr_desc) p_fiscal_yr_and_qtr_desc
    from ids_coredata.dim_date
    group by 
        fiscal_yr_and_qtr_desc) prev_qtr
on prev_qtr.fiscal_yr_and_qtr_desc = curr.fiscal_yr_and_qtr_desc

-- Geo / Market Area
LEFT OUTER JOIN ids_coredata.dim_country countries 
ON contracts.country_code = countries.country_code_iso2

-- Pivot ARR
LEFT OUTER JOIN jem_seat_pivot_mapping pvt
on pvt.contract_id = contracts.contract_id
and pvt.rownum = 1

-- Seat Creation Start Fiscal Weeks/Quarters
LEFT OUTER JOIN ids_coredata.dim_date seat_period 
on to_date(pvt.seat_creation_date) = seat_period.date_date

group by 
	contracts.contract_id,
	contracts.contract_type,
	TO_DATE(contracts.contract_created_date),
	
	period.fiscal_yr_and_wk_desc,
    period.fiscal_yr_and_qtr_desc,
    period.fiscal_yr_desc,
	period.fiscal_wk_in_qtr,
	period.fiscal_wk_in_yr,
	period.fiscal_qtr_id,
    
	curr.fiscal_yr_and_wk_desc,
	curr.fiscal_yr_and_qtr_desc,
	curr.fiscal_yr_desc,
	curr.fiscal_wk_in_qtr,
	curr.fiscal_wk_in_yr,
	curr.fiscal_qtr_id,
	
	prev_qtr.p_fiscal_yr_and_qtr_desc,
	substr(cast(round(curr.fiscal_yr_desc - 1) as string),1,4),
		
	TO_DATE(contracts.anniversary_date),
	
	countries.geo_code,
	countries.geo_description,
	countries.market_area_code,
	countries.market_area_description,
	
	pvt.market_segment,
	pvt.route_to_market,
	pvt.product_name,
	pvt.promotion,
	pvt.promo_type,
	pvt.product_category,
	pvt.subs_offer,
	pvt.cc_segment,
	pvt.cc_segment_offer,
	pvt.cloud_type_filter,
	pvt.phones_vs_web,
	pvt.gtm_acct_segment,
	pvt.offer_type_desc,
	pvt.product_name_description,
	pvt.surface,
	pvt.seat_creation_date,
	
	seat_period.fiscal_yr_and_wk_desc,
	seat_period.fiscal_yr_and_qtr_desc,
    seat_period.fiscal_yr_desc,
	seat_period.fiscal_wk_in_qtr,
	seat_period.fiscal_wk_in_yr,
	seat_period.fiscal_qtr_id,
	
	pvt.seat_cancelled_date; """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()