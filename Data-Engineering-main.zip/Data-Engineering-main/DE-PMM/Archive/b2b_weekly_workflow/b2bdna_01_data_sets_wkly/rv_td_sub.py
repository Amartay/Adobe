# Databricks notebook source
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

database_host = "10.50.217.133"
database_port = "1433" # update if you use a non-default port
database_name = "REPLICN_ECP"
table = "(select [SUB_STD_NAME_KEY] as [sub_std_name_key], [SUB_NAME] as [sub_name], [PRNT_STD_NAME_KEY] as [prnt_std_name_key], [CREATED_BY] as [created_by], [TAP_INDUSTRY] as [tap_industry], [TAP_INDUSTRY_SRC] as [tap_industry_src], [CITY] as [city], [STATE_REGION] as [state_region], [POSTAL_CODE] as [postal_code], [COUNTRY_CODE] as [country_code], [WEBSITE] as [website], [DUNS_NUM] as [duns_num], [DB_ANNUAL_SALES_USD] as [db_annual_sales_usd], [DB_ANNUAL_SALES_LCL] as [db_annual_sales_lcl], [DB_TOT_EMP_CNT] as [db_tot_emp_cnt], [DB_EMP_CNT] as [db_emp_cnt], [DB_EMP_RANGE] as [db_emp_range], [DB_SIC_1] as [db_sic_1], [DB_NUM_FAMILY_MEMBERS] as [db_num_family_members], [DB_DU_DUNS_NUM] as [db_du_duns_num], [DB_GU_DUNS_NUM] as [db_gu_duns_num], [NAICS_CODE] as [naics_code], [B2B_OR_B2C] as [b2b_or_b2c], cast([TAX_SHELTER_HQ_IND] as int) as [tax_shelter_hq_ind], cast([NAMED_ACT_CVG_IND] as int) as [named_act_cvg_ind], [ORG_ENTITY_ID] as [org_entity_id], [SFDC_ACT_ID] as [sfdc_act_id], [INDUSTRY] as [industry], [SAM_IND] as [sam_ind], [DME_CVG_IND] as [dme_cvg_ind], [SIGN_CVG_IND] as [sign_cvg_ind], [LastModifiedDttm] as [lastmodifieddttm] from REPLICN_ECP.TAP_PROD.RV_TD_SUB) RV_TD_SUB"

user = dbutils.secrets.get(scope="DBX-B2BDNA-APPLICATION", key="ssuser")
password = dbutils.secrets.get(scope="DBX-B2BDNA-APPLICATION", key="sspassword")

url = f"jdbc:sqlserver://{database_host}:{database_port};database={database_name}"
urlSuffix =";authenticationScheme=NTLM;integratedSecurity=true;domain=adobenet;trustServerCertificate=true"
#jdbc:sqlserver://10.50.217.133:1433;database={database_name};authenticationScheme=NTLM;integratedSecurity=true;domain=adobenet;
whole_url = url+urlSuffix
print(whole_url)

# COMMAND ----------

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", whole_url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .option("numPartitions", 25)
    .load()
)

# COMMAND ----------

target_table_name = "b2b.rv_td_sub"
spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
remote_table.write.format('parquet').mode("overwrite").insertInto(target_table_name)
