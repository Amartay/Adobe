# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE
             

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b_stg """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" set mapred.compress.map.output = true """)
             spark.sql(""" set mapred.output.compress= true """)
             spark.sql(""" drop table if exists b2b_stg.stg_enduserid_orgid_mapping """)
             spark.sql(""" create table b2b_stg.stg_enduserid_orgid_mapping  AS
SELECT
org_id,
end_user_id,
end_user_id_arr, 
case
    when rownum=1 then 1
    when (rownum>1 and end_user_id=end_user_id_arr) THEN 1
ELSE rownum END AS drv_rownum 
FROM
(
SELECT
end_user_id,
org_id,
end_user_id_arr,
ROW_NUMBER() OVER(PARTITION BY org_id ORDER BY end_user_id_arr DESC) AS rownum
FROM
(SELECT
stg_lkp.end_user_id,
stg_lkp.org_id,
ent.end_user_id_arr
FROM
	(
	SELECT 
	DISTINCT 
	dim.end_user_id,
	m.org_id
	FROM
	(SELECT DISTINCT org_id   FROM enterprise.fact_cce_membership_count where is_valid='Y' and contract_offer_type='ETLA' 
	UNION ALL
	SELECT DISTINCT org_id    FROM enterprise.fact_dce_membership_count where is_valid='Y' and contract_offer_type='ETLA' 
	) m
	JOIN
	( 
	SELECT
	DISTINCT
	org_id,
	cast(trim(end_user_aaui) as int) as end_user_id
	FROM
	( 
	SELECT 
	DISTINCT 
	org_id,
	end_user_id 
	FROM
	       	(
		SELECT
			DISTINCT
			org_id,
			end_user_id 
		FROM
		(
			SELECT
				org_id,
				end_user_id,
				ROW_NUMBER() OVER(PARTITION BY contract_id ORDER BY end_dttm desc) AS rownum 
			FROM enterprise.scd_contract 
			WHERE end_user_id <>''
			AND end_user_id <>  '<UNKNOWN>'
			AND end_user_id IS NOT NULL
			AND org_id <>'<UNKNOWN>' 
			AND (buying_program='ETLA' OR upper(model)='ALLOCATION') 
		) a where rownum =1 
         	UNION ALL
         	SELECT
		DISTINCT
         	org_id,
         	end_user_id
         	FROM enterprise.dim_org
         	WHERE end_user_id <>''
         	AND end_user_id <>  '<UNKNOWN>'
         	AND end_user_id IS NOT NULL
         	AND org_id <>'<UNKNOWN>'
        	) a
    	) b LATERAL VIEW explode (split(end_user_id,',')) id AS end_user_aaui
    	) dim
	ON m.org_id = dim.org_id
	) stg_lkp
LEFT JOIN
	(
	SELECT 
	DISTINCT 
	cast(end_user AS int) AS end_user_id_arr
    	FROM enterprise.ca_ent_arr_model_all
    	WHERE
    	date_date>=date_sub('{RUN_DATE}',90) and date_date<='{RUN_DATE}'
    	AND snapshot_type='W'
	) ent
on stg_lkp.end_user_id=ent.end_user_id_arr
   ) rn
) drv_rn """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" use b2b_stg """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" drop table if exists b2b_stg.enduserid_orgid_mapping """)
             spark.sql(""" create table b2b_stg.enduserid_orgid_mapping  AS
SELECT
DISTINCT
lkp.org_id,
lkp.end_user_id,
CASE WHEN lkp.end_user_id=ent.end_user_id_arr THEN 'Y' ELSE 'N' END AS active_flag
FROM
(
        SELECT
        DISTINCT
        org_id,
        cast(end_user_id as STRING) as end_user_id
        FROM b2b_stg.stg_enduserid_orgid_mapping
        WHERE drv_rownum=1
        UNION ALL
        SELECT
        DISTINCT
        a.org_id,
        cast(a.end_user_id as STRING) as end_user_id
        FROM b2b_stg.stg_enduserid_orgid_mapping a
        JOIN
        (
        SELECT
        DISTINCT
        org_id
        FROM
        b2b_stg.stg_enduserid_orgid_mapping
        WHERE drv_rownum=1 and end_user_id_arr IS NULL
        ) b
        ON a.org_id=b.org_id
        WHERE a.drv_rownum>1
) lkp
LEFT JOIN
	(
	SELECT 
	DISTINCT 
	cast(end_user AS int) AS end_user_id_arr
    	FROM enterprise.ca_ent_arr_model_all
    	WHERE
    	date_date>=date_sub('{RUN_DATE}',90) and date_date<='{RUN_DATE}'
    	AND snapshot_type='W'
	) ent
on lkp.end_user_id=ent.end_user_id_arr
WHERE lkp.end_user_id is not null """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.enduserid_orgid_mapping
SELECT
DISTINCT
a.org_id,
cast(a.end_user_id as int),
a.active_flag
FROM
b2b_stg.enduserid_orgid_mapping a
LEFT JOIN
(select distinct org_id from b2b_stg.enduserid_orgid_mapping where end_user_id='2000000') b
on a.org_id=b.org_id
where b.org_id is null """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()