from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys


class main():
    def __init__(self):
        try:
            spark = SparkSession.builder \
                .enableHiveSupport() \
                .config('hive.exec.dynamic.partition', 'true') \
                .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                .config('hive.exec.max.dynamic.partitions', '10000') \
                .getOrCreate()
            log4j = spark._jvm.org.apache.log4j
            log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
            spark.sql('SET hive.warehouse.data.skiptrash=true;')
            spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
            spark.conf.set('spark.sql.cbo.enabled', True)
            spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
            spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
            spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
            spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            spark.sql("set spark.sql.adaptive.enabled=false")

            dbutils.widgets.text("Custom_Settings", "")
            dbutils.widgets.text("RUN_DATE", "")
            dbutils.widgets.text("TODAY_DATE", "")

            Settings = dbutils.widgets.get("Custom_Settings")
            RUN_DATE = dbutils.widgets.get("RUN_DATE")
            TODAY_DATE = dbutils.widgets.get("TODAY_DATE")
            B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
            RUN_DATE = B2B_RUN_DATE

            Set_list = Settings.split(',')
            if len(Set_list) > 0:
                for i in Set_list:
                    if i != "":
                        print("spark.sql(+i+)")
                        spark.sql("""{i}""".format(i=i))

            spark.sql(""" SET hive.exec.parallel=true """)
            spark.sql(""" set hive.exec.reducers.max=50 """)
            spark.sql(""" set hive.exec.reducers.bytes.per.reducer=1000000 """)
            spark.sql(""" set hive.optimize.distinct.rewrite=true """)
            spark.sql(""" set hive.map.aggr=true """)
            spark.sql(""" SET hive.exec.Compress.intermediate=true """)
            spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
            spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
            spark.sql(""" SET hive.vectorized.execution.enabled = true """)
            spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
            spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
            spark.sql(""" SET hive.auto.convert.join=true """)
            spark.sql(""" SET hive.merge.mapfiles=true """)
            spark.sql(""" SET hive.merge.mapredfiles=true """)
            spark.sql(""" SET hive.merge.size.per.task=512000000 """)
            spark.sql(""" SET hive.merge.smallfiles.avgsize=512000000 """)
            spark.sql(""" SET hive.optimize.sort.dynamic.partition=false """)
            spark.sql(""" SET hive.exec.compress.output=true """)
            spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
            spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
            spark.sql(""" SET hive.stats.autogather=true """)
            spark.sql(""" set hive.cbo.enable=true """)
            spark.sql(""" set hive.compute.query.using.stats=true """)
            spark.sql(""" set hive.stats.fetch.column.stats=true """)
            spark.sql(""" set hive.stats.fetch.partition.stats=true """)
            spark.sql(""" SET hive.exec.dynamic.partition=true """)
            spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
            spark.sql(""" set hive.exec.dynamic.partition=true """)
            spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
            spark.sql(""" set hive.support.concurrency = false """)
            spark.sql(""" set hive.mapred.mode=nonstrict """)
            spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)

            spark.sql(
                """ CREATE OR REPLACE TEMP FUNCTION ORIGINAL as 'acom.adobe.com.hiveUdfs.LKP_ORIGINAL_ID' USING JAR 'abfs://artifacts@ariaprime.dfs.core.windows.net/common_artifacts/hiveUdfs-0.0.1-SNAPSHOT-jar-with-dependencies.jar' """)

            # spark.sql(""" msck repair table genai.firefly_high_value_events """)
            # spark.sql(""" refresh table genai.firefly_high_value_events """)
            spark.sql(''' refresh table genai_silver.firefly_high_value_events ''')
            spark.sql(""" INSERT OVERWRITE TABLE b2b.b2b_fact_user_activity partition (month,year,monthkey)
SELECT DISTINCT ua.event_category,
                ua.source_name,
                usrs.member_guid,
                ua.event_guid,
                cast(ua.event_date as date),
                CASE
                    WHEN ua.event_category = 'MOBILE'
                         AND ua.source_name = 'READER' THEN 'ACROBAT READER MOBILE'
                    WHEN ua.source_name = 'LIGHTROOM DESKTOP' THEN 'LIGHTROOM CC'
                    WHEN ua.event_category = 'MOBILE'
                         AND ua.source_name = 'LIGHTROOM' THEN 'LIGHTROOM MOBILE'
                    WHEN ua.event_category = 'MOBILE'
                         AND ua.source_name = 'PHOTOSHOP' THEN 'UNKNOWN'
                    WHEN ua.event_category = 'MOBILE'
                         AND ua.source_name = 'PREMIERE RUSH' THEN 'PREMIERE RUSH MOBILE'
                    WHEN ua.event_category = 'MOBILE'
                         AND ua.source_name = 'SCAN' THEN 'SCAN MOBILE'
                    WHEN ua.event_category = 'MOBILE'
                         AND ua.source_name = 'ILLUSTRATOR' THEN 'ILLUSTRATOR MOBILE'
                    WHEN ua.source_name = 'SUBSTANCE SOURCE' THEN 'SUBSTANCE SOURCE DL'
                    WHEN ua.source_name = 'FF_PS' THEN 'FIREFLY_PS' -- updated on 08/29 for B2BDME-4304
                    WHEN ua.source_name = 'FF_AI' THEN 'FIREFLY_AI' -- updated on 08/29 for B2BDME-4304
                    WHEN ua.source_name = 'FF_AX' THEN 'FIREFLY_AX' -- updated on 08/29 for B2BDME-4304
                    WHEN ua.source_name = 'FF_WEB' THEN 'FIREFLY_WEB' -- updated on 08/29 for B2BDME-4304
                    ELSE ua.source_name
                END AS app_name,
                MONTH(ua.event_date) AS MONTH,
                year(ua.event_date) AS YEAR,
                SUBSTRING(ua.event_date,
                          1,
                          7) AS monthkey
FROM 
  (SELECT DISTINCT member_guid
   FROM b2b.b2b_users
   WHERE as_of_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1) ) usrs
JOIN
  (SELECT DISTINCT event_category,
                   member_guid AS event_guid, 
 CASE
     WHEN act.member_guid=t2e.auth_id THEN t2e.profile_id
     ELSE act.member_guid
 END AS member_guid,
 event_date,
 source_name
   FROM
     ( 
 SELECT DISTINCT fua.event_category,
                 fua.member_guid,
                 fua.event_date,
                 fua.source_name
      FROM
        (SELECT DISTINCT CONCAT('FUA_',mp.category) AS event_category,
                         fuat.member_guid,
                         fuat.partition_date AS event_date,
                         mp.product AS source_name
         FROM ocf_analytics.fact_user_activity fuat
         JOIN b2b.ent_product_map_cce mp ON UPPER(mp.product_code) = UPPER(fuat.product)
         AND UPPER(mp.category_code) = UPPER(fuat.category)
         WHERE fuat.partition_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
           AND UPPER(mp.product) NOT LIKE '%SPARK%'
           AND mp.category != 'EXCLUDE' ) fua 
      LEFT JOIN
        (SELECT DISTINCT source_name,
                         event_date,
                         member_guid
         --FROM dms.user_activity
         FROM dms_hybrid.user_activity -- updated in 08/30
         WHERE event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1) ) dme 
         ON dme.source_name=fua.source_name
      AND dme.event_date=fua.event_date
      AND dme.member_guid=fua.member_guid
      WHERE dme.member_guid IS NULL 
      UNION ALL
      SELECT DISTINCT UPPER(event_category) AS event_category,
                                member_guid,
                                event_date,
                                source_name
      --FROM dms.user_activity
      FROM dms_hybrid.user_activity -- updated in 08/30
      WHERE event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      UNION ALL 
 SELECT DISTINCT 'SERVICE' AS event_category,
                 UPPER(userguid) AS member_guid,
                 event_date,
                 'SUBSTANCE SOURCE' AS source_name
      FROM darwin_max.ets_subsource_service_events
      WHERE upper(params['event.workflow'])='DOWNLOAD'
        AND event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      UNION ALL 
      SELECT DISTINCT 'DESKTOP' AS event_category,
                                UPPER(split(pguid,'@')[0]) AS member_guid,
                                substr(sessiontime, 1, 10) AS event_date,
                                'SUBSTANCE STAGER' AS source_name
      --FROM b2b_stg.cc_felixstar_session
      FROM cc_felixstar.session
      WHERE substr(sessiontime, 1, 10) >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      UNION ALL
      SELECT DISTINCT 'DESKTOP' AS event_category,
                                UPPER(userguid) AS member_guid,
                                event_date,
                                'SUBSTANCE PAINTER' AS source_name
      FROM darwin_max.ets_painter_service_events
      WHERE event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      UNION ALL 
      SELECT DISTINCT 'DESKTOP' AS event_category,
                                UPPER(userguid) AS member_guid,
                                event_date,
                                'SUBSTANCE SAMPLER' AS source_name
      FROM darwin_max.ets_alchemist_service_events
      WHERE event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      UNION ALL 
      SELECT DISTINCT 'DESKTOP' AS event_category,
                                UPPER(userguid) AS member_guid,
                                event_date,
                                'SUBSTANCE DESIGNER' AS source_name
      FROM darwin_max.ets_designer_service_events
      WHERE event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      UNION ALL
      SELECT DISTINCT 'DESKTOP' AS event_category,
                                UPPER(userguid) AS member_guid,
                                event_date,
                                'SUBSTANCE MODELER' AS source_name
      FROM darwin_max.ets_modeler_service_events
      WHERE event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      UNION ALL 
      SELECT DISTINCT 'SERVICE' AS event_category,
                                c.member_guid,
                                b.event_date,
                                'SPARK' AS source_name
      FROM spark.spark_active_users_b b
      JOIN
        (SELECT DISTINCT user_guid,
                         original_guid AS member_guid
         FROM spark.spark_user_guid_map) c ON b.user_guid=c.user_guid
      WHERE b.event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1) 

      -- Added on 08/24 for B2BDME-4283 -- START
      UNION ALL
      SELECT DISTINCT
         'SERVICE' as event_category,
         UPPER(ORIGINAL(event_user_guid,'guid')) as member_guid,
         event_date,
         'SPARK' as source_name
      FROM  ccex.ccex_active_users_b
      WHERE event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      AND event_user_guid NOT LIKE '%-%'
      -- Added on 08/24 for B2BDME-4283 -- END

      -- Added on 08/24 for B2BDME-4304 -- START
      UNION ALL

      SELECT DISTINCT
            'SERVICE' AS event_category,
            member_guid,
            event_date,
            CASE 
                WHEN event_stream = 'FIREFLY_EXP__GENERATE_OR_APPLY' THEN 'FF_AX'
                WHEN event_stream = 'FIREFLY_ILST__RECOLOR' THEN 'FF_AI'
                WHEN event_stream = 'FIREFLY_PSD__GENERATIVE_FILL' THEN 'FF_PS'
                WHEN event_stream LIKE 'FIREFLY_WEB__%' THEN 'FF_WEB'
            END AS source_name
      --FROM genai.firefly_high_value_events
      FROM genai_silver.firefly_high_value_events
      WHERE event_date >= date_add(last_day(add_months('{RUN_DATE}', -2)),1)
      AND event_type IN ('cdn','click','error','generate','info','request','response','success')
      AND event_subtype IN ('feedback','firefly-examples','generate','generate-cancelled','generate-from-recording','generative-ai-agreement','generative-fill','image','indemnify','ok','report','select-variation','text-effects')
      AND member_guid NOT LIKE '%-%'
      -- Added on 08/24 for B2BDME-4304 -- END

      ) act 
   LEFT JOIN
     (SELECT DISTINCT member_guid AS profile_id,
                      auth_id
      FROM b2b.b2b_users
      WHERE as_of_date = '{RUN_DATE}') t2e ON act.member_guid = t2e.auth_id) ua 
 ON usrs.member_guid=ua.member_guid """.format(RUN_DATE=RUN_DATE))
            spark.sql(""" delete from b2b_stg.b2b_table_audit_log where Table_name='b2b_fact_user_activity' """)
            spark.sql(
                """ INSERT INTO b2b_stg.b2b_table_audit_log VALUES ('b2b_fact_user_activity', 'b2b',CAST('{RUN_DATE}' as date),CAST('{TODAY_DATE}' as date)) """.format(
                    RUN_DATE=RUN_DATE, TODAY_DATE=TODAY_DATE))

            try:
                dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                print("exception:", e)
        except Exception as e:
            dbutils.notebook.exit(e)


if __name__ == '__main__':
    main()