# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")
             dbutils.widgets.text("TODAY_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             TODAY_DATE = dbutils.widgets.get("TODAY_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE
             
             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.b2b_arr  partition(as_of_date)
WITH org_map AS
(
SELECT 
distinct 
ech_parent_id,
ech_parent_name,
ech_parent_country_code,
ech_sub_id,
ech_sub_name,
ech_sub_country_code,
dme_acct_segment,
ech_parent_industry,
ech_sub_industry,
ech_parent_annual_sales_usd,
ech_sub_annual_sales_usd,
ech_sub_tot_emp_cont,
ech_parent_tot_emp_cont,
end_user_id,    
--mm_flag,
fy24_sops_segment,
dense_rank() over (partition by ech_parent_id, ech_parent_name, ech_parent_country_code, ech_sub_id, ech_sub_name, ech_sub_country_code, dme_acct_segment
, ech_parent_industry, ech_sub_industry, ech_parent_annual_sales_usd, ech_sub_annual_sales_usd, ech_sub_tot_emp_cont, ech_parent_tot_emp_cont, end_user_id 
order by named_flag desc) rnk
FROM b2b.ecp_ecc_org_map
WHERE as_of_date='{RUN_DATE}' 
),
cntry AS
(
SELECT 
DISTINCT 
geo_code,
market_area_code,
region_code,
country_code_iso2
FROM ids_coredata.dim_country
),



arr AS
(
SELECT 
"SIGN_ARIA" AS contract_type,
regexp_replace(arr.billingid,'^0+(?!$)','') AS contract_key,
"NONE" AS crm_customer_guid,
salesdocument AS sales_document,
"NONE" AS route_to_market,
plancategory AS entitlement_type,
marketsegment AS market_segment,
arr.salesdistrictdescription AS sales_district,
market_area_code AS market_area,
geo_code AS geo,
region_code AS region,
"NONE" AS product_config,
"SIGN_ARIA" AS product_name,
"SIGN_ARIA" AS product_name_description,
"NONE" AS cc_phone_vs_web,
materialnumber AS material_number,
"NONE" AS material_number_description,
"NONE" AS subscription_account_guid,
min(contractstartdate)contract_start_date,
max(contractenddate)contract_end_date,
"NONE" AS vip_contract,
regexp_replace(arr.billingid,'^0+(?!$)','') AS end_user_id,
"NONE" AS store_ui,
"NONE" AS subs_offer,
"SIGN" AS cc_segment,
"NONE" AS cc_segment_offer, 
accountname AS end_user_name, 
"ARIA" AS etla_seat_type,
"SIGN" AS olpg,
SUM(try_cast(totalarr AS DECIMAL(20,0))) AS fwk_end_arr, 
SUM(try_cast (totalendingquantity AS INT)) AS contract_quantity,
"NONE" AS material_metric,
"NONE" AS arr_type,
"NONE" AS arr_exclusion,
"NONE" AS sales_document_type,
snapshotdate AS date_date
FROM b2b.uda_vw_tf_adobesignconsolidatedarr arr 
LEFT JOIN cntry cnt 
ON cnt.country_code_iso2 = arr.accountcountry
WHERE snapshotdate='{RUN_DATE}'
AND udadatasource = 'SIGN_ARIA'
AND etlatype = 'Standalone'
GROUP BY 
regexp_replace(arr.billingid,'^0+(?!$)',''),
salesdocument,
plancategory,
marketsegment,
salesdistrictdescription,
market_area_code,
geo_code,
region_code,
materialnumber, 
accountname,
arr.snapshotdate
), 


pvt AS
(
SELECT 
CASE
    WHEN STYPE = 'TM' AND pivot.vip_contract != '' AND UPPER(product_config) LIKE '%E' THEN 'EVIP'
    WHEN STYPE = 'TM' AND cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
    WHEN STYPE = 'TM' AND route_to_market= 'RESELLER' THEN 'VIP'
    WHEN STYPE = 'TM' AND route_to_market = 'ADOBE.COM/CC.COM' AND cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
    ELSE 'UNKNOWN'
END AS contract_type,
lic.contract_id AS contract_key,
crm_customer_guid,
sales_document,
route_to_market,
entitlement_type,
market_segment,
sales_district,
market_area,
geo,
region,
product_config,
product_name,
product_name_description,
cc_phone_vs_web,
material_number,
"NONE" AS material_number_description,
pivot.subscription_account_guid,
min(concat((substr(contract_start_date_veda,1,4)),'-',(substr(contract_start_date_veda,6,2)),'-',(substr(contract_start_date_veda,9,2)))) as contract_start_date,
max(concat((substr(contract_end_date_veda,1,4)),'-',(substr(contract_end_date_veda,6,2)),'-',(substr(contract_end_date_veda,9,2)))) as contract_end_date,
pivot.vip_contract,
regexp_replace(ecc_customer_id,'^0+(?!$)','') AS end_user_id,
store_ui,
subs_offer,
cc_segment,
cc_segment_offer,
acct_name AS end_user_name,
"NONE" AS etla_seat_type,
p2.olpg,
--cc_segment AS olpg, 
SUM(try_cast(fwk_end_arr AS DECIMAL(20,0))) AS fwk_end_arr,
SUM(fwk_end_active) AS contract_quantity,
material_metric,
"NONE" AS arr_type,
"NONE" AS arr_exclusion,
sales_document_type,
date_date
FROM csmb.vw_ccm_pivot4_all pivot
left join (select distinct contract_id,subscription_account_guid from ocf_analytics.scd_license) lic 
on pivot.subscription_account_guid = lic.subscription_account_guid
left join (
select
distinct outlookproductgroup as olpg,
productcode,
dense_rank() over (partition by productcode order by systemmodstamp desc) rnk
from
b2b.uda_replicn_sf_corp_uda_vw_product2
) p2 
on pivot.product_name = p2.productcode
and p2.rnk = 1 
WHERE date_date='{RUN_DATE}'
AND event_source = 'SNAPSHOT'
AND STYPE = 'TM'
GROUP BY 
CASE
	WHEN STYPE = 'TM' AND pivot.vip_contract != '' AND upper(product_config) LIKE '%E' THEN 'EVIP'
	WHEN STYPE = 'TM' AND cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
	WHEN STYPE = 'TM' AND route_to_market= 'RESELLER' THEN 'VIP'
	WHEN STYPE = 'TM' AND route_to_market = 'ADOBE.COM/CC.COM' AND cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
	ELSE 'UNKNOWN'
END,
lic.contract_id,
crm_customer_guid,
sales_document,
route_to_market,
entitlement_type,
market_segment,
sales_district,
market_area,
geo,
region,
product_config,
product_name,
product_name_description,
cc_phone_vs_web,
material_number,
pivot.subscription_account_guid,
pivot.vip_contract,
regexp_replace(ecc_customer_id,'^0+(?!$)',''),
store_ui,
subs_offer,
cc_segment,
cc_segment_offer,
acct_name,
p2.olpg,
material_metric,
sales_document_type,
date_date
), 


model_arr AS
(
SELECT 
CASE
	WHEN olpg = 'SIGN' AND businesstype != 'ETLA' AND etlaseattype LIKE '%ETLA%' THEN 'ETLA'
	WHEN olpg = 'SIGN' AND businesstype = 'SIGN' THEN 'SIGN_SAP_SA'
	ELSE businesstype
END AS contract_type,
regexp_replace(enduser,'^0+(?!$)','') AS contract_key,
"NONE" AS crm_customer_guid,
salesdocument AS sales_document,
sellinchanneldesc AS route_to_market,
"NONE" AS entitlement_type,
marketsegment AS market_segment,
salesdistrict AS sales_district,
marketarea AS market_area,
geo,
region,
productconfig AS product_config,
productname AS product_name,
productnamedescription AS productname_description,
"NONE" AS cc_phone_vs_web,
materialnumber AS material_number,
materialnumberdescription as material_number_description,
"NONE" AS subscription_account_guid,
MIN(contractstartdate)contract_start_date,
MAX(contractenddate)contract_end_date,
"NONE" AS vip_contract,
regexp_replace(enduser,'^0+(?!$)','') AS end_user_id,
"NONE" AS store_ui,
"NONE" AS subs_offer,
olpg AS cc_segment,
"NONE" AS cc_segment_offer,
arr.endusername AS end_user_name,
etlaseattype AS etla_seat_type,
olpg,
SUM(try_cast(arr AS DECIMAL(20,0))) AS fwk_end_arr,
SUM (try_cast (contractquantity AS INT)) AS contract_quantity,
"NONE" AS material_metric,
arrtype AS arr_type,
arrexclusion AS arr_exclusion,
salesdocumenttype AS sales_document_type,
datedate
FROM b2b.uda_uda_finance_arr_vw_entarr arr 
WHERE datedate= '{RUN_DATE}'
AND snapshottype ='W'
AND olpg  NOT IN ('PPBU','CAPTIVATE PRIME','OTHER','DPS','CONNECT','DALP','UNMAPPED') -- Added on 2023-10-20 Jira B2BDME-5144
AND upper(endusername) NOT LIKE '%FULFILLMENT%FEE%ARR%'
AND upper(endusername) NOT LIKE'%BANK%OLITA%'
AND arrtype IN ('BILLED', 'PRE_BILLED', 'LAB_ARR', 'MANUAL')
GROUP BY 
CASE
	WHEN olpg = 'SIGN' AND businesstype != 'ETLA' AND etlaseattype LIKE '%ETLA%' THEN 'ETLA'
	WHEN olpg = 'SIGN' AND businesstype = 'SIGN' THEN 'SIGN_SAP_SA'
	ELSE businesstype
END,
salesdocument,
sellinchanneldesc,
arrtype,
arrexclusion,
marketsegment,
salesdistrict,
marketarea,
geo,
region,
productconfig,
productname,
productnamedescription,
materialnumber,
materialnumberdescription,
regexp_replace(enduser,'^0+(?!$)',''),
olpg,
arr.endusername,
etlaseattype,
olpg,
salesdocumenttype,
datedate
),


fnl AS
(
SELECT * FROM arr
UNION ALL 
SELECT * FROM pvt
UNION ALL SELECT * FROM model_arr
),

fnl_grp AS
(
SELECT * FROM fnl
GROUP BY 
contract_type,
contract_key,
crm_customer_guid,
sales_document,
route_to_market,
entitlement_type,
market_segment,
sales_district,
market_area,
geo,
region,
product_config,
product_name,
product_name_description,
cc_phone_vs_web,
material_number,
material_number_description,
subscription_account_guid,
contract_start_date,
contract_end_date,
vip_contract,
end_user_id,
store_ui,
subs_offer,
cc_segment,
cc_segment_offer,
end_user_name,
etla_seat_type,
olpg,
fwk_end_arr,
contract_quantity,
material_metric,
arr_type,
arr_exclusion,
sales_document_type,
date_date
)
SELECT   
ech_parent_id           ,
ech_parent_name         ,
ech_parent_country_code ,
ech_sub_id              ,
ech_sub_name            ,
cast(ech_sub_country_code as STRING) as ech_sub_country_code,
ech_parent_annual_sales_usd     ,
ech_parent_tot_emp_cont ,
ech_parent_industry     ,
ech_sub_annual_sales_usd        ,
ech_sub_tot_emp_cont    ,
ech_sub_industry        ,
dme_acct_segment        ,
product_segment         ,
lic_type                ,
contract_type           ,
contract_key            ,
crm_customer_guid       ,
cast(sales_document as bigint) as sales_document,
route_to_market         ,
entitlement_type        ,
market_segment          ,
sales_district          ,
market_area             ,
geo                     ,
region                  ,
product_config          ,
product_name            ,
product_name_description        ,
cc_phone_vs_web         ,
cast(material_number as bigint) as material_number,
material_number_description     ,
subscription_account_guid       ,
cast(contract_start_date as date) as contract_start_date,
cast(contract_end_date as date) as contract_end_date,
vip_contract            ,
cast(end_user_id as int) as end_user_id,
store_ui                ,
subs_offer              ,
cc_segment              ,
cc_segment_offer        ,
end_user_name           ,
etla_seat_type          ,
olpg                    ,
fwk_end_arr             ,
contract_quantity       ,
material_metric         ,
arr_type                ,
arr_exclusion           ,
sales_document_type     ,
mm_flag,
offering_type, 
ff_sku,
cc_pro,
sops_segment,
cast(as_of_date as date) as_of_date
from (
SELECT 
b2barr.*,
CASE
	WHEN product_segment = 'OTHER' THEN 'OTHER'
	WHEN upper(product_name_description) like 'ACRO%PRO%' THEN 'ACRO PRO'
	WHEN upper(product_name_description) like 'DOC%PRO%' THEN 'ACRO PRO'
	WHEN upper(product_name_description) like 'ACRO%STD%' THEN 'ACRO STD'
	WHEN upper(product_name_description) like 'DOC%STD%' THEN 'ACRO STD'
	WHEN product_name = 'ACRO' THEN 'ACRO STD'
	WHEN product_name IN ('CCLE','CCSV','CAUS','CCSB','CPFF','CAUP') THEN 'ALL_APPS' 
  -- B2BDME-4556 Added on 2023-09-11 for  CC Pro AA Firefly(CPFF)--Added CAUP in when condition on 2023-10-17 Jira B2BDME-4954
  --WHEN (upper(product_name_description) LIKE %ADOBE%EXPRESS% OR upper(product_name_description) LIKE '%ADOBE%SPARK%') THEN 'AX' --B2BDME-3725 Added on 2023-09-11
  --WHEN upper(product_name_description) LIKE '%CC%PRO%FIREFLY%' THEN 'FIREFLY' --B2BDME-3725 Added on 2023-09-11 
  WHEN product_name IN ('AEFF','ASPK','CCEX') THEN 'AX' --B2BDME-4556 Added on 2023-09-11
  WHEN product_name IN ('CPSF') THEN 'SINGLE_APP' --B2BDME-4556 Added on 2023-09-11 
	WHEN product_segment = 'SIGN' THEN 'SIGN'
	WHEN product_name = 'CTSK' THEN 'STOCK'
	WHEN product_segment = 'STOCK' THEN 'STOCK'
	WHEN product_segment = 'SUBSTANCE' THEN 'SUBST'
  ELSE 'SINGLE_APP'
END AS offering_type
FROM
(
	SELECT 
	ech_parent_id,
    ech_parent_name,
    ech_parent_country_code,
    ech_sub_id,
    ech_sub_name,
    ech_sub_country_code,
    ech_parent_industry,
    ech_sub_industry,
    ech_parent_annual_sales_usd,
    ech_sub_annual_sales_usd,
    ech_sub_tot_emp_cont,
    ech_parent_tot_emp_cont,
    'NA' AS mm_flag,
    --mm_flag,
    --CASE
    --    WHEN dme_acct_segment = 'ENT' THEN 'ENT'
    --    WHEN mm_flag = 'Y' THEN 'MM'
    --    WHEN contract_type = 'SIGN_ARIA' AND region = 'NAM' THEN 'MM'
    --    ELSE 'SMB'
    --END AS dme_acct_segment,
    CASE
    WHEN m.dme_acct_segment is null THEN 'SMB'
    ELSE m.dme_acct_segment
    END AS dme_acct_segment,
    CASE
		WHEN product_name IN ('CCAS','CCPS','CPDF','AIS','DAMC','DPS','WKF3','DCPS','SUPPORT PLAN ACROBAT','SUPPORT PLAN CC') THEN 'OTHER'
		WHEN product_name='CTSK' THEN 'STOCK'
		WHEN (product_name_description LIKE '%- Pro%' OR product_name IN ('CPSF','CPFF')) THEN 'CC'  -- B2BDME-4556 to include CC Pro SA Firefly,CC Pro AA Firefly under CC
    WHEN product_name IN ('CCEX','ASPK','AEFF') THEN 'AX'   -- B2BDME-4556 to include Adobe Express,Adobe Spark,AdobeExpress Firefly under AX
    WHEN product_name IN ('SBST','SRC','SBTX') OR olpg IN ('SUBSTANCE') THEN 'SUBSTANCE'
		WHEN product_name = 'CCLE' THEN 'CC'
		WHEN olpg IN ('ACROBAT','ACROBAT DC','DCE','ACROBAT CC') THEN 'ACROBAT'
		WHEN product_name = 'CCLE' THEN 'CC'
		WHEN olpg IN ('CREATIVE','FRAME.IO','EXPRESS','CC AEM','CC WKFT','CCE PRO PLUS') THEN 'CC'
		WHEN olpg IN ('SIGN','DCE TRANSACTION') THEN 'SIGN'
		WHEN olpg IN ('HED','TEAM') THEN 'CC'
		WHEN UPPER (product_name_description) LIKE '%STOCK%' THEN 'STOCK'
		WHEN UPPER (product_name_description) LIKE '%SINGLE%APP%' THEN 'CC'
		ELSE 'UNKNOWN'
	END AS product_segment, 
  CASE 
    WHEN product_name in ('AEFF','CPSF','CPFF') THEN 'YES'
    --WHEN product_name in ('CCEX','ASPK') THEN 'NO'
    ELSE 'NO' 
  END AS ff_sku,  --B2BDME-4556 Added on 2023-09-11 for a new column
	CASE
		WHEN olpg = 'CCE STOCK' then 'PRO'
		WHEN product_name_description LIKE '%- Pro%' THEN 'PRO'
        WHEN upper(product_name_description) LIKE '%PRO%PLUS%' THEN 'PRO PLUS' -- Added on 2023-10-09 Jira B2BDME-4883
		ELSE 'NO'
	END AS cc_pro, 
    CASE
        WHEN product_config = 'FRLMG' THEN 'FRL'
        WHEN UPPER(material_number_description) LIKE '%SHARED%DEVICE%LICENSE%' THEN 'SDL'
        WHEN olpg IN ('SIGN','DCE TRANSACTION') THEN 'SVCS'
        WHEN product_name_description LIKE '%- Pro%' THEN 'NUL'
        WHEN UPPER(product_name_description) LIKE '%CCT%STOCK%' THEN 'NUL'
        WHEN olpg = 'STOCK' THEN 'SVCS'
        ELSE 'NUL'
    END AS lic_type,
    CASE
        WHEN upper(dimc.buying_program) = 'VIPMP' THEN dimc.buying_program
        ELSE all.contract_type
    END AS contract_type,
    contract_key,
    crm_customer_guid,
    sales_document,
    route_to_market,
    entitlement_type,
    market_segment,
    sales_district,
    market_area,
    geo,
    region,
    product_config,
    product_name,
    product_name_description,
    cc_phone_vs_web,
    material_number,
    material_number_description,
    all.subscription_account_guid,
    cast(contract_start_date as date),
    cast(contract_end_date as date),
    vip_contract,
    all.end_user_id,
    store_ui,
    subs_offer,
    cc_segment,
    cc_segment_offer,
    end_user_name,
    etla_seat_type,
    olpg,
    fwk_end_arr,
    contract_quantity,
    material_metric,
    arr_type,
    arr_exclusion,
    sales_document_type,
    fy24_sops_segment as sops_segment,
    date_date AS as_of_date
	FROM fnl_grp all
	LEFT JOIN org_map m 
	ON m.end_user_id = all.end_user_id
  and m.rnk = 1
  LEFT JOIN (select contract_id, buying_program from enterprise.dim_contract WHERE buying_program <> '<UNKNOWN>') dimc
	on dimc.contract_id = all.contract_key
) b2barr )""".format(RUN_DATE = RUN_DATE))
             
             pivot4_all= spark.sql(''' 
                                   SELECT 
as_of_date,
SUM(try_cast(fwk_end_arr AS DECIMAL(20,0))) AS fwk_end_arr
FROM b2b.b2b_arr
WHERE as_of_date in ('{B2B_RUN_DATE}',date_sub('{B2B_RUN_DATE}',7))
GROUP BY
as_of_date
order by 1
                                    '''.format(B2B_RUN_DATE= B2B_RUN_DATE))
             display(pivot4_all)
             df_pandas = pivot4_all.select(pivot4_all.columns[1:]).toPandas()
             df_pandas.diff()

             df_pandas['WoWEfwk_end_arr'] = np.round(df_pandas['fwk_end_arr'].astype('float').pct_change() * 100,2)

             df_pandas = df_pandas.dropna()
             final_df = df_pandas.iloc[:, 1:]
             display(final_df)

             diff = final_df['WoWEfwk_end_arr'].iloc[0]
             if diff > 10 or diff < -10:
               dbutils.notebook.exit('WoW arr value is exceeding +-10%')
             else:
               pass
             
             spark.sql(""" delete from b2b_stg.b2b_table_audit_log where Table_name='b2b_arr' """)
             spark.sql(""" INSERT INTO b2b_stg.b2b_table_audit_log VALUES ('b2b_arr', 'b2b',CAST('{RUN_DATE}' as date),CAST('{TODAY_DATE}' as date)) """.format(RUN_DATE = RUN_DATE,TODAY_DATE = TODAY_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()
