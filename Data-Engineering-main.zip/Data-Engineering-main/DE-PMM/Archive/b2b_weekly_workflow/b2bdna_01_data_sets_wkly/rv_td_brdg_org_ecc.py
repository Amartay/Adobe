# Databricks notebook source
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

database_host = "10.50.217.133"
database_port = "1433" # update if you use a non-default port
database_name = "REPLICN_ECP"
table = "(select [ECC_ID] as [ecc_id], [PRNT_STD_NAME_KEY] as [prnt_std_name_key], [SUB_STD_NAME_KEY] as [sub_std_name_key], [CHILD_KEY] as [child_key], [GRADE] as [grade], [VERIFIED_BY] as [verified_by], [ORG_ENTITY_ID] as [org_entity_id], [T2_ORG_ENTITY_ID] as [t2_org_entity_id], [T1_ORG_ENTITY_ID] as [t1_org_entity_id], [T_ORG_ENTITY_ID] as [t_org_entity_id], [SFDC_OVERWRITE_IND] as [sfdc_overwrite_ind], [CUST_MAP_IND] as [cust_map_ind], [LastModifiedDttm] as [lastmodifieddttm] from REPLICN_ECP.TAP_PROD.RV_TD_BRDG_ORG_ECC) RV_TD_BRDG_ORG_ECC"

user = dbutils.secrets.get(scope="DBX-B2BDNA-APPLICATION", key="ssuser")
password = dbutils.secrets.get(scope="DBX-B2BDNA-APPLICATION", key="sspassword")

url = f"jdbc:sqlserver://{database_host}:{database_port};database={database_name}"
urlSuffix =";authenticationScheme=NTLM;integratedSecurity=true;domain=adobenet;trustServerCertificate=true"
whole_url = url+urlSuffix
print(whole_url)

# COMMAND ----------

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", whole_url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .option("numPartitions", 25)
    .load()
)

# COMMAND ----------

target_table_name = "b2b.rv_td_brdg_org_ecc"
spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
remote_table.write.format('parquet').mode("overwrite").insertInto(target_table_name)
