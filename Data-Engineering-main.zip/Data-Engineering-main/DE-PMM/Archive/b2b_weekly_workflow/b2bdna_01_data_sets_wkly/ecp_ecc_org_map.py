# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" REFRESH TABLE csmb.vw_ccm_pivot4_all; """)
             spark.sql(""" REFRESH TABLE ocf_analytics.dim_contract; """)
             spark.sql(""" REFRESH TABLE ids_coredata.dim_country; """)
             spark.sql(""" REFRESH TABLE enterprise.fact_cce_membership_count; """)
             spark.sql(""" REFRESH TABLE enterprise.fact_dce_membership_count; """)
             spark.sql(""" REFRESH TABLE enterprise.dim_org; """)
             spark.sql(""" REFRESH TABLE enterprise.dim_contract; """)
             spark.sql(""" REFRESH TABLE b2b.enduserid_orgid_mapping; """)
             spark.sql(""" REFRESH TABLE b2b.rv_td_prnt; """)
             spark.sql(""" REFRESH TABLE b2b.rv_td_sub; """)

             spark.sql(""" 
             CREATE OR REPLACE TABLE b2b_stg.ecp_ecc_org_map_stg1 AS
WITH brdg AS (
    SELECT
            ecc_id,
            max (sub_std_name_key) AS sub_std_name_key
        FROM b2b.rv_td_brdg_org_ecc brdg
        GROUP BY ecc_id
),

active_contracts_base AS (
    SELECT 
            regexp_replace(enduser, '^0+(?!$)', '') AS end_user_id,
            endusername AS end_user_name,
            marketsegment AS end_user_id_market_segment,
            geo AS end_user_id_geo,
            marketarea AS end_user_id_market_area,
            regexp_replace(enduser, '^0+(?!$)', '') AS contract_key,
            dmegtmsegment AS arr_dmegtmsegment,
            projecteddmegtmsegment AS projected_dme_gtm_segment,
            CAST (echparentid AS VARCHAR(50)) AS arr_parent_id,
            'NA' AS SFDC_Acct_id,
            datedate AS date,
            echparentindustry,
            echsubindustry,
            echsubid AS ech_sub_id,
            try_cast (totalendingarr AS double) AS arr,
            20 pref,
            salesdistrict AS sales_district,
            salesdistrictdescription AS sales_district_desc,
            rank() over (
                partition by regexp_replace(enduser, '^0+(?!$)', '') 
                order by to_date (datedate, 'yyyy-MM-dd') desc) AS rnk
        FROM b2b.uda_uda_finance_arr_vw_entarr
        WHERE snapshottype = 'W'
        AND to_date (datedate, 'yyyy-MM-dd')
                BETWEEN date_sub (to_date ('{RUN_DATE}', 'yyyy-MM-dd'), 90)
                    AND to_date ('{RUN_DATE}', 'yyyy-MM-dd')
        AND olpg NOT IN ('PPBU','CAPTIVATE PRIME','OTHER','DPS','CONNECT','DALP','UNMAPPED','COLDFUSION')

    UNION DISTINCT 

    SELECT 
            regexp_replace(ecc_customer_id, '^0+(?!$)', '') AS end_user_id,
            acct_name AS end_user_name,
            market_segment AS end_user_id_market_segment,
            geo AS end_user_id_geo,
            market_area AS end_user_id_market_area,
            lic.contract_id AS contract_key,
            gtm_acct_segment AS arr_dmegtmsegment,
            projected_dme_gtm_segment AS projected_dme_gtm_segment,
            CAST(ech_parent_id AS VARCHAR(50)) AS arr_parent_id,
            CASE
                WHEN ech_child_key IS NULL
                  OR ech_child_key like '%-_'
                    THEN 'NA'
                ELSE ech_child_key
            END AS SFDC_Acct_id,
            date_date AS date,
            null as echparentindustry,
            null as echsubindustry,
            ech_sub_id,
            fwk_end_arr AS arr,
            10 pref,
            sales_district, 
            sales_district_description,
            rank() over (
                partition by regexp_replace(ecc_customer_id, '^0+(?!$)', '')
                order by to_date (date_date, 'yyyy-MM-dd') desc,to_date (created_date_item, 'yyyy-MM-dd') desc) AS rnk
        FROM csmb.vw_ccm_pivot4_all pivot
        left join (select distinct contract_id,subscription_account_guid from ocf_analytics.scd_license) lic 
            on pivot.subscription_account_guid = lic.subscription_account_guid
        WHERE event_source = 'SNAPSHOT'
        AND to_date (date_date, 'yyyy-MM-dd')
                BETWEEN date_sub (to_date ('{RUN_DATE}', 'yyyy-MM-dd'), 90)
                    AND to_date ('{RUN_DATE}', 'yyyy-MM-dd')
        AND STYPE = 'TM'

    UNION DISTINCT 

    SELECT 
            regexp_replace(arr.billingid,'^0+(?!$)','') AS end_user_id,
            accountname AS end_user_name, 
            marketsegment AS market_segment,
            cnt.geo_code AS geo,
            cnt.market_area_code AS market_area,
            regexp_replace(arr.billingid,'^0+(?!$)','') AS contract_key,
            dmegtmsegmentfinal AS arr_dmegtmsegment,
            projecteddmegtmsegment AS projected_dme_gtm_segment,
            CAST(NULL AS VARCHAR(50)) AS arr_parent_id,
            coalesce(corpsfdcaccountidaria, 'NA') AS SFDC_Acct_ID,
            snapshotdate AS date,
            echparentindustry,
            echsubindustry,
            null AS ech_sub_id,
            try_cast(totalarr AS DECIMAL(20,0)) AS arr,
            30 pref,
            null AS sales_district,
            salesdistrictdescription AS sales_district_desc,
            rank() over (
                partition by regexp_replace(arr.billingid, '^0+(?!$)', '')
                order by to_date (arr.snapshotdate, 'yyyy-MM-dd') desc) AS rnk
        FROM b2b.uda_vw_tf_adobesignconsolidatedarr arr
        LEFT JOIN (
                SELECT DISTINCT country_code_iso2, geo_code, market_area_code 
                FROM ids_coredata.dim_country) cnt 
            ON cnt.country_code_iso2 = arr.accountcountry
        WHERE arr.snapshotdate
                BETWEEN date_sub (to_date ('{RUN_DATE}', 'yyyy-MM-dd'), 90)
                    AND to_date ('{RUN_DATE}', 'yyyy-MM-dd')
        AND arr.udadatasource = 'SIGN_ARIA'
        AND arr.etlatype = 'Standalone'

    UNION DISTINCT 

    SELECT 
            brdg.ecc_id AS end_user_id,
            null AS end_user_name, 
            null AS market_segment,
            COALESCE (cnt.geo_code, IFF (b.child_geo = 'NOT ASSIGNED', null, b.child_geo)) AS geo,
            COALESCE (cnt.market_area_code, IFF (b.child_market_area = 'Not Assigned', NULL, b.child_market_area)) AS market_area,
            NULL AS contract_key,
            b.curr_year_dme_major_seg AS arr_dmegtmsegment,
            null AS projected_dme_gtm_segment,
            b.prnt_id AS arr_parent_id,
            coalesce (b.workfront_sfdc_act, b.marketo_sfdc_act, b.magento_sfdc_act, 'NA') AS SFDC_Acct_ID,
            b.as_of_date AS date,
            null AS echparentindustry,
            null AS echsubindustry,
            b.sub_id AS ech_sub_id,
            b.arr_dma AS arr,
            40 pref,
            null AS sales_district,
            null AS sales_district_desc,
            1 rnk
        FROM b2b.uda_dx_tap_prod_dbo_report_planning_cube_child_dme b
        INNER JOIN brdg
            ON brdg.sub_std_name_key = b.sub_id
        LEFT JOIN (
                SELECT DISTINCT market_area_description, geo_code, market_area_code 
                FROM ids_coredata.dim_country) cnt 
            ON cnt.market_area_description = b.child_market_area
        WHERE b.as_of_date = '{RUN_DATE}'

),

active_contracts AS (
    SELECT *
        FROM active_contracts_base
        WHERE rnk = 1
),

-- ------------------------
-- Get top preference
-- ------------------------

end_user_pref AS (
    SELECT end_user_id, min (pref) AS pref
    FROM active_contracts ac
    GROUP BY end_user_id
),

-- -----------------------------
-- Max ARR to derive GEO fields
-- -----------------------------

top_arr AS (
    SELECT DISTINCT
            ac.end_user_id,
            ac.end_user_id_geo,
            ac.end_user_id_market_area,
            ROW_NUMBER() OVER (PARTITION BY ac.end_user_id ORDER BY ac.arr DESC) AS rnk
    FROM active_contracts ac
    JOIN end_user_pref eup ON eup.end_user_id = ac.end_user_id AND eup.pref = ac.pref

),

-- -------------------------
-- Filter out null contracts
-- -------------------------

end_user_keys AS (
    SELECT
            end_user_id,
            contract_key,
            arr_parent_id
        FROM active_contracts
        WHERE COALESCE (contract_key, '') <> ''

    UNION ALL

    SELECT
            end_user_id,
            contract_key,
            arr_parent_id
        FROM active_contracts a
        WHERE COALESCE (contract_key, '') = ''
        AND NOT EXISTS
            (SELECT TRUE
            FROM active_contracts b
            WHERE a.end_user_id = b.end_user_id
              AND COALESCE (a.arr_parent_id, 'N/A') = COALESCE (b.arr_parent_id, 'N/A')
              AND COALESCE (contract_key, '') <> '')

),

-- ------------------------
-- Pick up all end_user_ids
-- ------------------------

end_users AS (
    SELECT
            ac.end_user_id,
            min (ac.end_user_name) AS end_user_name,
            min (ac.ech_sub_id) AS ech_sub_id,
            coalesce(min (CASE WHEN ac.SFDC_Acct_id = 'NA' THEN NULL ELSE ac.SFDC_Acct_id END), 'NA') AS SFDC_Acct_id,
            min (CASE WHEN ac.echparentindustry = 'TBD' THEN NULL ELSE ac.echparentindustry END) AS echparentindustry,
            min (CASE WHEN ac.echsubindustry = 'TBD' THEN NULL ELSE ac.echsubindustry END) AS echsubindustry,
            min (top_arr.end_user_id_geo) AS end_user_id_geo,
            min (top_arr.end_user_id_market_area) AS end_user_id_market_area,
            min (ac.sales_district) AS sales_district,
            min (ac.sales_district_desc) AS sales_district_desc,
            min (
                CASE
                        WHEN ac.end_user_id_market_segment = 'COMMERCIAL' THEN 1
                        WHEN ac.end_user_id_market_segment = 'GOVERNMENT' THEN 2
                        WHEN ac.end_user_id_market_segment = 'EDUCATION'  THEN 3
                        WHEN ac.end_user_id_market_segment = 'NON-PROFIT' THEN 4
                        ELSE '5'
                END) end_user_id_market_segment_ind,
            min (
                CASE
                        WHEN ac.projected_dme_gtm_segment = 'CORP T1' THEN 1
                        WHEN ac.projected_dme_gtm_segment = 'Enterprise' THEN 2
                        WHEN ac.projected_dme_gtm_segment = 'CORP T2' THEN 3
                        WHEN ac.projected_dme_gtm_segment = 'CSMB'    THEN 4
                        ELSE '5' 
                END) AS projected_dme_gtm_segment_ind,
            min (
                CASE
                        WHEN ac.arr_dmegtmsegment = 'CORP T1' THEN 1
                        WHEN ac.arr_dmegtmsegment = 'Enterprise' THEN 2
                        WHEN ac.arr_dmegtmsegment = 'CORP T2' THEN 3
                        WHEN ac.arr_dmegtmsegment = 'CSMB'    THEN 4
                        ELSE '5' 
                END) AS arr_dmegtmsegment_ind,
            min (
                CASE
                        WHEN ac.arr_dmegtmsegment = 'CORP T1' THEN 1
                        WHEN ac.arr_dmegtmsegment = 'Enterprise' THEN 2
                        WHEN ac.arr_dmegtmsegment = 'CORP T2' THEN 3
                        WHEN ac.arr_dmegtmsegment = 'CSMB'    THEN 4
                        ELSE '5' 
                END) AS dme_acct_segment_ind
    FROM active_contracts ac
        JOIN end_user_pref eup ON eup.end_user_id = ac.end_user_id AND eup.pref = ac.pref
        LEFT JOIN top_arr ON top_arr.end_user_id = ac.end_user_id AND top_arr.rnk = 1
    WHERE COALESCE (ac.end_user_id, '') <> ''
    GROUP BY ac.end_user_id
)

SELECT 
            eu.end_user_id,
            ek.contract_key,
            ek.arr_parent_id,
            eu.SFDC_Acct_id,
            eu.ech_sub_id,
            eu.end_user_name,
            eu.end_user_id_geo,
            eu.end_user_id_market_area,
            eu.echparentindustry,
            eu.echsubindustry,
            eu.sales_district,
            eu.sales_district_desc,
            CASE eu.end_user_id_market_segment_ind
                WHEN 1 THEN 'COMMERCIAL'
                WHEN 2 THEN 'GOVERNMENT'
                WHEN 3 THEN 'EDUCATION'
                WHEN 4 THEN 'NON-PROFIT'
                ELSE 'N/A'
            END AS end_user_id_market_segment,
            CASE eu.dme_acct_segment_ind
                WHEN 1 THEN 'CORP T1'
                WHEN 2 THEN 'ENT'
                WHEN 3 THEN 'CORP T2'
                WHEN 4 THEN 'SMB'
                ELSE 'SMB'
            END AS dme_acct_segment,
            CASE eu.arr_dmegtmsegment_ind
                WHEN 1 THEN 'CORP T1'
                WHEN 2 THEN 'ENT'
                WHEN 3 THEN 'CORP T2'
                WHEN 4 THEN 'SMB'
                ELSE 'SMB'
            END AS arr_dmegtmsegment,
            CASE eu.projected_dme_gtm_segment_ind
                WHEN 1 THEN 'CORP T1'
                WHEN 2 THEN 'ENT'
                WHEN 3 THEN 'CORP T2'
                WHEN 4 THEN 'SMB'
                ELSE 'SMB'
            END AS projected_dme_gtm_segment

    FROM end_users eu
    JOIN end_user_keys ek ON ek.end_user_id = eu.end_user_id
    
    UNION DISTINCT  

    -- Get all records without end_uder_id as is
    SELECT 
            NULL AS end_user_id,
            ac.contract_key,
            ac.arr_parent_id,
            ac.SFDC_Acct_id,
            ac.ech_sub_id,
            ac.end_user_name,
            ac.end_user_id_geo,
            ac.end_user_id_market_area,
            ac.echparentindustry,
            ac.echsubindustry,
            ac.sales_district,
            ac.sales_district_desc,
            ac.end_user_id_market_segment,
            CASE
                WHEN ac.arr_dmegtmsegment = 'CORP T1' THEN 'CORP T1'
                WHEN ac.arr_dmegtmsegment = 'CORP T2' THEN 'CORP T2'
                WHEN ac.arr_dmegtmsegment = 'Enterprise' THEN 'ENT'
                WHEN ac.arr_dmegtmsegment = 'CSMB'       THEN 'SMB'
                ELSE ac.arr_dmegtmsegment
            END AS dme_acct_segment,
            CASE
                WHEN ac.arr_dmegtmsegment = 'CORP T1' THEN 'CORP T1'
                WHEN ac.arr_dmegtmsegment = 'CORP T2' THEN 'CORP T2'
                WHEN ac.arr_dmegtmsegment = 'Enterprise' THEN 'ENT'
                WHEN ac.arr_dmegtmsegment = 'CSMB'       THEN 'SMB'
                ELSE ac.arr_dmegtmsegment
            END AS arr_dmegtmsegment,
            CASE
                WHEN ac.projected_dme_gtm_segment = 'CORP T1' THEN 'CORP T1'
                WHEN ac.projected_dme_gtm_segment = 'CORP T2' THEN 'CORP T2'
                WHEN ac.projected_dme_gtm_segment = 'Enterprise' THEN 'ENT'
                WHEN ac.projected_dme_gtm_segment = 'CSMB'       THEN 'SMB'
                ELSE ac.projected_dme_gtm_segment
            END AS projected_dme_gtm_segment

    FROM active_contracts_base ac
    WHERE COALESCE (ac.end_user_id, '') = '';
             """.format(RUN_DATE = RUN_DATE))
             
             spark.sql(""" 
             CREATE OR REPLACE TABLE b2b_stg.ecp_ecc_org_map_stg2 AS

WITH

-- --------------------
-- Get the org id and contract key for SMB
-- --------------------

smb_data AS (
    SELECT 
            CASE
                WHEN contract_offer_type = 'ETLA' THEN end_user_id
                ELSE contract_id
            END AS contract_key,
            contract_id,
            c.org_id,
            org_name,
            market_segment AS org_market_segment,
            country AS org_country,
            row_insertion_dttm
        FROM enterprise.fact_cce_membership_count c
        LEFT JOIN b2b.enduserid_orgid_mapping mp 
             ON mp.org_id = c.org_id
            AND mp.active_flag = 'Y'

    UNION DISTINCT 

    SELECT 
            CASE
                WHEN contract_offer_type = 'ETLA' THEN end_user_id
                ELSE contract_id
            END AS contract_key,
            contract_id,
            d.org_id,
            org_name,
            market_segment AS org_market_segment,
            country AS org_country,
            row_insertion_dttm
        FROM enterprise.fact_dce_membership_count d
        LEFT JOIN b2b.enduserid_orgid_mapping mp 
             ON mp.org_id = d.org_id
            AND mp.active_flag = 'Y'
),

-- --------------------
-- All SMB data together
-- --------------------

smb_combined_base AS (
    select distinct 
  contract_key,contract_id,org_id,org_name,org_market_segment,org_country 
  from (
    select
    contract_key,contract_id,org_id,org_name,org_market_segment,org_country,row_insertion_dttm,
    dense_rank() over (partition by contract_key,contract_id,org_id,org_name,org_market_segment order by row_insertion_dttm desc) as rnk
    from (
    SELECT 
            distinct 
            contract.contract_id as contract_key,
            contract.contract_id,
            contract.owner_identity_id AS org_id,
            org.org_name,
            seat.market_segments AS org_market_segment,
            contract.country_code AS org_country,
            contract.last_modified_date as row_insertion_dttm
        FROM ocf_analytics.dim_contract contract
        LEFT JOIN ocf_analytics.scd_license seat ON contract.contract_id = seat.contract_id
        LEFT JOIN enterprise.dim_org org ON contract.owner_identity_id = org.org_id
        WHERE contract.contract_type != 'DIRECT_INDIVIDUAL'

    UNION DISTINCT 
    
    SELECT cce.*
        FROM smb_data cce
    
        WHERE NOT EXISTS
            (SELECT TRUE
            FROM    ocf_analytics.dim_contract ccm
            WHERE   ccm.contract_type != 'DIRECT_INDIVIDUAL'
            AND     cce.org_id = ccm.owner_identity_id)
        OR EXISTS
            (SELECT TRUE
            FROM    enterprise.dim_contract ent
            WHERE   ent.contract_type != 'DIRECT_INDIVIDUAL'
            AND     cce.org_id = ent.org_id)
   )
  )
  where rnk = 1 
),

-- --------------------
-- Process duplicates
-- --------------------

smb_combined_dedup AS (

    SELECT
            contract_key,
            org_id,
            org_name,
            org_country,
            min (contract_id) AS contract_id,
            CASE
                min (CASE org_market_segment
                        WHEN 'COMMERCIAL' THEN '1'
                        WHEN 'GOVERNMENT' THEN '2'
                        WHEN 'EDUCATION'  THEN '3'
                        WHEN 'NON-PROFIT' THEN '4'
                        ELSE org_market_segment
                     END)
                WHEN '1' THEN 'COMMERCIAL'
                WHEN '2' THEN 'GOVERNMENT'
                WHEN '3' THEN 'EDUCATION'
                WHEN '4' THEN 'NON-PROFIT'
                ELSE min (org_market_segment)
            END AS org_market_segment
        FROM smb_combined_base
        GROUP BY
          contract_key,
          org_id,
          org_name,
          org_country

),

-- --------------------
-- Link missing contracts to extract Org details
-- --------------------

smb_links AS (
    SELECT
          arr1.contract_key as empty_key,
          min(arr2.contract_key) AS new_key
        FROM b2b_stg.ecp_ecc_org_map_stg1 arr1
        JOIN b2b_stg.ecp_ecc_org_map_stg1 arr2
            ON arr2.end_user_id = arr1.end_user_id
        WHERE NOT EXISTS
            (SELECT TRUE
            FROM smb_combined_dedup jem1 
            WHERE jem1.contract_key = arr1.contract_key)
        AND EXISTS
            (SELECT TRUE
            FROM smb_combined_dedup jem2
            WHERE jem2.contract_key = arr2.contract_key)
        GROUP BY 1
  
),

smb_combined AS (
    SELECT
          jem.contract_key,
          jem.contract_id,
          jem.org_id,
          jem.org_name,
          jem.org_country,
          jem.org_market_segment
        FROM smb_combined_dedup jem
        WHERE EXISTS
            (SELECT TRUE
            FROM b2b_stg.ecp_ecc_org_map_stg1 arr 
            WHERE jem.contract_key = arr.contract_key)
    UNION ALL
    SELECT
          smb_links.empty_key AS contract_key,
          jem.contract_id,
          jem.org_id,
          jem.org_name,
          jem.org_country,
          jem.org_market_segment
        FROM smb_combined_dedup jem
        JOIN smb_links
            ON smb_links.new_key = jem.contract_key
)

SELECT * FROM smb_combined;
             """)

             spark.sql(""" 
             CREATE OR REPLACE TABLE b2b_stg.ecp_ecc_org_map_stg3 AS

WITH

-- --------------------
-- BRDG to get ech attributes
-- --------------------

bdrg_base AS (
    SELECT DISTINCT
            ecc_id AS end_user_id,
            seg.dmegtmsegment,
            brdg.prnt_std_name_key AS ech_parent_id,
            (regexp_replace(prnt.prnt_name,'"','')) AS ech_parent_name,
            prnt.country_code AS ech_parent_country_code,
            prnt_c.country_name AS ech_parent_country_name,
            prnt_c.market_area_code AS ech_parent_market_area_code,
            prnt_c.market_area_description AS ech_parent_market_area_description,
            prnt_c.region_code AS ech_parent_region_code,
            prnt_c.region_description AS ech_parent_region_description,
            prnt_c.geo_code AS ech_parent_geo_code,
            prnt_c.geo_description AS ech_parent_geo_description,
            prnt.db_annual_sales_usd AS ech_parent_annual_sales_usd,
            prnt.db_tot_emp_cnt AS ech_parent_tot_emp_cont,
            prnt.tap_industry AS ech_parent_industry,
            CASE
                WHEN prnt.tap_industry = 'TBD' THEN 'TBD'
                WHEN upper(prnt.tap_industry) LIKE '%GOV%' THEN 'GOV'
                WHEN upper(prnt.tap_industry) LIKE '%EDU%' THEN 'EDU'
                ELSE 'COM'
            END AS ent_sops_market_segment,
            prnt.duns_num AS duns_number,
            prnt.db_gu_duns_num AS global_ultimate_duns_number,
            prnt.db_du_duns_num AS domestic_ultimate_duns_number,
            brdg.sub_std_name_key AS ech_sub_id,
            sub.sub_name AS ech_sub_name,
            sub.country_code AS ech_sub_country_code,
            sub.db_annual_sales_usd AS ech_sub_annual_sales_usd,
            sub.db_tot_emp_cnt AS ech_sub_tot_emp_cont,
            sub.tap_industry AS ech_sub_industry,
            seg.snapshotdatekey,
            ROW_NUMBER() OVER(PARTITION BY ecc_id ORDER BY brdg.sub_std_name_key DESC) rownum
        FROM b2b.rv_td_brdg_org_ecc brdg
        
        LEFT JOIN
        (
            SELECT 
                    accountid,
                    dmegtmsegment,
                    snapshotdatekey
            FROM b2b.vw_tf_accountsegmentationsnapshot
            WHERE accounttype = 'ECC'
            AND snapshotdatekey =
                    (SELECT max(snapshotdatekey)
                    FROM b2b.vw_tf_accountsegmentationsnapshot)
        ) seg 
            ON regexp_replace(brdg.ecc_id, '^0+(?!$)', '') = regexp_replace(seg.accountid, '^0+(?!$)', '')
        
        LEFT JOIN b2b.rv_td_prnt prnt
            ON prnt.prnt_std_name_key = brdg.prnt_std_name_key
        LEFT JOIN Ids_coredata.dim_country prnt_c
            ON prnt.country_code = prnt_c.country_code_iso2
        LEFT JOIN b2b.rv_td_sub sub
            ON sub.sub_std_name_key = brdg.sub_std_name_key
),

-- --------------------------------------------
-- Derive sops_segment
-- --------------------------------------------

uda_dbo1 AS (
    SELECT
            sub_id,
            CASE
                WHEN curr_year_dme_major_seg = 'Enterprise' THEN 'ENT'
                WHEN curr_year_dme_major_seg = 'Mid-Market' THEN 'MM'
                WHEN curr_year_dme_major_seg = 'CSMB' THEN 'SMB'
                ELSE curr_year_dme_major_seg
            END AS sops_segment,
            array_join (array_sort (array_agg (distinct child_id)), '|') AS child_id,
            array_join (array_sort (array_agg (distinct child_name)), '|') AS child_name
        FROM b2b.uda_dx_tap_prod_dbo_report_planning_cube_child_dme
        WHERE as_of_date = '{RUN_DATE}'
        GROUP BY 1, 2
),

uda_dbo2 AS (
    SELECT
            sub_id,
            array_join (array_sort (array_agg (distinct 
                CASE
                    WHEN curr_year_dme_major_seg = 'Enterprise' THEN 'ENT'
                    WHEN curr_year_dme_major_seg = 'Mid-Market' THEN 'MM'
                    WHEN curr_year_dme_major_seg = 'CSMB' THEN 'SMB'
                    ELSE curr_year_dme_major_seg
                END)), '|') AS sops_segment,
            array_join (array_sort (array_agg (distinct child_id)), '|') AS child_id,
            array_join (array_sort (array_agg (distinct child_name)), '|') AS child_name
        FROM b2b.uda_dx_tap_prod_dbo_report_planning_cube_child_dme
        WHERE as_of_date = '{RUN_DATE}'
        GROUP BY 1
),

-- --------------------
-- Unique custom profiles
-- --------------------

customer_profile AS (
    SELECT DISTINCT
            case 
                when upper(fy24_proposal_segment_flag) ='ENTERPRISE' then 'ENT'
                when upper(fy24_proposal_segment_flag) ='CSMB' then 'SMB'
                else fy24_proposal_segment_flag
            end fy24_sops_segment,
            sales_district,
            named_flag,
            ech_sub_id,
            end_user_id
        FROM b2b.dme_customer_profile
),

-- --------------------
-- Combine all source together
-- --------------------

ecp_ecc_org_map AS (
    SELECT DISTINCT
            arr.end_user_id,
            arr.end_user_name,
            arr.end_user_id_market_segment,
            arr.end_user_id_geo,
            arr.end_user_id_market_area,
            arr.dme_acct_segment,
            jem.org_id,
            jem.org_name,
            jem.org_market_segment,
            jem.org_country,
            jem.contract_id,
            arr.contract_key,
            ecp.ech_parent_id,
            ecp.ech_parent_name,
            ecp.ech_parent_country_code,
            ecp.ech_parent_country_name,
            ecp.ech_parent_market_area_code,
            ecp.ech_parent_market_area_description,
            ecp.ech_parent_region_code,
            ecp.ech_parent_region_description,
            ecp.ech_parent_geo_code,
            ecp.ech_parent_geo_description,
            COALESCE (arr.ech_sub_id, ecp.ech_sub_id) ech_sub_id,
            ecp.ech_sub_name,
            ecp.ech_sub_country_code,
            ecp.ech_parent_annual_sales_usd,
            ecp.ech_parent_tot_emp_cont,
            CASE
                WHEN COALESCE (arr.echparentindustry,   'TBD') != 'TBD' THEN arr.echparentindustry
                WHEN COALESCE (ecp.ech_parent_industry, 'TBD') != 'TBD' THEN ecp.ech_parent_industry
                ELSE COALESCE (dfg.industry, 'UNKNOWN')
            END AS ech_parent_industry,
            ecp.ent_sops_market_segment,
            ecp.duns_number,
            ecp.global_ultimate_duns_number,
            ecp.domestic_ultimate_duns_number,
            ecp.ech_sub_annual_sales_usd,
            ecp.ech_sub_tot_emp_cont,
            CASE
                WHEN COALESCE (arr.echsubindustry,   'TBD') != 'TBD' THEN arr.echsubindustry
                WHEN COALESCE (ecp.ech_sub_industry, 'TBD') != 'TBD' THEN ecp.ech_sub_industry
                ELSE COALESCE (dfg.industry, 'UNKNOWN')
            END AS ech_sub_industry,
            ecp.dmegtmsegment AS uda_dmegtmsegment,
            coalesce (uda1.sops_segment, uda2.sops_segment) AS ent_sops_segment,
            coalesce (uda1.child_id, uda2.child_id) AS child_id,
            coalesce (uda1.child_name, uda2.child_name) AS child_name,
            arr.arr_parent_id,
            arr.SFDC_Acct_id,
            arr.arr_dmegtmsegment,
            arr.projected_dme_gtm_segment,
            arr.sales_district,
            arr.sales_district_desc,
            cp.fy24_sops_segment,
            cp.sales_district as dcp_sales_district,
            cp.named_flag,
            '{RUN_DATE}' AS as_of_date
        FROM b2b_stg.ecp_ecc_org_map_stg1 arr 
        LEFT JOIN b2b_stg.ecp_ecc_org_map_stg2 jem 
             ON jem.contract_key = arr.contract_key
        LEFT JOIN bdrg_base ecp 
             ON ecp.end_user_id = arr.end_user_id
            AND (ecp.ech_sub_id = arr.ech_sub_id OR (arr.ech_sub_id IS NULL AND ecp.rownum = 1))
        LEFT JOIN ocf.dim_firmographics AS dfg
             ON dfg.contract_id = arr.contract_key
        LEFT JOIN uda_dbo1 uda1
             ON uda1.sub_id = COALESCE (arr.ech_sub_id, ecp.ech_sub_id)
            AND uda1.sops_segment = arr.dme_acct_segment
        LEFT JOIN uda_dbo2 uda2
             ON uda2.sub_id = COALESCE (arr.ech_sub_id, ecp.ech_sub_id)
        LEFT JOIN customer_profile AS cp
              ON cp.ech_sub_id = COALESCE (arr.ech_sub_id, ecp.ech_sub_id)
             AND cp.end_user_id = arr.end_user_id
             AND cp.sales_district = arr.sales_district
)

SELECT * FROM ecp_ecc_org_map;
              """.format(RUN_DATE = RUN_DATE))
             
             spark.sql(""" 
             INSERT OVERWRITE TABLE b2b.ecp_ecc_org_map partition(as_of_date)
--WITH highest_segment AS (
--    SELECT org_id,
--          CASE min (
--                CASE
--                        WHEN dme_acct_segment = 'CORP T1' THEN 1
--                        WHEN dme_acct_segment = 'ENT' THEN 2
--                        WHEN dme_acct_segment = 'CORP T2' THEN 3
--                        WHEN dme_acct_segment = 'SMB' THEN 4
--                        ELSE '5' 
--                END)
--                WHEN 1 THEN 'CORP T1'
--                WHEN 2 THEN 'ENT'
--                WHEN 3 THEN 'CORP T2'
--                WHEN 4 THEN 'SMB'
--                ELSE 'SMB'
--            END AS dme_acct_segment
--    FROM b2b_stg.ecp_ecc_org_map_stg3
--    WHERE org_id IS NOT NULL 
--    AND org_id <> ''
--    GROUP BY org_id
--)

-- Final Results
    SELECT DISTINCT 
            cast(fnl.end_user_id as int) as end_user_id,
            end_user_name,
            end_user_id_market_segment,
--            coalesce (highest_segment.dme_acct_segment, fnl.dme_acct_segment) AS dme_acct_segment,
            fnl.dme_acct_segment,
            'N/A' AS mm_flag,
            fnl.org_id,
            org_name,
            org_market_segment,
            org_country,
            contract_key,
            ech_parent_id,
            ech_parent_name,
            ech_parent_country_code,
            ech_parent_country_name,
            ech_parent_market_area_code,
            ech_parent_market_area_description,
            ech_parent_region_code,
            ech_parent_region_description,
            ech_parent_geo_code,
            ech_parent_geo_description,
            ech_sub_id,
            ech_sub_name,
            ech_sub_country_code,
            ech_parent_annual_sales_usd,
            ech_parent_tot_emp_cont,
            ech_parent_industry,
            ech_sub_annual_sales_usd,
            ech_sub_tot_emp_cont,
            ech_sub_industry,
            uda_dmegtmsegment,
            arr_parent_id,
            projected_dme_gtm_segment,
            end_user_id_geo,
            end_user_id_market_area,
            contract_id,
            ent_sops_market_segment,
            duns_number,
            global_ultimate_duns_number,
            domestic_ultimate_duns_number,
            ent_sops_segment,
            child_id,
            child_name,
            SFDC_Acct_id,
            arr_dmegtmsegment,
            sales_district,
            sales_district_desc,
            fy24_sops_segment,
            dcp_sales_district,
            named_flag,
            cast(as_of_date as DATE) as as_of_date
        FROM b2b_stg.ecp_ecc_org_map_stg3 fnl
--        LEFT JOIN highest_segment 
--             ON highest_segment.org_id = fnl.org_id;
              """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()
