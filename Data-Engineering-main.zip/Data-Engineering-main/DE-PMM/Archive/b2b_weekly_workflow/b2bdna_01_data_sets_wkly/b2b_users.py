from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" 
                       create or replace table b2b_stg.b2b_users_first_delegation_date as
WITH delegates AS (
SELECT
     distinct 
     d.contract_id,
     l.product_arrangement_code,
     d.member_guid,
     to_date (start_ts) AS delegation_start_date,
     d.org_id org_id
FROM ocf_analytics.scd_delegate AS d
  left join ocf_analytics.scd_license l
    on d.contract_id = l.contract_id
    and d.root_license_id = l.root_license_id
     WHERE to_date(d.start_ts) >= '2021-09-04'
UNION DISTINCT
SELECT
     distinct 
     scdf.contract_id,
     offer.product_arrangement_code,
     scd.member_guid,
     to_date(scd.start_dttm) AS delegation_start_date,
     scd.org_id AS org_id
FROM enterprise.scd_lds_delegated_license_change scd
left join enterprise.scd_fulfillable_entitlement scdf
     on scd.product_id = scdf.fulfillable_entitlement_id
     AND to_date(scd.start_dttm) >= '2021-09-04'
left join enterprise.scd_offering offer
    on scdf.offer_id = offer.offer_id
)
SELECT
     d.org_id,
     d.contract_id,
     d.product_arrangement_code,
     d.member_guid,
     min(d.delegation_start_date) firstdelegation_date
FROM delegates d
GROUP BY
    d.org_id,
    d.contract_id,
    d.product_arrangement_code,
    d.member_guid;
                        """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.b2b_users partition (as_of_date)
SELECT DISTINCT org_actv.org_id,
                org_actv.contract_id,
                org_actv.offer_id,
                usrs.member_guid,
                UPPER(id_type) as id_type,
                CASE
                    WHEN UPPER(contract_offer_type)='TEAM DIRECT' THEN 'TEAM_DIRECT'
                    WHEN dimc.buying_program ='VIPMP' THEN dimc.buying_program
                    ELSE UPPER(org_actv.contract_offer_type)
                END AS contract_offer_type, 
 CASE
     WHEN usrs.member_guid=t2e.profile_id THEN t2e.auth_id
     ELSE usrs.member_guid
 END AS auth_id,
 org_actv.offering_name,
 group_id,
 lvt.pers_first_name,
 lvt.pers_last_name,
 lvt.pers_country_code,
 lvt.pers_email,
 lvt.language_name,
 cast(del.firstdelegation_date as date) as first_delegation_date,
 cast('{RUN_DATE}' as date) AS as_of_date
FROM 
  (SELECT DISTINCT org_id, 
                   offer_id, 
                   contract_offer_type,
                   contract_id,
                   offering_name,
                   market_segment,
                   contract_start_date,
                   org_name,
                   row_number() over (partition by contract_id,org_id,offering_name,contract_offer_type,provisioned_count,cloud_type,org_name,market_segment,contract_start_date,contract_end_date
    order by offer_id) as row_num
   FROM enterprise.fact_snapshot_org_activation 
   WHERE snapshot_date= '{RUN_DATE}' and is_valid='Y') org_actv 

   LEFT JOIN ( SELECT DISTINCT ccmpivot.vip_contract FROM csmb.vw_ccm_pivot4_all ccmpivot
   WHERE event_source ='SNAPSHOT' AND source_type = 'TM' AND date_date = '{RUN_DATE}') pivot_contracts
   ON org_actv.contract_id = pivot_contracts.vip_contract
   AND org_actv.contract_offer_type = 'EVIP'
   AND org_actv.market_segment NOT IN ('EDUCATION','EDU')

LEFT JOIN 
  (SELECT contract_id, 
          buying_program 
   FROM enterprise.dim_contract) dimc ON dimc.contract_id = org_actv.contract_id 
INNER JOIN 
  ( 
   SELECT 
		 sls.org_id,
		 fct.offer_id,
		 sls.member_guid,
		 sls.user_auth_src_type as id_type,
		 sls.contract_id,
		 sls.delegation_group_id as group_id
	 FROM enterprise.fact_sls_license_delegation_snapshot sls
	 LEFT JOIN
	 enterprise.fact_snapshot_org_activation fct
	 ON
	 sls.org_id = fct.org_id
	 and sls.contract_id = fct.contract_id
	 and sls.snapshot_date = fct.snapshot_date
	 and sls.product_arrangement_code = fct.product_arrangement_code
	 where sls.snapshot_date = '{RUN_DATE}' and fct.is_valid='Y'
) usrs 
     ON (usrs.org_id = org_actv.org_id
AND usrs.contract_id = org_actv.contract_id
AND usrs.offer_id=org_actv.offer_id )
LEFT JOIN 
  (SELECT distinct org_id, 
          profile_id, 
          auth_id 
   FROM 
     (SELECT UPPER(split(org_id,'@')[0]) AS org_id, 
             auth_id, 
             profile_id, 
             row_number() over (PARTITION BY org_id, profile_id 
                                ORDER BY coll_dts DESC) AS rw_num 
      FROM ocf_analytics.vw_type2e_profile_reference 
      WHERE  
         SUBSTRING(end_dts,1,10)<='{RUN_DATE}') a
   WHERE rw_num = 1 )t2e 
   ON (usrs.member_guid=t2e.profile_id
    AND org_actv.org_id = t2e.org_id)


LEFT JOIN ocf_analytics.dim_user_lvt_profile AS lvt
ON usrs.member_guid = lvt.user_guid
AND Upper(lvt.pers_email) NOT LIKE '%ADOBE.COM'
AND Upper(lvt.pers_email) NOT LIKE '%ADOBE-IDENTITY.COM'

LEFT JOIN enterprise.scd_offering offer
    on usrs.offer_id = offer.offer_id

LEFT JOIN b2b_stg.b2b_users_first_delegation_date del
on offer.product_arrangement_code = del.product_arrangement_code
and usrs.org_id = del.org_id
and usrs.contract_id = del.contract_id
and usrs.member_guid = del.member_guid

    WHERE NOT (
pivot_contracts.vip_contract IS NULL AND org_actv.contract_offer_type = 'EVIP' AND org_actv.market_segment NOT IN ('EDUCATION','EDU')
and cast(org_actv.contract_start_date AS DATE) < DATE_ADD(cast('{RUN_DATE}' as DATE),-30)
)
AND ((org_actv.org_name is null or org_actv.org_name = '') or (org_actv.org_name not like 'BANK%OLITA%'))
AND org_actv.row_num = 1
    """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()