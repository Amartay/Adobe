# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

# DBTITLE 1,mail
from email.message import EmailMessage
import smtplib

def send_email(body):
    fromaddr = 'do-not-reply-dpaas-dbx@adobe.com'
    toaddrs = "lat57607@adobe.com,lat41525@adobe.com,tek43117@adobe.com"
    SMTPServer = 'adobe-com.mail.protection.outlook.com'
    port = 25 #587
    html_content = """
    <html>
    <body>
    <pre><b>Hi All,
     
    {body}
    [This is an auto generated email, please do not reply]</b>
    </pre>
    </body>
    </html>
    """
    msg = EmailMessage()
    msg['Subject'] = " B2B PRE VALIDATION ISSUES"
    msg['From'] = fromaddr
    msg['To'] = toaddrs
    msg.set_content(html_content.format(body=body), subtype='html')
    server = smtplib.SMTP(SMTPServer, port)
    server.send_message(msg)
    server.quit()

# COMMAND ----------

# MAGIC %sql
# MAGIC msck repair table b2b.uda_vw_tf_adobesignconsolidatedarr;
# MAGIC msck repair table b2b.vw_tf_accountsegmentationsnapshot;

# COMMAND ----------

from datetime import date
from datetime import datetime, timedelta
from pyspark.sql.functions import *

today = datetime.today()
run_day = date.today().strftime("%A")
days_since_friday = (today.weekday() + 3) % 7
print(run_day)
if run_day == 'Friday':
    run_date = today - timedelta(days=7)
    run_date = run_date.date().strftime("%Y%m%d")
else:
    today = datetime.today()
    days_since_friday = (today.weekday() + 3) % 7
    last_friday = today - timedelta(days=days_since_friday)
    run_date = last_friday.date().strftime("%Y%m%d")
print(run_date)
query = "select * from b2b.uda_vw_tf_adobesignconsolidatedarr where datekey = '{}' ".format(run_date)
count = spark.sql(query).count()
print(count)
body = ''
if (count!=0):
    pass
else:
    a = "b2b.uda_vw_tf_adobesignconsolidatedarr doesnt have latest snapshot"
    body = body+a
    send_email(body)
    raise Exception("Table is not updated")

# COMMAND ----------

# DBTITLE 1,checking tables are refreshed with latest snapshot
from dateutil.relativedelta import relativedelta
two_days_back = YESTERDAY - relativedelta(days=1)

table_4 = 'dms_hybrid.user_activity'
table_1 = 'enterprise.fact_snapshot_org_activation'
table_2 = 'b2b.snapshot_fact_enterprise_member_license_delegation'
table_3 = 'mdpd_target.imsrengaservice' 
table_5 = 'b2b.uda_uda_finance_arr_vw_entarr'

org_act= spark.sql(''' select * from enterprise.fact_snapshot_org_activation where snapshot_date = '{B2B_RUN_DATE}' and is_valid='Y' '''.format(B2B_RUN_DATE= B2B_RUN_DATE)).count()
print(org_act)
snapshot_del = spark.sql(''' select * from b2b.snapshot_fact_enterprise_member_license_delegation where asofdate = '{B2B_RUN_DATE}' '''.format(B2B_RUN_DATE = B2B_RUN_DATE)).count()
print(snapshot_del)
#renga_service = spark.sql(''' select * from mdpd_target.imsrengaservice where insertdate = '{SATURDAY}' '''.format(SATURDAY = SATURDAY)).count()
#print(renga_service)
uda_finance_dly = spark.sql(''' select * from b2b.uda_uda_finance_arr_vw_entarr  where SnapshotType = 'D' and DateDate = '{SATURDAY}' '''.format(SATURDAY = SATURDAY)).count()
print(uda_finance_dly)
uda_finance_wkly = spark.sql(''' select * from b2b.uda_uda_finance_arr_vw_entarr  where SnapshotType = 'W' and DateDate = '{B2B_RUN_DATE}' '''.format(B2B_RUN_DATE = B2B_RUN_DATE)).count()
print(uda_finance_wkly)
user_act = spark.sql(''' select * from dms_hybrid.user_activity  where event_date = '{two_days_back}' '''.format(two_days_back = two_days_back)).count()
print(user_act)


body = ''
if org_act == 0:
    a = "{table_1} is not refreshed for latest snapshot\n".format(table_1=table_1)
    body = body+a
if snapshot_del == 0:
    a = "{table_2} is not refreshed for latest snapshot\n".format(table_2=table_2)
    body = body+a
# if renga_service == 0:
#     a = "{table_3} is not refreshed for latest snapshot\n".format(table_3=table_3)
#     body = body+a
if uda_finance_dly == 0:
    a = "{table_5} is not refreshed for latest daily snapshot\n".format(table_5=table_5)
    body = body+a
if uda_finance_wkly == 0:
    a = "{table_5} is not refreshed for latest weekly snapshot\n".format(table_5=table_5)
    body = body+a
if user_act == 0:
    a = "{table_4} is not refreshed for latest snapshot\n".format(table_4=table_4)
    body = body+a



# COMMAND ----------

# DBTITLE 1,verify contract_types in enterprise.fact_snapshot_org_activation
contract_type_list = ['CUSTOM VIP','EVIP','VIP','ETLA','Team Direct']
org_act= spark.sql(''' select distinct contract_offer_type from enterprise.fact_snapshot_org_activation where snapshot_date = '{B2B_RUN_DATE}' and is_valid='Y' '''.format(B2B_RUN_DATE= B2B_RUN_DATE))
org_act_list = org_act.select("contract_offer_type").rdd.flatMap(lambda x: x).collect()
contract_type_list.sort()
org_act_list.sort()
print(contract_type_list)
print(org_act_list)
#body = ''
if contract_type_list == org_act_list:
    print("All Contract_offer_types exists")
    pass
else:
    a = "All Contract_offer_types does not exists in enterprise.fact_snapshot_org_activation\n"
    body = body+a
    #print("All Contract_offer_types does not exists")

# COMMAND ----------

# DBTITLE 1,Count level validation in enterprise.fact_snapshot_org_activation
import numpy as np
import datetime,time
import pyspark.sql.functions as f
from dateutil.relativedelta import relativedelta


prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

org_df = spark.sql(''' select snapshot_date,contract_offer_type,count(org_id) as org_id,count(offer_id) as offer_id,count(contract_id) as contract_id from  enterprise.fact_snapshot_org_activation WHERE snapshot_date in ('{B2B_RUN_DATE}') group by 1,2 order by 2 '''.format(B2B_RUN_DATE = B2B_RUN_DATE))

org_df_prev = spark.sql(''' select snapshot_date,contract_offer_type,count(org_id) as org_id,count(offer_id) as offer_id,count(contract_id) as contract_id from  enterprise.fact_snapshot_org_activation WHERE snapshot_date in ('{prev_week_date}') group by 1,2 order by 2 '''.format(prev_week_date = prev_week_date))

org_df.show()
org_df_prev.show()

final_df = org_df.join(org_df_prev, org_df.contract_offer_type == org_df_prev.contract_offer_type,'inner').select(org_df['contract_offer_type'],f.round(((org_df["org_id"] - org_df_prev["org_id"])/(org_df_prev["org_id"]) * 100),2).alias("org_id"),f.round(((org_df["offer_id"] - org_df_prev["offer_id"])/(org_df_prev["offer_id"]) * 100),2).alias("offer_id"),f.round(((org_df["contract_id"] - org_df_prev["contract_id"])/(org_df_prev["contract_id"]) * 100),2).alias("contract_id"))

df_pandas = final_df.select(final_df.columns[1:]).toPandas()
display(df_pandas)

# COMMAND ----------

# DBTITLE 1,Count level +-4% check
TABLE_NAME='enterprise.fact_snapshot_org_activation'
#body = ''
for x,y in df_pandas.items():
    for z in y:
        if float(z) > 4 or float(z) < -4:
            b= "The table b2b.{TABLE_NAME} has QC ISSUES for {B2B_RUN_DATE} snapshot date\n".format(TABLE_NAME=TABLE_NAME,B2B_RUN_DATE=B2B_RUN_DATE)
            a = "WoW count for {x} is greater than +-4% i.e {z} \n".format(x=x,z=z)
            body = body+a+b
        else:
            pass
# print(len(body))
# if len(body) == 0:
#     pass
# else:
#     send_email(body)

# COMMAND ----------

# DBTITLE 1,Checking records available for latest snapshot
dim_contract_jem= spark.sql(''' select contract_id from ocf_analytics.dim_contract_jem where date(contract_modified_date) = '{YESTERDAY}' '''.format(YESTERDAY= YESTERDAY)).count()
print(dim_contract_jem)
table_6 = 'ocf_analytics.dim_contract_jem'
if dim_contract_jem == 0:
    a = "{table_6} is not refreshed for latest snapshot\n".format(table_6=table_6)
    body = body+a

# COMMAND ----------

# DBTITLE 1,csmb.vw_ccm_pivot4_all validation
pivot4_all= spark.sql(''' 
                      select date_date,
                      sum(if(contract_type = 'EVIP',fwk_end_arr,0)) as EVIP_fwk_end_arr,
                      sum(if(contract_type = 'VIP',fwk_end_arr,0)) as VIP_fwk_end_arr,
                      sum(if(contract_type = 'TEAM_DIRECT',fwk_end_arr,0)) as TEAM_DIRECT_fwk_end_arr
                      from (                      SELECT 
date_date,
CASE
    WHEN STYPE = 'TM' AND pivot.vip_contract != '' AND UPPER(product_config) LIKE '%E' THEN 'EVIP'
    WHEN STYPE = 'TM' AND cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
    WHEN STYPE = 'TM' AND route_to_market= 'RESELLER' THEN 'VIP'
    WHEN STYPE = 'TM' AND route_to_market = 'ADOBE.COM/CC.COM' AND cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
    ELSE 'UNKNOWN'
END AS contract_type,
SUM(try_cast(fwk_end_arr AS DECIMAL(20,0))) AS fwk_end_arr
FROM csmb.vw_ccm_pivot4_all pivot
WHERE date_date in ('{B2B_RUN_DATE}',date_sub('{B2B_RUN_DATE}',7))
AND event_source = 'SNAPSHOT'
AND STYPE = 'TM'
GROUP BY
date_date, 
CASE
	WHEN STYPE = 'TM' AND pivot.vip_contract != '' AND upper(product_config) LIKE '%E' THEN 'EVIP'
	WHEN STYPE = 'TM' AND cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
	WHEN STYPE = 'TM' AND route_to_market= 'RESELLER' THEN 'VIP'
	WHEN STYPE = 'TM' AND route_to_market = 'ADOBE.COM/CC.COM' AND cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
	ELSE 'UNKNOWN'
END
order by 1,2)
group by 1
'''.format(B2B_RUN_DATE= B2B_RUN_DATE))

df_pandas = pivot4_all.select(pivot4_all.columns[1:]).toPandas()
df_pandas.diff()

df_pandas['WoWEVIP_fwk_end_arr'] = np.round(df_pandas['EVIP_fwk_end_arr'].astype('float').pct_change() * 100,2)
df_pandas['WoWVIP_fwk_end_arr'] = np.round(df_pandas['VIP_fwk_end_arr'].astype('float').pct_change() * 100,2)
df_pandas['WoWTEAM_DIRECT_fwk_end_arr'] = np.round(df_pandas['TEAM_DIRECT_fwk_end_arr'].astype('float').pct_change() * 100,2)
df_pandas = df_pandas.dropna()
final_df = df_pandas.iloc[:, 3:]
display(final_df)

pivot_table = 'csmb.vw_ccm_pivot4_all'

for x,y in final_df.items():
    for z in y:
        if float(z) > 10 or float(z) < -10:
            a = "WoW count for {x} is greater than +-10% \n".format(x=x)
            body = body+a
        else:
            pass
print(len(body))
if len(body) == 0:
    pass
else:
    a = "{pivot_table} has data issue\n".format(pivot_table=pivot_table)
    body = body+a

# COMMAND ----------

print(body)
print(len(body))
if len(body) == 0:
    print("B2B PRE VALIDATIONS PASSED")
    pass
else:
    send_email(body)
    raise Exception("B2B PRE VALIDATIONS FAILED")
