from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))
             spark.sql(""" SET hive.exec.dynamic.partition=TRUE """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" INSERT overwrite TABLE b2b.product_offering_map PARTITION (as_of_date)

WITH aos_items AS
(
SELECT d.offer_id,
       fulfillable_product
FROM
    ( SELECT aos.offer_id,
             UPPER(trim(aos.code)) AS fulfillable_product,
             ROW_NUMBER() OVER( PARTITION BY offer_id,code
                                ORDER BY load_date DESC ) AS rownum
      FROM ocf.aos_fulfillable_items aos
      WHERE load_date <= '{B2B_RUN_DATE}' 
      and source ='PROD_OFFERS_API'
	) d
WHERE rownum = 1 
),
archive_offers AS
(
SELECT e.offer_id,
       e.fulfillable_product
FROM
    ( SELECT a.offer_id,
             UPPER (a.fulfillable_product) AS fulfillable_product
      FROM b2b.product_offer_archive a
      UNION ALL 
	  SELECT offer_id,
             UPPER(fulfillable_codes) AS fulfillable_product
      FROM enterprise.scd_offering 
	) e
WHERE e.offer_id NOT IN ( SELECT offer_id FROM aos_items ) 
)
SELECT DISTINCT p.product AS product_name,
                b.offer_id,
                b.fulfillable_product,
                aos.productcode AS sap_product_code,
                cast('{B2B_RUN_DATE}' as date) AS as_of_date
FROM
  (SELECT aos.offer_id,
           aos.fulfillable_product
   FROM aos_items aos
   UNION ALL 
   SELECT offer_id,
          fulfillable_product
   FROM archive_offers) b
LEFT JOIN b2b.fulfillable_product_map p 
ON UPPER(p.fulfillable_product) = b.fulfillable_product
LEFT JOIN enterprise.scd_offering aos 
ON aos.offer_id = b.offer_id """.format(B2B_RUN_DATE = B2B_RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()