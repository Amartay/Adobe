# Databricks notebook source
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

database_host = "10.50.217.133"
database_port = "1433" # update if you use a non-default port
database_name = "uda_finance"
table = "(SELECT [AcctID]  AS accountid ,[AcctType] AS accounttype ,[BusinessUnit] as businessunit ,[ActSegCompKey] as actsegcompkey,[FiscalYrAndWk] as fiscalyrandwk,[FiscalYrAndQtr] as fiscalyrandqtr,[FiscalWkInQtr] as fiscalwkinqtr ,[QuarterlySnapshotFlag] as quarterlysnapshotflag,[DateKey] AS snapshotdatekey ,[GtmAcctSegment]  AS dmegtmsegment ,[ChildKey] as childkey ,[SubStdNameKey] as substdnamekey,[PrntStdNameKey] as prntstdnamekey,[SubName] as subname,[PrntName] as prntname,[CountryCode] as countrycode,[Industry] as industry,NULL as segmentruletype,[NewCustOverRideFlag] as newcustoverrideflag ,[DmuOverRideFlag] as dmuoverrideflag ,[ActiveInd] as activeind,[dmeGtmSegmentMovementQtr] as dmegtmsegmentmovementqtr,[dmeGtmSegmentMovement] as dmegtmsegmentmovement ,[dmeGtmSegmentType] as dmegtmsegmenttype,[LastModified] as lastmodified,[UDAInsertedDate] as udainserteddate, CAST(CAST(CAST((dateadd(d, -((datepart(weekday, GETDATE()) + 1 + @@DATEFIRST) % 7), GETDATE())) AS DATE) as VARCHAR(10)) as date) as as_of_date  FROM [dbo].[vw_GtmConsAcctSegmentWklySnapshot] where [DateKey] = CAST(CAST((dateadd(d, -((datepart(weekday, GETDATE()) + 1 + @@DATEFIRST) % 7), GETDATE())) AS DATE) as VARCHAR(10))) vw_tf_accountsegmentationsnapshot"

user = dbutils.secrets.get(scope="DBX-B2BDNA-APPLICATION", key="ssuser")
password = dbutils.secrets.get(scope="DBX-B2BDNA-APPLICATION", key="sspassword")

url = f"jdbc:sqlserver://{database_host}:{database_port};database={database_name}"
urlSuffix =";authenticationScheme=NTLM;integratedSecurity=true;domain=adobenet;trustServerCertificate=true"
whole_url = url+urlSuffix
print(whole_url)

# COMMAND ----------

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", whole_url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .option("numPartitions", 2000)
    .load()
)

# COMMAND ----------

target_table_name = "b2b.vw_tf_accountsegmentationsnapshot"
spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
remote_table.write.format('parquet').mode("overwrite").insertInto(target_table_name)
