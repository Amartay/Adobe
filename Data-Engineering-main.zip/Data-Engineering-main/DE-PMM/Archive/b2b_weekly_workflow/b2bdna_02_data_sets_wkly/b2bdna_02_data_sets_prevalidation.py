# Databricks notebook source
from datetime import date
from datetime import datetime, timedelta

run_date = date.today()
print(run_date)

# checking if both tables were last loaded on max of 2 days
query = "select count(*) from b2b_stg.b2b_table_audit_log where Table_name in ('b2b_arr','b2b_fact_user_activity') and  Run_date <= '{run_date}'  and Run_date >= (date'{run_date}'-1) ".format(run_date=run_date)

count = spark.sql(query).collect()[0][0]
print(count)
if (count!=2):
    raise Exception("Table is not updated")
else:
    pass