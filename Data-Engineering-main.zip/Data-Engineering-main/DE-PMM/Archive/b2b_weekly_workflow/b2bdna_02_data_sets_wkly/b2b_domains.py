from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.b2b_domains """)
             spark.sql(""" create table b2b.b2b_domains AS
WITH
domains_base AS
(
    SELECT
            CAST(parent_id AS String) AS parent_id,
            CAST(sub_id AS String) AS sub_id,
            CAST(org_id AS String) AS org_id,
            contract_id,
            REPLACE(LOWER(domain), ' ') AS domain,
            datasource
    FROM (
        SELECT
                NULL as parent_id,
                NULL as sub_id,
                SPLIT(ownerident, '@')[0] AS org_id,
                NULL as contract_id,
                domain AS domain,
                'CLAIMED_DOMAIN' as datasource
            FROM enterprise.active_domain
        UNION ALL
        SELECT
                NULL as parent_id,
                NULL as sub_id,
                owning_org_id AS org_id,
                NULL as contract_id,
                name AS domain,
                'CLAIMED_DOMAIN' as datasource
            FROM enterprise.dim_multi_domain 
            WHERE domain_create_date >= '2021-06-17'
        UNION ALL
        SELECT
                prnt_std_name_key AS parent_id,
                sub_std_name_key AS sub_id,
                NULL AS org_id,
                NULL as contract_id,
                website AS domain,
                'SUB_DOMAIN' AS datasource 
            FROM b2b.rv_td_sub
        UNION ALL
        SELECT
                prnt_std_name_key AS parent_id,
                NULL AS sub_id,
                NULL AS org_id,
                NULL as contract_id,
                website AS domain,
                'PARENT_DOMAIN' AS datasource 
            FROM b2b.rv_td_prnt 
        UNION ALL
        SELECT
                NULL AS parent_id,
                NULL AS sub_id,
                org_id,
                NULL as contract_id,
                SPLIT(email, '@')[1] AS domain,
                'IT_ADMINS_DOMAIN' as datasource
            FROM b2b.it_admins
        UNION ALL
        SELECT
                NULL AS parent_id,
                NULL AS sub_id,
                NULL AS org_id,
                contract_id,
                domain,
                'OCF_DIM_DOMAIN' as datasource
            FROM ocf.dim_firmographics
        UNION ALL
        SELECT
                NULL AS parent_id,
                CAST(sub_std_name_key AS String) AS sub_id,
                NULL AS org_id,
                NULL as contract_id,
                coalesce(ecp_domain, ecp_secondlevel_domain) AS domain,
                'GEDI_SUB_DOMAIN' AS datasource 
            FROM gedi_shared.subsidiary_domain
        UNION ALL
        SELECT
                NULL AS parent_id,
                NULL AS sub_id,
                a.owner_identity_id as org_id,
                a.contract_id,
                SPLIT(c.pers_email, '@')[1] as domain,
                'ENROLEE_DOMAIN' AS datasource
            FROM ocf_analytics.dim_user_lvt_profile as c
            LEFT JOIN ocf_analytics.dim_contract as a--changed ocf_analytics.dim_contract_jem to ocf_analytics.dim_contract
                ON a.enrollee_id = c.user_guid
            WHERE lower(a.contract_type) <> 'direct_individual'
        UNION ALL
        SELECT
                NULL AS parent_id,
                NULL AS sub_id,
                orgid AS org_Id,
                NULL as contract_id,
                SPLIT(email, '@')[1] AS domain,
                'MDPD_DOMAIN' as datasource
            FROM mdpd_target.imsrengaservice
            WHERE insertdate >= '2022-01-01'
    )
    WHERE COALESCE (domain, '') <> ''
    AND domain like '%.%'
),
domains AS (
    SELECT  DISTINCT parent_id, sub_id, org_id, contract_id, datasource,
        CASE
            WHEN domain like 'http3a2f2fmobile.%' THEN substr (domain, 18)
            WHEN domain like 'http-download.%'    THEN substr (domain, 15)
            WHEN domain like 'http3a2f2fwww.%'    THEN substr (domain, 15)
            WHEN domain like 'http3a2f2fm.%'      THEN substr (domain, 13)
            WHEN domain like 'http:\corp.%'      THEN substr (domain, 13)
            WHEN domain like 'h_____.www_.%'      THEN substr (domain, 13)
            WHEN domain like 'origin-www2.%'      THEN substr (domain, 13)
            WHEN domain like 'preview.www.%'      THEN substr (domain, 13)
            WHEN domain like 'https:www1.%'       THEN substr (domain, 12)
            WHEN domain like 'https:www2.%'       THEN substr (domain, 12)
            WHEN domain like 'https:www3.%'       THEN substr (domain, 12)
            WHEN domain like 'http:\www.%'       THEN substr (domain, 12)
            WHEN domain like 'htttps:www.%'       THEN substr (domain, 12)
            WHEN domain like 'origin-www.%'       THEN substr (domain, 12)
            WHEN domain like 'origin.www.%'       THEN substr (domain, 12)
            WHEN domain like 'secure-www.%'       THEN substr (domain, 12)
            WHEN domain like 'http3a2f2f%'        THEN substr (domain, 11)
            WHEN domain like 'https:www.%'        THEN substr (domain, 11)
            WHEN domain like 'local-www.%'        THEN substr (domain, 11)
            WHEN domain like 'login.www.%'        THEN substr (domain, 11)
            WHEN domain like 'prods.www.%'        THEN substr (domain, 11)
            WHEN domain like 'http:www.%'         THEN substr (domain, 10)
            WHEN domain like 'httpswww.%'         THEN substr (domain, 10)
            WHEN domain like 'http.www.%'         THEN substr (domain, 10)
            WHEN domain like 'http;www.%'         THEN substr (domain, 10)
            WHEN domain like 'prod.www.%'         THEN substr (domain, 10)
            WHEN domain like 'ttps:www.%'         THEN substr (domain, 10)
            WHEN domain like 'http:www%'          THEN substr (domain,  9)
            WHEN domain like 'httpwww.%'          THEN substr (domain,  9)
            WHEN domain like 'dev-www.%'          THEN substr (domain,  9)
            WHEN domain like 'new.www.%'          THEN substr (domain,  9)
            WHEN domain like 'ttp:www.%'          THEN substr (domain,  9)
            WHEN domain like 'qa-www.%'           THEN substr (domain,  8)
            WHEN domain like 'q-www.%'            THEN substr (domain,  7)
            WHEN domain like 'https:%'            THEN substr (domain,  7)
            WHEN domain like 'http\\%'            THEN substr (domain,  7)
            WHEN domain like 'http:%'             THEN substr (domain,  6)
            WHEN domain like 'www2.%'             THEN substr (domain,  6)
            WHEN domain like '2www.%'             THEN substr (domain,  6)
            WHEN domain like 'hwww.%'             THEN substr (domain,  6)
            WHEN domain like 'www.%'              THEN substr (domain,  5)
            ELSE domain
        END AS domain
    FROM domains_base
),
b2b_orgs AS
(
    SELECT DISTINCT
            opd.contract_key    AS contract_id,
            opd.contract_type   AS contract_type,
            opd.org_id          AS org_id,
            opd.org_name        AS org_name,
            eom.ech_sub_id      AS sub_id,
            eom.ech_sub_name    AS sub_name,
            opd.ech_parent_id   AS parent_id,
            opd.ech_parent_name AS parent_name
    FROM    b2b.b2b_org_pro_del AS opd
        LEFT JOIN b2b.ecp_ecc_org_map AS eom
             ON eom.org_id = opd.org_id
            AND eom.as_of_date = opd.as_of_date
    WHERE   opd.as_of_date = '{B2B_RUN_DATE}'
),
org_based_domains AS
(
    SELECT
            coalesce (d.contract_id, o1.contract_id,   o2.contract_id)   AS contract_id,
            coalesce (               o1.contract_type, o2.contract_type) AS contract_type,
            coalesce (d.org_id,      o1.org_id,        o2.org_id)        AS org_id,
            coalesce (               o1.org_name,      o2.org_name, o3.org_name) AS org_name,
            coalesce (d.sub_id,      o1.sub_id,        o2.sub_id)        AS sub_id,
            coalesce (               o1.sub_name,      o2.sub_name)      AS sub_name,
            coalesce (d.parent_id,   o1.parent_id,     o2.parent_id)     AS parent_id,
            coalesce (               o1.parent_name,   o2.parent_name)   AS parent_name,
            d.datasource AS datasource,
            d.domain     AS domain,
            'Org'        AS association
        FROM domains d
        LEFT JOIN b2b_orgs o1
             ON o1.org_id = d.org_id
            AND o1.contract_id = d.contract_id
        LEFT JOIN b2b_orgs o2
             ON o2.org_id = d.org_id
            AND d.contract_id IS NULL
        LEFT JOIN enterprise.dim_org o3
             ON o3.org_id = d.org_id
        WHERE d.org_id IS NOT NULL
),
sub_based_domains AS
(
    SELECT
            coalesce (d.contract_id, o1.contract_id,   o2.contract_id)   AS contract_id,
            coalesce (               o1.contract_type, o2.contract_type) AS contract_type,
            coalesce (d.org_id,      o1.org_id,        o2.org_id)        AS org_id,
            coalesce (               o1.org_name,      o2.org_name)      AS org_name,
            coalesce (d.sub_id,      o1.sub_id,        o2.sub_id)        AS sub_id,
            coalesce (               o1.sub_name,      o2.sub_name)      AS sub_name,
            coalesce (d.parent_id,   o1.parent_id,     o2.parent_id)        AS parent_id,
            coalesce (               o1.parent_name,   o2.parent_name)   AS parent_name,
            d.datasource AS datasource,
            d.domain     AS domain,
            'Sub'        AS association
        FROM domains d
        LEFT JOIN b2b_orgs o1
             ON o1.sub_id = d.sub_id
            AND o1.contract_id = d.contract_id
        LEFT JOIN b2b_orgs o2
             ON o2.sub_id = d.sub_id
            AND d.contract_id IS NULL
        WHERE d.sub_id IS NOT NULL
),
parent_based_domains AS
(
    SELECT
            coalesce (d.contract_id, o1.contract_id,   o2.contract_id)   AS contract_id,
            coalesce (               o1.contract_type, o2.contract_type) AS contract_type,
            coalesce (d.org_id,      o1.org_id,        o2.org_id)        AS org_id,
            coalesce (               o1.org_name,      o2.org_name)      AS org_name,
            coalesce (d.sub_id,      o1.sub_id,        o2.sub_id)        AS sub_id,
            coalesce (               o1.sub_name,      o2.sub_name)      AS sub_name,
            coalesce (d.parent_id,   o1.parent_id,     o2.parent_id)        AS parent_id,
            coalesce (               o1.parent_name,   o2.parent_name)   AS parent_name,
            d.datasource AS datasource,
            d.domain     AS domain,
            'Parent'     AS association
        FROM domains d
        LEFT JOIN b2b_orgs o1
             ON o1.parent_id = d.parent_id
            AND o1.contract_id = d.contract_id
        LEFT JOIN b2b_orgs o2
             ON o2.parent_id = d.parent_id
            AND d.contract_id IS NULL
        WHERE d.parent_id IS NOT NULL
),
contract_based_domains AS
(
    SELECT
            d.contract_id    AS contract_id,
            o1.contract_type AS contract_type,
            o1.org_id        AS org_id,
            o1.org_name      AS org_name,
            o1.sub_id        AS sub_id,
            o1.sub_name      AS sub_name,
            o1.parent_id     AS parent_id,
            o1.parent_name   AS parent_name,
            d.datasource     AS datasource,
            d.domain         AS domain,
            'Org'            AS association 
        FROM domains d
        LEFT JOIN b2b_orgs o1
             ON o1.contract_id = d.contract_id
        WHERE d.contract_id IS NOT NULL
        AND   d.org_id IS NULL
        AND   d.sub_id IS NULL
        AND   d.parent_id IS NULL
),
org_domains AS
(
    SELECT * FROM org_based_domains      UNION DISTINCT
    SELECT * FROM sub_based_domains      UNION DISTINCT
    SELECT * FROM parent_based_domains   UNION DISTINCT
    SELECT * FROM contract_based_domains
),
lookups AS
(
    SELECT '1.GENERIC' AS category, 'gmail'       AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'hotmail'     AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'adobe'       AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'yahoo'       AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'aol'         AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'msn'         AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'icloud'      AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'protonmail'  AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'outlook'     AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'appleid'     AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'nifty'       AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'libero'      AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'shaw.ca'     AS domain UNION ALL
    SELECT '1.GENERIC' AS category, 'live.com.au' AS domain UNION ALL
    SELECT '2.EDU'     AS category, 'edu'         AS domain UNION ALL
    SELECT '2.EDU'     AS category, 'college'     AS domain UNION ALL
    SELECT '2.EDU'     AS category, 'school'      AS domain UNION ALL
    SELECT '2.EDU'     AS category, 'student'     AS domain UNION ALL
    SELECT '2.EDU'     AS category, 'k12'         AS domain UNION ALL
    SELECT '3.GOV'     AS category, 'gov'         AS domain
),
org_domains_cat AS
(
    SELECT
            od.contract_id,
            od.contract_type,
            od.org_id,
            od.org_name,
            od.sub_id,
            od.sub_name,
            od.parent_id,
            od.parent_name,
            od.datasource,
            od.domain,
            od.association,
            COALESCE (
                MIN (
                    CASE
                        WHEN LOWER(rd.type) = 'generic' THEN '1.GENERIC'
                        ELSE cl.category
                    END
                    ),
                '4.OTHERS') AS domain_category
        FROM org_domains AS od
        LEFT JOIN lookups AS cl
            ON instr(od.domain, cl.domain) > 0
        LEFT JOIN b2b_stg.pl_generic_reseller_domains AS rd
            ON LOWER(rd.domain) = od.domain
        GROUP BY
            od.contract_id,
            od.contract_type,
            od.org_id,
            od.org_name,
            od.sub_id,
            od.sub_name,
            od.parent_id,
            od.parent_name,
            od.datasource,
            od.domain,
            od.association
)
    SELECT
            domain,
            org_id,
            domain_category,
            concat_ws('|',array_sort(collect_set(org_name))) as org_name,
            concat_ws('|',array_sort(collect_set(parent_id))) as parent_id,
            concat_ws('|',array_sort(collect_set(parent_name))) as parent_name,
            concat_ws('|',array_sort(collect_set(sub_id))) as sub_id,
            concat_ws('|',array_sort(collect_set(sub_name))) as sub_name,
            concat_ws('|',array_sort(collect_set(contract_id))) as contract_id,
            concat_ws('|',array_sort(collect_set(contract_type))) as contract_type,
              concat_ws('|',array_sort(collect_set(datasource))) as datasource,
              min (
              CASE datasource
                  WHEN 'CLAIMED_DOMAIN'   THEN 1
                  WHEN 'ENROLEE_DOMAIN'   THEN 2
                  WHEN 'IT_ADMINS_DOMAIN' THEN 3
                  WHEN 'OCF_DIM_DOMAIN'   THEN 4
                  WHEN 'SUB_DOMAIN'       THEN 5
                  WHEN 'PARENT_DOMAIN'    THEN 6
                  WHEN 'MDPD_DOMAIN'      THEN 7
                  WHEN 'GEDI_SUB_DOMAIN'  THEN 8
                  ELSE 9 -- Should never happen
              END
              ) AS confidence_level,
            case
            when array_contains(collect_set(association),'Org') then "TRUE" else "FALSE" end as associated_with_org,
            case
            when array_contains(collect_set(association),'Sub') then "TRUE" else "FALSE" end as associated_with_sub,
            case
            when array_contains(collect_set(association),'Parent') then "TRUE" else "FALSE" end as associated_with_parent
        FROM org_domains_cat
        GROUP BY
            domain,
            org_id,
            domain_category """.format(B2B_RUN_DATE = B2B_RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()

