# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel=TRUE """)
             spark.sql(""" SET hive.exec.reducers.max=50 """)
             spark.sql(""" SET hive.exec.reducers.bytes.per.reducer=1000000 """)
             spark.sql(""" SET hive.optimize.distinct.rewrite=TRUE """)
             spark.sql(""" SET hive.map.aggr=TRUE """)
             spark.sql(""" SET hive.exec.Compress.intermediate=TRUE """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = TRUE """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = TRUE """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = TRUE """)
             spark.sql(""" SET hive.auto.convert.join=TRUE """)
             spark.sql(""" SET hive.merge.mapfiles=TRUE """)
             spark.sql(""" SET hive.merge.mapredfiles=TRUE """)
             spark.sql(""" SET hive.merge.size.per.task=512000000 """)
             spark.sql(""" SET hive.merge.smallfiles.avgsize=512000000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=FALSE """)
             spark.sql(""" SET hive.exec.compress.output=TRUE """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
             spark.sql(""" SET hive.stats.autogather=TRUE """)
             spark.sql(""" SET hive.cbo.enable=TRUE """)
             spark.sql(""" SET hive.compute.query.USING.stats=TRUE """)
             spark.sql(""" SET hive.stats.fetch.column.stats=TRUE """)
             spark.sql(""" SET hive.stats.fetch.partition.stats=TRUE """)
             spark.sql(""" SET hive.exec.dynamic.partition=TRUE """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.dynamic.partition=TRUE """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.support.concurrency = FALSE """)
             spark.sql(""" SET hive.mapred.mode=nonstrict """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.b2b_app_usage partition (as_of_date)
SELECT DISTINCT *
FROM
  (SELECT CASE
              WHEN mm_flag = 'Y' THEN 'MM'
              ELSE dme_acct_segment
          END AS dme_acct_segment,
          contract_type,
          ech_parent_id as ech_parent_id, --removed cast function on 2023-08-31
          ech_parent_name,
          pro.org_id,
          org_name,
          cc_pro,
          jem_contract_id,
          contract_key as contract_key, --removed cast function on 2023-08-31
          end_user_id as end_user_id, --removed cast function on 2023-08-31
          route_to_market,
          cc_phone_vs_web,
          org_country,
          org_geo_description,
          org_market_area_description,
          ech_sub_industry,
          market_segment,
          pro.offering_type,
          pro.offering_name,
          pro.offer_id, 
pro.product_code, 
CASE
    WHEN pro.app_name = 'SPARK' THEN 'ADOBE EXPRESS'
    ELSE pro.app_name
                              END AS app_name,
                              app_seats_provisioned,
                              COUNT(DISTINCT member_guid) AS app_users_delegated,
                              COUNT(DISTINCT activation_guid) AS app_users_activated,
                              cast(COUNT(DISTINCT qau_member_guid) as int) AS app_qalu,
                              cast(COUNT(DISTINCT mau_member_guid) as int) AS app_malu,
                              cast(COUNT(DISTINCT rmau_member_guid) as int) AS app_rmalu,
							  pro.ech_sub_id, 
							  pro.ech_sub_name, 
							  dte.fiscal_yr_and_qtr_desc,
							  dte.fiscal_per_id AS fiscal_mo_order,
							  dte.fiscal_per_name,
							  dte.fiscal_wk_in_qtr,
							  dte.fiscal_wk_in_yr,
                              pro.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681
                              pro.as_of_date
   FROM
     ( SELECT Concat_ws('|',sort_array(collect_set(prov.dme_acct_segment))) AS dme_acct_segment,
              Concat_ws('|',sort_array(collect_set(prov.ech_parent_id))) AS ech_parent_id, 
              Concat_ws('|',sort_array(collect_set(prov.ech_parent_name))) AS ech_parent_name,
              Concat_ws('|',sort_array(collect_set(prov.jem_contract_id))) AS jem_contract_id,
              Concat_ws('|',sort_array(collect_set(prov.contract_key))) AS contract_key, 
              Concat_ws('|',sort_array(collect_set(prov.end_user_id))) AS end_user_id, 
              Concat_ws('|',sort_array(collect_set(prov.route_to_market))) AS route_to_market,
              Concat_ws('|',sort_array(collect_set(prov.cc_phone_vs_web))) AS cc_phone_vs_web,
              Concat_ws('|',sort_array(collect_set(prov.org_country))) AS org_country,
              Concat_ws('|',sort_array(collect_set(prov.org_geo_description))) AS org_geo_description,
              Concat_ws('|',sort_array(collect_set(prov.org_market_area_description))) AS org_market_area_description,
              Concat_ws('|',sort_array(collect_set(prov.mm_flag))) AS mm_flag,
              Concat_ws('|',sort_array(collect_set(prov.ech_sub_industry))) AS ech_sub_industry,
              Concat_ws('|',sort_array(collect_set(prov.market_segment))) AS market_segment,
              contract_type,
              cc_pro,
              m.app_name,
              org_id,
              org_name,
              offering_type,
              prov.offer_id,
              prov.product_name AS product_code, 
              offering_name,
              SUM(cast(local_licensed_qty AS int)) AS app_seats_provisioned,
              prov.ech_sub_id, 
              prov.ech_sub_name,
              prov.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681
              as_of_date
      FROM b2b.b2b_org_pro_del prov
      INNER JOIN
        ( SELECT DISTINCT offer_id,
                          product_name AS app_name
         FROM b2b.product_offering_map
         WHERE as_of_date='{RUN_DATE}'
           AND product_name IS NOT NULL 
           AND product_name NOT LIKE '%RUSH%MOBILE%' 
           AND product_name NOT IN (
 'ACROBATACP_ASSURANCE', 
 'CAPTIVATE', 
 'CAPTURE', 
 'FRAME IO', 
 'FRESCO', 
 'PHOTOSHOP (IPAD)', 
 'PHOTOSHOP API', 
 'NONE', 
 'STOCK', 'SIGN', 
 'OZ', 
 'ADOBE FONTS', 
 'BEHANCE MOBILE', 
 'BEHANCE PUBLISH', 
 'BEHANCE WEB', 
 'CC ASSETS WEB', 
 'CC LIBRARIES', 
 'FIREWORKS', 
 'FLASH BUILDER', 
 'FRESCO (IOS)', 
 'ILLUSTRATOR DRAW', 
 'ILLUSTRATOR(IPAD)', 
 'PHOTOSHOP (ROCKET)', 
 'PHOTOSHOP WEB', 
 'RUSH MOBILE', 
 'SPARK PAGE', 
 'SPARK POST', 
 'SPARK VIDEO', 
 'SPARK WEB', 
 'PRELUDE', 'RUSH', 
 'SPEEDGRADE', 
 'CLOUD-DOCS', 
 'CCLIBRARY', 
 'EDGE ANIMATE', 
 'RUSH MOBILE', 'MUSE') ) m ON prov.offer_id = m.offer_id 
      WHERE prov.as_of_date = '{RUN_DATE}' 
        AND lic_type NOT IN ('FRL' 
 )
        AND upper(offering_name) NOT LIKE '%ALL%APPS%SHARED%DEVICE%' 
        AND upper(offering_name) NOT LIKE '%FONTS%'
        AND upper(offering_name) NOT LIKE '%AUTOMATION%'
        AND upper(offering_name) NOT LIKE '%PDF%SERVICES%' --code change 09-07-23 - B2BDME-4503
      --AND upper(offering_name) NOT LIKE '%FREE%' 
        AND upper(offering_name) != '<UNKNOWN>'
        AND upper(offering_name) NOT LIKE '%SINGLE%APP%'
        AND upper(offering_name) NOT LIKE '%INDESIGN%SERVER%'
        AND offering_type NOT IN ('SIGN',
                                  'STOCK')
      GROUP BY contract_type,
               m.app_name,
               org_id,
               cc_pro,
               offering_type,
               offering_name,
               prov.offer_id,
               prov.product_name,
               org_name,
			   prov.ech_sub_id, 
			   prov.ech_sub_name,
               prov.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681 
               as_of_date) pro
   LEFT JOIN
     ( SELECT DISTINCT org_id,
                       member_guid,
                       contract_offer_type,
                       offering_type,
                       offer_id,
                       offering_name,
                       app_name,
                       as_of_date
      FROM
        ( SELECT org_id,
                 member_guid,
                 contract_offer_type,
                 offering_type,
                 offer_id,
                 offering_name,
                 app_name,
                 as_of_date,
                 ROW_NUMBER() OVER(PARTITION BY org_id,app_name,member_guid
                                   ORDER BY priority,offer_id ASC) AS rownum
         FROM
           ( SELECT DISTINCT u.org_id,
                             member_guid,
                             contract_offer_type,
                             offering_type,
                             pr.offering_name,
                             pr.offer_id,
                             app_name,
                             CASE
                                 WHEN upper(u.offering_name) LIKE '%CREATIVE%CLOUD%DEVICE%HIGHER%' THEN 90
                                 WHEN app_name LIKE '%SUBST%'
                                      AND offering_type = 'SUBST' THEN 5
                                 WHEN app_name LIKE '%SUBST%'
                                      AND offering_type = 'ALL_APPS' THEN 6
                                 WHEN app_name = 'XD'
                                      AND upper(u.offering_name) LIKE '%XD%' THEN 10
                                 WHEN app_name in ('SPARK', 'FIREFLY_AX') -- code change 09-07-23 - B2BDME-4503
                                      AND upper(u.offering_name) LIKE '%EXPRESS%' THEN 16
                                 WHEN app_name LIKE '%PHOTOSHOP%'
                                      AND upper(u.offering_name) LIKE '%PHOTOSHOP%' THEN 21
                                 WHEN app_name LIKE '%PREMIERE%'
                                      AND upper(u.offering_name) LIKE '%PREMIERE%' THEN 23
                                 WHEN app_name LIKE '%AFTER%EFFECTS%'
                                      AND upper(u.offering_name) LIKE '%AFTER%EFFECTS%' THEN 24
                                 WHEN app_name LIKE '%ANIMATE%'
                                      AND upper(u.offering_name) LIKE '%ANIMATE%' THEN 25
                                 WHEN app_name LIKE '%INDESIGN%'
                                      AND upper(u.offering_name) LIKE '%INDESIGN%' THEN 26
                                 WHEN app_name LIKE '%LIGHTROOM%'
                                      AND upper(u.offering_name) LIKE '%LIGHTROOM%' THEN 27
                                 WHEN app_name LIKE '%ILLUSTR%'
                                      AND upper(u.offering_name) LIKE '%ILLUSTR%' THEN 28
                                 WHEN app_name LIKE '%LIGHTROOM%'
                                      AND upper(u.offering_name) LIKE '%LIGHTROOM%' THEN 29
                                 WHEN app_name = 'AUDITION'
                                      AND upper(u.offering_name) LIKE '%AUDITION%' THEN 30
                                 WHEN app_name ='DIMENSION'
                                      AND upper(u.offering_name) LIKE '%DIMENSION%' THEN 31
                                 WHEN app_name IN ('BEHANCE',
                                                   'PORTFOLIO',
                                                   'PHOTOSHOP EXPRESS',
                                                   'PREMIERE RUSH',
                                                   'XD',
                                                   'BRIDGE',
                                                   'SPARK',
                                                   'FIREFLY_AX',
                                                   'FIREFLY_WEB')
                                      AND offering_type = 'ALL_APPS' THEN 35 --code change 09-07-23 - B2BDME-4503
                                 WHEN app_name IN ('BEHANCE',
                                                   'PORTFOLIO',
                                                   'PHOTOSHOP EXPRESS',
                                                   'PREMIERE RUSH',
                                                   'XD',
                                                   'SPARK',
                                                   'FIREFLY_AX',
                                                   'FIREFLY_WEB')
                                      AND upper(u.offering_name) LIKE '%PHOTOSHOP%'THEN 36 --code change 09-07-23 - B2BDME-4503
                                 WHEN offering_type = 'SINGLE_APP' THEN 40
                                 WHEN offering_type LIKE '%ACRO%' THEN 50
                                 WHEN offering_type = 'ALL_APPS' THEN 60
                                 WHEN offering_type = 'OTHERS' THEN 70
                                 WHEN offering_type = 'AX' THEN 75
                                 WHEN offering_type = 'SUBST' THEN 80
                             END AS priority,
                             u.as_of_date
            FROM
              ( SELECT org_id,
                       contract_offer_type,
                       offer_id,
                       offering_name,
                       as_of_date,
                       member_guid
               FROM b2b.b2b_users
               WHERE as_of_date = '{RUN_DATE}' ) u
            INNER JOIN
              ( SELECT DISTINCT org_id,
                                offer_id,
                                contract_type,
                                offering_type,
                                offering_name,
                                as_of_date
               FROM b2b.b2b_org_pro_del pr ) pr ON (u.org_id = pr.org_id
                                                    AND u.as_of_date = pr.as_of_date
                                                    AND u.offer_id = pr.offer_id
                                                    AND u.contract_offer_type = pr.contract_type)
            INNER JOIN
              ( SELECT DISTINCT offer_id,
                                product_name AS app_name
               FROM b2b.product_offering_map
               WHERE as_of_date='{RUN_DATE}' ) m ON u.offer_id = m.offer_id ) a
         GROUP BY org_id,
                  member_guid,
                  contract_offer_type,
                  offering_type,
                  offer_id,
                  offering_name,
                  app_name,
                  priority,
                  as_of_date ) s
      WHERE rownum = 1 ) users ON (pro.org_id = users.org_id
                                   AND pro.contract_type = users.contract_offer_type
                                   AND pro.app_name = users.app_name
                                   AND pro.offer_id = users.offer_id
                                   AND pro.as_of_date = users.as_of_date)
   LEFT JOIN 
     (SELECT DISTINCT activation_guid,
                      qau_member_guid,
                      mau_member_guid,
                      rmau_member_guid,
                      app_name,
                      as_of_date
      FROM b2b.b2b_guid_usage_events_stg
      WHERE as_of_date = '{RUN_DATE}' ) USAGE ON (usage.activation_guid = users.member_guid
                                                   AND usage.app_name = users.app_name)
	LEFT JOIN
	(SELECT DISTINCT date_date,fiscal_yr_and_qtr_desc,fiscal_per_id,fiscal_per_name,fiscal_wk_in_qtr,fiscal_wk_in_yr FROM ids_coredata.dim_date) dte
	ON dte.date_date=pro.as_of_date
   GROUP BY dme_acct_segment,
            contract_type,
            ech_parent_id,
            ech_parent_name,
            pro.org_id,
            org_name,
            cc_pro,
            jem_contract_id,
            contract_key,
            end_user_id,
            route_to_market,
            cc_phone_vs_web,
            org_country,
            org_geo_description,
            org_market_area_description,
            mm_flag,
            ech_sub_industry,
            market_segment,
            pro.app_name,
            pro.offering_type,
            pro.offering_name,
            pro.offer_id, 
			pro.product_code, 
			app_seats_provisioned,
			pro.ech_sub_id, 
			pro.ech_sub_name, 
			dte.fiscal_yr_and_qtr_desc, 
			dte.fiscal_per_id, 
			dte.fiscal_per_name, 
			dte.fiscal_wk_in_qtr, 
			dte.fiscal_wk_in_yr,
            pro.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681 
            pro.as_of_date
   UNION ALL 
   SELECT CASE
                        WHEN mm_flag = 'Y' THEN 'MM'
                        ELSE dme_acct_segment
                    END AS dme_acct_segment,
                    pro.contract_type,
                    ech_parent_id,
                    ech_parent_name,
                    pro.org_id,
                    org_name,
                    cc_pro,
                    jem_contract_id,
                    contract_key,
                    end_user_id,
                    route_to_market,
                    cc_phone_vs_web,
                    org_country,
                    org_geo_description,
                    org_market_area_description,
                    ech_sub_industry,
                    market_segment,
                    pro.offering_type,
                    pro.offering_name,
                    pro.offer_id, 
pro.product_code, 
CASE
    WHEN users.product_name = 'SPARK' THEN 'ADOBE EXPRESS'
    ELSE users.product_name
                              END AS app_name,
                              CAST(COUNT(DISTINCT member_guid) AS int) app_seats_provisioned,
                              CAST(COUNT(DISTINCT member_guid) AS int) app_users_delegated,
                              CAST(COUNT(DISTINCT activation_guid) AS int) app_users_activated,
                              CAST(COUNT(DISTINCT qau_member_guid) AS int) AS app_qalu,
                              CAST(COUNT(DISTINCT mau_member_guid) AS int) AS app_malu,
                              CAST(COUNT(DISTINCT rmau_member_guid) AS int) AS app_rmalu,
							  pro.ech_sub_id, 
							  pro.ech_sub_name, 
							  dte.fiscal_yr_and_qtr_desc,
							  dte.fiscal_per_id AS fiscal_mo_order,
							  dte.fiscal_per_name,
							  dte.fiscal_wk_in_qtr,
							  dte.fiscal_wk_in_yr,
                              pro.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681
                              pro.as_of_date
   FROM
     (SELECT Concat_ws('|',sort_array(collect_set(pro.dme_acct_segment))) AS dme_acct_segment,
             contract_type,
             cc_pro,
             offering_type,
             Concat_ws('|',sort_array(collect_set(pro.ech_parent_id))) AS ech_parent_id, --removed cast function on 2023-08-31
             Concat_ws('|',sort_array(collect_set(pro.ech_parent_name))) AS ech_parent_name,
             org_id,
             org_name,
             product_name AS product_code,
             Concat_ws('|',sort_array(collect_set(pro.jem_contract_id))) AS jem_contract_id,
             Concat_ws('|',sort_array(collect_set(pro.contract_key))) AS contract_key, --removed cast function on 2023-08-31
             Concat_ws('|',sort_array(collect_set(pro.end_user_id))) AS end_user_id, --removed cast function on 2023-08-31
             Concat_ws('|',sort_array(collect_set(pro.route_to_market))) AS route_to_market,
             Concat_ws('|',sort_array(collect_set(pro.cc_phone_vs_web))) AS cc_phone_vs_web,
             Concat_ws('|',sort_array(collect_set(pro.org_country))) AS org_country,
             Concat_ws('|',sort_array(collect_set(pro.org_geo_description))) AS org_geo_description,
             Concat_ws('|',sort_array(collect_set(pro.org_market_area_description))) AS org_market_area_description,
             Concat_ws('|',sort_array(collect_set(pro.mm_flag))) AS mm_flag,
             Concat_ws('|',sort_array(collect_set(pro.ech_sub_industry))) AS ech_sub_industry,
             Concat_ws('|',sort_array(collect_set(pro.market_segment))) AS market_segment,
             offer_id,
             Concat_ws('|',sort_array(collect_set(pro.offering_name))) AS offering_name,
			 pro.ech_sub_id, 
			 pro.ech_sub_name,
             pro.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681 
             as_of_date
      FROM b2b.b2b_org_pro_del pro
      WHERE pro.as_of_date = '{RUN_DATE}' 
        AND contract_type = 'ETLA'
        AND upper(offering_name) LIKE '%SINGLE%APP%'
        AND upper(offering_name) NOT LIKE '%LIGHTROOM%'
      GROUP BY contract_type,
               offer_id,
               org_id,
               cc_pro,
               product_name,
               offering_type,
               org_name,
			   pro.ech_sub_id, 
			   pro.ech_sub_name,
               pro.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681 
               as_of_date) pro
   INNER  JOIN
     (SELECT c.org_id,
             c.offer_id,
             c.contract_offer_type,
             c.member_guid,
             CASE
                 WHEN upper(name) LIKE '%PHOTOSHOP%' THEN 'PHOTOSHOP'
                 WHEN upper(name) LIKE '%PS%' THEN 'PHOTOSHOP'
                 WHEN upper(name) LIKE '%PHOTO%' THEN 'PHOTOSHOP'
                 WHEN upper(name) LIKE '%AI%' THEN 'ILLUSTRATOR'
                 WHEN upper(name) LIKE '%ILLUSTRATOR%' THEN 'ILLUSTRATOR'
                 WHEN upper(name) LIKE '%ILLUS%' THEN 'ILLUSTRATOR'
                 WHEN upper(name) LIKE '%INDESIGN%' THEN 'INDESIGN'
                 WHEN upper(name) LIKE '%ID%' THEN 'INDESIGN'
                 WHEN upper(name) LIKE '%XD%' THEN 'XD'
                 WHEN upper(name) LIKE '%LIGHTROOM%' THEN 'LIGHTROOM CC'
                 WHEN upper(name) LIKE '%LRC%' THEN 'LIGHTROOM CC'
                 WHEN upper(name) LIKE '%RUSH%' THEN 'PREMIERE RUSH'
                 WHEN upper(name) LIKE '%RU%' THEN 'PREMIERE RUSH'
                 WHEN upper(name) LIKE '%ANIMATE%' THEN 'ANIMATE'
                 WHEN upper(name) LIKE '%AN%' THEN 'ANIMATE'
                 WHEN upper(name) LIKE '%AUDITION%' THEN 'AUDITION'
                 WHEN upper(name) LIKE '%AU%' THEN 'AUDITION'
                 WHEN upper(name) LIKE '%PREMIERE%PRO%' THEN 'PREMIERE PRO'
                 WHEN upper(name) LIKE '%PR%' THEN 'PREMIERE PRO'
                 WHEN upper(name) LIKE '%DIMENSION%' THEN 'DIMENSION'
                 WHEN upper(name) LIKE '%AFTER%EFFECT%' THEN 'AFTER EFFECTS'
                 WHEN upper(name) LIKE '%AE%' THEN 'AFTER EFFECTS'
                 WHEN upper(name) LIKE '%DREAMWEAVER%' THEN 'DREAMWEAVER'
                 WHEN upper(name) LIKE '%DW%' THEN 'DREAMWEAVER'
                 WHEN upper(name) LIKE '%INCOPY%' THEN 'INCOPY'
                 WHEN upper(name) LIKE '%IC%' THEN 'INCOPY' 
                 WHEN upper(name) LIKE '%DN%' THEN 'DIMENSION'
                 WHEN upper(name) LIKE '%DIMENSION%' THEN 'DIMENSION'
                 ELSE 'NA'
             END AS product_name,
             c.as_of_date
      FROM b2b.b2b_users c
      INNER JOIN enterprise.scd_group d ON (c.group_id = d.group_id
                                            AND c.org_id = d.org_id)
      WHERE c.contract_offer_type = 'ETLA'
        AND end_dttm >= '2050-01-01'
      UNION ALL SELECT c.org_id,
                       c.offer_id,
                       c.contract_offer_type,
                       c.member_guid,
                       product_name,
                       c.as_of_date
      FROM b2b.b2b_users c
      INNER JOIN b2b.product_offering_map n ON (n.offer_id = c.offer_id
                                                AND n.as_of_date = c.as_of_date)
      WHERE n.product_name IN ('SPARK',
                               'BEHANCE',
                               'XD',
                               'FIREFLY_AX',
                               'FIREFLY_WEB') --code change 09-07-23 - B2BDME-4503
        AND c.contract_offer_type = 'ETLA' ) users ON (pro.org_id = users.org_id
                                                       AND pro.contract_type = users.contract_offer_type
                                                       AND pro.offer_id = users.offer_id
                                                       AND pro.as_of_date = users.as_of_date)
   LEFT JOIN
     (SELECT *
      FROM b2b.b2b_guid_usage_events_stg
      WHERE as_of_date = '{RUN_DATE}')USAGE ON (usage.activation_guid = users.member_guid
                                                 AND usage.source_name = users.product_name
                                                 AND usage.as_of_date = users.as_of_date)
	LEFT JOIN
	(SELECT DISTINCT date_date,fiscal_yr_and_qtr_desc,fiscal_per_id,fiscal_per_name,fiscal_wk_in_qtr,fiscal_wk_in_yr FROM ids_coredata.dim_date) dte
	ON dte.date_date=pro.as_of_date
   WHERE users.product_name != 'NA'
   GROUP BY dme_acct_segment,
            pro.contract_type,
            ech_parent_id,
            ech_parent_name,
            pro.org_id,
            org_name,
            jem_contract_id,
            contract_key,
            end_user_id,
            route_to_market,
            cc_phone_vs_web,
            org_country,
            cc_pro,
            org_geo_description,
            org_market_area_description,
            mm_flag,
            ech_sub_industry,
            market_segment,
            users.product_name,
            pro.offer_id,
            offering_name,
            offering_type,
            product_code,
			pro.ech_sub_id, 
			pro.ech_sub_name, 
			dte.fiscal_yr_and_qtr_desc, 
			dte.fiscal_per_id, 
			dte.fiscal_per_name, 
			dte.fiscal_wk_in_qtr, 
			dte.fiscal_wk_in_yr,
            pro.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681 
            pro.as_of_date) stg """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()
