# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.renga_query_it_admins """)
             spark.sql(""" create table b2b.renga_query_it_admins as
select split(str_to_map(replace(trim('{}' from params),'"',''),',',':')['ROLE_ORG'],'@',1) AS org_id ,member_guid ,str_to_map(replace(trim('{}' from params),'"',''),',',':')['ROLE_CODE'] AS role_type ,event_code ,row_number() over(partition by split(str_to_map(replace(trim('{}' from params),'"',''),',',':')['ROLE_ORG'],'@',1), member_guid, str_to_map(replace(trim('{}' from params),'"',''),',',':')['ROLE_CODE'] order by event_dttm desc ) r_num from enterprise.renga_change_all where member_guid is not null and params is not null and params <> '' and params like '%ROLE_CODE%' and params like '%ROLE_ORG%' """)
             spark.sql(""" drop table if exists b2b.it_admins """)
             spark.sql(""" create table b2b.it_admins AS
select distinct 
    a.org_id
   ,b.member_guid
   ,c.pers_first_name AS firstname
   ,c.pers_last_name AS lastname
   ,LOWER(c.pers_email) AS email
   ,a.org_country
   ,c.language_name
   ,CASE
            WHEN b.role_type = 'ORG_ADMIN'        THEN 'SYSTEM'
            WHEN b.role_type = 'PRODUCT_ADMIN'    THEN 'PRODUCT'
            WHEN b.role_type = 'SUPPORT_ADMIN'    THEN 'SUPPORT'
            WHEN b.role_type = 'LICENSE_ADMIN'    THEN 'PRODUCT_PROFILE'
            WHEN b.role_type = 'STORAGE_ADMIN'    THEN 'STORAGE'
            WHEN b.role_type = 'DEPLOYMENT_ADMIN' THEN 'DEPLOYMENT'
            WHEN b.role_type = 'USER_ADMIN_GRP'   THEN 'USER_GROUP'
            WHEN b.role_type = 'USER_ADMIN_ORG'   THEN 'USER_GROUP'
            WHEN b.role_type = 'USER_GROUP_ADMIN' THEN 'USER_GROUP'
            ELSE b.role_type
        END as role_type
   ,cast(a.as_of_date as date)
from b2b.b2b_org_pro_del a
inner join 
(
	select distinct 
		 substring_index(org_id[0],'@',1) as org_id
		,member_guid
		,UPPER(role_type) as role_type
	from 
		(select * from b2b.renga_query_it_admins
		)
	where r_num = 1 and org_id is not null and role_type is not null
		 and event_code <> 'ROLE_ASSIGN_DELETE'
) b
on a.org_id = b.org_id
inner join ocf_analytics.dim_user_lvt_profile c
on b.member_guid = c.user_guid
   and Upper(c.pers_email) NOT LIKE '%ADOBE.COM'
   AND Upper(c.pers_email) NOT LIKE '%ADOBE-IDENTITY.COM'
where a.as_of_date= '{RUN_DATE}' """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()