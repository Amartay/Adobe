# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET mapreduce.job.maps=5 """)
             spark.sql(""" set hive.exec.reducers.max=50 """)
             spark.sql(""" set hive.exec.reducers.bytes.per.reducer=1000000 """)
             spark.sql(""" set hive.optimize.distinct.rewrite=true """)
             spark.sql(""" SET hive.map.aggr=true """)
             spark.sql(""" SET hive.merge.mapfiles=flase """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
             spark.sql(""" SET hive.exec.Compress.intermediate=true """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
             spark.sql(""" SET hive.auto.convert.join=true """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.cbo.enable=true """)
             spark.sql(""" set hive.compute.query.using.stats=true """)
             spark.sql(""" set hive.stats.fetch.column.stats=true """)
             spark.sql(""" set hive.stats.fetch.partition.stats=true """)
             spark.sql(""" set hive.exec.dynamic.partition=true """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.support.concurrency = false """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" INSERT overwrite TABLE b2b.b2b_deployment_usage PARTITION (as_of_date) 
SELECT DISTINCT
dte.fiscal_yr_and_qtr_desc,
pda.ech_parent_id, 
pda.ech_parent_name, 
pda.org_id,
pda.org_name,
pda.org_country,
pda.org_geo_description, 
pda.org_market_area_description, 
pda.jem_contract_id,
pda.mm_flag, 
pda.offer_id,
pda.contract_type,
pda.market_segment, 
pda.ech_sub_industry, 
pda.offering_type,
pda.offering_name,
pda.cc_pro,
pda.lic_type,
pda.cloud_type,
CASE
	WHEN mm_flag = 'Y' THEN 'MM'
	ELSE dme_acct_segment
END AS dme_acct_segment,
--updated below on 2023-08-31 for B2BDME-4397 -- Start --
case when pda.provisioned is null or pda.provisioned ='' then 0 else pda.provisioned end as provisioned,
case when pda.local_licensed_qty is null or pda.local_licensed_qty ='' then 0 else pda.local_licensed_qty end as local_licensed_qty,
case when pda.delegated is null or pda.delegated ='' then 0 else pda.delegated end as delegated,
case when activated is null or activated ='' then 0 else activated end as activated,
case when mau is null or mau ='' then 0 else mau end as mau,
case when qau is null or qau ='' then 0 else qau end as qau,
case when rmau is null or rmau ='' then 0 else rmau end as rmau,
--updated below on 2023-08-31 for B2BDME-4397 -- End --
pda.contract_key,	
pda.end_user_id,	
pda.route_to_market,	
pda.cc_phone_vs_web,	
pda.ech_sub_id, 
pda.ech_sub_name, 
pda.contract_start_date, 
pda.contract_end_date, 
dte.fiscal_per_id AS fiscal_mo_order, 
dte.fiscal_per_name, 
dte.fiscal_wk_in_qtr, 
dte.fiscal_wk_in_yr, 
pda.ff_sku, -- added on 2023-10-01 Jira B2BDME-4681
pda.as_of_date
FROM
b2b.b2b_org_pro_del pda
LEFT JOIN
(SELECT DISTINCT date_date,fiscal_yr_and_qtr_desc,fiscal_per_id,fiscal_per_name,fiscal_wk_in_qtr,fiscal_wk_in_yr FROM ids_coredata.dim_date) dte  
ON dte.date_date=pda.as_of_date
LEFT JOIN
(
SELECT
u.org_id,
u.offer_id,
u.contract_type,
u.as_of_date,
COUNT(DISTINCT u.activation_guid) AS activated,
COUNT(DISTINCT u.mau_member_guid) AS mau,
COUNT(DISTINCT u.qau_member_guid) AS qau,
COUNT(DISTINCT u.rmau_member_guid) AS rmau
FROM
b2b.b2b_guid_usage_events_stg u 
where (coalesce (sap_product_code, 'N/A') != 'SBST'
        or (
           u.sap_product_code = 'SBST'
            and u.product_name like 'SUBSTANCE%'
        ))
      AND as_of_date = '{RUN_DATE}' 
group by 
u.org_id,
u.offer_id,
u.contract_type,
u.as_of_date
) usrs
ON (pda.org_id=usrs.org_id
AND pda.offer_id=usrs.offer_id
AND pda.contract_type=usrs.contract_type )
AND pda.as_of_date=usrs.as_of_date
WHERE pda.as_of_date='{RUN_DATE}'
AND UPPER(pda.offering_name) NOT LIKE '%ADOBE%SIGN%'
AND (UPPER(pda.offering_name) NOT LIKE '%ACROBAT%SIGN%' OR UPPER(pda.offering_name) LIKE '%ACROBAT%E-SIGN%') 
AND UPPER(pda.offering_name) NOT LIKE '%STOCK%' """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()