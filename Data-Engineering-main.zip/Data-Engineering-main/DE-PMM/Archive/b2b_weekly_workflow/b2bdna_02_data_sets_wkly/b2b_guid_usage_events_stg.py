# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" INSERT overwrite TABLE b2b.b2b_guid_usage_events_stg PARTITION (as_of_date) 
SELECT DISTINCT org_id,
                users.offer_id,
                contract_type,
                product_name,
                source_name,
                app_name,
                sap_product_code,
                activation_guid,
                qau_member_guid,
                mau_member_guid,
                if(mau_member_guid = rmau_member_guid,rmau_member_guid,NULL) AS rmau_member_guid,
                '{B2B_RUN_DATE}' AS as_of_date
FROM
  (SELECT DISTINCT org_id,
                   offer_id,
                   contract_offer_type AS contract_type,
                   member_guid,
                   as_of_date
   FROM b2b.b2b_users
   WHERE as_of_date = '{B2B_RUN_DATE}' ) users
INNER JOIN
  (SELECT DISTINCT sap_product_code,
				   product_name, 
                   offer_id,
                   as_of_date
   FROM b2b.product_offering_map
   WHERE product_name NOT IN ('STOCK',
                              'OZ'))offer_map ON users.offer_id = offer_map.offer_id
AND offer_map.as_of_date = users.as_of_date
INNER JOIN
  (SELECT DISTINCT 
                   source_name,
                   app_name,
                   member_guid AS activation_guid,
                   MAX(CASE
                       WHEN CAST(event_date as date) >= DATE_ADD(cast('{B2B_RUN_DATE}' as date),-90)
                            AND CAST(event_date as date) <= CAST('{B2B_RUN_DATE}' AS DATE) THEN member_guid
                       ELSE NULL
                   END) AS qau_member_guid,
                   MAX(CASE
                       WHEN CAST(event_date as date) >= DATE_ADD(cast('{B2B_RUN_DATE}' as date),-27)
                            AND CAST(event_date as date) <= CAST('{B2B_RUN_DATE}' AS DATE) THEN member_guid
                       ELSE NULL
                   END) AS mau_member_guid,
                   MAX(CASE
                       WHEN CAST(event_date as date) >= DATE_ADD(cast('{B2B_RUN_DATE}' as date),-55)
                            AND CAST(event_date as date) <= DATE_ADD(cast('{B2B_RUN_DATE}' as date),-28) THEN member_guid
                       ELSE NULL
                   END) AS rmau_member_guid
   FROM b2b.b2b_fact_user_activity
   WHERE CAST(event_date as date) BETWEEN DATE_ADD(cast('{B2B_RUN_DATE}' as date),-1094) AND CAST('{B2B_RUN_DATE}' AS DATE) 
   GROUP BY member_guid,app_name,source_name
   )fuat ON users.member_guid = fuat.activation_guid
AND offer_map.product_name = fuat.app_name """.format(B2B_RUN_DATE = B2B_RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()