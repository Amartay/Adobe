from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")
             B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.b2b_org_pro_del partition(as_of_date)
SELECT
ech_parent_id           ,
ech_parent_name         ,
ech_parent_country_name ,
ech_parent_market_area_description,
ech_parent_geo_code     ,
dme_acct_segment        ,
org_id                  ,
org_name                ,
org_geo_description     ,
org_country             ,
org_country_name        ,
org_market_area_code    ,
org_market_area_description,
org_region_code         ,
org_region_description  ,
mm_flag                 , 
ech_sub_industry        , 
cast(contract_start_date as date) as contract_start_date     ,
cast(contract_end_date as date) as contract_end_date       ,
jem_contract_id         ,
contract_key            ,
end_user_id             ,
offer_id                ,
offering_name           ,
product_name            ,
product_name_description,
product_segment         ,
cc_pro			, 
lic_type                ,
route_to_market         ,
cc_phone_vs_web         ,
cloud_type              ,
contract_type           ,
etla_seat_type          ,
offering_type           ,
market_segment          ,
provisioned             ,
local_licensed_qty      ,
delegated               ,
cast(ech_sub_id as bigint) as ech_sub_id,
ech_sub_name,
directory_sync_services, --B2BDME-2527 Adding Directory Sync enabled services 2023-09-06
ff_sku,  --B2BDME-4557 Adding new column 2023-09-06
-- Added on 2023-10-10 Jira B2BDME-2158 -- start--
gac_root_org_id,
gac_root_org_name,
gac_parent_org_id,
gac_parent_org_name,
subscription_account_guid,
-- end --
cast(as_of_date as date) as as_of_date from 
(
SELECT DISTINCT * EXCEPT(rownum) FROM (
SELECT
ech_parent_id,
ech_parent_name,
ech_parent_country_name,
ech_parent_market_area_description,
ech_parent_geo_code,
ech_sub_id, 
ech_sub_name, 
--CASE
--	WHEN dme_acct_segment LIKE '%ENT%' THEN 'ENT'
--	ELSE 'SMB'
--END AS dme_acct_segment,
CASE
	WHEN dme_acct_segment LIKE '%CORP T1%' THEN 'CORP T1'
	WHEN dme_acct_segment LIKE '%ENT%' THEN 'ENT'
	WHEN dme_acct_segment LIKE '%CORP T2%' THEN 'CORP T2'
	ELSE 'SMB'
END AS dme_acct_segment,
act.org_id,
act.org_name,
CASE WHEN (org_geo_description IS NULL OR org_geo_description='' OR org_geo_description='<UNKNOWN>') THEN 'UNKNOWN' ELSE org_geo_description END AS org_geo_description, 
org_country,
org_country_name,
org_market_area_code,
CASE WHEN (org_market_area_description IS NULL OR org_market_area_description='' OR org_market_area_description='<UNKNOWN>' OR org_market_area_description='NULL') THEN 'UNKNOWN' ELSE org_market_area_description END AS org_market_area_description, 
org_region_code,
org_region_description,
contract_start_date,
contract_end_date,
act.contract_id AS jem_contract_id,
contract_key,
end_user_id,
--MIN(act.offer_id) AS offer_id,
act.offer_id AS offer_id,
act.offering_name,
product_name,
product_name_description,
product_segment,
cc_pro,
lic_type,
route_to_market,
--cc_phone_vs_web, -- updated on 2023-10-04 Jira B2BDME-3569
CASE
    WHEN cc_phone_vs_web IS NULL THEN 'N/A'
    WHEN cc_phone_vs_web NOT LIKE '%PHONE%'
         AND cc_phone_vs_web NOT LIKE '%WEB%' THEN 'N/A'
    WHEN cc_phone_vs_web LIKE '%PHONE%'
         AND cc_phone_vs_web LIKE '%WEB%' THEN 'PHONE|WEB'
    WHEN cc_phone_vs_web LIKE '%PHONE%' THEN 'PHONE'
    WHEN cc_phone_vs_web LIKE '%WEB%' THEN 'WEB'
    ELSE cc_phone_vs_web
END AS cc_phone_vs_web,
cloud_type,
contract_type, 
CASE
	WHEN contract_type = 'ETLA' AND etla_seat_type LIKE '%ACCESS%' THEN 'ETLA_ACCESS'
	WHEN contract_type = 'ETLA' AND etla_seat_type LIKE '%HYBRID%' AND NOT regexp_like(upper(etla_seat_type),'ACCESS|STANDARD') THEN 'ETLA_HYBRID'
	WHEN contract_type = 'ETLA' AND etla_seat_type LIKE '%HYBRID%' AND NOT regexp_like(upper(etla_seat_type),'ACCESS') THEN 'ETLA_HYBRID'
	WHEN contract_type = 'ETLA' AND etla_seat_type LIKE '%STANDARD%' AND NOT regexp_like(upper(etla_seat_type),'ACCESS|HYBRID') THEN 'ETLA_STANDARD' 
	ELSE 'NONE'
END AS etla_seat_type,
offering_type, 
ff_sku,  --B2BDME-4557 Adding new column 2023-09-06
CASE  
	WHEN market_segment = 'EDU' THEN 'EDUCATION'
	WHEN market_segment = 'COM' THEN 'COMMERCIAL'
	WHEN (market_segment IS NULL OR market_segment='' OR market_segment='<UNKNOWN>') THEN 'UNKNOWN' ELSE market_segment
END AS market_segment, 
CASE
	WHEN (mm_flag='Y|N' OR mm_flag='N|Y') THEN 'Y'
	WHEN (mm_flag IS NULL OR mm_flag='') THEN 'N'
	ELSE mm_flag 
END AS mm_flag, 
CASE 
	WHEN (ech_sub_industry IS NULL OR market_segment='' OR ech_sub_industry='<UNKNOWN>' OR ech_sub_industry='TBD') THEN 'UNKNOWN' 
	ELSE ech_sub_industry 
END AS ech_sub_industry, 
provisioned,
local_licensed_qty,
delegated, 
dir_sync.directory_sync_services, --B2BDME-2527 Adding Directory Sync enabled services 2023-09-06
--CASE WHEN dir_sync.directory_sync_enabled is null THEN 'N' ELSE dir_sync.directory_sync_enabled END AS directory_sync_enabled,  --B2BDME-2527 Adding Directory Sync enabled services 2023-09-06
snapshot_date AS as_of_date,
-- Added on 2023-10-10 Jira B2BDME-2158 - Start--
COALESCE(gac.gac_root_org_id, 'NONE') AS gac_root_org_id,
COALESCE(gac.gac_root_org_name, 'NONE') AS gac_root_org_name,
COALESCE(gac.gac_parent_org_id, 'NONE') AS gac_parent_org_id,
COALESCE(gac.gac_parent_org_name, 'NONE') AS gac_parent_org_name,
subscription_account_guid,
--End--
row_number() over (partition by act.contract_id,act.org_id,act.offering_name,product_name,contract_type,provisioned,cloud_type,org_name,market_segment,contract_start_date,contract_end_date
	order by offer_id) as rownum--updated on 2023-08-29 for B2BDME-4215
FROM
(
	SELECT 
	act.org_id,
	act.org_name,
	c.geo_description AS org_geo_description,
	drv_cntry.country AS org_country,
	country_name AS org_country_name,
	market_area_code AS org_market_area_code,
	market_area_description AS org_market_area_description,
	region_code AS org_region_code,
	region_description AS org_region_description,
	( split(contract_start_date,' ')[0]) AS contract_start_date,
	( split(contract_end_date,' ')[0]) AS contract_end_date,
	act.contract_id,
	subscription_account_guid,
	act.offer_id,
	act.offering_name,
	Concat_ws('|',sort_array(collect_set(product_name))) AS product_name,
	Concat_ws('|',sort_array(collect_set(product_name_description))) AS product_name_description,
	CASE
		WHEN upper(offering_name) LIKE '%ACROBAT%PRO%' THEN 'ACRO PRO'
		WHEN upper(offering_name) LIKE '%ACROBAT%STANDARD%' THEN 'ACRO STD'
		when upper(offering_name) like '%ACRO%WEB%MOB%' then 'OTHERS'
		WHEN upper(offering_name) LIKE '%DOCUMENT%CLOUD%' THEN 'ACRO PRO'
		WHEN UPPER(offering_name) LIKE '%ALL%APPS%' THEN 'ALL_APPS'
		WHEN regexp_like(UPPER(offering_name),'ADOBE EXPRESS|SPARK|CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD EXPRESS') THEN 'AX'
		--WHEN (UPPER(offering_name) LIKE '%ACRO%' -- Removed on 2023-09-26 Jira B2BDME-4670
		--	  AND UPPER(offering_name) NOT LIKE '%ACROBAT%SIGN%')
		--	 OR UPPER(offering_name) LIKE '%ACROBAT%E-SIGN%' THEN 'ACRO'
		WHEN UPPER(offering_name) LIKE '%STOCK%' THEN 'STOCK'
		WHEN UPPER(offering_name) LIKE '%ADOBE%SIGN%'
			 OR (
				UPPER(offering_name) LIKE '%ACROBAT%SIGN%'
				AND UPPER(offering_name) NOT LIKE '%ACROBAT%E-SIGN%'
				) THEN 'SIGN'
		WHEN UPPER(offering_name) LIKE '%SUBST%' THEN 'SUBST'
		WHEN regexp_like(UPPER(offering_name),'SINGLE|AUDITION|ANIMATE|DIMENSION|DREAM|PHOTO|ILLUS|PRELU|AFTER|INCO|XD|PREMIERE|LIGHT|INDES|FRESCO|MUSE') THEN 'SINGLE_APP'
		ELSE 'OTHERS'
	END AS offering_type,
	CASE 
		WHEN UPPER(offering_name) LIKE '%ADOBE%FIREFLY%' THEN 'YES'
		ELSE 'NO'
		END AS ff_sku, --B2BDME-4557 Adding new column 2023-09-06
	CASE
		WHEN UPPER(offering_name) LIKE '%SUBSTANCE%' THEN 'SUBSTANCE'
		WHEN UPPER(offering_name) LIKE '%PDF%SERVICES%' THEN 'ACROBAT'
		WHEN UPPER(offering_name) LIKE '%DOCUMENT%CLOUD%' THEN 'ACROBAT'
		WHEN (UPPER(offering_name) LIKE '%ACROBAT%' AND UPPER(offering_name) NOT LIKE '%ACROBAT%SIGN%') OR UPPER(offering_name) LIKE '%ACROBAT%E-SIGN%' THEN 'ACROBAT'
		WHEN UPPER(offering_name) LIKE '%ADOBE%SIGN%' OR (UPPER(offering_name) LIKE '%ACROBAT%SIGN%' AND UPPER(offering_name) NOT LIKE '%ACROBAT%E-SIGN%') THEN 'SIGN'
		WHEN (UPPER(offering_name) LIKE '%STOCK%' OR product_name = 'CTSK') THEN 'STOCK'
		WHEN regexp_like(UPPER(offering_name),'ADOBE EXPRESS|SPARK|CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD EXPRESS') THEN 'AX' --B2BDME-4557
		ELSE 'CC'
	END AS product_segment,
	CASE
		WHEN upper(offering_name) like '%PLUS%' then 'PRO PLUS'
		WHEN (
			UPPER(offering_name) LIKE '%PRO%EDITION%'
			OR UPPER(offering_name) IN (
										'SINGLE APP PRO GROUP B',
										'SINGLE APP PRO - ENTERPRISE',
										'SINGLE APP PRO',
										'SINGLE APP PRO GROUP B - ENTERPRISE',
										'ADOBE STOCK IMAGES - PRO'
										)
			)
			AND UPPER(offering_name) NOT LIKE '%ACRO%PRO%' THEN 'PRO'
		ELSE 'NO'
	END AS cc_pro,
	CASE
		WHEN act.cloud_type = 'CCE' THEN 'CC'
		WHEN act.cloud_type = 'DCE' THEN 'DC'
		WHEN (UPPER(act.offering_name) LIKE '%TECHNICAL%' OR UPPER(act.offering_name) LIKE '%ROBO%HELP%' OR UPPER(act.offering_name) LIKE '%CAPTIVATE%' OR UPPER(act.offering_name) LIKE '%FRAME%MAKER%') THEN 'PPBU'
		ELSE cloud_type
	END AS cloud_type,
	CASE
		WHEN UPPER(offering_name) LIKE '%SHARED%DEVICE%' AND UPPER(offering_name) NOT LIKE '%CREATIVE CLOUD SHARED DEVICE ACCESS%' THEN 'SDL'
		WHEN UPPER(offering_name) like 'CREATIVE%STOCK%' then 'NUL'
		WHEN UPPER(offering_name) LIKE '%FRL%OFFLINE%' THEN 'FRL'
		WHEN UPPER(offering_name) LIKE '%FEATURE%RESTRICTED%' THEN 'FRL'
		WHEN (UPPER(offering_name) LIKE '%ADOBE%SIGN%' OR  UPPER(offering_name) LIKE '%ACROBAT%SIGN%') AND UPPER(offering_name) NOT LIKE '%ACROBAT%E-SIGN%' THEN 'SVCS'
		WHEN UPPER(offering_name) LIKE '%STOCK%' THEN 'SVCS'
		WHEN act.contract_offer_type IN ('ETLA','EVIP','CUSTOM VIP') AND (market_segment IN ('GOVERNMENT','COMMERCIAL','COM') OR market_segment IS NULL OR market_segment='<UNKNOWN>' OR market_segment='')
		AND regexp_like(UPPER(offering_name), 'CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD AUTOMATION SERVICES|FREE MEMBERSHIP|FONTS') THEN 'FREE' 
		WHEN act.contract_offer_type IN ('ETLA','EVIP','CUSTOM VIP') AND (market_segment IN ('GOVERNMENT','COMMERCIAL','COM') OR market_segment IS NULL OR market_segment='<UNKNOWN>' OR market_segment='')
		AND regexp_like(UPPER(offering_name), 'ADOBE EXPRESS|SPARK|CREATIVE CLOUD EXPRESS') THEN 'NUL' 
		WHEN act.contract_offer_type IN ('ETLA','EVIP','CUSTOM VIP') AND market_segment IN ('EDUCATION','EDU')
		AND regexp_like(UPPER(offering_name), 'ADOBE EXPRESS|SPARK|CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD EXPRESS|CREATIVE CLOUD AUTOMATION SERVICES|FREE MEMBERSHIP|FONTS') THEN 'FREE'
		ELSE 'NUL'
	END AS lic_type,
	CASE
		WHEN upper(dimc.buying_program) = 'VIPMP' THEN dimc.buying_program 
		WHEN upper(act.contract_offer_type) LIKE '%TEAM%DIRECT%' THEN 'TEAM_DIRECT'
		ELSE act.contract_offer_type
	END AS contract_type,
	--market_segment,
	CASE 
 	WHEN size(market_segment_set) = 1 THEN market_segment
	WHEN size(market_segment_set) > 1
 		 AND cast(market_segment_set as string) LIKE '%COMMERCIAL%' THEN 'COMMERCIAL'
    WHEN size(market_segment_set) > 1
 		 AND cast(market_segment_set as string) LIKE '%GOVERNMENT%' THEN 'GOVERNMENT'
    WHEN size(market_segment_set) > 1
 		 AND cast(market_segment_set as string) LIKE '%EDUCATION%' THEN 'EDUCATION'
	ELSE market_segment
	END AS market_segment,
	provisioned_count AS provisioned,
	local_licensed_qty,
	SUM(delegated) AS delegated,
	snapshot_date,
	SUM(type1_activated_count+type2_activated_count+type3_activated_count+type2e_activation_count+unknown_activation_count) AS activated
	FROM (select *,
	collect_set(market_segment) over (partition by org_id) as market_segment_set
 	from enterprise.fact_snapshot_org_activation
	where snapshot_date= '{RUN_DATE}' and (is_valid='Y' OR org_id='332EF6555697E3357F000101')) act
	left join (
                select
                  distinct contract_id,
                  subscription_account_guid
                from
                  ocf_analytics.scd_license
              ) lic
              ON act.contract_id = lic.contract_id
	left outer join (select contract_id, buying_program from enterprise.dim_contract WHERE buying_program <> '<UNKNOWN>') dimc
	on dimc.contract_id = act.contract_id
	LEFT JOIN ( SELECT DISTINCT ccmpivot.vip_contract 
				FROM csmb.vw_ccm_pivot4_all ccmpivot 
				WHERE event_source ='SNAPSHOT' AND source_type = 'TM' AND date_date = '{RUN_DATE}') pivot_contracts
	ON act.contract_id = pivot_contracts.vip_contract
	AND act.contract_offer_type = 'EVIP'
	AND act.market_segment NOT IN ('EDUCATION','EDU')
	LEFT JOIN 
	(
    select * FROM 
    (
	SELECT 
	a.*,
	row_number() over (PARTITION BY org_id ORDER BY cntry_order ASC) AS rw_num 
	FROM (
			SELECT DISTINCT org_id,country,
			CASE 
				WHEN contract_offer_type='ETLA' THEN 1 
				WHEN contract_offer_type='EVIP' THEN 2
				WHEN contract_offer_type='VIP' THEN  3
				ELSE 1
			END AS cntry_order
			FROM
			enterprise.fact_snapshot_org_activation
			WHERE snapshot_date='{RUN_DATE}' and (is_valid='Y' OR org_id='332EF6555697E3357F000101')
		) a 
     ) fnl   
	WHERE rw_num=1
    ) drv_cntry
	ON act.org_id=drv_cntry.org_id
    LEFT JOIN 
	(
		SELECT 
		u.org_id,
		u.offer_id,
		u.group_id, 
		COUNT(DISTINCT member_guid) AS delegated,
		CASE 
			WHEN UPPER(contract_offer_type)='TEAM_DIRECT' THEN 'TEAM DIRECT' 
			ELSE UPPER(contract_offer_type) 
		END AS contract_offer_type 
		FROM b2b.b2b_users u
		WHERE as_of_date='{RUN_DATE}'
		GROUP BY 
		org_id,
		offer_id,
		u.group_id, 
		CASE 
			WHEN UPPER(contract_offer_type)='TEAM_DIRECT' THEN 'TEAM DIRECT' 
			ELSE UPPER(contract_offer_type) 
		END
	) usrs
	ON act.org_id=usrs.org_id 
    AND act.offer_id=usrs.offer_id
    AND UPPER(IF(dimc.buying_program ='VIPMP',dimc.buying_program,act.contract_offer_type))=usrs.contract_offer_type
	LEFT JOIN ids_coredata.dim_country c 
	ON drv_cntry.country = c.country_code_iso2
	LEFT JOIN 
	(
		SELECT DISTINCT productcode AS product_name,product_name_description, offer_id FROM enterprise.scd_offering o
		LEFT JOIN
		(SELECT DISTINCT product_name,product_name_description FROM b2b.b2b_arr WHERE as_of_date = '{RUN_DATE}') ar 
		ON ar.product_name = o.productcode
	) aos 
	ON act.offer_id = aos.offer_id
  WHERE NOT (
	pivot_contracts.vip_contract IS NULL AND act.contract_offer_type = 'EVIP' AND act.market_segment NOT IN ('EDUCATION','EDU')
	and cast(act.contract_start_date AS DATE) < date_add(cast('{RUN_DATE}' as date),-30)
	)
	GROUP BY 
	act.org_id,
	act.org_name,
	c.geo_description,
	drv_cntry.country,
	country_name,
	market_area_code,
	market_area_description,
	region_code,
	region_description,
	( split(contract_start_date,' ')[0]),
	( split(contract_end_date,' ')[0]),
	act.contract_id,
	act.offer_id,
	offering_name,
	lic.subscription_account_guid,
	snapshot_date,
	CASE
		WHEN upper(offering_name) LIKE '%ACROBAT%PRO%' THEN 'ACRO PRO'
		WHEN upper(offering_name) LIKE '%ACROBAT%STANDARD%' THEN 'ACRO STD'
		when upper(offering_name) like '%ACRO%WEB%MOB%' then 'OTHERS'
		WHEN upper(offering_name) LIKE '%DOCUMENT%CLOUD%' THEN 'ACRO PRO'
		WHEN UPPER(offering_name) LIKE '%ALL%APPS%' THEN 'ALL_APPS'
		WHEN regexp_like(UPPER(offering_name),'ADOBE EXPRESS|SPARK|CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD EXPRESS') THEN 'AX'
		--WHEN (UPPER(offering_name) LIKE '%ACRO%' -- Removed on 2023-09-26 Jira B2BDME-4670
		--	  AND UPPER(offering_name) NOT LIKE '%ACROBAT%SIGN%')
		--	 OR UPPER(offering_name) LIKE '%ACROBAT%E-SIGN%' THEN 'ACRO'
		WHEN UPPER(offering_name) LIKE '%STOCK%' THEN 'STOCK'
		WHEN UPPER(offering_name) LIKE '%ADOBE%SIGN%'
			 OR (
				UPPER(offering_name) LIKE '%ACROBAT%SIGN%'
				AND UPPER(offering_name) NOT LIKE '%ACROBAT%E-SIGN%'
				) THEN 'SIGN'
		WHEN UPPER(offering_name) LIKE '%SUBST%' THEN 'SUBST'
		WHEN regexp_like(UPPER(offering_name),'SINGLE|AUDITION|ANIMATE|DIMENSION|DREAM|PHOTO|ILLUS|PRELU|AFTER|INCO|XD|PREMIERE|LIGHT|INDES|FRESCO|MUSE') THEN 'SINGLE_APP'
		ELSE 'OTHERS'
	END,
		CASE 
		WHEN UPPER(offering_name) LIKE '%ADOBE%FIREFLY%' THEN 'YES'
		ELSE 'NO' --B2BDME-4557 Adding new column 2023-09-06
		END, 
	CASE
		WHEN UPPER(offering_name) LIKE '%SUBSTANCE%' THEN 'SUBSTANCE'
		WHEN UPPER(offering_name) LIKE '%PDF%SERVICES%' THEN 'ACROBAT'
		WHEN UPPER(offering_name) LIKE '%DOCUMENT%CLOUD%' THEN 'ACROBAT'
		WHEN (UPPER(offering_name) LIKE '%ACROBAT%' AND UPPER(offering_name) NOT LIKE '%ACROBAT%SIGN%') OR UPPER(offering_name) LIKE '%ACROBAT%E-SIGN%' THEN 'ACROBAT'
		WHEN UPPER(offering_name) LIKE '%ADOBE%SIGN%' OR (UPPER(offering_name) LIKE '%ACROBAT%SIGN%' AND UPPER(offering_name) NOT LIKE '%ACROBAT%E-SIGN%') THEN 'SIGN'
		WHEN (UPPER(offering_name) LIKE '%STOCK%' OR product_name = 'CTSK') THEN 'STOCK'
		WHEN regexp_like(UPPER(offering_name),'ADOBE EXPRESS|SPARK|CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD EXPRESS') THEN 'AX' --B2BDME-4557
		ELSE 'CC'
	END, 
	CASE
		WHEN upper(offering_name) like '%PLUS%' then 'PRO PLUS'
		WHEN (
			UPPER(offering_name) LIKE '%PRO%EDITION%'
			OR UPPER(offering_name) IN (
										'SINGLE APP PRO GROUP B',
										'SINGLE APP PRO - ENTERPRISE',
										'SINGLE APP PRO',
										'SINGLE APP PRO GROUP B - ENTERPRISE'
										)
			)
			AND UPPER(offering_name) NOT LIKE '%ACRO%PRO%' THEN 'PRO'
		ELSE 'NO'
	END, 
	CASE
		WHEN act.cloud_type = 'CCE' THEN 'CC'
		WHEN act.cloud_type = 'DCE' THEN 'DC'
		WHEN (UPPER(act.offering_name) LIKE '%TECHNICAL%' OR UPPER(act.offering_name) LIKE '%ROBO%HELP%' OR UPPER(act.offering_name) LIKE '%CAPTIVATE%' OR UPPER(act.offering_name) LIKE '%FRAME%MAKER%') THEN 'PPBU'
		ELSE cloud_type
	END,
	CASE
		WHEN UPPER(offering_name) LIKE '%SHARED%DEVICE%' AND UPPER(offering_name) NOT LIKE '%CREATIVE CLOUD SHARED DEVICE ACCESS%' THEN 'SDL'
		WHEN UPPER(offering_name) like 'CREATIVE%STOCK%' then 'NUL'
		WHEN UPPER(offering_name) LIKE '%FRL%OFFLINE%' THEN 'FRL'
		WHEN UPPER(offering_name) LIKE '%FEATURE%RESTRICTED%' THEN 'FRL'
		WHEN (UPPER(offering_name) LIKE '%ADOBE%SIGN%' OR  UPPER(offering_name) LIKE '%ACROBAT%SIGN%') AND UPPER(offering_name) NOT LIKE '%ACROBAT%E-SIGN%' THEN 'SVCS'
		WHEN UPPER(offering_name) LIKE '%STOCK%' THEN 'SVCS'
		WHEN act.contract_offer_type IN ('ETLA','EVIP','CUSTOM VIP') AND (market_segment IN ('GOVERNMENT','COMMERCIAL','COM') OR market_segment IS NULL OR market_segment='<UNKNOWN>' OR market_segment='')
		AND regexp_like(UPPER(offering_name), 'CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD AUTOMATION SERVICES|FREE MEMBERSHIP|FONTS') THEN 'FREE' 
		WHEN act.contract_offer_type IN ('ETLA','EVIP','CUSTOM VIP') AND (market_segment IN ('GOVERNMENT','COMMERCIAL','COM') OR market_segment IS NULL OR market_segment='<UNKNOWN>' OR market_segment='')
		AND regexp_like(UPPER(offering_name), 'ADOBE EXPRESS|SPARK|CREATIVE CLOUD EXPRESS') THEN 'NUL' 
		WHEN act.contract_offer_type IN ('ETLA','EVIP','CUSTOM VIP') AND market_segment IN ('EDUCATION','EDU')
		AND regexp_like(UPPER(offering_name), 'ADOBE EXPRESS|SPARK|CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD EXPRESS|CREATIVE CLOUD AUTOMATION SERVICES|FREE MEMBERSHIP|FONTS') THEN 'FREE'
		ELSE 'NUL'
	END,
	CASE
		WHEN upper(dimc.buying_program) = 'VIPMP' THEN dimc.buying_program 
		WHEN upper(act.contract_offer_type) LIKE '%TEAM%DIRECT%' THEN 'TEAM_DIRECT'
		ELSE act.contract_offer_type
	END,
	market_segment,
	provisioned_count,
	local_licensed_qty,
	CASE 
 	WHEN size(market_segment_set) = 1 THEN market_segment
	WHEN size(market_segment_set) > 1
 		 AND cast(market_segment_set as string) LIKE '%COMMERCIAL%' THEN 'COMMERCIAL'
    WHEN size(market_segment_set) > 1
 		 AND cast(market_segment_set as string) LIKE '%GOVERNMENT%' THEN 'GOVERNMENT'
    WHEN size(market_segment_set) > 1
 		 AND cast(market_segment_set as string) LIKE '%EDUCATION%' THEN 'EDUCATION'
	ELSE market_segment
	END
) act

   --B2BDME-2527 Adding Directory Sync enabled services 2023-09-06
	LEFT JOIN   
    (
    SELECT org_id,
        Concat_ws('|',sort_array(collect_set(service_type))) AS directory_sync_services
        --,SUM(COALESCE(members_synched, 0)) num_directory_sync_enabled
        --CASE WHEN SUM(COALESCE(members_synched, 0)) > 0 THEN 'Y' ELSE 'N' END AS directory_sync_enabled
    FROM enterprise.fact_automated_user_sync_snapshot
    WHERE substring(snapshot_date,1,10) ='{RUN_DATE}' --(SELECT MAX(snapshot_date) FROM enterprise.fact_automated_user_sync_snapshot)
    --AND members_synched > 0
    GROUP BY org_id
    ) dir_sync ON dir_sync.org_id = act.org_id


LEFT JOIN
(
	SELECT 
	org_id,
	Concat_ws('|',sort_array(collect_set(ech_parent_id))) AS ech_parent_id, 
   	Concat_ws('|',sort_array(collect_set(ech_parent_name))) AS ech_parent_name, 
    	Concat_ws('|',sort_array(collect_set(ech_parent_country_name))) AS ech_parent_country_name, 
    	Concat_ws('|',sort_array(collect_set(ech_parent_market_area_description))) AS ech_parent_market_area_description, 
    	Concat_ws('|',sort_array(collect_set(ech_parent_geo_code))) AS ech_parent_geo_code,
		Concat_ws('|',sort_array(collect_set(ech_sub_id))) AS ech_sub_id,  
		Concat_ws('|',sort_array(collect_set(ech_sub_name))) AS ech_sub_name, 
    	Concat_ws('|',sort_array(collect_set(etla_seat_type))) AS etla_seat_type, 
    	Concat_ws('|',sort_array(collect_set(a.contract_key))) AS contract_key, 
    	Concat_ws('|',sort_array(collect_set(a.end_user_id))) AS end_user_id, 
    	Concat_ws('|',sort_array(collect_set(a.cc_phone_vs_web))) AS cc_phone_vs_web, 
    	Concat_ws('|',sort_array(collect_set(a.route_to_market))) AS route_to_market, 
    	Concat_ws('|',sort_array(collect_set(dme_acct_segment))) AS dme_acct_segment, 
	Concat_ws('|',sort_array(collect_set(mm_flag))) AS mm_flag, 
	Concat_ws('|',sort_array(collect_set(ech_sub_industry))) AS ech_sub_industry 
	FROM
	(
		SELECT 
		etla_seat_type,
	        m.contract_key,
        	m.ech_parent_id,
	        m.ech_parent_name,
        	m.ech_parent_country_name,
	        m.ech_parent_market_area_description,
       		m.ech_parent_geo_code,
			m.ech_sub_id, 
			m.ech_sub_name, 
        	org_id,
        	m.end_user_id,
        	route_to_market,
        	cc_phone_vs_web,
        	m.dme_acct_segment,
		m.mm_flag,
		m.ech_sub_industry
      		FROM b2b.ecp_ecc_org_map m
      		LEFT JOIN 
		(
			SELECT 
			etla_seat_type,
			end_user_id,
			route_to_market,
			cc_phone_vs_web 
			FROM b2b.b2b_arr 
			WHERE as_of_date='{RUN_DATE}'
        		GROUP BY etla_seat_type,end_user_id,route_to_market,cc_phone_vs_web 
		) arr 
		ON arr.end_user_id = m.end_user_id
      		WHERE m.as_of_date = '{RUN_DATE}'
		GROUP BY 
		etla_seat_type,
        	m.contract_key,
        	m.ech_parent_id,
        	m.ech_parent_name,
        	m.ech_parent_country_name,
        	m.ech_parent_market_area_description,
        	m.ech_parent_geo_code,
			m.ech_sub_id, 
        	m.ech_sub_name, 
        	org_id,
        	m.end_user_id,
        	route_to_market,
        	cc_phone_vs_web,
        	m.dme_acct_segment,
		m.mm_flag,
		m.ech_sub_industry
	) a
   	GROUP BY 
	org_id
) m 
ON m.org_id = act.org_id

-- Added on 2023-10-10 Jira B2BDME-2158
LEFT JOIN (
  WITH
  gac_hier AS (
    SELECT
        g.root_org_id   AS gac_root_org_id,
        g.parent_org_id AS gac_parent_org_id,
        g.child_org_id  AS org_id,
        COALESCE(ro.org_name, 'NONE') AS gac_root_org_name,
        COALESCE(po.org_name, 'NONE') AS gac_parent_org_name
      FROM enterprise.dim_contract_hierarchy AS g
      LEFT JOIN enterprise.dim_org AS ro
        ON ro.org_id = g.root_org_id
      LEFT JOIN enterprise.dim_org AS po
        ON po.org_id = g.parent_org_id
      WHERE COALESCE(g.root_org_id,'') != '<UNKNOWN>'
        AND COALESCE(g.parent_org_id,'') != 'ADOBE'
        AND COALESCE(g.root_org_id,'') != 'ADOBE'
  ),
  gac_all AS (
    SELECT
        gac_root_org_id,
        gac_root_org_name,
        gac_parent_org_id,
        gac_parent_org_name,
        org_id
      FROM gac_hier
    UNION ALL
    SELECT 
        gac_root_org_id,
        gac_root_org_name,
        gac_root_org_id AS gac_parent_org_id,
        gac_root_org_name AS gac_parent_org_name,
        gac_root_org_id AS org_id
      FROM gac_hier
    UNION ALL
    SELECT
        gac_root_org_id,
        gac_root_org_name,
        gac_parent_org_id,
        gac_parent_org_name,
        gac_parent_org_id AS org_id
      FROM gac_hier
  )
    SELECT
        org_id,
        Concat_ws('|',sort_array(collect_set(gac_root_org_id))) AS gac_root_org_id,
        Concat_ws('|',sort_array(collect_set(gac_root_org_name))) AS gac_root_org_name,
        Concat_ws('|',sort_array(collect_set(gac_parent_org_id))) AS gac_parent_org_id,
        Concat_ws('|',sort_array(collect_set(gac_parent_org_name))) AS gac_parent_org_name
      FROM gac_all
      GROUP BY
        org_id
) gac
ON gac.org_id = act.org_id

WHERE (act.org_name is null or act.org_name = '') or (act.org_name not like 'BANK%OLITA%') 
)
where rownum = 1)
""".format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()
