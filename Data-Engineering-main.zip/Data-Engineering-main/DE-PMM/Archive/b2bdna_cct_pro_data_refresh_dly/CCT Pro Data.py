# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'false') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql(""" insert overwrite table b2b.cct_pro_all_contracts
SELECT  contracts.contract_id,
    contracts.geo,
    contracts.country_code,
    contracts.billing_payment_category,
    contracts.billing_frequency,
    to_date(contracts.anniversary_date) anniversary_date,
    period.fiscal_yr_and_qtr_desc as anniversary_quarter,
    to_date(contracts.previous_anniversary_date) previous_anniversary_date,
    coalesce(bob.bob_flag,'No') bob_flag,
    bob.fiscal_yr_and_qtr_desc bob_qtr,
    sort_array(collect_set(rtm.rtm)) rtm,
    sort_array(collect_set(seats.market_segment)) market_segment,
    sort_array(collect_set(coalesce(puf.puf,'No'))) paid_upfront,
    count(distinct seats.seat_id) AS cct_seat_count,
    count(distinct (CASE 
        WHEN seats.product_name IN ('CTSK','STEL','STKL','STKM','STKS','STOK','STOS') THEN seats.seat_id 
        ELSE null 
        END)) cct_stock_seats,
    count(distinct (CASE 
        WHEN seats.product_name IN ('CAUS','CSAD','CSAE','CSAM','CSDW','CSIC','CSID','CSIL','CSLR','CSPH','CSPM','CSPP','CSXD') THEN seats.seat_id 
        ELSE null 
        END)) cct_pro_seats,
    count(distinct (CASE 
        WHEN seats.product_name IN ('ACRS','APCC','ACRO','APAP','APAS','APSF','ASIG','ECHE','ECHP','ECHG') THEN seats.seat_id 
        ELSE null 
        END)) cct_acrobat_sign_seats,
    count(distinct (CASE 
        WHEN seats.seat_delegation_status = 'ASSIGNED' THEN seats.seat_id 
        ELSE null 
        END)) deployed_seats
FROM ocf_analytics.dim_contract_jem contracts
INNER JOIN (select * 
    from ocf_analytics.dim_seat
    where seat_status = 'ACTIVE SEAT'
    and contract_type != 'DIRECT_INDIVIDUAL') seats
ON seats.contract_id = contracts.contract_id 
INNER JOIN (
    Select * 
    from mdpd_stage.scd_seat_provisioning 
    where enddate_dttm = '9999-12-31 00:00:00' 
    and UPPER(seat_status) = 'ACTIVE'
    and contract_type != 'DIRECT_INDIVIDUAL') active_seats
on seats.seat_id = active_seats.seat_id
and seats.contract_id = active_seats.contract_id
left outer join 
    (select *
    from (select subscription_account_guid, 
            material_number,
            if(cc_phone_vs_web='N/A', 'RESELLER', cc_phone_vs_web) as rtm,
            ROW_NUMBER() OVER(PARTITION BY subscription_account_guid, material_number ORDER BY date_date desc) as rownum
        from csmb.vw_ccm_pivot4_all
        where 1=1
        and subscription_account_guid is not null
        and subscription_account_guid != '') recent_rtm
    where rownum = 1) rtm
on rtm.subscription_account_guid = seats.subscription_account_guid
and rtm.material_number = seats.material_number
left outer join
    (select *,
        'Yes' as puf
    from (select subscription_account_guid,
            material_number,
            ROW_NUMBER() OVER(PARTITION BY subscription_account_guid, material_number ORDER BY date_date desc) as rownum
        from csmb.vw_ccm_pivot4_all
        where 1=1
        and subscription_account_guid is not null
        and subscription_account_guid != ''
        and bill_plan_period = 'YA'
        and entitlement_period_desc = 'ANNUAL') recent_puf
    where rownum = 1) puf
on puf.subscription_account_guid = seats.subscription_account_guid
and puf.material_number = seats.material_number
left outer join
    ids_coredata.dim_date period on to_date(contracts.anniversary_date) = period.date_date
LEFT JOIN 
    (select distinct contract_id,
        fiscal_yr_and_qtr_desc,
        'Yes' bob_flag
    from b2b.dim_bob
    inner join (
        select max(fiscal_yr_and_qtr_desc) qtr
        from b2b.dim_bob) latest_bob
   on dim_bob.fiscal_yr_and_qtr_desc = latest_bob.qtr) bob
on bob.contract_id = contracts.contract_id
group by contracts.contract_id,
    contracts.geo,
    contracts.country_code,
    contracts.billing_payment_category,
    contracts.billing_frequency,
    to_date(contracts.anniversary_date),
    period.fiscal_yr_and_qtr_desc,
    to_date(contracts.previous_anniversary_date),
    coalesce(bob.bob_flag,'No'),
    bob.fiscal_yr_and_qtr_desc """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()