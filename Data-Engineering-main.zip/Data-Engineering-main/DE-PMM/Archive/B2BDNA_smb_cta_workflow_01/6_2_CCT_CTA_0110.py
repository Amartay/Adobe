# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" insert overwrite table b2b.smb_analytics_CCT_active_trialist
select     lvt.email_domain as email_domain,
           lvt.member_guid as member_guid,
           first_dl_date as last_download,
           first_product as last_product
from (	select * from ocf_analytics.scd_member_all_cloud ocf
		where ocf.end_dttm = "9999-12-31 00:00:00" and ocf.member_guid is not null and ocf.member_guid!='' and ocf.paid_or_free = "FREE" ) scd_member
INNER JOIN ( 	select upper(user_guid) member_guid,
				LOWER(regexp_replace (pers_email,'.*@','')) email_domain from ocf_analytics.dim_user_lvt_profile) lvt
ON lvt.member_guid = upper(scd_member.member_guid)
INNER JOIN (select distinct email_domain from cahcsmb.cah_cct_direct_contracts_uqfms_stock_play ) base
on base.email_domain = lvt.email_domain
LEFT OUTER JOIN( select     first_dl.member_guid as member_guid,
							to_date ( first_dl.first_dl_dts ) as first_dl_date,
							first_dl.first_product as first_product
				from   ( select upper(substr(download.member_guid,1,24))  member_guid,
							   download.dl_end_dts as first_dl_dts,
							   coalesce ( product.product_code , '<UNKNOWN>' ) as first_product,
							   row_number () over ( partition by member_guid  order by dl_end_dts desc)  as row_num
						from   ocf_analytics.ccmusg_fact_download_info	  download
						left outer join b2b_stg.dim_product_name product
						on ( upper ( product.source_product_code ) = upper ( download.product_name ) )
						where  dl_end_date >= date_sub(current_date(),40)    
						group by download.member_guid, download.dl_end_dts, product.product_code) first_dl
				where  first_dl.row_num = 1) first_download
ON upper(scd_member.member_guid) = upper(first_download.member_guid) """)
             spark.sql(""" insert overwrite table b2b.smb_analytics_CCT_active_trialist1
select 	A.*,
		B.last_active
from b2b.smb_analytics_CCT_active_trialist A
left outer join (select member_guid,
						max(period_name_desc) as last_active 
				from ccea_prod.dme_member_activity_monthly A
				inner join (select distinct 
									fiscal_yr_and_wk_desc,
									fiscal_wk_ending_date
							from Ids_coredata.dim_date	
							where fiscal_wk_ending_date between date_sub(current_date(),40) and current_date()) B
				on A.period_name_desc = B.fiscal_yr_and_wk_desc
				where user_type IN ('NEW', 'REPEAT', 'REACTIVATED') and measure_type in ('CATEGORY') 
				and measure = 'DESKTOP'
				group by member_guid) B
on A.member_guid = B.member_guid """)
             spark.sql(""" insert overwrite table b2b.smb_analytics_CCT_active_trialist_count
select email_domain,
       count(distinct member_guid) as free_active_user
from b2b.smb_analytics_CCT_active_trialist1 A
where datediff(current_date(),last_download) < 30 or last_active is not null
group by email_domain """)
             spark.sql(""" drop table if exists b2b.smb_cct_cta_data1 """)
             spark.sql(""" create table b2b.smb_cct_cta_data1 as
select  distinct
		A.email_domain,
		A.account_name,
		A.market_area,
		A.count_contract,
		B.cci_count as count_cci_complete,
		B.count_single_app as count_single_app,
		C.free_active_user,
		D.domestic_employees_range_for_msft_excel,
    (case
           when D.domestic_employees_range_for_msft_excel in 
		   ('f.[201-500]','g.[501-1000]','h.[1001-2500]','i.[2501-5000]','j.[5001-10,000]','k.[>10,000]') then '>200'
           when D.domestic_employees_range_for_msft_excel in ('e.[101-200]') then '101-200'
           when D.domestic_employees_range_for_msft_excel in ('a.[0]','b.[1-10]','c.[11-50]','d.[51-100]') then '<=100'
           else 'Other'
    end) as EmployeeSize
from b2b.csam_smb_cta_table_base A
left outer join (select email_domain, 
						count(email) as cci_count,
						count(case when product_name not in ('CCLE','CCSN','CTSK','CISK','CCES') then email else null end) as count_single_app
				from b2b.csam_smb_cci_email_info 
				group by email_domain) B
on upper(A.email_domain) = upper(B.email_domain)
left outer join b2b.smb_analytics_CCT_active_trialist_count C
on upper(A.email_domain) = upper(C.email_domain)
left outer join b2b.gtm_firmographics D
on upper(A.email_domain) = upper(D.domain) """)
             spark.sql(""" drop table if exists b2b.smb_cct_cta_data2 """)
             spark.sql(""" create table b2b.smb_cct_cta_data2 as
select 	distinct
		email_domain,
		account_name,
		market_area,
		count_contract,
		count_cci_complete,
		count_single_app,
		free_active_user,
		domestic_employees_range_for_msft_excel,
		(case 
			when EmployeeSize in ('>200') and ((count_cci_complete >= 10) or (free_active_user >= 5)) then 'High'
			when EmployeeSize in ('101-200') and 
				((count_cci_complete >= 5 and  count_cci_complete <= 9) or (free_active_user >= 2 and free_active_user <= 4)) then 'Medium'
			when (count_cci_complete >= 2 and  count_cci_complete <= 4) then 'Low'
		 else "Other"
		 end) as CCT_CTA
from b2b.smb_cct_cta_data1 """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()