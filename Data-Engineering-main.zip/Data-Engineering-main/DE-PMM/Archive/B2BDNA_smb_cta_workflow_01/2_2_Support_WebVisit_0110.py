# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("JAR_PATH", "")
             dbutils.widgets.text("JAR_NAME_1", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             JAR_PATH = dbutils.widgets.get("JAR_PATH")
             JAR_NAME_1 = dbutils.widgets.get("JAR_NAME_1")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" create temporary function LKP_REAL as 'com.mci.hive.udfs.LKP_ORIGINAL' using jar '{JAR_PATH}/{JAR_NAME_1}' """.format(JAR_PATH = JAR_PATH, JAR_NAME_1 = JAR_NAME_1))
             spark.sql(""" insert overwrite table b2b.VisitOnEnterprisePages
select distinct 
		A.email_domain_full, 
		A.contract_id, 
		A.seat_id, 
		A.member_guid, 
		B.click_date, 
		B.pagename
from b2b.all_domian_contracts_all_seat_detail_all A 
inner join (    select 	member_guid,
			click_date,
			nvl(post_pagename, pagename) as pagename 
			from acometl_shared.web_visits_detailed 
			where member_guid is not null and datediff(current_date(),to_date(click_date))<=90) B 
ON UPPER(substr(trim(A.member_guid),1,24)) = LKP_REAL(B.member_guid,'guid')
inner join acometl_shared.lkp_page_taxonomy C 
on B.pagename=C.pagename 
where C.web_taxonomy_cloud='CC' and C.web_taxonomy_section ='Enterprise' """)
             spark.sql(""" insert overwrite table b2b.VisitOnEnterprisePages_agg
select 	contract_id, 
		count(*) visit_count_in_last_3_months
from b2b.VisitOnEnterprisePages 
where datediff(current_date(),to_date(click_date))<=90
group by contract_id """)
             spark.sql(""" insert overwrite table b2b.VisitOnEnterprisePages_domainagg
select 	email_domain_full, 
		count(*) visit_count_in_last_3_months
from b2b.VisitOnEnterprisePages 
where datediff(current_date(),to_date(click_date))<=90
group by email_domain_full """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()