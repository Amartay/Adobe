# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.acrobat_cct_table """)
             spark.sql(""" create table b2b.acrobat_cct_table as
select 	a.*, 
		b.num_times_seat_added as domain_acro_added_seat_count,
		c.acro_count
from b2b.csam_smb_cta_table_base A
left outer join b2b.domain_level_acro_addCount B
on upper(A.email_domain) = upper(B.email_domain)
left outer join (	SELECT  lvt_profile.email_domain,
							count(distinct(CASE WHEN dim_seat.product_name IN ('ACRS','APCC','ACRO','APAP','APAS','APSF','ASIG') THEN dim_seat.member_guid ELSE null END)) AS acro_count
					FROM 
						(SELECT CASE WHEN seat.member_guid is null or trim(seat.member_guid) = ''  THEN NULL ELSE seat.member_guid END member_guid ,
								seat.contract_type,
								seat.product_name
						FROM ocf_analytics.dim_seat seat
						WHERE seat.contract_type IN ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION') and seat.seat_status = "ACTIVE SEAT" ) dim_seat
						LEFT JOIN (SELECT UPPER(user_guid) user_guid,
									LOWER(regexp_replace (pers_email,'.*@','')) email_domain
									FROM ocf_analytics.dim_user_lvt_profile	 where user_guid is not null and trim(user_guid) !='') lvt_profile
						ON (lvt_profile.user_guid = dim_seat.member_guid)
					GROUP BY lvt_profile.email_domain) C
on upper(A.email_domain) = upper(C.email_domain)
where A.email_domain is not null """)
             spark.sql(""" drop table if exists b2b.acrobat_trials """)
             spark.sql(""" create table b2b.acrobat_trials as
select email_domain,
       count(distinct member_guid) as free_acrobat_users
from b2b.smb_analytics_CCT_active_trialist1 A
where (datediff(current_date(),last_download) < 30 or last_active is not null)
and last_product IN ('ACOM','ACRO','ACRS','APAP','APAS','APCC','APRO','APSF','ASIG')
group by email_domain
having count(distinct member_guid)>0 """)
             spark.sql(""" drop table if exists b2b.smb_acrobat_cta_data1 """)
             spark.sql(""" create table b2b.smb_acrobat_cta_data1 as
select  distinct
			A.email_domain,
			A.account_name,
			A.market_area,
			A.domain_acro_added_seat_count,
			coalesce(A.acro_count,0) acro_count,
			case when C.email_domain is not null then 'Yes' else 'No' end as acro_trial,
			B.domestic_ultimate_core_industry as industry,
			B.domestic_employees_range_for_msft_excel as employee_range_for_msft_excel
from b2b.acrobat_cct_table A 
left outer join b2b.gtm_firmographics B
on upper(A.email_domain) = upper(B.domain)
left outer join b2b.acrobat_trials C
on upper(A.email_domain) = upper(C.email_domain) """)
             spark.sql(""" drop table if exists b2b.smb_acrobat_cta_data2 """)
             spark.sql(""" create table b2b.smb_acrobat_cta_data2 as
select  distinct
		email_domain,
		account_name,
		market_area,
		domain_acro_added_seat_count,
		acro_count,
		acro_trial,
		industry,
		employee_range_for_msft_excel,
		(case when B.License is not null then 'Perpetual' else 'Non_Perpetual' end) as Perpetual_flag
from b2b.smb_acrobat_cta_data1 A
left outer join b2b.acrobat_perpetual_tableau B
on upper(A.email_domain) = upper(B.domains) and A.market_area = B.country """)
             spark.sql(""" drop table if exists b2b.smb_acrobat_cta_data3 """)
             spark.sql(""" create table b2b.smb_acrobat_cta_data3 as
select     Temp.*,
       (case
           when EmployeeSize in ('HighSize') and perpetual_flag = 'Perpetual' and acro_count/total_employees < 0.3 and acro_trial = 'Yes' then "High"
           when EmployeeSize in ('HighSize', 'MedSize') and acro_count/total_employees < 0.3 then "Medium"
           when EmployeeSize in ('LowSize') and 
			(industry = 'Legal' or industry = 'Pharmaceuticals' or industry = 'Pharmaceuticals & Biotech' or industry = 'Healthcare' or 
			industry = 'Computer Software and Services' or industry = 'Business Services' or industry = 'Engineering, Design, Architecture & Planning' or 
			industry = 'Financial Services' or industry = 'Construction' or industry = 'Real Estate' or industry = 'Biotechnology') then "Low"
           else 'Other'
           end) as CTA_Acrobat
from
(select A.*,
    (case
       when employee_range_for_msft_excel='a.[0]' or employee_range_for_msft_excel='b.[1-10]' or employee_range_for_msft_excel='c.[11-50]' or 
			employee_range_for_msft_excel='d.[51-100]' then 'LowSize'
       when employee_range_for_msft_excel='e.[101-200]' then 'MedSize'
       when employee_range_for_msft_excel='f.[201-500]' or employee_range_for_msft_excel='g.[501-1000]' or 
			employee_range_for_msft_excel='h.[1001-2500]' or employee_range_for_msft_excel='i.[2501-5000]' or 
			employee_range_for_msft_excel='j.[5001-10,000]' or employee_range_for_msft_excel='k.[>10,000]' then 'HighSize'
       else 'Others'
       end) as EmployeeSize,
	(case
		when employee_range_for_msft_excel='c.[11-50]' then 10
		when employee_range_for_msft_excel='d.[51-100]' then 50
		when employee_range_for_msft_excel='e.[101-200]' then 100
		when employee_range_for_msft_excel='f.[201-500]' then 200 
		when employee_range_for_msft_excel='g.[501-1000]' then 500 
		when employee_range_for_msft_excel='h.[1001-2500]' then 1000 
		when employee_range_for_msft_excel='i.[2501-5000]' then 2500 
		when employee_range_for_msft_excel='j.[5001-10,000]' then 5000 
		when employee_range_for_msft_excel='k.[>10,000]' then 10000
		else 1
		end) as total_employees
from b2b.smb_acrobat_cta_data2 A) Temp """)
             spark.sql(""" set hive.auto.convert.join = false """)
             spark.sql(""" drop table if exists b2b.smb_acrobat_cta_summary """)
             spark.sql(""" create table b2b.smb_acrobat_cta_summary as	   
select  A.market_area,
        A.domain_acro_added_seat_count,
        A.industry,
        A.employee_range_for_msft_excel,
        A.perpetual_flag,
        A.cta_acrobat,
        count(distinct A.email_domain) as sum_domains
from b2b.smb_acrobat_cta_data3 A
inner join b2b.csam_smb_all_cta_table_stage3 B
on A.email_domain = B.email_domain
group by A.market_area,
        A.domain_acro_added_seat_count,
        A.industry,
        A.employee_range_for_msft_excel,
        A.perpetual_flag,
        A.cta_acrobat """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()