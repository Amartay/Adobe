# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" drop table if exists b2b.smb_cce_renewal_quarter_stage1 """)
             spark.sql(""" create table b2b.smb_cce_renewal_quarter_stage1 as
select 	LOWER(regexp_replace (C.pers_email,'.*@','')) as email_domain_anniversary,
		A.external_contract_id,
		A.anniversary_date,
		A.next_anniversary_date,
		(case when to_date(A.anniversary_date) between current_date() and date_add(current_date(),181) then 1 else 0 end) anniversary_flag,
		(case when to_date(A.next_anniversary_date) between current_date() and date_add(current_date(),181) then 1 else 0 end) next_anniversary_flag,
		D.total_active_seats_today,
		D.is_contract_cancelled
from ocf_analytics.dim_contract_jem A
left outer join ocf_analytics.dim_user_lvt_profile C
on A.enrollee_id = C.user_guid
left outer join b2b.contract_level_agg_all_v1 D
on A.contract_id = D.contract_id
where A.contract_type in ('DIRECT_ORGANIZATION') """)
             spark.sql(""" drop table if exists b2b.smb_cce_renewal_quarter """)
             spark.sql(""" create table b2b.smb_cce_renewal_quarter as
select 	email_domain_anniversary,
		sum(case when anniversary_flag > 0 or next_anniversary_flag > 0 then 1 else 0 end) as NextQuarterRenewal
from b2b.smb_cce_renewal_quarter_stage1
where total_active_seats_today > 0
group by email_domain_anniversary """)
             spark.sql(""" drop table if exists b2b.smb_cce_cta_data1 """)
             spark.sql(""" create table b2b.smb_cce_cta_data1 as
select  distinct
		A.email_domain,
		A.account_name,
		A.market_area,
		A.count_contract,
		B.employee_range_for_msft_excel,
		C.NextQuarterRenewal,
		(case when C.NextQuarterRenewal is not null then 1 else 0 end) as Quarter_flag,
		D.visit_count_in_last_3_months,
		E.avg_engagement_index,
		E.avg_percentile_score,
		F.g_suite,
		F.microsoft_azure,
		F.office_365,
		F.identity_and_access_management as IAM,
		G.cc_complete_count
from b2b.csam_smb_cta_table_base A
left outer join (select distinct domain, domestic_employees_range_for_msft_excel as employee_range_for_msft_excel from b2b.gtm_firmographics) B
on upper(A.email_domain) = upper(B.domain)
left outer join (select * from b2b.smb_cce_renewal_quarter where NextQuarterRenewal > 0) C
on upper(A.email_domain) = upper(C.email_domain_anniversary)
left outer join b2b.VisitOnEnterprisePages_domainagg D
on upper(A.email_domain) = upper(D.email_domain_full)
left outer join b2b.Engagement_score_domain_agg E
on upper(A.email_domain) = upper(E.domain)
left outer join b2b.csam_smb_technographics_data F
on upper(A.email_domain) = upper(F.email_domain)
left outer join (select distinct email_domain, cc_complete_count from b2b.stocks_cct_table) G
on upper(A.email_domain) = upper(G.email_domain) """)
             spark.sql(""" insert overwrite table b2b.smb_cce_cta_data2
select 	A.email_domain,
		A.account_name,
		A.market_area,
		A.count_contract,
		A.employee_range_for_msft_excel,
		A.cc_complete_count,
		A.quarter_flag,
		A.visit_count_in_last_3_months,
		A.avg_engagement_index,
		A.avg_percentile_score,
		A.CEI_Flag,
		A.g_suite,
		A.microsoft_azure,
		A.office_365,
		A.IAM,
		(case
			when EmployeeSize in ('HighSize') and cc_complete_count >= 25 and Quarter_flag = 1 and 
				(lower(g_suite) in ('yes','true') or lower(microsoft_azure) in ('yes','true') or lower(office_365) in ('yes','true') or length(IAM) > 2) then "High"
			when EmployeeSize in ('MidSize', 'HighSize') and cc_complete_count >= 10 and Quarter_flag = 1 and 
				(lower(g_suite) in ('yes','true') or lower(microsoft_azure) in ('yes','true') or lower(office_365) in ('yes','true') or length(IAM) > 2) then "Medium" 
			when EmployeeSize in ('LowSize') and Quarter_flag = 1 then "Low"
			else "Other" end) as CTA_CCE
from (select *,
      (case
           when employee_range_for_msft_excel= 'a.[0]' or employee_range_for_msft_excel = 'b.[1-10]' or employee_range_for_msft_excel= 'c.[11-50]' then 'LowSize'
           when employee_range_for_msft_excel = 'd.[51-100]' or employee_range_for_msft_excel = 'e.[101-200]' then 'MidSize'
           when employee_range_for_msft_excel = 'f.[201-500]' or employee_range_for_msft_excel = 'g.[501-1000]' or 
				employee_range_for_msft_excel = 'h.[1001-2500]' or employee_range_for_msft_excel = 'i.[2501-5000]' or 
				employee_range_for_msft_excel = 'j.[5001-10,000]' or employee_range_for_msft_excel = 'k.[>10,000]' then 'HighSize'
       else 'Other' end) as EmployeeSize,
	   (case
           when avg_percentile_score <= 70 then 'LowCEI'
           when avg_percentile_score > 70 then 'HighCEI'
           else 'Other' end) as CEI_Flag
       from b2b.smb_cce_cta_data1) A """)
             spark.sql(""" insert overwrite table b2b.smb_cce_selected_Domains
select  distinct
        A.email_domain,
        A.account_name,
        A.employee_range_for_msft_excel,
        A.quarter_flag,
        (case when B.email_domain is not null then 'Present' else 'Not Present' end) as presence_flag
from (select *,
      (case
           when employee_range_for_msft_excel= 'a.[0]' or employee_range_for_msft_excel = 'b.[1-10]' or employee_range_for_msft_excel= 'c.[11-50]' then 'LowSize'
           when employee_range_for_msft_excel = 'd.[51-100]' or employee_range_for_msft_excel = 'e.[101-200]' then 'MidSize'
           when employee_range_for_msft_excel = 'f.[201-500]' or employee_range_for_msft_excel = 'g.[501-1000]' or employee_range_for_msft_excel = 'h.[1001-2500]' or employee_range_for_msft_excel = 'i.[2501-5000]' or employee_range_for_msft_excel = 'j.[5001-10,000]' or employee_range_for_msft_excel = 'k.[>10,000]' then 'HighSize'
       else 'Other' end) as EmployeeSize
       from b2b.smb_cce_cta_data1) A
left outer join b2b.csam_smb_technographics_data B
on upper(A.email_domain) = upper(B.email_domain)
where A.Quarter_flag = 1 and (A.EmployeeSize = 'HighSize' or A.EmployeeSize = 'MidSize') """)
             spark.sql(""" insert overwrite table b2b.smb_cce_cta_summary
select 	market_area,
		employee_range_for_msft_excel,
		quarter_flag,
		visit_count_in_last_3_months,
		CEI_Flag,
		CTA_CCE,
		count(email_domain) as count_domain
from b2b.smb_cce_cta_data2
group by market_area,
		employee_range_for_msft_excel,
		quarter_flag,
		visit_count_in_last_3_months,
		CEI_Flag,
		CTA_CCE """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

