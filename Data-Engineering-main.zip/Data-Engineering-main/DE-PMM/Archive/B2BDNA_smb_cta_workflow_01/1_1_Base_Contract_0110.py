# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql("""create or replace table b2b.all_domian_contracts_all as
select  distinct
		contract_id,
		enrollee_id as guid, 
		B.pers_email as email,
		case when B.pers_email IS NULL then 'NA' else split(B.pers_email, "@")[1] end as email_domain_full,
		contract_created_date,
		contract_type,
		billing_payment_category
from ocf_analytics.dim_contract_jem A
left join (select * from ocf_analytics.dim_user_lvt_profile	 x
          where split(x.pers_email, '[\@]')[1] <> 'adobe.com' and LENGTH(x.pers_email)<>0) B
on A.enrollee_id = B.user_guid
where A.contract_type in ('DIRECT_ORGANIZATION') """)
             
             spark.sql("drop table if exists b2b.all_domian_contracts_all_seat_detail_all")
             
             spark.sql("""create or replace table b2b.all_domian_contracts_all_seat_detail_all
select distinct 
		A.email_domain_full
		,A.contract_id
		,A.contract_type
		,A.contract_created_date
		,A.billing_payment_category
		,B.seat_id
		,B.seat_createddate
		,B.seat_status
		,B.seat_delegation_status
		,B.seat_last_modifieddate
		,B.member_guid
		,B.regular_vs_promotion
		,case when mdpd.pers_email IS NULL then NULL else split(mdpd.pers_email, "@")[1]  end as member_domain
		,case when isp.isp_domains is NULL then "N" else "Y" end as member_isp_flag
from b2b.all_domian_contracts_all A
LEFT join ocf_analytics.dim_seat B 
on A.contract_id = B.contract_id
LEFT join (select * from ocf_analytics.dim_user_lvt_profile	 x
          where split(x.pers_email, '[\@]')[1] <> 'adobe.com' and LENGTH(x.pers_email)<>0) mdpd
on B.member_guid=mdpd.user_guid
LEFT JOIN b2b.sai_isp_domains isp 
on isp.isp_domains = split(mdpd.pers_email, "@")[1]
where A.guid is not null and B.contract_type in ('DIRECT_ORGANIZATION') """)
             
             
             spark.sql("drop table if exists b2b.all_domian_contracts_seats_to_start_with")
             
             spark.sql("""create or replace table b2b.all_domian_contracts_seats_to_start_with
select 	email_domain_full,
		contract_id, 
		count(distinct seat_id) seats_start 
from  b2b.all_domian_contracts_all_seat_detail_all 
where datediff(to_date(substr(seat_createddate,1,10)),to_date(substr(contract_created_date,1,10)))<30 
group by email_domain_full,contract_id """)
             
             spark.sql(""" drop table if exists b2b.contract_level_agg_all """)

             spark.sql("""create or replace table b2b.contract_level_agg_all
select 
	email_domain_full
	,contract_id
	,contract_type
	,billing_payment_category
	,min(contract_created_date) contract_created_date
	,count(distinct seat_id ) as total_seats_till_date 
	,datediff(max(seat_createddate),min(contract_created_date)) days_taken
	,count(distinct case when member_domain is NOT NULL  then member_domain end) as distinct_domain_assignment
	,count(distinct case when member_domain is NOT NULL and member_isp_flag =  "Y" then member_domain end) as distinct_ISP_domain_assignment
	,count(distinct case when member_domain is NOT NULL and member_isp_flag =  "N" then member_domain end) as distinct_NONISP_domain_assignment
	,count(distinct case when seat_status='ACTIVE SEAT' then seat_id end) as total_active_seats_today 
	,count(distinct case when seat_status='ACTIVE SEAT' and seat_delegation_status = 'ASSIGNED' then seat_id end) as total_deployed_seats_today
	,count(distinct case when seat_status='CANCELLED SEAT' or seat_status='DECLINED SEAT'  or seat_status='CANCELLING SEAT' then seat_id end) as total_cancelled_seats_today 
	,case when count(distinct case when seat_status='ACTIVE SEAT' then seat_id end) =0 then MAX(to_date(substr(seat_last_modifieddate,1,10))) else NULL end Contract_Cancelled_Date
	,case when count(distinct case when seat_status='ACTIVE SEAT' then seat_id end) =0 then 'Yes' else 'No' end Is_Contract_Cancelled
from b2b.all_domian_contracts_all_seat_detail_all
group by email_domain_full,contract_id,contract_type,billing_payment_category """)
             spark.sql(""" drop table if exists b2b.contract_level_agg_all_v1 """)
             spark.sql(""" create or replace table b2b.contract_level_agg_all_v1 as
select 	A.email_domain_full,
		segment.market_segment,
		A.contract_id,
		B.seats_start,
		case 
				when B.seats_start=0 or B.seats_start is null  then "0" 
				when B.seats_start=1 then "1" 
				when B.seats_start >=2 AND B.seats_start<=5 then "2-5"
				when B.seats_start >=6 AND B.seats_start<=9 then "6-9"
				when B.seats_start >=10 AND B.seats_start<=15 then "10-15"
				when B.seats_start >15 then "Above 15" else "NA" end as start_seat_count_bucket,
		A.contract_type,
		A.billing_payment_category,
		A.contract_created_date,
		A.total_seats_till_date,
		A.distinct_domain_assignment,
		A.distinct_ISP_domain_assignment,
		A.distinct_NONISP_domain_assignment,
		A.days_taken,
		A.total_active_seats_today,
		case 
				when A.total_active_seats_today=0  then "0" 
				when A.total_active_seats_today=1 then "1" 
				when A.total_active_seats_today >=2 AND A.total_active_seats_today<=5 then "2-5"
				when A.total_active_seats_today >=6 AND A.total_active_seats_today<=9 then "6-9"
				when A.total_active_seats_today >=10 AND A.total_active_seats_today<=15 then "10-15"
				when A.total_active_seats_today >15 then "Above 15" else "NA" end as current_seat_count_bucket,
		A.total_deployed_seats_today,
		A.total_cancelled_seats_today,
		A.Contract_Cancelled_Date,
		A.Is_Contract_Cancelled,
		case when isp.isp_domains is NULL then "N" else "Y" end as isp_flag
from b2b.contract_level_agg_all A 
LEFT JOIN b2b.all_domian_contracts_seats_to_start_with B 
on A.contract_id=B.contract_id and A.email_domain_full=B.email_domain_full
LEFT JOIN 
b2b.sai_isp_domains isp 
on isp.isp_domains = A.email_domain_full
left join (select '' email_domain_full, '' market_segment,0 as seat_count, 0 RowRank) segment
on A.email_domain_full = segment.email_domain_full """)
             
             spark.sql("drop table if exists b2b.smb_analytics_market_segment_map")

             spark.sql("""create or replace table b2b.smb_analytics_market_segment_map
select 	email_domain_full,
		market_segment,
		seat_count,
		ROW_NUMBER() over (partition by email_domain_full order by seat_count desc) as RowRank
from
(select A.email_domain_full,
		B.market_segment,
		count(B.seat_id) as seat_count
from b2b.contract_level_agg_all_v1 A
left join ocf_analytics.dim_seat B
on A.contract_id = B.contract_id
where B.seat_status = 'ACTIVE SEAT' and B.seat_delegation_status = 'ASSIGNED' and A.contract_type in ('DIRECT_ORGANIZATION')
group by A.email_domain_full,
		A.contract_id,
		B.market_segment) temp """)
             spark.sql("drop table if exists b2b.contract_level_agg_all_qc")
             spark.sql("""create or replace table b2b.contract_level_agg_all_qc
select contract_id,
       count(distinct email_domain_full) as distinct_domain_cont,
       count(email_domain_full) as domain_cont,
       1 as counter
from b2b.contract_level_agg_all
group by contract_id """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()