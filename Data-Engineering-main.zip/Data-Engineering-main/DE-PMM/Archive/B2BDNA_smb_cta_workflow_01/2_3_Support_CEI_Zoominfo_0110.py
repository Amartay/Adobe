# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.Engagement_score """)
             spark.sql(""" create table  b2b.Engagement_score as 
select 	A.email_domain_full, 
		A.contract_id, 
		A.seat_id, 
		A.member_guid, 
		avg(B.engagement_index) avg_engagement_index, 
		avg(B.percentile_score) avg_percentile_score
from b2b.all_domian_contracts_all_seat_detail_all A 
inner join dsnp_scores.engagement_index B 
on UPPER(substr(trim(A.member_guid),1,24)) = UPPER(substr(trim(B.member_guid),1,24)) 
where B.segment='CCSNcommercial' and B.model_type = 'CCI_CEI' and datediff(current_date(),to_date(B.snapshot_date))<= 90
group by 	A.email_domain_full, 
			A.contract_id, 
			A.seat_id,
			A.member_guid,
			B.subscription_id """)
             spark.sql(""" insert overwrite table b2b.Engagement_score_contract_agg 
select 	contract_id, 
		avg(avg_engagement_index) avg_engagement_index, 
		avg(avg_percentile_score) avg_percentile_score
from b2b.Engagement_score 
group by contract_id """)
             spark.sql(""" insert overwrite table b2b.Engagement_score_domain_agg
select 	email_domain_full as domain, 
		avg(avg_engagement_index) avg_engagement_index, 
		avg(avg_percentile_score) avg_percentile_score
from b2b.Engagement_score 
group by email_domain_full """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()