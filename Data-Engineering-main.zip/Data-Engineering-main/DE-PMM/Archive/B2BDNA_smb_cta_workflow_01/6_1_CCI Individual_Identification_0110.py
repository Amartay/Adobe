# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.all_domian_contracts_individual """)
             spark.sql(""" create table b2b.all_domian_contracts_individual as
select  distinct
		contract_id,
		enrollee_id as guid, 
		B.pers_email as email,
		case when B.pers_email IS NULL then 'NA' else split(B.pers_email, "@")[1] end as email_domain_full,
		contract_created_date,
		contract_type,
		billing_payment_category
from ocf_analytics.dim_contract_jem A
left join (select * from ocf_analytics.dim_user_lvt_profile	 x
          where split(x.pers_email, '[\@]')[1] <> 'adobe.com' and LENGTH(x.pers_email)<>0) B
on A.enrollee_id = B.user_guid
where A.contract_type in ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION','DIRECT_INDIVIDUAL') """)
             spark.sql(""" insert overwrite table b2b.all_domian_contracts_individual_emails1
SELECT 	B.email_domain_full as contract_domain,
		lvt_profile.email_domain,
		lvt_profile.pers_email as email,
		dim_seat.contract_id,
		dim_seat.member_guid,
		dim_seat.contract_type,
		dim_seat.product_name
FROM
(    SELECT CASE WHEN seat.member_guid is null or trim(seat.member_guid) = ''  THEN NULL ELSE seat.member_guid END member_guid ,
			seat.contract_id,
			seat.contract_type,
			seat.product_name
   FROM ocf_analytics.dim_seat seat
   WHERE seat.contract_type IN ('DIRECT_INDIVIDUAL') and seat.seat_status = "ACTIVE SEAT" ) dim_seat
   INNER JOIN b2b.all_domian_contracts_individual B
   on dim_seat.contract_id = B.contract_id
   LEFT OUTER JOIN
       (    SELECT UPPER(user_guid) user_guid,
           LOWER(regexp_replace (pers_email,'.*@','')) email_domain,
           pers_email
           FROM ocf_analytics.dim_user_lvt_profile	 where user_guid is not null and trim(user_guid) !=''
        ) lvt_profile
   ON (lvt_profile.user_guid = dim_seat.member_guid) """)
             spark.sql(""" insert overwrite table b2b.all_domian_contracts_individual_emails_nonISP1
select 	A.*
		,case when isp.isp_domains is NULL then "N" else "Y" end as domain_isp_flag
from b2b.all_domian_contracts_individual_emails1 A
left join b2b.sai_isp_domains isp 
on upper(isp.isp_domains) = upper(A.contract_domain) """)
             spark.sql(""" insert overwrite table b2b.all_domian_contracts_individual_emails_nonISP1_account
select  A.*,
      AC.account_name__c as account_name,
       AC.market_area__c as market_area
from b2b.all_domian_contracts_individual_emails_nonISP1 A
LEFT OUTER JOIN replicn_sfdc.sfdc_post_sales__c AC 
ON A.contract_id = AC.contract_id__c """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()