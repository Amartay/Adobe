# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.all_domian_seats_to_start_with """)
             spark.sql(""" create table  b2b.all_domian_seats_to_start_with as
select 	email_domain_full, 
		count(distinct seat_id) seats_start 
from  b2b.all_domian_contracts_all_seat_detail_all 
group by email_domain_full
having datediff(max(to_date(substr(seat_createddate,1,10))),min(to_date(substr(contract_created_date,1,10))))<30 """)
             spark.sql(""" drop table if exists b2b.all_domian_contracts_to_start_with """)
             spark.sql(""" create table  b2b.all_domian_contracts_to_start_with as
select 	email_domain_full, 
		count(distinct contract_id) contracts_start 
from  b2b.all_domian_contracts_all_seat_detail_all 
group by email_domain_full
having datediff(max(to_date(substr(contract_created_date,1,10))),min(to_date(substr(contract_created_date,1,10))))<30 """)
             spark.sql(""" insert overwrite table b2b.domain_level_agg_all
select 	email_domain_full
		,min(contract_created_date) first_contract_created_date
		,count(distinct contract_id ) as total_contracts_created
		,count(distinct case when contract_type ='DIRECT_ORGANIZATION' then contract_id end ) as Direct_contracts_created
		,count(distinct case when contract_type ='INDIRECT_ORGANIZATION' then contract_id end ) as Inirect_contracts_created
		,count( distinct case when  Is_Contract_Cancelled='Yes' then contract_id  end) as Cancelled_contract_count
		,datediff(max(contract_created_date),min(contract_created_date)) days_taken
		,sum(total_seats_till_date ) as total_seats_till_date 
		,max(days_taken) days_taken_seat
		,sum(total_active_seats_today) total_active_seats_today
		,sum(case when contract_type ='DIRECT_ORGANIZATION' then total_active_seats_today end ) Direct_active_seats_today
		,sum(case when contract_type ='INDIRECT_ORGANIZATION' then total_active_seats_today end ) Indirect_active_seats_today
		,sum(total_deployed_seats_today) total_deployed_seats_today
		,sum(total_cancelled_seats_today ) total_cancelled_seats_today
from b2b.contract_level_agg_all
group by email_domain_full """)
             spark.sql(""" insert overwrite table b2b.domain_level_agg_all_v1
select 	A.email_domain_full,
		segment.market_segment,
		total_contracts_created,
		Direct_contracts_created,
		Inirect_contracts_created,
		Cancelled_contract_count,
		total_contracts_created-Cancelled_contract_count as total_contracts_active,
		C.contracts_start,
		B.seats_start,
		case 
			when B.seats_start=0 or B.seats_start is null  then "0" 
			when B.seats_start=1 then "1" 
			when B.seats_start >=2 AND B.seats_start<=5 then "2-5"
			when B.seats_start >=6 AND B.seats_start<=9 then "6-9"
			when B.seats_start >=10 AND B.seats_start<=15 then "10-15"
			when B.seats_start >15 then "Above 15" else "NA" end as start_seat_count_bucket,
		A.first_contract_created_date,
		A.total_seats_till_date,
		A.days_taken,
		A.total_active_seats_today,
		case 
			when A.total_active_seats_today=0  then "0" 
			when A.total_active_seats_today=1 then "1" 
			when A.total_active_seats_today >=2 AND A.total_active_seats_today<=5 then "2-5"
			when A.total_active_seats_today >=6 AND A.total_active_seats_today<=9 then "6-9"
			when A.total_active_seats_today >=10 AND A.total_active_seats_today<=15 then "10-15"
			when A.total_active_seats_today >15 then "Above 15" else "NA" end as current_seat_count_bucket,
		A.Direct_active_seats_today,
		A.Indirect_active_seats_today,
		A.total_deployed_seats_today,
		A.total_cancelled_seats_today,
		case when isp.isp_domains is NULL then "N" else "Y" end as isp_flag
from b2b.domain_level_agg_all A 
LEFT JOIN b2b.all_domian_seats_to_start_with B 
on A.email_domain_full=B.email_domain_full
LEFT JOIN b2b.all_domian_contracts_to_start_with C
on A.email_domain_full=C.email_domain_full
LEFT JOIN b2b.sai_isp_domains isp 
on isp.isp_domains = A.email_domain_full
left join (select * from b2b.smb_analytics_market_segment_map
			where RowRank = 1) segment
on A.email_domain_full = segment.email_domain_full """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

