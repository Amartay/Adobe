# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" set hive.optimize.skewjoin=true """)
             spark.sql(""" set hive.auto.convert.join=true """)
             spark.sql(""" drop table if exists b2b.SeatAddedInLast12Months """)
             spark.sql(""" create table b2b.SeatAddedInLast12Months as
select 	con.contract_id,
		con.email_domain_full,
		to_date(seat.seat_createddate) seat_add_date, 
		count(distinct  seat.seat_id ) as seat_count
from b2b.contract_level_agg_all con
inner join ocf_analytics.dim_seat seat
on con.contract_id=seat.contract_id 
where seat.contract_type in ('DIRECT_ORGANIZATION') and datediff(current_date(),to_date(seat.seat_createddate))<=364
group by con.contract_id,con.email_domain_full,to_date(seat.seat_createddate) """)
             spark.sql(""" drop table if exists b2b.SeatAddedInLast12Months_agg """)
             spark.sql(""" create table b2b.SeatAddedInLast12Months_agg as
select 	email_domain_full, 
		count(distinct seat_add_date) num_times_seat_added, 
		sum(seat_count) added_seat_count
from b2b.SeatAddedInLast12Months
group by email_domain_full """)
             spark.sql(""" drop table if exists b2b.AcroSeatAddedInLast12Months """)
             spark.sql(""" create table b2b.AcroSeatAddedInLast12Months as
select 	con.contract_id, 
		con.email_domain_full, 
		count(distinct to_date(seat.seat_createddate)) as num_times_seat_added, 
		count(distinct  seat.seat_id ) as seat_count
from b2b.contract_level_agg_all con
inner join ocf_analytics.dim_seat seat 
on con.contract_id=seat.contract_id 
where seat.contract_type in ('DIRECT_ORGANIZATION') AND seat.product_name in ('ACRO','APAP','APCC','ACRS','APRO') AND datediff(current_date(),to_date(seat.seat_createddate))<=364
group by con.contract_id,con.email_domain_full """)
             spark.sql(""" insert overwrite table b2b.domain_level_acro_addCount
select  A.email_domain
        ,sum(B.num_times_seat_added) as num_times_seat_added
        ,sum(B.seat_count) as total_seat_count
from cahcsmb.cah_cct_direct_contracts_uqfms_stock_play A 
left outer join b2b.AcroSeatAddedInLast12Months B
on A.contract_id = B.contract_id
group by A.email_domain """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

