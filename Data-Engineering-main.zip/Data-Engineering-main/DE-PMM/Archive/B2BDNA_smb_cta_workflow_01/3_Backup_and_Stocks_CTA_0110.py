# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET mapred.job.queue.name= root.scheduled.P2 """)
             spark.sql(""" set hive.optimize.skewjoin=true """)
             spark.sql(""" set hive.auto.convert.join=true """)
             spark.sql(""" insert into b2b.csam_smb_all_cta_table_stage1_archive
select *,current_date() archived_date from b2b.csam_smb_all_cta_table_stage1 """)
             spark.sql(""" insert into b2b.csam_smb_all_cta_table_stage2_archive
select *,current_date() archived_date from b2b.csam_smb_all_cta_table_stage2 """)
             spark.sql(""" insert into b2b.csam_smb_cta_table_base_contract_archived 
select *,current_date() archived_date from b2b.csam_smb_cta_table_base_contract """)
             spark.sql(""" drop table if exists b2b.csam_smb_all_cta_table_stage3_archived """)
             spark.sql(""" create table b2b.csam_smb_all_cta_table_stage3_archived as
select *,current_date() archived_date from b2b.csam_smb_all_cta_table_stage3 """)
             spark.sql(""" set hive.support.quoted.identifiers=none """)
             spark.sql(""" insert into b2b.csam_smb_all_cta_table_stage4_intermediate_archived
select *,current_date() archived_date from b2b.csam_smb_all_cta_table_stage4_intermediate """)
             spark.sql(""" insert into b2b.csam_smb_all_cta_table_stage4_intermediate_tableau_archived
select *,current_date() archived_date from b2b.csam_smb_all_cta_table_stage4_intermediate_tableau """)
             spark.sql(""" insert into b2b.smb_stocks_cta_data3_archived
select *,current_date() archived_date from b2b.smb_stocks_cta_data3 """)
             spark.sql(""" insert into b2b.smb_acrobat_cta_data3_archived
select *,current_date() archived_date from b2b.smb_acrobat_cta_data3 """)
             spark.sql(""" insert into b2b.smb_cce_cta_data2_archived
select *,current_date() archived_date from b2b.smb_cce_cta_data2 """)
             spark.sql(""" insert into b2b.smb_cct_cta_data2_archived
select *,current_date() archived_date from b2b.smb_cct_cta_data2 """)
             spark.sql(""" insert into b2b.smb_cct_cta_data1_archived
select *,current_date() archived_date from b2b.smb_cct_cta_data1 """)
             spark.sql(""" insert into b2b.smb_analytics_CCT_active_trialist_count_archived
select *,current_date() archived_date from b2b.smb_analytics_CCT_active_trialist_count """)
             spark.sql(""" insert overwrite table b2b.csam_smb_cta_table_base
SELECT  Base.email_domain,
		AC.account_name__c as account_name,
		AC.market_area__c as market_area,
		count(distinct Base.contract_id) as count_contract
FROM cahcsmb.cah_cct_direct_contracts_uqfms_stock_play Base
LEFT OUTER JOIN replicn_sfdc.sfdc_post_sales__c AC
ON Base.contract_id = AC.contract_id__c
where base.generic_domain_flag = 'N'
group by Base.email_domain,
       AC.account_name__c,
       AC.market_area__c """)
             spark.sql(""" drop table if exists b2b.stocks_cct_table """)
             spark.sql(""" create table b2b.stocks_cct_table as
select 	a.*, 
		b.cc_complete_count
from b2b.csam_smb_cta_table_base A
left outer join (	SELECT  lvt_profile.email_domain,
							count(distinct(CASE WHEN dim_seat.product_name IN ('CCLE') THEN dim_seat.member_guid ELSE null END)) AS cc_complete_count
					FROM 
						(SELECT CASE WHEN seat.member_guid is null or trim(seat.member_guid) = ''  THEN NULL ELSE seat.member_guid END member_guid ,
								seat.contract_type,
								seat.product_name
						FROM ocf_analytics.dim_seat seat
						WHERE seat.contract_type IN ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION') and seat.seat_status = "ACTIVE SEAT" ) dim_seat
						LEFT JOIN (SELECT UPPER(user_guid) user_guid,
									LOWER(regexp_replace (pers_email,'.*@','')) email_domain
									FROM ocf_analytics.dim_user_lvt_profile where user_guid is not null and trim(user_guid) !='') lvt_profile
						ON (lvt_profile.user_guid = dim_seat.member_guid)
					GROUP BY lvt_profile.email_domain) B
on upper(A.email_domain) = upper(B.email_domain) """)
             spark.sql(""" insert overwrite table b2b.smb_stocks_cta_data1
select  distinct
			A.contract_id,
			A.email_domain,
			A.generic_domain_flag,
			(case when C.OverageFlag > 0 then 1 else 0 end) as OverageFlag,
			C.sales_document as overage_sales,
			(stock_large_count + stock_small_count + stock_medium_count) as stock_plans,
			A.stock_cct_count,
			A.stock_others_count,
			A.stock_search,
			A.stock_usage,
			B.stock_competitor_info,
			(case when instr(B.stock_competitor_info,"Yes")>0 then 1 else 0 end) as StockCompetitorFlag
from cahcsmb.cah_cct_direct_contracts_uqfms_stock_play A
left outer join (
    Select distinct email_domain,
        CONCAT('hasgettyimages:',
            (case when lower(getty_images) in ('yes','true') then 'Yes' else 'No' end),'|hasistockphoto:',
            (case when lower(istock) in ('yes','true') then 'Yes' else 'No' end),'|hasshutterstock:',
            (case when lower(shutterstock) in ('yes','true') then 'Yes' else 'No' end))
            as stock_competitor_info
    from b2b.csam_smb_technographics_data
    where lower(getty_images) in ('yes','true') or lower(istock) in ('yes','true') or lower(shutterstock) in ('yes','true')) B
on lower(A.email_domain) = lower(B.email_domain)
left outer join (select contract_id,
                        sum(OverageFlag) as OverageFlag,
                        sum(sales_document) as sales_document
                from b2b.domian_contracts_seat_detail_all_v1
                group by contract_id) C
on A.contract_id = C.contract_id
where generic_domain_flag = 'N' """)
             spark.sql(""" insert overwrite table b2b.smb_stocks_cta_data2
select  A.email_domain,
		A.account_name,
		A.market_area,
		A.count_contract,
		B.StockCompetitorFlag,
		B.stock_search,
		B.stock_usage,
		B.stock_plans,
		B.stock_others_count,
		B.stock_cct_count,
		A.cc_complete_count,
		(case when OverageFlag > 0 then 1 else 0 end) as OverageFlag,
		(case
           when ((stock_search > 0 or stock_usage > 0) and stock_plans = 0) then 1 else 0
		end) as stock_pure_play,
		(case
           when (stock_others_count  > 0 or stock_plans > 0 and stock_cct_count = 0) then 1 else 0
		end) as stock_cci_presence,
		(case
           when (StockCompetitorFlag=1 and stock_search = 0 and stock_usage = 0 and stock_plans = 0) then 1 else 0
		end) as stock_competitor
from b2b.stocks_cct_table A
left outer join (select email_domain,
						sum(case when instr(stock_competitor_info,"Yes")>0 then 1 else 0 end) as StockCompetitorFlag,
						sum(stock_search) as stock_search,
						sum(case when stock_usage is null then 0 else 1 end) as stock_usage,
						sum(stock_plans) as stock_plans,
						sum(OverageFlag) as OverageFlag,
						sum(stock_others_count) as stock_others_count,
						sum(stock_cct_count) as stock_cct_count
				from b2b.smb_stocks_cta_data1
				group by email_domain) B
on A.email_domain = B.email_domain """)
             spark.sql(""" insert overwrite table b2b.smb_stocks_cta_data3
select  A.*,
		(case 
			when OverageFlag = 1 and cc_complete_count >= 1 then "High"
			when (stock_pure_play = 1 or stock_cci_presence = 1) and cc_complete_count > 3 then "Medium"
			when stock_competitor = 1 and cc_complete_count >= 1 then "Low"
			else "Others" 
			end) as CTA_Stock
from b2b.smb_stocks_cta_data2 A """)
             spark.sql(""" SET hive.groupby.orderby.position.alias=true """)
             spark.sql(""" drop table if exists b2b.smb_stocks_cta_summary """)
             spark.sql(""" create table b2b.smb_stocks_cta_summary as
select 	cc_complete_count,
		OverageFlag,
		stock_pure_play,
		stock_cci_presence,
		stock_competitor,
		CTA_Stock,
		count(distinct email_domain) as count_domain
from b2b.smb_stocks_cta_data3
group by 1,2,3,4,5,6 """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()