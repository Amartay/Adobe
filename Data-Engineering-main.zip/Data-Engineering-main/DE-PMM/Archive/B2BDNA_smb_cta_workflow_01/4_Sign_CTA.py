# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" insert overwrite table b2b.sign_cta_base
select 	A.*, 
	B.domestic_ultimate_core_industry as industry,
	B.domestic_employees_range_for_msft_excel as employee_range_for_msft_excel
from b2b.csam_smb_cta_table_base A
left outer join b2b.gtm_firmographics B
on upper(A.email_domain) = upper(B.domain)
where A.email_domain is not null """)
             spark.sql(""" insert overwrite table b2b.sign_cta_data1
select  distinct
	A.email_domain,
	A.account_name,
	A.market_area,
	A.industry,
	A.employee_range_for_msft_excel,
	(case when B.License is not null then 'Perpetual' else 'Non_Perpetual' end) as Perpetual_flag
from b2b.sign_cta_base A 
left outer join b2b.acrobat_perpetual_tableau B
on upper(A.email_domain) = upper(B.domains) and A.market_area = B.country """)
             spark.sql(""" insert overwrite table b2b.sign_cta_data2
select  A.*,
	B.count_sign_cci
from b2b.sign_cta_data1 A
left outer join (select email_domain, 
			count(email) as count_cci,
			count(case when product_name in ('APAS','ASIG','ECHP') then email else null end) as count_sign_cci 
		from b2b.csam_smb_cci_email_info
				group by email_domain) B
on upper(A.email_domain) = upper(B.email_domain) """)
             spark.sql(""" drop table if exists b2b.sign_users """)
             spark.sql(""" create table b2b.sign_users as
select
   upper(split(A.originator_adobe_guid, '@')[0]) as guid,
   B.pers_email as email,
   B.email_domain,
   count(distinct A.agreement_id) as n_agreements,
   count(distinct AE.agreement_id) as agreement_sent_for_esignature
from
   b2b_stg.a_sign_pub_agreement A
left outer join (
	select agreement_id, 
		event 
	from b2b_stg.a_sign_agreement_event
	where event = 'SIGNATURE_REQUESTED') AE
on A.agreement_id = AE.agreement_id 
LEFT OUTER JOIN (   
	SELECT UPPER(user_guid) user_guid,
		LOWER(regexp_replace (pers_email,'.*@','')) email_domain,
		pers_email
    FROM ocf_analytics.dim_user_lvt_profile
	where user_guid is not null 
	and trim(user_guid) !=''  ) B
ON B.user_guid = upper(split(A.originator_adobe_guid, '@')[0])
WHERE
   to_date(A.created) BETWEEN date_sub(CURRENT_DATE(), 365) AND CURRENT_DATE() 
   and A.agreement_should_be_ignored = 0
group by
   upper(split(A.originator_adobe_guid, '@')[0]),
   B.pers_email,
   B.email_domain """)
             spark.sql(""" drop table if exists b2b.sign_power_user_domains """)
             spark.sql(""" create table b2b.sign_power_user_domains as
SELECT email_domain,
		count(distinct case when n_agreements>100 then guid else null end) as power_users,
		count(distinct case when n_agreements>50 and n_agreements<=100 then guid else null end) as moderate_users,
		count(distinct case when n_agreements>20 and n_agreements<=50 then guid else null end) as low_users,
		count(distinct case when agreement_sent_for_esignature>0 then guid else null end) as sent_for_signature_users,
		sum(agreement_sent_for_esignature) total_sent_for_signature
FROM b2b.sign_users
group by email_domain """)
             spark.sql(""" drop table if exists b2b.sign_cta_data3 """)
             spark.sql(""" create table b2b.sign_cta_data3 as
select  A.*,
    B.power_users,
    B.moderate_users,
    B.low_users,
    B.total_sent_for_signature
from b2b.sign_cta_data2 A
left outer join b2b.sign_power_user_domains B
on upper(A.email_domain) = upper(B.email_domain) """)
             spark.sql(""" drop table if exists b2b.sign_cta_data4 """)
             spark.sql(""" create table b2b.sign_cta_data4 as
select     Temp.*,
       (case
           when EmployeeSize in ('>100') and total_sent_for_signature > 0 and power_users >= 2 then 'High'
           when EmployeeSize in ('51-100','>100') and total_sent_for_signature > 0 and (power_users + moderate_users) >= 2  then 'Medium'
           when EmployeeSize in ('51-100','>100') and (power_users + moderate_users + low_users) >=2 and 
				(industry = 'Legal' or industry = 'Pharmaceuticals' or industry = 'Pharmaceuticals & Biotech' or industry = 'Healthcare' or 
				industry = 'Computer Software and Services' or industry = 'Business Services' or 
				industry = 'Engineering, Design, Architecture & Planning' or industry = 'Financial Services' or industry = 'Construction' or 
				industry = 'Real Estate' or industry = 'Biotechnology') then 'Low'
           else 'Other' end) as CTA_Sign
from 
(Select A.*,
    (case
           when employee_range_for_msft_excel in ('e.[101-200]','f.[201-500]','g.[501-1000]','h.[1001-2500]','i.[2501-5000]','j.[5001-10,000]',
'k.[>10,000]') then '>100'
           when employee_range_for_msft_excel in ('d.[51-100]') then '51-100'
           when employee_range_for_msft_excel in ('a.[0]','b.[1-10]','c.[11-50]') then '<=50'
           else 'Other'
    end) as EmployeeSize
from b2b.sign_cta_data3 A) Temp """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()