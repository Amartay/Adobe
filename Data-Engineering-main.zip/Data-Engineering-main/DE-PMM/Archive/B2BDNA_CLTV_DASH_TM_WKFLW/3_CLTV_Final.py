# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET mapred.output.compression.type=BLOCK """)
             spark.sql(""" SET hive.exec.reducers.bytes.per.reducer=268435456 """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" set hive.support.concurrency=false """)
             spark.sql(""" drop table  if exists b2b.gl_cltv_final """)
             spark.sql(""" create table b2b.gl_cltv_final as
select 
pvt.contract_id,
pvt.product_category,
pvt.fiscal_yr_and_per_desc,
max(pvt.gtm_acct_segment) as gtm_acct_segment,
max(pvt.route_to_market) as route_to_market,
max(pvt.cc_phone_vs_web) as cc_phone_vs_web,
max(pvt.geo) as geo,
max(pvt.country_code) as country_code,
max(pvt.market_segment) as market_segment,
max(pvt.fmnth_end_active) as fmnth_end_active,
max(pvt.fmnth_end_arr_cfx) as fmnth_end_arr_cfx,
max(pvt.init_purchase_unit)init_purchase_unit,
max(pvt.init_purchase_arr) as init_purchase_arr,
max(cltv_table.Year_of_Contract) as Year_of_Contract,
max(firmo.employee_range) as employee_range,
max(firmo.revenue_range) as revenue_range,
max(firmo.Industry) as Industry,
max(cltv_table.contract_type) as contract_type,
max(cltv_table.life_time_value) as life_time_value
from (
select distinct a.*,
       b.init_purchase as init_purchase_unit,
       b.init_arr as init_purchase_arr
from b2b.gl_cltv_dash_end_tbl a
left outer join b2b.gl_cltv_dash_init_tbl b on a.contract_id = b.contract_id and a.product_category = b.product_category
)pvt
LEFT OUTER JOIN (
    SELECT substr(subscription_id,0,20) AS contract_id,
                       dim_date.fiscal_yr_and_per_desc, 
                       case when upper(model_subtype) ='DC_CLTV' then 'DC_products'
                            else 'CC_products' end as product_category,
                       max(extra_attr['Year_of_Contract']) AS Year_of_Contract,
                       max(segment) as contract_type,
                       max(life_time_value) as life_time_value
                       from dsnp_scores.cccm_cct_cltv cltv
                       inner join (
                           select date(date_date) as date_date,
                                  fiscal_yr_and_per_desc
                                  from ids_coredata.dim_date
                            where fiscal_yr_desc >= '2021' 
                            and  fiscal_wk_in_per = fiscal_weeks_in_per
                       )dim_date on date(cltv.score_date) = date(dim_date.date_date)
                       group by 1,2,3
)cltv_table on pvt.contract_id = cltv_table.contract_id 
           and pvt.fiscal_yr_and_per_desc = cltv_table.fiscal_yr_and_per_desc 
           and pvt.product_category = cltv_table.product_category
LEFT OUTER JOIN (SELECT distinct contract_id, employee_range,industry,revenue_range FROM b2b.sp_firmographics_smb_contract_details) firmo ON firmo.contract_id = pvt.contract_id 
group by 1,2,3 """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

