# Databricks notebook source
# from pyspark import SparkContext, SparkConf , StorageLevel
# from pyspark.sql import SparkSession, HiveContext
# from pyspark.sql.functions import *
# from pyspark.sql.types import *
# import logging
# from dateutil.rrule import rrule, MONTHLY
# from datetime import datetime
# import json
# from pyspark.sql import functions
# import sys
# class main() :
#     def __init__(self):
#          try :
#              spark = SparkSession.builder \
#                  .enableHiveSupport() \
#                  .config('hive.exec.dynamic.partition', 'true') \
#                  .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
#                  .config('hive.exec.max.dynamic.partitions', '10000') \
#                  .getOrCreate()
#              log4j = spark._jvm.org.apache.log4j
#              log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
#              spark.sql('SET hive.warehouse.data.skiptrash=true;')
#              spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
#              spark.conf.set('spark.sql.cbo.enabled', True)
#              spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
#              spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
#              spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
#              spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
#              spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
#              spark.sql("set spark.sql.adaptive.enabled=false")

#              dbutils.widgets.text("Custom_Settings", "")

#              Settings = dbutils.widgets.get("Custom_Settings")

#              Set_list = Settings.split(',')
#              if len(Set_list)>0:
#                  for i in Set_list:
#                      if i != "":
#                          print("spark.sql(+i+)")
#                          spark.sql("""{i}""".format(i=i))

#              spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
#              spark.sql(""" SET hive.execution.engine = mr """)
#              spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
#              spark.sql(""" drop table if exists b2b.org_industry_map """)
#              spark.sql(""" create table  b2b.org_industry_map  AS
# SELECT 
# DISTINCT 
# b.ecp_parent_id,
# CASE
#     WHEN b.ecp_parent_geo IN ('CEEU','SWEU') THEN 'EMEA'
#     WHEN b.ecp_parent_geo IN ('INDI','CHNA','KORE') THEN 'ASIA'
#     WHEN b.ecp_parent_geo IN ('NAM','RLAN') THEN 'AMER'
#     ELSE b.ecp_parent_geo
# END AS ecp_parent_geo,
# ecp_sub_id,
# ecp_sub_name,
# ecp_market_area,
# b.org_id,
# org_name,
# org_country,
# org_geo,
# contract_id,
# contract_offer_type,
# market_segment,
# industry,
# CASE WHEN ent_account IS NULL THEN 'NON_ENT' ELSE ent_account END AS ent_account,
# db_tot_emp_cnt,
# db_emp_cnt,
# db_emp_range,
# CURRENT_DATE AS asofdate
# FROM
# (
# 	SELECT 
# 	contract_id,
#     ecp_parent_id,
#     ecp_parent_geo,
#     ecp_sub_id,
#     ecp_sub_name,
#     ecp_market_area,
#     org_id,
#     org_name,
#     org_country,
#     org_geo,
#     contract_offer_type,
#     market_segment,
#     industry,
#     db_tot_emp_cnt,
#     db_emp_cnt,
#     db_emp_range,
#     ROW_NUMBER() OVER(PARTITION BY org_id ORDER BY industry ASC) AS rownum
# 	FROM
# 	(
# 		SELECT 
# 		DISTINCT 
# 		contract_id,
#         b.prnt_std_name_key AS ecp_parent_id,
#         global_region AS ecp_parent_geo,
#         b.sub_std_name_key AS ecp_sub_id,
#         b.sub_name AS ecp_sub_name,
#         b.market_area AS ecp_market_area,
#         org_id,
#         org_name,
#         org_country,
#         org_geo,
#         c.market_segment,
#         contract_offer_type,
#         tap_industry AS industry,
#         db_tot_emp_cnt,
#         db_emp_cnt,
#         db_emp_range
# 		FROM
# 		(
# 			SELECT 
# 			DISTINCT 
# 			contract_id,
#             market_segment,
#             org_id,
#             org_name,
#             contract_offer_type,
#             e.country AS org_country,
#             geo_code AS org_geo
# 			FROM enterprise.fact_cce_membership_count e
# 			LEFT OUTER JOIN ids_coredata.dim_country dim_geo 
# 			ON dim_geo.country_code_iso2 = e.country
# 			WHERE contract_offer_type = 'EVIP'
# 			AND license_type = 'CONTRACTED'
# 			AND is_valid = 'Y'
# 			UNION ALL 
# 			SELECT 
# 			DISTINCT 
# 			contract_id,
#             market_segment,
#             org_id,
#             org_name,
#             contract_offer_type,
#             e.country AS org_country,
#             geo_code AS org_geo
# 			FROM enterprise.fact_dce_membership_count e
# 			LEFT OUTER JOIN ids_coredata.dim_country dim_geo 
# 			ON dim_geo.country_code_iso2 = e.country
# 			WHERE contract_offer_type = 'EVIP'
# 			AND is_valid = 'Y'
# 			AND license_type = 'CONTRACTED'
# 			UNION ALL 
# 			SELECT 
# 			DISTINCT 
# 			a.contract_id,
#             b.market_segment,
#             owner_identity_id AS org_id,
#             org_name,
#             a.contract_type AS contract_offer_type,
#             a.country_code AS org_country,
#             a.geo AS org_geo
# 			FROM ocf_analytics.dim_contract a
# 			INNER JOIN ocf_analytics.dim_seat b 
# 			ON a.contract_id = b.contract_id
# 			LEFT JOIN b2b.cct_org_name n 
# 			ON a.owner_identity_id = n.org_id
# 			WHERE b.seat_status LIKE '%ACTIVE%'
# 			AND a.contract_type != 'DIRECT_INDIVIDUAL'
# 		) c
# 		LEFT JOIN b2b_stg.hana_tap_ca_tf_dme_etla a 
# 		ON c.contract_id= a.licensing_contract
# 		LEFT JOIN b2b_stg.hana_tap_an_rv_td_sub b 
# 		ON a.SUB_STD_NAME_KEY = b.SUB_STD_NAME_KEY
# 		UNION ALL 
# 		SELECT 
# 		DISTINCT 
# 		c.contract_id,
#         ech_prnt_std_name_key AS ecp_parent_id,
#         ech_parent_geo AS ecp_parent_geo,
#         ech_sub_std_name_key AS ecp_sub_id,
#         ech_sub_name AS ecp_sub_name,
#         ecp_market_area,
#         c.org_id,
#         c.org_name,
#         org_country,
#         org_geo,
#         c.market_segment,
#         contract_offer_type,
#         ech_sub_industry AS industry,
#         db_tot_emp_cnt,
#         db_emp_cnt,
#         db_emp_range
# 		FROM
# 		(
# 			SELECT 
# 			DISTINCT 
# 			contract_id,
#             market_segment,
#             org_id,
#             org_name,
#             contract_offer_type,
#             country AS org_country,
#             geo_code AS org_geo
# 			FROM enterprise.fact_cce_membership_count e
# 			LEFT OUTER JOIN ids_coredata.dim_country dim_geo 
# 			ON dim_geo.country_code_iso2 = e.country
# 			WHERE contract_offer_type = 'ETLA'
# 			AND is_valid = 'Y'
# 			AND license_type = 'CONTRACTED'
# 			UNION ALL 
# 			SELECT 
# 			DISTINCT 
# 			contract_id,
#             market_segment,
#             org_id,
#             org_name,
#             contract_offer_type,
#             country AS org_country,
#             geo_code AS org_geo
# 			FROM enterprise.fact_dce_membership_count e
# 			LEFT OUTER JOIN ids_coredata.dim_country dim_geo 
# 			ON dim_geo.country_code_iso2 = e.country
# 			WHERE contract_offer_type = 'ETLA'
# 			AND license_type = 'CONTRACTED'
# 			AND is_valid = 'Y' 
# 		) c
# 		LEFT JOIN b2b.enduserid_orgid_mapping m 
# 		ON c.org_id = m.org_id
# 		LEFT JOIN
# 		(
# 			SELECT 
# 			DISTINCT 
# 			CAST (end_user AS int) AS end_user_id,
#             ech_prnt_std_name_key,
#             ech_parent_geo,
#             ech_sub_std_name_key,
#             ech_sub_name,
#             ech_sub_industry,
#             ech_parent_market_area AS ecp_market_area
# 			FROM enterprise.ca_ent_arr_model_all
# 			WHERE date_date > DATE_SUB(CURRENT_DATE,180)
# 			AND ech_sub_industry NOT IN('Americas', 'Asia', 'EMEA')
# 		) e 
# 		ON e.end_user_id = CAST(m.end_user_id AS int)
# 		LEFT JOIN b2b_stg.hana_tap_an_rv_td_sub f 
# 		ON e.ech_sub_std_name_key = f.sub_std_name_key
# 	) a
# ) b
# LEFT JOIN
# (
# 	SELECT 	
# 	parentid AS ecp_parent_id,
# 	parentname AS ecp_parent_name,
# 	imsaccounts AS org_id,
# 	CASE
# 		WHEN geo = 'Americas' THEN 'AMER'
# 		WHEN geo = 'JAPAN' THEN 'JPN'
# 		WHEN geo = 'APAC' THEN 'ASIA'
# 		WHEN geo = 'APAC' THEN 'ASIA'
# 	ELSE geo
# 	END AS ecp_parent_geo,
# 	CASE
# 		WHEN signonly= 'No' THEN 'CC_DC_SIGN_ENT'
# 		WHEN signonly = 'Yes' THEN 'SIGN_ENT'
# 	END AS ent_account
# 	FROM
# 	(
# 		SELECT 
# 		parentid,
# 		parentname,
# 		imsaccounts,
# 		signonly,
# 		geo,
# 		ROW_NUMBER() OVER(PARTITION BY geo,imsaccounts ORDER BY parentid ASC) AS rownum
# 		FROM b2b.uda_parentid_orgid_mapping
# 		WHERE imsaccounts != ''
# 		GROUP BY 
# 		parentid,
# 		parentname,
# 		imsaccounts,
# 		signonly,
# 		geo
# 	) x
# WHERE rownum = 1
# ) u 
# ON (u.org_id = b.org_id AND u.ecp_parent_geo = b.org_geo)
# WHERE rownum = 1
# AND b.org_id IS NOT NULL
# AND b.org_id != ''
# AND b.org_id != 'UNKNOWN' """)

#              try:
#                  dbutils.notebook.exit("SUCCESS")
#              except Exception as e:
#                  print("exception:",e)
#          except Exception as e:
#              dbutils.notebook.exit(e)

# if __name__ == '__main__':
#         main()

dbutils.notebook.exit("SUCCESS")