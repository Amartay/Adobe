# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.serial_mau_wau_fisc_wk_end partition (fisc_wk_end_date,type)
SELECT l.end_user_id,
         cast('NONE' as string)  as serial_number,
         count (distinct machine_id) AS num_mcs,
         cast(fisc_wk_end_date as date) as fisc_wk_end_date,
         'SERIAL_MAU_EUID_ACRO' AS type
FROM 
(select distinct end_user_id,serial_number
from
b2b.fact_serial_sku_txt l
where ucase (long_text)  like '%ACRO%')l
INNER JOIN 
  (SELECT serialnum,
         date,
         machine_id
  FROM b2b.applaunch_all d
  WHERE license_type = 'perpetual'
          AND year >= '2018'
          and date between date_sub(current_date,120) and current_date)d
    ON d.serialnum = l.serial_number
INNER JOIN 
  (SELECT fisc_mau_date,
         fisc_wk_end_date
  FROM b2b.fisc_mau_wk_dates
  WHERE fisc_wk_end_date between date_sub(current_date,16) and current_date) m
    ON m.fisc_mau_date = d.date
GROUP BY  l.end_user_id, fisc_wk_end_date""")

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()