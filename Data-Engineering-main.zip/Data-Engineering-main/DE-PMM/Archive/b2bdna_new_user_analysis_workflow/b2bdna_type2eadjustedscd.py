# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)

             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')             
            #  spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            #  spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            #  spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.type2e_adjusted_scd_seat_provisioning """)
             spark.sql(""" create table b2b.type2e_adjusted_scd_seat_provisioning AS 
select *
from (
	SELECT distinct
		auth_id,
		if(is_profile_id = 'N' and next_is_profile_id = 'Y' and datediff(TO_DATE(next_startdate_dttm),TO_DATE(enddate_dttm))<=1, next_seat_id, seat_id) seat_id,
		product_name,
		subscription_account_guid,
		startdate_dttm,
		if(is_profile_id = 'N' and next_is_profile_id = 'Y' and datediff(TO_DATE(next_startdate_dttm),TO_DATE(enddate_dttm))<=1, next_enddate_dttm, enddate_dttm) as enddate_dttm,
		if(is_profile_id = 'Y' and prev_is_profile_id = 'N' and datediff(TO_DATE(startdate_dttm),TO_DATE(prev_enddate_dttm))<=1, 'Y', 'N') as ignore_current_row
	FROM (
		SELECT 
			member_guid,
			auth_id,
			is_profile_id,
			seat_id,
			product_name,
			subscription_account_guid,
			startdate_dttm,
			enddate_dttm,
			LEAD(is_profile_id,1) OVER(PARTITION BY auth_id, subscription_account_guid, product_name ORDER BY startdate_dttm asc) as next_is_profile_id,
			LEAD(startdate_dttm,1) OVER(PARTITION BY auth_id, subscription_account_guid, product_name ORDER BY startdate_dttm asc) as next_startdate_dttm,
			LEAD(enddate_Dttm,1) OVER(PARTITION BY auth_id, subscription_account_guid, product_name ORDER BY startdate_dttm asc) as next_enddate_dttm,
			LEAD(seat_id,1) OVER(PARTITION BY auth_id, subscription_account_guid, product_name ORDER BY startdate_dttm asc) as next_seat_id,
			LAG(is_profile_id,1) OVER(PARTITION BY auth_id, subscription_account_guid, product_name ORDER BY startdate_dttm asc) as prev_is_profile_id,
			LAG(enddate_Dttm,1) OVER(PARTITION BY auth_id, subscription_account_guid, product_name ORDER BY startdate_dttm asc) as prev_enddate_dttm
		FROM (
			select 
				scd.member_guid,
				seat.seat_id,
				seat.product_name,
				seat.subscription_account_guid,
				COALESCE(type2e_profile.auth_id,scd.member_guid) as auth_id,
				if(type2e_profile.profile_id is not null, 'Y', 'N') is_profile_id,
				startdate_dttm,
				enddate_dttm
               from mdpd_stage.scd_seat_provisioning scd
			left outer join ocf_analytics.dim_seat seat on scd.seat_id = seat.seat_id
			left outer join ocf_analytics.vw_type2e_profile_reference type2e_profile on scd.member_guid = type2e_profile.profile_id 
			where 1=1 
				and UPPER(scd.contract_type) in ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION')
				and (UPPER(scd.seat_status) = 'ACTIVE' and UPPER(scd.seat_delegation_status) = 'ASSIGNED')
			) scd  
		) inner_tbl  
	)outer_tbl
WHERE ignore_current_row = 'N' """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()