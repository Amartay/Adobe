# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)

             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')

            #  spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            #  spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            #  spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)

             df_prov_cohort = spark.sql("select distinct scd.auth_id as member_guid,b2b.product_name,b2b.market_segment,b2b.route_to_market,b2b.geo_code,b2b.market_area_code,b2b.market_area_description,b2b.subs_offer,b2b.cc_segment,b2b.cc_segment_offer,b2b.product_name_description,b2b.regular_vs_promotion,b2b.seat_level_pivot_arr,b2b.seat_creation_date,b2b.seat_cancel_date,TO_DATE(scd.startdate_dttm) as deployment_start_date,TO_DATE(scd.enddate_dttm) as deployment_end_date,min(TO_DATE(scd.startdate_dttm)) OVER(PARTITION BY scd.auth_id,b2b.product_name order by NULL) as first_product_assign_date,max(TO_DATE(scd.startdate_dttm)) OVER(PARTITION BY scd.auth_id,b2b.product_name order by NULL) as latest_product_assign_date,max(TO_DATE(scd.enddate_dttm)) OVER(PARTITION BY scd.auth_id,b2b.product_name order by NULL) as latest_product_unassign_date,LAG(TO_DATE(scd.startdate_dttm)) OVER(PARTITION BY scd.auth_id,b2b.product_name ORDER BY TO_DATE(scd.startdate_dttm), TO_DATE(scd.enddate_dttm)) as prev_product_assign_date,LAG(TO_DATE(scd.enddate_dttm)) OVER(PARTITION BY scd.auth_id,b2b.product_name ORDER BY TO_DATE(scd.startdate_dttm), TO_DATE(scd.enddate_dttm)) as prev_product_unassign_date,min(TO_DATE(scd.startdate_dttm)) OVER(PARTITION BY scd.auth_id order by NULL) as first_member_assign_date,max(TO_DATE(scd.enddate_dttm)) OVER(PARTITION BY scd.auth_id order by NULL) as latest_member_unassign_date from b2b.type2e_adjusted_scd_seat_provisioning scd left outer join b2b.b2b_cohort_data b2b on scd.seat_id = b2b.seat_id")

             df_prov_cohort.createOrReplaceTempView("df_prov_cohort")

             spark.sql(""" drop table if exists b2b.smb_new_member_deployment_cohort_data """)
             spark.sql(""" create table b2b.smb_new_member_deployment_cohort_data AS
select distinct
	scd.member_guid,
	scd.product_name,
	scd.market_segment,
	scd.route_to_market,
	scd.geo_code,
	scd.market_area_code,
	scd.market_area_description,
	scd.subs_offer,
	scd.cc_segment,
	scd.cc_segment_offer,
	scd.product_name_description,
	scd.regular_vs_promotion,
	scd.seat_level_pivot_arr,
	scd.seat_creation_date,
	scd.seat_cancel_date,
	scd.deployment_start_date,
	scd.deployment_end_date,
	period.fiscal_yr_and_qtr_desc as deployment_start_qtr,
	period.fiscal_yr_and_wk_desc as deployment_start_week,
	datediff(scd.deployment_end_date, scd.deployment_start_date) as deployment_duration,
	scd.first_product_assign_date,
	scd.latest_product_assign_date,
	scd.latest_product_unassign_date,
	scd.prev_product_assign_date,
	scd.prev_product_unassign_date,
	scd.first_member_assign_date,
	scd.latest_member_unassign_date,
	datediff(TO_DATE(scd.deployment_start_date), TO_DATE(scd.prev_product_unassign_date)) as prev_prod_unassign_duration,
	datediff(TO_DATE(scd.prev_product_unassign_date), TO_DATE(scd.prev_product_assign_date)) as prev_prod_assign_duration,
	if(TO_DATE(scd.prev_product_unassign_date) is null, 'New', if(datediff(TO_DATE(scd.deployment_start_date), TO_DATE(scd.prev_product_unassign_date)) > 90, 'Resub>90', 'Resub<=90')) member_type
from df_prov_cohort scd 
inner join  (
    Select *
    from ids_coredata.dim_date 
    where 1=1
    	AND fiscal_yr_and_wk_desc >= '2019-01') period 
	on TO_DATE(scd.deployment_start_date) = TO_DATE(period.date_date) """)
             

             spark.sql(""" drop table if exists b2b.smb_new_member_deployment_cohort_data_deduped """)
             spark.sql(""" create table b2b.smb_new_member_deployment_cohort_data_deduped AS
select *
from (
	Select *,
        concat(member_guid,product_name) assignment,
        row_number() over(Partition by member_guid, product_name, deployment_start_qtr order by deployment_start_date, deployment_end_date asc) assignment_num
    from b2b.smb_new_member_deployment_cohort_data ) earliest
where 
	assignment_num = 1 """)
             
             df_user_profile_event=spark.sql("select if(type_2e.profile_id is NULL,hau.member_guid,type_2e.auth_id) as member_guid,members.deployment_start_qtr,members.product_name,hau.event_category as surface,min(if(TO_DATE(hau.event_date) >= TO_DATE(members.deployment_start_date), TO_DATE(hau.event_date), NULL)) as first_launch_date_after_assignment, count(distinct if(TO_DATE(hau.event_date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),6), hau.event_date, NULL)) as launch_days_7days,count(distinct if(TO_DATE(hau.event_date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),27), hau.event_date, NULL)) as launch_days_28days,count(distinct if(TO_DATE(hau.event_date) between date_add(TO_DATE(members.deployment_start_date),7) and date_add(TO_DATE(members.deployment_start_date),34), hau.event_date, NULL)) launch_days_8to35days,sort_array(collect_set(if(TO_DATE(hau.event_date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),6), hau.source_name, NULL))) as products_used_7days,sort_array(collect_set(if(TO_DATE(hau.event_date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),27), hau.source_name, NULL))) as products_used_28days,sort_array(collect_set(if(TO_DATE(hau.event_date) between date_add(TO_DATE(members.deployment_start_date),7) and date_add(TO_DATE(members.deployment_start_date),34), hau.source_name, NULL))) as products_used_8to35days,sort_array(collect_set(hau.source_name)) as product_used_35_days from dms.user_activity hau left outer join ocf_analytics.vw_type2e_profile_reference type_2e on upper(hau.member_guid) = upper(type_2e.profile_id) INNER JOIN b2b.smb_new_member_deployment_cohort_data_deduped members on UPPER(if(type_2e.profile_id is NULL,hau.member_guid,type_2e.auth_id)) = UPPER(members.member_guid) where 1=1 and hau.source_system is not null and hau.source_name is not null and hau.event_date is not null and hau.member_guid is not NULL and hau.member_guid != '' and UPPER(hau.event_category) != 'UNKNOWN' and TO_DATE(hau.event_Date) >='2018-01-01' and TO_DATE(hau.event_Date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),34) group by if(type_2e.profile_id is NULL,hau.member_guid,type_2e.auth_id),members.deployment_start_qtr,members.product_name,hau.event_category")
             
             df_user_profile_event.createOrReplaceTempView("df_user_profile_event")
             
             df_user_all_profile=spark.sql("select if(type_2e.profile_id is NULL,hau.member_guid,type_2e.auth_id) as member_guid,members.deployment_start_qtr,members.product_name,'ALL' as surface,min(if(TO_DATE(hau.event_date) >= TO_DATE(members.deployment_start_date), TO_DATE(hau.event_date), NULL)) as first_launch_date_after_assignment, count(distinct if(TO_DATE(hau.event_date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),6), hau.event_date, NULL)) as launch_days_7days,count(distinct if(TO_DATE(hau.event_date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),27), hau.event_date, NULL)) as launch_days_28days,count(distinct if(TO_DATE(hau.event_date) between date_add(TO_DATE(members.deployment_start_date),7) and date_add(TO_DATE(members.deployment_start_date),34), hau.event_date, NULL)) launch_days_8to35days,sort_array(collect_set(if(TO_DATE(hau.event_date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),6), hau.source_name, NULL))) as products_used_7days,sort_array(collect_set(if(TO_DATE(hau.event_date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),27), hau.source_name, NULL))) as products_used_28days,sort_array(collect_set(if(TO_DATE(hau.event_date) between date_add(TO_DATE(members.deployment_start_date),7) and date_add(TO_DATE(members.deployment_start_date),34), hau.source_name, NULL))) as products_used_8to35days,sort_array(collect_set(hau.source_name)) as product_used_35_days from dms.user_activity hau left outer join ocf_analytics.vw_type2e_profile_reference type_2e on upper(hau.member_guid) = upper(type_2e.profile_id) INNER JOIN b2b.smb_new_member_deployment_cohort_data_deduped members on UPPER(if(type_2e.profile_id is NULL,hau.member_guid,type_2e.auth_id)) = UPPER(members.member_guid) where 1=1 and hau.source_system is not null and hau.source_name is not null and hau.event_date is not null and hau.member_guid is not NULL and hau.member_guid != '' and UPPER(hau.event_category) != 'UNKNOWN' and TO_DATE(hau.event_Date) >='2018-01-01' and TO_DATE(hau.event_Date) between TO_DATE(members.deployment_start_date) and date_add(TO_DATE(members.deployment_start_date),34) group by if(type_2e.profile_id is NULL,hau.member_guid,type_2e.auth_id),members.deployment_start_qtr,members.product_name")
             
             df_user_all_profile.createOrReplaceTempView("df_user_all_profile")
             
             spark.sql(""" drop table if exists b2b.smb_new_member_deployment_cohort_data_usage """)
             spark.sql(""" create table b2b.smb_new_member_deployment_cohort_data_usage AS
SELECT 
    members.*,
	product_mapping.surface,
	hau.first_launch_date_after_assignment, 
	hau.launch_days_7days,
	hau.launch_days_28days,
	hau.launch_days_8to35days,
	hau.products_used_7days,
	hau.products_used_28days,
	hau.products_used_8to35days,
	hau.product_used_35_days
FROM b2b.smb_new_member_deployment_cohort_data_deduped members  
cross join (
	select distinct 
		hy_event_category as surface
	from ccea_prod.hybrid_product_mapping
	UNION ALL
	Select 'ALL' as surface
	) product_mapping
LEFT OUTER JOIN (select * from df_user_profile_event
	union all
	select * from df_user_all_profile)hau 
	on UPPER(hau.member_guid) = UPPER(members.member_guid) 
	and hau.deployment_start_qtr = members.deployment_start_qtr
	and hau.product_name = members.product_name
	and hau.surface = product_mapping.surface """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()