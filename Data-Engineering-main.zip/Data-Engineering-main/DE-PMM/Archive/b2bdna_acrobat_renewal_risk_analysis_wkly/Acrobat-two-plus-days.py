# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.gl_renewals_usage """)
             spark.sql(""" create table b2b.gl_renewals_usage as 
 with renewals AS 
(SELECT contract_id,
        renewal_date,
        product_name,
         min(if(UPPER(route_to_market) = 'RESELLER',if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date)),
            if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date))))) as reference_date
       from b2b_stg.pp_smb_contract_renewal
       WHERE upper(product_category) in ('ACROBAT + E-SIGN','ACROBAT STD / PRO')
       group by contract_id,
                renewal_Date,
                product_name
)
select renewals.contract_id,
         renewals.renewal_date,
         renewals.product_name,
         deployment.active_seat,
         deployment.delegated_seat,
         deployment.member_guid,
         deployment.active_28_days,
         deployment.active_90_days,
         deployment.active_180_days,
         partition_date,
         reference_date,
         count(case when active_28_days = 'Y' and   partition_date between date_sub(TO_DATE(reference_Date),28) and TO_DATE(reference_Date) then partition_date else null end) 
                over (partition by renewals.contract_id,renewals.renewal_date,deployment.member_guid order by NULL) as 28_member_active,
         count(case when active_90_days = 'Y' and   partition_date between date_sub(date_sub(TO_DATE(reference_Date),90),28) and date_sub(TO_DATE(reference_Date),90)then partition_date else null end) 
                over (partition by renewals.contract_id,renewals.renewal_date,deployment.member_guid order by NULL) as 90_member_active,
         count(case when active_180_days = 'Y' and   partition_date between date_sub(date_sub(TO_DATE(reference_Date),180),28) and date_sub(TO_DATE(reference_Date),180)then partition_date else null end) 
                over (partition by renewals.contract_id,renewals.renewal_date,deployment.member_guid order by NULL) as 180_member_active
 FROM renewals renewals 
  inner join b2b.pp_at_renewal_Deployed_members deployment on renewals.contract_id = deployment.contract_id and renewals.renewal_date = deployment.renewal_date and renewals.product_name = deployment.product_name
  LEFT OUTER JOIN (
       SELECT distinct member_guid,
                       partition_date from(
                    SELECT distinct CASE
                     WHEN t2el.profile_id IS NULL THEN hau.member_guid
                     ELSE t2el.auth_id
                     END as member_guid,
                     TO_DATE(event_date) as partition_date
                     FROM dms.user_activity2  hau
                     LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el
                     ON (hau.member_guid = t2el.profile_id)
                     WHERE upper(source_name) like ('%ACROBAT%')
                     and TO_DATE(event_date) >= TO_DATE('2020-03-29')   
                     UNION ALL                                         
                     SELECT distinct CASE
                     WHEN t2el.profile_id IS NULL THEN ccea.member_guid
                     ELSE t2el.auth_id
                     END as member_guid,
                     TO_DATE(event_date) as partition_date
                     FROM ccea_prod.fct_acrobat_web_activity  ccea
                     LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el
                     ON (ccea.member_guid = t2el.profile_id)
                     WHERE TO_DATE(event_date) >= TO_DATE('2020-03-29')   
              )template_hb
            ) hb_launch ON hb_launch.member_guid = deployment.member_guid """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()