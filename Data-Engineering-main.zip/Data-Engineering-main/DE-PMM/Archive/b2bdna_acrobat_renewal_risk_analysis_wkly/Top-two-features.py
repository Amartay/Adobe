# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.PP_SMB_ACROBAT_TOP_FEATURES """)
             spark.sql(""" create table b2b.PP_SMB_ACROBAT_TOP_FEATURES as 
with renewals AS 
(SELECT contract_id,
        renewal_date,
        product_name,
         min(if(UPPER(route_to_market) = 'RESELLER',if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date)),
            if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date))))) as reference_date
       from b2b_stg.pp_smb_contract_renewal
       WHERE upper(product_category) in ('ACROBAT + E-SIGN','ACROBAT STD / PRO')
       group by contract_id,
                renewal_Date,
                product_name
),
usage AS 
(select distinct CASE
                    WHEN t2el.profile_id IS NULL THEN hau.crm_customer_guid
                    ELSE t2el.auth_id
          END as member_guid,
                 featurename,
                 TO_DATE(date) as partition_date
            FROM dcia.dc_usage_applaunch  hau
            LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el
            ON (hau.crm_customer_guid = t2el.profile_id)
            WHERE TO_DATE(date) >= TO_DATE('2017-11-30')
)
  SELECT contract_id,
         renewal_Date,
         product_name,
         max(if(ROWNUM_28 = 1,featurename,NULL)) as top_used_feature_28,
         max(if(ROWNUM_90 = 1,featurename,NULL)) as top_used_feature_90,
         max(if(ROWNUM_180 = 1,featurename,NULL)) as top_used_feature_180,
         collect_set(if(ROWNUM_28 in (1,2),featurename,NULL)) as top_2_features_used_28_days,
         collect_set(if(ROWNUM_90 in (1,2),featurename,NULL)) as top_2_features_used_90_days,
         collect_set(if(ROWNUM_180 in (1,2),featurename,NULL)) as top_2_features_used_180_days
FROM
(SELECT  contract_id,
	      renewal_Date,
	      product_name,
	      featurename,
	     ROW_NUMBER() OVER(PARTITION BY contract_id,renewal_date,product_name ORDER BY 28_member_tool_usage_days desc) AS ROWNUM_28,
         ROW_NUMBER() OVER(PARTITION BY contract_id,renewal_date,product_name ORDER BY 90_member_tool_usage_days desc) AS ROWNUM_90,
         ROW_NUMBER() OVER(PARTITION BY contract_id,renewal_date,product_name ORDER BY 180_member_tool_usage_days desc) AS ROWNUM_180
 FROM
  (select renewals.contract_id,
         renewals.renewal_Date,
         renewals.product_name,
         usage.featurename,
         count(distinct case when active_28_days = 'Y' and   partition_date between date_sub(TO_DATE(reference_Date),28) and TO_DATE(reference_Date) then partition_Date else NULL end) as 28_member_tool_usage_days,
         count(distinct case when active_90_days = 'Y' and   partition_date between date_sub(date_sub(TO_DATE(reference_Date),90),28) and date_sub(TO_DATE(reference_Date),90) then partition_Date else NULL end) as 90_member_tool_usage_days,
         count(distinct case when active_180_days = 'Y' and   partition_date between date_sub(date_sub(TO_DATE(reference_Date),180),28) and date_sub(TO_DATE(reference_Date),180)then partition_Date else NULL end) as 180_member_tool_usage_days
  from renewals renewals 
  inner join b2b.pp_at_renewal_Deployed_members deployment on renewals.contract_id = deployment.contract_id and renewals.renewal_date = deployment.renewal_date and UPPER(renewals.product_name) = UPPER(deployment.product_name)
 INNER JOIN (select * from usage where featurename is not NULL and featurename != '') usage on usage.member_guid = deployment.member_guid 
  group BY renewals.contract_id,
  renewals.renewal_Date,
  renewals.product_name,
  usage.featurename
 ) temp_tbl 
 )usage
  group by contract_id,
           renewal_date,
           product_name """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()