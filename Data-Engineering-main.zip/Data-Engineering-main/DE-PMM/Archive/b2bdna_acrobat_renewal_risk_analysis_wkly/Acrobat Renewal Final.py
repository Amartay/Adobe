# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.pp_acrobat_renewals_risk_analysis_tbl """)
             spark.sql(""" create table b2b.pp_acrobat_renewals_risk_analysis_tbl AS 
SELECT
       renewals.renewal_qtr,
       renewals.renewal_wk,
       renewals.contract_id,
       renewals.subs_offer,  
       renewals.cc_segment,
       renewals.market_segment,
       renewals.product_category,
       renewals.product_name_description,
       max(smb_contract.dme_acct_segment) as dme_acct_segment,
       max(smb_contract.mm_flag) as mm_flag,
       max(renewals.contract_type) as contract_type,
       max(renewals.route_to_market) as route_to_market,
       max(renewals.cc_phone_vs_web) as cc_phone_vs_web,
       max(renewals.industry) as industry,
       max(renewals.derived_contract_start_date) as derived_contract_start_date,
       max(renewals.derived_contract_end_date) as derived_contract_end_date,
       max(renewals.renewal_counter) as renewal_counter,
       max(renewals.billing_payment_category) as billing_payment_category,
       max(renewals.geo) as geo,
       max(renewals.market_area_description) as market_area_description,             
       max(renewals.data_source_type) as data_source_type,
       max(renewals.billing_plan_type) as billing_plan_type,
       max(renewals.distributor) as distributor, 
       max(renewals.reseller) as reseller, 
       max(renewals.partner_level) as partner_level, 
       max(renewals.end_user) as end_user,
max(renewals.industry) as line_of_business ,
max(renewals.employee_range) as employee_range,
max(renewals.revenue_range)  as revenue_range,
max(renewals.adobe_acrobat) as adobe_acrobat,
max(renewals.photoshop) as photoshop,
max(renewals.adobe_stock) as adobe_stock,
max(renewals.adobe_creative_cloud) as adobe_creative_cloud,
max(renewals.digital_media) as digital_media,
max(renewals.renewal_date) as renewal_date,
max(datediff(to_DATE(renewals.renewal_date),TO_DATE(current_date))) as days_to_renewal,
max(usage_deploy.active_seats_28_days) as active_seats_28_days,
max(usage_deploy.active_seats_90_days) as active_seats_90_days,
max(usage_deploy.active_seats_180_days) as active_seats_180_days,
max(usage_deploy.delegated_seats_28_days) as delegated_seats_28_days,
max(usage_deploy.delegated_seats_90_days) as delegated_seats_90_days,
max(usage_deploy.delegated_seats_180_days) as delegated_seats_180_days,
max(usage_deploy.delegated_members_28_days) as delegated_members_28_days,
max(usage_deploy.delegated_members_90_days) as delegated_members_90_days,
max(usage_deploy.delegated_members_180_days) as delegated_members_180_days,
max(28_days_contract_usage) as 28_days_contract_usage,
max(90_days_contract_usage) as 90_days_contract_usage,
max(180_days_contract_usage) as 180_days_contract_usage,
max(28_2plus_usage_seats) as 28_2plus_days_usage_seats,
max(90_2plus_usage_seats) as 90_2plus_days_usage_seats,
max(180_2plus_usage_seats) as 180_2plus_days_usage_seats,
max(28_member_tool_usage_days) as 28_member_tool_usage_days,
max(90_member_tool_usage_days) as 90_member_tool_usage_days,
max(180_member_tool_usage_days) as 180_member_tool_usage_days,
max(28_member_no_of_tools_used) as 28_member_no_of_tools_used,
max(90_member_no_of_tools_used) as 90_member_no_of_tools_used,
max(180_member_no_of_tools_used) as 180_member_no_of_tools_used,
max(top_used_feature_28) as top_used_feature_28,
max(top_used_feature_90) as top_used_feature_90,
max(top_used_feature_180) as top_used_feature_180,
max(top_2_features_used_28_days) as top_2_features_used_28_days,
max(top_2_features_used_90_days) as top_2_features_used_90_days,
max(top_2_features_used_180_days) as top_2_features_used_180_days,
max(count_of_members_w_2_plus_tools_28_days) as count_of_members_w_2_plus_tools_28_days,
max(count_of_members_w_2_plus_tools_90_days) as count_of_members_w_2_plus_tools_90_days,
max(count_of_members_w_2_plus_tools_180_days) as count_of_members_w_2_plus_tools_180_days,
max(churn_score) as churn_score,
max(percentile_score) as percentile_score,
max(churn_top_reason) as churn_top_reason,   
max(mdpd_phone_permission) as mdpd_phone_permission,
max(mdpd_email_permission) as mdpd_email_permission,
min(first_mid_term_explicit_cancel_date) first_mid_term_explicit_cancel_date,
min(first_mid_term_cc_failure_cancel_date) first_mid_term_cc_failure_cancel_date,
min(first_pivot_cancel_date) first_pivot_cancel_date,
sum(term_begin_active_count) as term_begin_active_count,
sum(term_end_active_count) as  term_end_active_count,
sum(expansion_at_renewal_same) as  expansion_at_renewal_same,
sum(expansion_at_renewal_diff) as  expansion_at_renewal_diff,
sum(mid_term_migration_to) as  mid_term_migration_to,
sum(mid_term_reactivation) as  mid_term_reactivation,
sum(mid_term_renewal_to) as  mid_term_renewal_to,
sum(mid_term_cancel_explicit) as  mid_term_cancel_explicit,
sum(mid_term_cancel_cc_failure) as  mid_term_cancel_cc_failure,
sum(mid_term_partial_cancel_explicit) as  mid_term_partial_cancel_explicit,
sum(mid_term_partial_cancel_cc_failure) as  mid_term_partial_cancel_cc_failure,
sum(mid_term_returns) as  mid_term_returns,
sum(end_term_migration_to) as  end_term_migration_to,
sum(end_term_migration_from) as  end_term_migration_from,
sum(end_term_cancel) as  end_term_cancel,
sum(end_term_cancel_explicit) as  end_term_cancel_explicit,
sum(end_term_cancel_cc_failure) as  end_term_cancel_cc_failure,
sum(end_term_partial_cancel_explicit) as  end_term_partial_cancel_explicit,
sum(end_term_partial_cancel_cc_failure) as  end_term_partial_cancel_cc_failure,
sum(end_term_returns) as  end_term_returns,
sum(end_term_reactivation) as  end_term_reactivation,
sum(end_term_renewal_to) as  end_term_renewal_to,
sum(end_term_renewal_from) as  end_term_renewal_from,
sum(term_begin_active) as  term_begin_active,
sum(up_for_renewal) as  up_for_renewal,
sum(term_end_active) as  term_end_active,
sum(term_end_renewal) as  term_end_renewal,
sum(term_end_active_post_reactivation) as  term_end_active_post_reactivation,
sum(term_end_arr) as  term_end_arr,
sum(expansion_at_renewal_same_arr) as  expansion_at_renewal_same_arr,
sum(expansion_at_renewal_diff_arr) as  expansion_at_renewal_diff_arr,
sum(mid_term_migration_to_arr) as  mid_term_migration_to_arr,
sum(mid_term_reactivation_arr) as  mid_term_reactivation_arr,
sum(mid_term_renewal_to_arr) as  mid_term_renewal_to_arr,
sum(mid_term_cancel_explicit_arr) as  mid_term_cancel_explicit_arr,
sum(mid_term_cancel_cc_failure_arr) as  mid_term_cancel_cc_failure_arr,
sum(mid_term_partial_cancel_explicit_arr) as  mid_term_partial_cancel_explicit_arr,
sum(mid_term_partial_cancel_cc_failure_arr) as  mid_term_partial_cancel_cc_failure_arr,
sum(mid_term_migration_from_arr) as  mid_term_migration_from_arr,
sum(mid_term_renewal_from_arr) as  mid_term_renewal_from_arr,
sum(mid_term_returns_arr) as  mid_term_returns_arr,
sum(end_term_migration_from_arr) as  end_term_migration_from_arr,
sum(end_term_cancel_arr) as  end_term_cancel_arr,
sum(end_term_cancel_explicit_arr) as  end_term_cancel_explicit_arr,
sum(end_term_cancel_cc_failure_arr) as  end_term_cancel_cc_failure_arr,
sum(end_term_partial_cancel_explicit_arr) as  end_term_partial_cancel_explicit_arr,
sum(end_term_partial_cancel_cc_failure_arr) as  end_term_partial_cancel_cc_failure_arr,
sum(end_term_migration_to_arr) as  end_term_migration_to_arr,
sum(end_term_reactivation_arr) as  end_term_reactivation_arr,
sum(end_term_renewal_to_arr) as  end_term_renewal_to_arr,
sum(end_term_renewal_from_arr) as  end_term_renewal_from_arr,
sum(end_term_returns_arr) as  end_term_returns_arr,
sum(annual_inactive_arr) as  annual_inactive_arr,
sum(annual_active_arr) as  annual_active_arr,
sum(term_begin_arr) as  term_begin_arr,
sum(term_end_renewal_arr) as  term_end_renewal_arr,
sum(term_end_active_arr) as  term_end_active_arr,
sum(up_for_renewal_arr) as  up_for_renewal_arr,
sum(term_end_active_post_reactivation_arr) as  term_end_active_post_reactivation_arr,
sum(annual_active) as annual_active,
sum(annual_inactive) as annual_inactive,
sum(gross_new_arr) gross_new_arr,
sum(net_cancelled_arr) net_cancelled_arr,
sum(reactivated_arr) reactivated_arr,
sum(returns_arr) returns_arr
FROM (select * from b2b.smb_renewal_churn_deploy_firmo where upper(product_category) in ('ACROBAT + E-SIGN','ACROBAT STD / PRO')) renewals
LEFT OUTER JOIN b2b.pp_acrobat_tool_usage_renewals usage_deploy on usage_deploy.contract_id = renewals.contract_id and TO_DATE(usage_deploy.renewal_date) = TO_DATE(renewals.renewal_date) and UPPER(usage_deploy.product_name) = UPPER(renewals.product_name)
LEFT OUTER JOIN b2b.PP_SMB_ACROBAT_TOP_FEATURES acrobat_features on acrobat_features.contract_id = renewals.contract_id and TO_DATE(acrobat_features.renewal_Date) = TO_DATE(renewals.renewal_date) and UPPER(acrobat_features.product_name) = UPPER(renewals.product_name)
LEFT OUTER JOIN b2b.gl_renewals_aggr usage_agg on usage_agg.contract_id = renewals.contract_id and TO_DATE(usage_agg.renewal_date) = TO_DATE(renewals.renewal_date) and UPPER(usage_agg.product_name) = UPPER(renewals.product_name)
LEFT OUTER JOIN(select distinct contract_id,mm_flag,dme_acct_segment 
                 from b2b.smb_all_contracts_details) smb_contract on renewals.contract_id = smb_contract.contract_id 
where renewals.renewal_qtr >= '2020-Q2'
group by renewals.renewal_qtr,
         renewals.renewal_wk,
         renewals.contract_id,
         renewals.subs_offer,
         renewals.cc_segment,
         renewals.market_segment,
         renewals.product_category,
         renewals.product_name_description """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()