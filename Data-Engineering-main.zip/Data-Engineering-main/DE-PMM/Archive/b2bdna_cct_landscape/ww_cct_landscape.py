# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=21333334 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=21333334 """)
             spark.sql(""" set hive.exec.dynamic.partition=true """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.ww_cct_landscape PARTITION(fiscal_yr_and_qtr_desc) 
SELECT fiscal_yr_desc,  
    phone_vs_web,
    route_to_market,  
    geo, 
    geo_description, 
    market_area, 
    market_area_description, 
    sales_district, 
    sales_district_description, 
    region, 
    region_description, 
    market_segment, 
    payment_method,
    payment_method_description,
	case
	    when upper(subs_offer) like '%SIGN%' then 'SIGN'
	    when upper(subs_offer) like '%STOCK%' then 'STOCK'
	    when upper(subs_offer) in ('ACROBAT CC', 'DCE SINGLE APP', 'DCT SINGLE APP') then 'ACROBAT'
	    when upper(subs_offer) in ('CCE COMPLETE','CCE SINGLE APP','CCT COMPLETE','CCT SINGLE APP','LIGHTROOM CC') then 'CC'
	    else 'OTHERS'
	end subs_offer_group,
    subs_offer,
    stype, 
    promotion, 
    promo_type, 
    product_config, 
    product_config_description, 
    product_name, 
    product_name_description, 
    offer_type_description, 
    if(cc_segment='<UNKNOWN>', 'Others', cc_segment) cc_segment,	 	 
    cc_segment_offer,
    crm_customer_guid,
    domain,
    generic_domain_flag,
    contract_id,
    sales_center,
    smb_industry, 
    employee_range, 
    revenue_range,
    manual_adjust_flag,
    phones_adash,
    sum(COALESCE(init_purchase, 0)) as init_purchase,
    sum(COALESCE(addl_purchase, 0)) addl_purchase,
    sum(COALESCE(gross_new_subs, 0)) as gross_new_subs,
    sum(COALESCE(returns, 0)) as returns,
    sum(COALESCE(net_purchases, 0)) as net_purchases,
    sum(COALESCE(migrated_from, 0)) as migrated_from,
    sum(COALESCE(migrated_to, 0)) as migrated_to,
    sum(coalesce(migrated_subs,0)) as migrated_subs,
    sum(COALESCE(gross_cancellations, 0)) as gross_cancellations,
    sum(COALESCE(reactivated_subs, 0)) as reactivated_subs,
    sum(COALESCE(net_cancelled_subs, 0)) as net_cancelled_subs,
    sum(COALESCE(renewal_from, 0)) as renewal_from,
    sum(COALESCE(renewal_to, 0)) as renewal_to,
    sum(COALESCE(fqtr_begin_active, 0)) as fqtr_begin_active,
    sum(COALESCE(fqtr_end_active, 0)) as fqtr_end_active,
    sum(COALESCE(net_new_subs, 0)) as net_new_subs,
    sum(COALESCE(init_purchase_arr_cfx, 0.00)) as init_purchase_arr_cfx,
    sum(COALESCE(addl_purchase_arr_cfx, 0.00)) as addl_purchase_arr_cfx,
    sum(COALESCE(gross_new_arr_cfx, 0.00)) as gross_new_arr_cfx,
    sum(COALESCE(returns_arr_cfx, 0.00)) as returns_arr_cfx,
    sum(COALESCE(net_purchases_arr_cfx, 0.00)) as net_purchases_arr_cfx,
    sum(COALESCE(migrated_from_arr_cfx, 0.00)) as migrated_from_arr_cfx,
    sum(COALESCE(migrated_to_arr_cfx, 0.00)) as migrated_to_arr_cfx,
    sum(COALESCE(migration_arr_cfx, 0.00)) as migration_arr_cfx,
    sum(COALESCE(gross_cancel_arr_cfx, 0.00)) as gross_cancel_arr_cfx,
    sum(COALESCE(reactivated_arr_cfx, 0.00)) as reactivated_arr_cfx,
    sum(COALESCE(net_cancelled_arr_cfx, 0.00)) as net_cancelled_arr_cfx,
    sum(COALESCE(renewal_from_arr_cfx, 0.00)) as renewal_from_arr_cfx,
    sum(COALESCE(renewal_to_arr_cfx, 0.00)) as renewal_to_arr_cfx,
    sum(COALESCE(fqtr_begin_arr_cfx, 0.00)) as fqtr_begin_arr_cfx,
    sum(COALESCE(fqtr_end_arr_cfx, 0.00)) as fqtr_end_arr_cfx,
    sum(COALESCE(net_new_arr_cfx, 0.00)) as net_new_arr_cfx,
    A.fiscal_yr_and_qtr_desc
FROM b2b.ww_shuri A 
inner join b2b.dim_date b 
on A.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc
where stype = 'TM'
group by 
    fiscal_yr_desc, 
    phone_vs_web,
    route_to_market,  
    geo, 
    geo_description, 
    market_area, 
    market_area_description, 
    sales_district, 
    sales_district_description, 
    region, 
    region_description, 
    market_segment, 
    payment_method,
    payment_method_description,
	case
	    when upper(subs_offer) like '%SIGN%' then 'SIGN'
	    when upper(subs_offer) like '%STOCK%' then 'STOCK'
	    when upper(subs_offer) in ('ACROBAT CC', 'DCE SINGLE APP', 'DCT SINGLE APP') then 'ACROBAT'
	    when upper(subs_offer) in ('CCE COMPLETE','CCE SINGLE APP','CCT COMPLETE','CCT SINGLE APP','LIGHTROOM CC') then 'CC'
	    else 'OTHERS'
	end,
    subs_offer,
    stype, 
    promotion, 
    promo_type, 
    product_config, 
    product_config_description, 
    product_name, 
    product_name_description, 
    offer_type_description, 
    cc_segment,	 	 
    cc_segment_offer,
    crm_customer_guid,
    domain,
    generic_domain_flag,
    contract_id,
    sales_center,
    smb_industry, 
    employee_range, 
    revenue_range,
    manual_adjust_flag,
    phones_adash,  
    A.fiscal_yr_and_qtr_desc """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()