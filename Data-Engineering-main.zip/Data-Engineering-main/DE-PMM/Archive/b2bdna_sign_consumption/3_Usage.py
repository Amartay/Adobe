# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" SET hive.mapred.mode=nonstrict """)
             spark.sql(""" drop table if exists b2b.ss_sign_uda_usage """)
             spark.sql(""" create table b2b.ss_sign_uda_usage as
Select 
    sign_contracts.contract_id,
	sign_contracts.contract_end_date,
    min(usage.transaction_date) earliest_transaction_date,
    max(usage.transaction_date) latest_transaction_date,
    count(distinct usage.agreement_id) as n_agreements,
    count(distinct sfs.agreement_id) as agreement_sent_for_esignature, 
    count(distinct case when cast(usage.transaction_date as date) > date_sub(current_date(),30) and cast(usage.transaction_date as date) <= current_date() then sfs.agreement_id end) as last_30_days_sent_for_sign,
    count(distinct case when cast(usage.transaction_date as date) > date_sub(current_date(),60) and cast(usage.transaction_date as date) <= current_date() then sfs.agreement_id end) as last_60_days_sent_for_sign,
    count(distinct case when cast(usage.transaction_date as date) > date_sub(current_date(),90) and cast(usage.transaction_date as date) <= current_date() then sfs.agreement_id end) as last_90_days_sent_for_sign,
    count(distinct case when cast(usage.transaction_date as date) > date_sub(current_date(),120) and cast(usage.transaction_date as date) <= current_date() then sfs.agreement_id end) as last_120_days_sent_for_sign,
    count(distinct case when usage.status NOT IN ('WAITING_FOR_AUTHORING','ARCHIVED','ABANDONED_BEFORE_SEND') and usage.sender_signs NOT IN ('FILL_SIGN','APPROVE') and usage.composition != 'MULTICAST' then usage.agreement_id end) as total_billable_usage,
    count(distinct case when usage.is_transaction = '1' then usage.agreement_id end) as txn_usage,
    count(distinct case when usage.is_transaction = '1' and cast(usage.transaction_date as date) > date_sub(current_date(),30) and cast(usage.transaction_date as date) <= current_date() then usage.agreement_id end) as last_30_days_txn_usage,
    count(distinct case when usage.is_transaction = '1' and cast(usage.transaction_date as date) > date_sub(current_date(),60) and cast(usage.transaction_date as date) <= current_date() then usage.agreement_id end) as last_60_days_txn_usage,
    count(distinct case when usage.is_transaction = '1' and cast(usage.transaction_date as date) > date_sub(current_date(),90) and cast(usage.transaction_date as date) <= current_date() then usage.agreement_id end) as last_90_days_txn_usage,
    count(distinct case when usage.is_transaction = '1' and cast(usage.transaction_date as date) > date_sub(current_date(),120) and cast(usage.transaction_date as date) <= current_date() then usage.agreement_id end) as last_120_days_txn_usage,
    count(distinct case when usage.is_transaction = '1' and created_via_acrobat_dc = 1 and agreement_sent_for_esignature = 1 then usage.agreement_id end) as acrobat_esign_txn_usage
from b2b.ss_sign_contract_base sign_contracts
inner join (
    Select distinct accountid as contract_id, 
        echosignid as sign_account_id
    from b2b.sign_uda_accounts
    where echosignid != ''
    and echosignid is not NULL
    and accountid != ''
    and accountid is not NULL) accounts
on sign_contracts.contract_id = accounts.contract_id
left outer join (
    SELECT 
        account_id,
        (case 
            when cast(substr(transaction_date, 1, 10) as date) is not null then substr(transaction_date, 1, 10)
            else substr(created, 1, 10)
            end) as transaction_date, 
        agreement_id,
        is_transaction,
        created_via_acrobat_dc,
        agreement_sent_for_esignature,
        upper(status) status,
        UPPER(sender_signs) sender_signs,
        UPPER(composition) composition
    FROM b2b_stg.a_sign_pub_agreement
    WHERE 1=1
    and agreement_should_be_ignored = 0
    and account_id is not NULL 
    and account_id != '') usage
ON accounts.sign_account_id = usage.account_id
left outer join (
	select agreement_id, 
		event 
	from b2b_stg.a_sign_agreement_event
	where event = 'SIGNATURE_REQUESTED') sfs
on usage.agreement_id = sfs.agreement_id
where usage.transaction_date between sign_contracts.sign_start_date and sign_contracts.contract_end_date
group by sign_contracts.contract_id,
	sign_contracts.contract_end_date """)
             spark.sql(""" drop table if exists b2b.ss_sign_non_uda_usage """)
             spark.sql(""" create table b2b.ss_sign_non_uda_usage as
select 
    sign_contracts.contract_id,
	sign_contracts.contract_end_date,
    min(usage.transaction_date) earliest_transaction_date,
    max(usage.transaction_date) latest_transaction_date,
    count(distinct usage.agreement_id) as n_agreements,
    count(distinct sfs.agreement_id) as agreement_sent_for_esignature,
    count(distinct case when cast(usage.transaction_date as date) > date_sub(current_date(),30) and cast(usage.transaction_date as date) <= current_date() then sfs.agreement_id end) as last_30_days_sent_for_sign,
    count(distinct case when cast(usage.transaction_date as date) > date_sub(current_date(),60) and cast(usage.transaction_date as date) <= current_date() then sfs.agreement_id end) as last_60_days_sent_for_sign,
    count(distinct case when cast(usage.transaction_date as date) > date_sub(current_date(),90) and cast(usage.transaction_date as date) <= current_date() then sfs.agreement_id end) as last_90_days_sent_for_sign,
    count(distinct case when cast(usage.transaction_date as date) > date_sub(current_date(),120) and cast(usage.transaction_date as date) <= current_date() then sfs.agreement_id end) as last_120_days_sent_for_sign,
    count(distinct case when usage.status NOT IN ('WAITING_FOR_AUTHORING','ARCHIVED','ABANDONED_BEFORE_SEND') and usage.sender_signs NOT IN ('FILL_SIGN','APPROVE') and usage.composition != 'MULTICAST' then usage.agreement_id end) as total_billable_usage,
    count(distinct case when usage.is_transaction = '1' then usage.agreement_id end) as txn_usage,
    count(distinct case when usage.is_transaction = '1' and cast(usage.transaction_date as date) > date_sub(current_date(),30) and cast(usage.transaction_date as date) <= current_date() then usage.agreement_id end) as last_30_days_txn_usage,
    count(distinct case when usage.is_transaction = '1' and cast(usage.transaction_date as date) > date_sub(current_date(),60) and cast(usage.transaction_date as date) <= current_date() then usage.agreement_id end) as last_60_days_txn_usage,
    count(distinct case when usage.is_transaction = '1' and cast(usage.transaction_date as date) > date_sub(current_date(),90) and cast(usage.transaction_date as date) <= current_date() then usage.agreement_id end) as last_90_days_txn_usage,
    count(distinct case when usage.is_transaction = '1' and cast(usage.transaction_date as date) > date_sub(current_date(),120) and cast(usage.transaction_date as date) <= current_date() then usage.agreement_id end) as last_120_days_txn_usage,
    count(distinct case when usage.is_transaction = '1' and created_via_acrobat_dc = 1 and agreement_sent_for_esignature = 1 then usage.agreement_id end) as acrobat_esign_txn_usage
from b2b.ss_sign_contract_base sign_contracts
left outer join (
    Select distinct accountid as contract_id, 
        echosignid as sign_account_id
    from b2b.sign_uda_accounts
    where echosignid != ''
    and echosignid is not NULL
    and accountid != ''
    and accountid is not NULL) accounts
on sign_contracts.contract_id = accounts.contract_id
left outer join 
    (SELECT delegate.contract_id,
        min(TO_DATE(delegate.start_ts)) startdate,
        max(TO_DATE(delegate.end_ts)) enddate,
        if(t2el.profile_id is NULL,  delegate.member_guid, t2el.auth_id) as member_guid
    from ocf_analytics.scd_delegate delegate
    left outer join ocf_analytics.vw_type2e_profile_reference t2el 
    ON delegate.member_guid = t2el.profile_id
	where delegate.contract_type in ('INDIRECT_ORGANIZATION','DIRECT_ORGANIZATION')
    and product_name in ('APAS','ASIG','ECHE','ECHG','ECHP')
    group by delegate.contract_id
    ,if(t2el.profile_id is NULL,  delegate.member_guid, t2el.auth_id)
) members
on sign_contracts.contract_id = members.contract_id
left outer join (
    SELECT 
        split(originator_adobe_guid,'@')[0] member_guid,
        case 
            when cast(substr(transaction_date, 1, 10) as date) is not null then substr(transaction_date, 1, 10)
            else substr(created, 1, 10)
            end as transaction_date, 
        agreement_id,
        is_transaction,
        created_via_acrobat_dc,
        agreement_sent_for_esignature,
        upper(status) status,
        UPPER(sender_signs) sender_signs,
        UPPER(composition) composition
    FROM b2b_stg.a_sign_pub_agreement
    WHERE 1=1
    and agreement_should_be_ignored = 0
    and originator_adobe_guid is not NULL 
    and originator_adobe_guid != '') usage
ON members.member_guid = usage.member_guid
left outer join (
	select agreement_id, 
		event 
	from b2b_stg.a_sign_agreement_event
	where event = 'SIGNATURE_REQUESTED') sfs
on usage.agreement_id = sfs.agreement_id
where accounts.contract_id is null 
and usage.transaction_date between sign_contracts.sign_start_date and sign_contracts.contract_end_date
and usage.transaction_date between members.startdate and members.enddate
group by sign_contracts.contract_id,
	sign_contracts.contract_end_date """)
             spark.sql(""" drop table if exists b2b.ss_sign_usage_data """)
             spark.sql(""" create table  b2b.ss_sign_usage_data as
Select * 
from (
    Select *
    from b2b.ss_sign_uda_usage
    union all
    select *
    from b2b.ss_sign_non_uda_usage) temp """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

