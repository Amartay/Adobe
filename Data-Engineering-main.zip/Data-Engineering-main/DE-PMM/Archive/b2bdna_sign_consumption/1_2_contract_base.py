# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")
             spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" drop table if exists b2b.ss_contract_base """)
             spark.sql(""" create table b2b.ss_contract_base as
Select
	IF(pvt.vip_contract is NULL or pvt.vip_contract='', jem.contract_id, pvt.vip_contract) as contract_id, 
	--regexp_replace(pvt.contract_start_date_veda,'\\.','-') contract_start_date,
	--regexp_replace(pvt.contract_end_date_veda,'\\.','-') contract_end_date,
    regexp_replace(pvt.contract_start_date_veda,r'[.]','-') contract_start_date,
	regexp_replace(pvt.contract_end_date_veda,r'[.]','-') contract_end_date,
	pvt.geo,
	pvt.market_area,
	pvt.market_area_description,
	pvt.region,
	pvt.region_description,
	pvt.sales_document, 
	pvt.sales_document_item,
	if(pvt.cc_phone_vs_web = 'N/A', 'RESELLER', pvt.cc_phone_vs_web) channel,
	pvt.route_to_market,
	pvt.product_name, 
	max(pvt.product_name_description) product_name_description, 
	pvt.product_config,
	pvt.product_config_description,
	pvt.market_segment,
	pvt.promo_type,
	sum(nvl(pvt.gross_new_subs,0)) AS gross_new_subs,
	sum(nvl(pvt.returns,0)) AS returns,
	sum(nvl(pvt.net_purchases,0)) AS net_purchases,
	sum(nvl(pvt.migrated_subs,0)) AS migrated_subs,
	sum(nvl(pvt.gross_cancellations,0)) AS gross_cancellations,
	sum(nvl(pvt.reactivated_subs,0)) AS reactivated_subs,
	sum(nvl(pvt.net_cancelled_subs,0)) AS net_cancelled_subs,
	sum(nvl(pvt.net_new_subs,0)) net_new_subs,
	sum(nvl(pvt.renewal_to,0)) renewals,
	sum(cast(nvl(pvt.net_new_arr_cfx, 0) as decimal(20,2))) net_new_arr_cfx
from csmb.vw_ccm_pivot4_all pvt
left outer join (
	Select distinct
		contract_id,
		subscription_account_guid
	from ocf_analytics.scd_license
	where 1=1
	and (contract_id is not null and contract_id != '')
	and (subscription_account_guid is not NULL and subscription_account_guid != '') 
	and contract_type != 'DIRECT_INDIVIDUAL'
    and contract_type in ('INDIRECT_ORGANIZATION','DIRECT_ORGANIZATION')) jem
on pvt.subscription_account_guid = jem.subscription_account_guid
where 1=1 
and pvt.source_type = 'TM'
and pvt.date_key >= '20171202'
and pvt.date_key <= regexp_replace(date_sub(current_date(),((cast(date_format(current_date(), 'u') as INT)+1)%7)+1),'-','')
group by 
	IF(pvt.vip_contract is NULL or pvt.vip_contract='', jem.contract_id, pvt.vip_contract), 
 	--regexp_replace(pvt.contract_start_date_veda,'\\.','-'),
	--regexp_replace(pvt.contract_end_date_veda,'\\.','-'),
	regexp_replace(pvt.contract_start_date_veda,r'[.]','-'),
	regexp_replace(pvt.contract_end_date_veda,r'[.]','-'),
	pvt.geo,
	pvt.market_area,
	pvt.market_area_description,
	pvt.region,
	pvt.region_description,
	pvt.sales_document, 
	pvt.sales_document_item,
	if(pvt.cc_phone_vs_web = 'N/A', 'RESELLER', pvt.cc_phone_vs_web),
	pvt.route_to_market,
	pvt.product_name, 
	pvt.product_config,
	pvt.product_config_description,
	pvt.market_segment,
	pvt.promo_type """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()