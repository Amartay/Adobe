# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" drop table if exists b2b.b2b_sign_consumption_renewals_tbl """)
             spark.sql(""" create  table b2b.b2b_sign_consumption_renewals_tbl AS
SELECT 
	renewals.renewal_qtr,
	renewals.renewal_wk,
	if(renewals.contract_id is not NULL and renewals.contract_id != '', renewals.contract_id,renewals.team_group_id) as contract_id,
	renewals.subs_offer,  
	renewals.cc_segment,
	renewals.market_segment,
	renewals.product_category,
	renewals.product_name_description,
	renewals.transaction_vs_seat,
	renewals.contract_type,
	renewals.route_to_market,
	renewals.cc_phone_vs_web,
	renewals.billing_payment_category,
	renewals.geo,
	renewals.market_area_description,             
	renewals.data_source_type,
	renewals.billing_plan_type,
	renewals.distributor, 
	renewals.reseller, 
	renewals.partner_level, 
	renewals.end_user,
	max(derived_contract_start_date) as derived_contract_start_date,
	max(derived_contract_end_date) as derived_contract_end_date,
	max(contract_start_date) as contract_start_date,
	max(contract_end_date) as contract_end_date,
	max(renewal_counter) as renewal_counter,
	min(first_mid_term_explicit_cancel_date) first_mid_term_explicit_cancel_date,
	min(first_mid_term_cc_failure_cancel_date) first_mid_term_cc_failure_cancel_date,
	min(first_pivot_cancel_date) first_pivot_cancel_date,
	sum(term_begin_active_count) as term_begin_active_count,
	sum(term_end_active_count) as  term_end_active_count,
	sum(expansion_at_renewal_same) as  expansion_at_renewal_same,
	sum(expansion_at_renewal_diff) as  expansion_at_renewal_diff,
	sum(mid_term_migration_to) as  mid_term_migration_to,
	sum(mid_term_reactivation) as  mid_term_reactivation,
	sum(mid_term_renewal_to) as  mid_term_renewal_to,
	sum(mid_term_cancel_explicit) as  mid_term_cancel_explicit,
	sum(mid_term_cancel_cc_failure) as  mid_term_cancel_cc_failure,
	sum(mid_term_partial_cancel_explicit) as  mid_term_partial_cancel_explicit,
	sum(mid_term_partial_cancel_cc_failure) as  mid_term_partial_cancel_cc_failure,
	sum(mid_term_returns) as  mid_term_returns,
	sum(end_term_migration_to) as  end_term_migration_to,
	sum(end_term_migration_from) as  end_term_migration_from,
	sum(end_term_cancel) as  end_term_cancel,
	sum(end_term_cancel_explicit) as  end_term_cancel_explicit,
	sum(end_term_cancel_cc_failure) as  end_term_cancel_cc_failure,
	sum(end_term_partial_cancel_explicit) as  end_term_partial_cancel_explicit,
	sum(end_term_partial_cancel_cc_failure) as  end_term_partial_cancel_cc_failure,
	sum(end_term_returns) as  end_term_returns,
	sum(end_term_reactivation) as  end_term_reactivation,
	sum(end_term_renewal_to) as  end_term_renewal_to,
	sum(end_term_renewal_from) as  end_term_renewal_from,
	sum(term_begin_active) as  term_begin_active,
	sum(up_for_renewal) as  up_for_renewal,
	sum(term_end_active) as  term_end_active,
	sum(term_end_renewal) as  term_end_renewal,
	sum(term_end_active_post_reactivation) as  term_end_active_post_reactivation,
	sum(term_end_arr) as  term_end_arr,
	sum(expansion_at_renewal_same_arr) as  expansion_at_renewal_same_arr,
	sum(expansion_at_renewal_diff_arr) as  expansion_at_renewal_diff_arr,
	sum(mid_term_migration_to_arr) as  mid_term_migration_to_arr,
	sum(mid_term_reactivation_arr) as  mid_term_reactivation_arr,
	sum(mid_term_renewal_to_arr) as  mid_term_renewal_to_arr,
	sum(mid_term_cancel_explicit_arr) as  mid_term_cancel_explicit_arr,
	sum(mid_term_cancel_cc_failure_arr) as  mid_term_cancel_cc_failure_arr,
	sum(mid_term_partial_cancel_explicit_arr) as  mid_term_partial_cancel_explicit_arr,
	sum(mid_term_partial_cancel_cc_failure_arr) as  mid_term_partial_cancel_cc_failure_arr,
	sum(mid_term_migration_from_arr) as  mid_term_migration_from_arr,
	sum(mid_term_renewal_from_arr) as  mid_term_renewal_from_arr,
	sum(mid_term_returns_arr) as  mid_term_returns_arr,
	sum(end_term_migration_from_arr) as  end_term_migration_from_arr,
	sum(end_term_cancel_arr) as  end_term_cancel_arr,
	sum(end_term_cancel_explicit_arr) as  end_term_cancel_explicit_arr,
	sum(end_term_cancel_cc_failure_arr) as  end_term_cancel_cc_failure_arr,
	sum(end_term_partial_cancel_explicit_arr) as  end_term_partial_cancel_explicit_arr,
	sum(end_term_partial_cancel_cc_failure_arr) as  end_term_partial_cancel_cc_failure_arr,
	sum(end_term_migration_to_arr) as  end_term_migration_to_arr,
	sum(end_term_reactivation_arr) as  end_term_reactivation_arr,
	sum(end_term_renewal_to_arr) as  end_term_renewal_to_arr,
	sum(end_term_renewal_from_arr) as  end_term_renewal_from_arr,
	sum(end_term_returns_arr) as  end_term_returns_arr,
	sum(annual_inactive_arr) as  annual_inactive_arr,
	sum(annual_active_arr) as  annual_active_arr,
	sum(term_begin_arr) as  term_begin_arr,
	sum(term_end_renewal_arr) as  term_end_renewal_arr,
	sum(term_end_active_arr) as  term_end_active_arr,
	sum(up_for_renewal_arr) as  up_for_renewal_arr,
	sum(term_end_active_post_reactivation_arr) as  term_end_active_post_reactivation_arr,
	sum(init_purchase) as init_purchase,
	sum(add_on_purchase) as add_on_purchase,
	sum(annual_active) as annual_active,
	sum(annual_inactive) as annual_inactive,
	sum(gross_new_arr) gross_new_arr,
	sum(net_cancelled_arr) net_cancelled_arr,
	sum(reactivated_arr) reactivated_arr,
	sum(returns_arr) returns_arr,
	sum(if(transaction_vs_seat = 'Transactions',
			up_for_renewal, 
			up_for_renewal * 150)) as ufr_consumable_transactions,
	sum(if(transaction_vs_seat = 'Transactions',
			(term_begin_active + annual_active), 
			(term_begin_active + annual_active) * 150)) as total_consumable_transactions,
	sum(if(entitled_vs_auth = 'Entitlement', 
			if(transaction_vs_seat = 'Transactions',
				(term_begin_active + annual_active), 
				(term_begin_active + annual_active) * 150),
			0)) as total_consumable_transactions_wo_auth,
	sum(book_qty) book_qty,
	sum(order_quantity) order_quantity,
	sum(if(transaction_vs_seat = 'Transactions',order_quantity, order_quantity * 150)) as order_quantity_based_consumable_transactions,
	sum(if(transaction_vs_seat = 'Transactions',book_qty, book_qty * 150)) as book_qty_based_consumable_transactions,
	max(product_language) product_language,
	max(consuming_org_industry) consuming_org_industry,
	max(consuming_org_country) consuming_org_country,
	sum(net_booking_amt_usd) net_booking_amt_usd,
	max(net_price) net_price,
	min(contract_duration_months) contract_duration_months,
	min(contract_duration_days) contract_duration_days,
	max(max_contract_duration_months) max_contract_duration_months,
	max(max_contract_duration_days) max_contract_duration_days,
	max(payment_method) payment_method,
	max(payment_term) payment_term,
	sum(gross_booking_amount_usd_new) gross_booking_amount_usd_new,
	max(eu_domain_name) eu_domain_name,
	max(num_users) num_users,
	max(billable_transactions) billable_transactions,
	max(total_agreements) total_agreements,
	max(total_sent_for_esignature) total_sent_for_esignature,
	max(last_30_days_agreement_sent_for_esignature) last_30_days_usage,
	max(last_60_days_agreement_sent_for_esignature) last_60_days_usage,
	max(last_90_days_agreement_sent_for_esignature) last_90_days_usage,
	max(last_180_days_agreement_sent_for_esignature) last_180_days_usage,
	max(last_360_days_agreement_sent_for_esignature) last_360_days_usage,
	max(acrobat_esign_usage) acrobat_esign_usage
FROM (
	select 
		*,
		if(product_config in ('DCATE','DCITE'), 'Transactions','Seat') as transaction_vs_seat,
		if(promo_type like '%KB AUTH%' or promo_type like '%PHONE AUTH%', 'Authentication', 'Entitlement') as entitled_vs_auth
	from b2b_stg.pp_smb_contract_renewal
	where UPPER(product_category) in ('SIGN','ACROBAT + E-SIGN')) renewals
left outer join  (
	select 
		renewals.subscription_id,
		renewals.renewal_date,
		sum(fact_sales.book_qty) as book_qty,
		max(fact_sales.consuming_org_industry) as consuming_org_industry,
		max(fact_sales.consuming_org_country) as consuming_org_country,
		max(fact_sales.consuming_org_city) as consuming_org_city,
		sum(fact_sales.net_booking_amt_usd) net_booking_amt_usd,
		sum(fact_sales.order_quantity) order_quantity,
		max(fact_sales.offer_code) offer_code,
		max(fact_sales.product_language) product_language,
		max(fact_sales.net_price) net_price,
		max(fact_sales.eu_domain_name) eu_domain_name,
		min(fact_sales.contract_duration_months) contract_duration_months,
		min(fact_sales.contract_duration_days) contract_duration_days,
		max(fact_sales.contract_duration_months) max_contract_duration_months,
		max(fact_sales.contract_duration_days) max_contract_duration_days,
		min(fact_sales.lic_start_date) lic_start_date,
		max(fact_sales.lic_end_date) lic_end_date,
		sum(fact_sales.gross_booking_amount_usd_new) gross_booking_amount_usd_new,
		max(fact_sales.payment_method) payment_method,
		max(fact_sales.payment_term) payment_term,
		max(fact_sales.team_org_name) team_org_name
	from (
		select 
			concat(LPAD(sales_document,10,0),LPAD(sales_document_item,6,0)) as subscription_id, 
			* 
		from ids_can_analytics.sales_item) fact_sales 
	inner join b2b_stg.pp_smb_contract_renewal renewals
	on fact_sales.subscription_id = renewals.subscription_id
 	where (from_unixtime(UNIX_TIMESTAMP(fact_sales.contract_start_date, "yyyyMMdd"), 'yyyy-MM-dd')) between renewals.contract_start_date and renewals.contract_end_date
	GROUP BY 
		renewals.subscription_id,
		renewals.renewal_date ) fact_sales 
on fact_sales.subscription_id = renewals.subscription_id 
and fact_sales.renewal_date = renewals.renewal_date
LEFT OUTER JOIN (
	SELECT 
		renewals.team_group_id,
		renewals.renewal_date,
		count(distinct sign_usage.member_guid) as num_users,
		count(distinct if(is_transaction = 1, agreement_id,NULL)) as billable_transactions,
		count(distinct agreement_id) as total_agreements,
		sum(agreement_sent_for_esignature) as total_sent_for_esignature,
		sum(if(to_date(transaction_date) BETWEEN  date_sub(CURRENT_DATE, 30) AND CURRENT_DATE,agreement_sent_for_esignature,0)) as last_30_days_agreement_sent_for_esignature,
		sum(if(to_date(transaction_date) BETWEEN  date_sub(CURRENT_DATE, 60) AND CURRENT_DATE,agreement_sent_for_esignature,0)) as last_60_days_agreement_sent_for_esignature,
		sum(if(to_date(transaction_date) BETWEEN  date_sub(CURRENT_DATE, 90) AND CURRENT_DATE,agreement_sent_for_esignature,0)) as last_90_days_agreement_sent_for_esignature,
		sum(if(to_date(transaction_date) BETWEEN  date_sub(CURRENT_DATE, 180) AND CURRENT_DATE,agreement_sent_for_esignature,0)) as last_180_days_agreement_sent_for_esignature,
		sum(if(to_date(transaction_date) BETWEEN  date_sub(CURRENT_DATE, 360) AND CURRENT_DATE,agreement_sent_for_esignature,0)) as last_360_days_agreement_sent_for_esignature,
		count(distinct case when created_via_acrobat_dc = 1 and agreement_sent_for_esignature = 1 then agreement_id end) as acrobat_esign_usage
	from (
		select 
			if(contract_type = 'DIRECT_ORGANIZATION', contract_id, team_group_id) as renewal_contract_id,
			* 
		from b2b_stg.pp_smb_contract_renewal) renewals
	INNER JOIN b2b.sign_all_users sign_all_users 
	on renewals.renewal_contract_id = sign_all_users.contract_id
	INNER JOIN (
		SELECT 
			upper(split(originator_adobe_guid, '@')[0]) as member_guid, 
			(case 
				when is_transaction = 1 THEN TO_DATE(transaction_date)
				else TO_DATE(substr(created, 1, 10))
			 end) as transaction_date, 
			agreement_id,
			is_transaction,
			created_via_acrobat_dc,
			agreement_sent_for_esignature,
			agreement_fill_and_sign
		FROM b2b_stg.a_sign_pub_agreement
		WHERE originator_adobe_guid is not NULL
		and originator_adobe_guid != ''
		and agreement_should_be_ignored = 0) sign_usage 
	ON UPPER(sign_usage.member_guid) = UPPER(sign_all_users.member_guid)
	where TO_DATE(sign_usage.transaction_date) between TO_DATE(renewals.contract_start_date) and date_add(TO_DATE(renewals.contract_end_date),1)
	group by 
		renewals.team_group_id,
		renewals.renewal_date) sign_consumption 
ON renewals.team_group_id = sign_consumption.team_group_id 
and renewals.renewal_date = sign_consumption.renewal_date
group by  
	renewals.renewal_qtr,
	renewals.renewal_wk,
	if(renewals.contract_id is not NULL and renewals.contract_id != '', renewals.contract_id,renewals.team_group_id),
	renewals.subs_offer,  
	renewals.cc_segment,
	renewals.market_segment,
	renewals.product_category,
	renewals.product_name_description,
	renewals.transaction_vs_seat,
	renewals.contract_type,
	renewals.route_to_market,
	renewals.cc_phone_vs_web,
	renewals.billing_payment_category,
	renewals.geo,
	renewals.market_area_description,             
	renewals.data_source_type,
	renewals.billing_plan_type,
	renewals.distributor,
	renewals.reseller, 
	renewals.partner_level, 
	renewals.end_user """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()