# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" drop table if exists b2b.ss_sign_contract_base """)
             spark.sql(""" create table b2b.ss_sign_contract_base as
select 
    sign_contracts.contract_id,
    sign_contracts.contract_start_date,
    sign_contracts.contract_end_date,
	if(cast(sign_contracts.contract_end_date as date)>=current_date(),'Yes','No') as current_term,
	events.sign_start_date,
    if(cast(contract_status.latest_end_date as date)>=current_date() and coalesce(direct_ufr.up_for_renewal, indirect_ufr.up_for_renewal)>0, 'Active', 'Inactive') contract_status,
    if(cast(sign_contracts.contract_end_date as date)>=current_date() and coalesce(direct_ufr.up_for_renewal, indirect_ufr.up_for_renewal)>0, cast(date_add(cast(sign_contracts.contract_end_date as date),1) as string), null) anniversary_date,
    ctype.contract_type,
    if(partner.distributor='0','',partner.distributor) distributor,
    if(partner.reseller='0','',partner.reseller) reseller,
    partner.partner_level,
    partner.end_user, 
    coalesce(direct_ufr.term_begin_active, indirect_ufr.term_begin_active) term_begin_active, 
    coalesce(direct_ufr.annual_active, indirect_ufr.annual_active) annual_active, 
    coalesce(direct_ufr.up_for_renewal, indirect_ufr.up_for_renewal) up_for_renewal, 
    coalesce(direct_ufr.term_begin_arr, indirect_ufr.term_begin_arr) term_begin_arr, 
    coalesce(direct_ufr.annual_active_arr, indirect_ufr.annual_active_arr) annual_active_arr, 
    coalesce(direct_ufr.up_for_renewal_arr, indirect_ufr.up_for_renewal_arr) up_for_renewal_arr, 
    coalesce(direct_ufr.total_consumable_transactions, indirect_ufr.total_consumable_transactions) total_consumable_transactions, 
    coalesce(direct_ufr.total_consumable_transactions_wo_auth, indirect_ufr.total_consumable_transactions_wo_auth) total_consumable_transactions_wo_auth
from (
    Select
        contract_id,
        contract_end_date,
        min(contract_start_date) contract_start_date, 
        collect_set(product_name) all_products
    from b2b.ss_contract_base 
    group by contract_id,
        contract_end_date
    having array_contains(collect_set(product_name),'APAS')
    or array_contains(collect_set(product_name),'ASIG')
    or array_contains(collect_set(product_name),'ECHE')
    or array_contains(collect_set(product_name),'ECHG')
    or array_contains(collect_set(product_name),'ECHP')) sign_contracts
left outer join (
    Select
        contract_id,
        max(contract_end_date) latest_end_date
    from b2b.ss_contract_base 
    where product_name in ('APAS','ASIG','ECHE','ECHG','ECHP') 
    and contract_id!= '' 
    and contract_id is not null
    group by contract_id) contract_status
on sign_contracts.contract_id = contract_status.contract_id
left outer join (
    select 
        if(pvt.vip_contract is not NULL and pvt.vip_contract != '', pvt.vip_contract, jem_seat.contract_id) contract_id,
        regexp_replace(contract_end_date_veda,r'[.]','-') contract_end_date,
        min(date_date) sign_start_date
    from csmb.vw_ccm_pivot4_all pvt
    left outer join ocf_analytics.scd_license jem_seat
    on pvt.subscription_account_guid = jem_seat.subscription_account_guid
    where 1=1
    and pvt.event_source = 'EVENT'
    and pvt.product_name in ('APAS','ASIG','ECHE','ECHG','ECHP')
    and (gross_new_subs>0 or migrated_to>0 or reactivated_subs>0 or renewal_to>0)
    and contract_type in ('INDIRECT_ORGANIZATION','DIRECT_ORGANIZATION')
    group by 
        if(pvt.vip_contract is not NULL and pvt.vip_contract != '', pvt.vip_contract, jem_seat.contract_id),
        regexp_replace(contract_end_date_veda,r'[.]','-')) events
on sign_contracts.contract_id = events.contract_id
and sign_contracts.contract_end_date = events.contract_end_date
left outer join (
    Select distinct
        contract_id, 
        contract_type
    from ocf_analytics.dim_contract) ctype
on sign_contracts.contract_id = ctype.contract_id
left outer join (
    select team_group_id, 
        distributor, 
        reseller, 
        partner_level, 
        end_user, 
        ROW_NUMBER() OVER(PARTITION BY team_group_id ORDER BY order_date desc) as rownum
    from csmb.vw_dim_contract_partner
    where team_type ='TI' and end_user not in ('GDPR_DELETED', 'null') and end_user is not null ) partner
on sign_contracts.contract_id = partner.team_group_id
and partner.rownum = 1
left outer join (
    select contract_id, 
        derived_contract_end_date, 
        sum(term_begin_active) term_begin_active, 
        sum(annual_active) annual_active, 
        sum(up_for_renewal) up_for_renewal, 
        sum(term_begin_arr) term_begin_arr, 
        sum(annual_active_arr) annual_active_arr, 
        sum(up_for_renewal_arr) up_for_renewal_arr, 
        sum(total_consumable_transactions) total_consumable_transactions, 
        sum(total_consumable_transactions_wo_auth) total_consumable_transactions_wo_auth
    from b2b.b2b_sign_consumption_renewals_tbl        
    where cc_phone_vs_web not in ('VIP-PHONE','N/A')
    group by contract_id, derived_contract_end_date ) direct_ufr
on sign_contracts.contract_id = direct_ufr.contract_id
and sign_contracts.contract_end_date = direct_ufr.derived_contract_end_date
left outer join (
    select contract_id, 
        contract_end_date, 
        sum(term_begin_active) term_begin_active, 
        sum(annual_active) annual_active, 
        sum(up_for_renewal) up_for_renewal, 
        sum(term_begin_arr) term_begin_arr, 
        sum(annual_active_arr) annual_active_arr, 
        sum(up_for_renewal_arr) up_for_renewal_arr, 
        sum(total_consumable_transactions) total_consumable_transactions, 
        sum(total_consumable_transactions_wo_auth) total_consumable_transactions_wo_auth
    from b2b.b2b_sign_consumption_renewals_tbl
    where cc_phone_vs_web in ('VIP-PHONE','N/A')
    group by contract_id, contract_end_date ) indirect_ufr
on sign_contracts.contract_id = indirect_ufr.contract_id
and sign_contracts.contract_end_date = indirect_ufr.contract_end_date """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()