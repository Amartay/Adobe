# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" drop table if exists b2b.ss_sign_consumption_order_lvl_data """)
             spark.sql(""" create table b2b.ss_sign_consumption_order_lvl_data as
Select sign_contracts.contract_id,
    sign_contracts.contract_start_date,
    sign_contracts.contract_end_date,
    sign_contracts.current_term,
    sign_contracts.sign_start_date,
    sign_contracts.contract_status,
    sign_contracts.anniversary_date,
    sign_contracts.contract_type,
    sign_contracts.distributor,
    sign_contracts.reseller,
    sign_contracts.partner_level,
    sign_contracts.end_user,
    sign_contracts.term_begin_active, 
    sign_contracts.annual_active, 
    sign_contracts.up_for_renewal, 
    sign_contracts.term_begin_arr, 
    sign_contracts.annual_active_arr, 
    sign_contracts.up_for_renewal_arr, 
    sign_contracts.total_consumable_transactions,
    sign_contracts.total_consumable_transactions_wo_auth as transaction_quota,
    sign_contracts.term_begin_active + sign_contracts.annual_active as book_qty,
    sign_contracts.term_begin_arr + sign_contracts.annual_active_arr as net_booking_amt,
    order_details.geo,
    order_details.market_area,
    order_details.market_area_description,
    order_details.region,
    order_details.region_description,
    order_details.sales_document, 
    order_details.sales_document_item,
    order_details.contract_start_date as order_start_date,
    order_details.contract_end_date as order_end_date,
    order_details.channel,
    order_details.route_to_market,
    order_details.product_name, 
    order_details.product_name_description,
    order_details.product_config,
    order_details.product_config_description,
    order_details.market_segment,
    if(UPPER(order_details.product_config) in ('DCATE','DCITE'),'Transaction','Seat') as seat_vs_transaction,
    order_details.gross_new_subs,
    order_details.returns,
    order_details.net_purchases,
    order_details.migrated_subs,
    order_details.gross_cancellations,
    order_details.reactivated_subs,
    order_details.net_cancelled_subs,
    order_details.net_new_subs,
    order_details.renewals,
    order_details.net_new_arr_cfx,
    case 
        when UPPER(order_details.product_config) in ('DCATE','DCITE') then (order_details.net_new_subs + order_details.renewals)
        else (order_details.net_new_subs + order_details.renewals)*150
        end as pivot_quota,
    mm_data.dc_sign_psm,                                           
    if(mm_data.vip_contract is not NULL, 'Y','N') as MM_contract_flag 
from b2b.ss_sign_contract_base sign_contracts
left outer join (Select * 
                from b2b.ss_contract_base 
                where product_name in ('APAS','ASIG','ECHE','ECHG','ECHP') 
                and contract_id!= '' 
                and contract_id is not null) order_details
on sign_contracts.contract_id = order_details.contract_id
and sign_contracts.contract_end_date = order_details.contract_end_date
left outer join (select vip_contract, 
                        max(dcpsm_name) as dc_sign_psm 
                 from b2b.agodah_mmviplist
                 group by vip_contract) mm_data          
on sign_contracts.contract_id = mm_data.vip_contract """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

