# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" SET hive.mapred.mode=nonstrict """)
             spark.sql(""" drop table if exists b2b.ss_sign_consumption_contract_lvl_data """)
             spark.sql(""" create table  b2b.ss_sign_consumption_contract_lvl_data as
Select order_lvl.contract_id,
    order_lvl.contract_start_date,
    order_lvl.contract_end_date,
    order_lvl.current_term,
    order_lvl.sign_start_date,
    order_lvl.contract_status,
    order_lvl.anniversary_date,
    order_lvl.contract_type,
    order_lvl.distributor,
    order_lvl.reseller,
    order_lvl.partner_level,
    order_lvl.end_user,
    order_lvl.term_begin_active, 
    order_lvl.annual_active, 
    order_lvl.up_for_renewal, 
    order_lvl.term_begin_arr, 
    order_lvl.annual_active_arr, 
    order_lvl.up_for_renewal_arr, 
    coalesce(order_lvl.transaction_quota, sum(order_lvl.pivot_quota)) total_transaction_quota,
    coalesce(order_lvl.book_qty, sum((order_lvl.net_new_subs + order_lvl.renewals))) total_book_qty,
    coalesce(order_lvl.net_booking_amt, sum(order_lvl.net_new_arr_cfx)) total_booking_amount,
    order_lvl.geo,
    order_lvl.market_area,
    order_lvl.market_area_description,
    order_lvl.market_segment,
    order_lvl.channel,
    order_lvl.route_to_market,
    min(order_lvl.order_start_date) usage_start_date,
    sort_array(collect_set(order_lvl.product_name)) product_names, 
    sort_array(collect_set(order_lvl.product_name_description)) product_name_descriptions, 
    sort_array(collect_set(order_lvl.seat_vs_transaction)) seat_vs_transactions, 
    order_lvl.dc_sign_psm,                          
    order_lvl.MM_contract_flag,                     
    usage.earliest_transaction_date,
    usage.latest_transaction_date,
    usage.n_agreements,
    usage.agreement_sent_for_esignature,
    usage.last_30_days_sent_for_sign,
    usage.last_60_days_sent_for_sign,
    usage.last_90_days_sent_for_sign,
    usage.last_120_days_sent_for_sign,
    usage.total_billable_usage,
    usage.txn_usage,
    usage.last_30_days_txn_usage,
    usage.last_60_days_txn_usage,
    usage.last_90_days_txn_usage,
    usage.last_120_days_txn_usage,
    usage.acrobat_esign_txn_usage
from b2b.ss_sign_consumption_order_lvl_data order_lvl
left outer join b2b.ss_sign_usage_data usage
on order_lvl.contract_id = usage.contract_id
and order_lvl.contract_end_date = usage.contract_end_date
group by order_lvl.contract_id,
    order_lvl.contract_start_date,
    order_lvl.contract_end_date,
    order_lvl.current_term,
    order_lvl.sign_start_date,
    order_lvl.contract_status,
    order_lvl.anniversary_date,
    order_lvl.contract_type,
    order_lvl.distributor,
    order_lvl.reseller,
    order_lvl.partner_level,
    order_lvl.end_user,
    order_lvl.term_begin_active, 
    order_lvl.annual_active, 
    order_lvl.up_for_renewal, 
    order_lvl.term_begin_arr, 
    order_lvl.annual_active_arr, 
    order_lvl.up_for_renewal_arr, 
    order_lvl.transaction_quota,
    order_lvl.book_qty,
    order_lvl.net_booking_amt,
    order_lvl.geo,
    order_lvl.market_area,
    order_lvl.market_area_description,
    order_lvl.market_segment,
    order_lvl.channel,
    order_lvl.route_to_market,
    order_lvl.dc_sign_psm,                          
    order_lvl.MM_contract_flag,                     
    usage.earliest_transaction_date,
    usage.latest_transaction_date,
    usage.n_agreements,
    usage.agreement_sent_for_esignature,
    usage.last_30_days_sent_for_sign,
    usage.last_60_days_sent_for_sign,
    usage.last_90_days_sent_for_sign,
    usage.last_120_days_sent_for_sign,
    usage.total_billable_usage,
    usage.txn_usage,
    usage.last_30_days_txn_usage,
    usage.last_60_days_txn_usage,
    usage.last_90_days_txn_usage,
    usage.last_120_days_txn_usage,
    usage.acrobat_esign_txn_usage """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

