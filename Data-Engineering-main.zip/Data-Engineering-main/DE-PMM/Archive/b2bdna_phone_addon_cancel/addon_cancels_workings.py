from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" With snapshot as (
	Select 
		fiscal_yr_and_qtr_desc qtr, 
		min(date_key) startdate,
		max(date_key) enddate
	from ids_coredata.dim_date
	where fiscal_currnt_yr_to_dt_flg='Y' or fiscal_prv_yr_flag = 'Y'
	group by fiscal_yr_and_qtr_desc)
INSERT OVERWRITE TABLE b2b.addon_cancel_workings
SELECT 
    A.manual_adjust_flag,
    A.fiscal_yr_desc,
    A.fiscal_yr_and_qtr_desc,
    A.route_to_market,
    A.cc_phone_vs_web,
    B.fiscal_yr_and_qtr_desc as csam_qtr,
    B.csam_market_area as csam_market_area,
    B.csam as csam,
    A.geo,
    A.market_area,
    A.market_area_description,
    A.subscription_account_guid,
    jem.contract_id,
    CASE
    	WHEN A.manual_adjust_flag = 'Yes' THEN 'Manual Adjustment'
    	WHEN A.payment_method = '00' THEN 'VIP Non-CC (00)'
    	WHEN A.payment_method = '02' THEN 'Credit Card (02)'
    	WHEN A.payment_method = '05' THEN 'Bank Transfer (05)'
    	WHEN A.payment_method = '06' THEN 'Direct Debit (06)'
    	WHEN A.payment_method = '08' THEN 'Paypal'
    	WHEN A.payment_method = '09' THEN 'Purchase Order'
    	WHEN A.payment_method = '99' THEN 'No Instrument'
    	ELSE 'UNKNOWN' end payment_method_desc,
    A.promo_type,
    A.market_segment,
    A.product_config_description,
    coalesce(if(upper(A.promo_type) like '%K12%','K-12',
                if(upper(A.promo_type) like '%LAB%','CCDA',
                    if(upper(A.product_config_description) like '%ENT%', 'CCE',
                        qrfp.qrf))),qrfp_rest.qrf) as qrf_product,
    A.subs_offer as subscription_offering,
    A.entitlement_type,
    A.cc_segment,
    A.cc_segment_offer,
    A.prod_group_hier as internal_segment,
    A.product_name_description,
    CASE
    	WHEN A.manual_adjust_flag = 'Yes' THEN 'Manual Adjustment'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between -49 and -10 THEN '-10 to -49'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between -9 and -5 THEN '-5 to -9'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between -4 and -2 THEN '-2 to -4'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) = -1 THEN '-1'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) = 0 THEN '0'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) = 1 THEN '1'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between 2 and 4 THEN '2 to 4'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between 5 and 9 THEN '5 to 9'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between 10 and 49 THEN '10 to 49'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between 50 and 99 THEN '50 to 99'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between 100 and 199 THEN '100 to 199'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between 200 and 299 THEN '200 to 299'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) between 300 and 999 THEN '300 to 999'
    	WHEN if(sum(A.fqtr_begin_active) = 0, sum(A.net_new_subs), sum(A.fqtr_begin_active)) >= 1000 THEN '>=1000+'
    	ELSE 'new_seat' end as beg_seat_band,
    round(datediff(current_date(), to_date(contract.contract_created_date))/365.25,0) as contract_tenure,
    sum(A.fqtr_begin_active) as fqtr_begin_active,
    sum(nvl(A.fqtr_begin_arr_cfx,0)) AS fqtr_begin_arr_cfx,
    sum(nvl(A.fqtr_end_active,0)) AS fqtr_to_date_end_active,
    sum(nvl(A.fqtr_end_arr_cfx,0)) AS fqtr_to_date_end_arr_cfx, 
    sum(nvl(A.net_purchases,0)) AS gross_new_subs,
    sum(nvl(A.net_purchases_arr_cfx,0)) AS gross_new_arr_cfx,
    sum(nvl(A.net_cancelled_subs,0)) AS net_cancelled_subs,
    sum(nvl(A.net_cancelled_arr_cfx,0)) AS net_cancelled_arr_cfx,
    sum(nvl(A.addl_purchase_same,0)) + sum(nvl(A.addl_purchase_diff,0)) AS addl_purchase,
    sum(nvl(A.gross_new_arr_cfx,0)) - sum(nvl(A.init_purchase_arr_cfx,0)) AS addl_purchases_arr_cfx, 
    sum(nvl(A.migrated_to_arr_cfx,0)) AS migrated_to_arr_cfx,
    sum(nvl(A.migrated_from_arr_cfx,0)) AS migrated_from_arr_cfx
from (
    Select *
    from csmb.vw_ccm_pivot4_all pvt
    left outer join snapshot dt
    on pvt.fiscal_yr_and_qtr_desc = dt.qtr
    where source_type = 'TM'
        and ((event_source != 'SNAPSHOT') or (event_source = 'SNAPSHOT' and (pvt.date_key = dt.startdate or pvt.date_key = dt.enddate)))
    ) A


LEFT OUTER JOIN (
    Select upper(subscription_account_guid) subs_guid, 
           upper(contract_id) contract_id,
	       sum(provisioned_quantity) as total_seats
    from 
    ( 
    select distinct subscription_account_guid, contract_id, provisioned_quantity,
    ROW_NUMBER() over(partition by contract_id,subscription_account_guid order by scd_end desc ) rown
    from ocf_analytics.scd_license license
    where contract_id is not null and contract_id != '' 
    and subscription_account_guid is not null and subscription_account_guid != ''
    --and scd_end = '9999-12-31 00:00:00' 
    and contract_type in ('INDIRECT_ORGANIZATION','DIRECT_ORGANIZATION')
    )
    where rown = 1
    group by subscription_account_guid, contract_id) jem
on A.subscription_account_guid = jem.subs_guid


left outer join (
    Select * 
    from ocf_analytics.dim_contract 
    where country_code is not null) contract
on jem.contract_id = upper(contract.contract_id)
left outer join (
    Select bob.fiscal_yr_and_qtr_desc,
        upper(bob.contract_id) as contract_id,
        upper(bob.csam) as csam,
        upper(bob.csam_market_area) as csam_market_area
    from b2b.bob_raw bob
    where upper(bob.csam_bob_flag) = 'YES') B
on A.fiscal_yr_and_qtr_desc = B.fiscal_yr_and_qtr_desc
and jem.contract_id = upper(B.contract_id)
left outer join b2b.dim_qrf_product1 qrfp
on upper(A.market_segment) = upper(qrfp.market_segment)
and upper(A.product_name) = upper(qrfp.product_name)
and upper(A.subs_offer) = upper(qrfp.subs_offer)
left outer join b2b.dim_qrf_product2 qrfp_rest
on upper(A.market_segment) = upper(qrfp_rest.market_segment)
and upper(A.product_name) = upper(qrfp_rest.product_name)
group by 
    A.manual_adjust_flag,
    A.fiscal_yr_desc,
    A.fiscal_yr_and_qtr_desc,
    A.route_to_market,
    A.cc_phone_vs_web,
    B.fiscal_yr_and_qtr_desc,
    B.csam_market_area,
    B.csam,
    A.geo,
    A.market_area,
    A.market_area_description,
    A.subscription_account_guid,
    jem.contract_id,
    A.payment_method,
    A.promo_type,
    A.market_segment,
    A.product_config_description,
    qrfp.qrf,
    qrfp_rest.qrf,
    A.subs_offer,
    A.entitlement_type,
    A.cc_segment,
    A.cc_segment_offer,
    A.prod_group_hier,
    A.product_name_description,
    contract.contract_created_date """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()