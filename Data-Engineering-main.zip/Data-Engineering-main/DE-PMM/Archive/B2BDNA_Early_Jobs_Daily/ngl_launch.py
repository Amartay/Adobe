# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")

             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')

             spark.conf.set("spark.sql.statistics.histogram.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewedJoin.enabled",True)

             
             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" set hive.exec.reducers.max=50 """)
             spark.sql(""" set hive.exec.reducers.bytes.per.reducer=1000000 """)
             spark.sql(""" set hive.optimize.distinct.rewrite=true """)
             spark.sql(""" set hive.map.aggr=true """)
             spark.sql(""" SET hive.exec.Compress.intermediate=true """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
             spark.sql(""" SET hive.auto.convert.join=true """)
             spark.sql(""" SET hive.merge.mapfiles=true """)
             spark.sql(""" SET hive.merge.mapredfiles=true """)
             spark.sql(""" SET hive.merge.size.per.task=512000000 """)
             spark.sql(""" SET hive.merge.smallfiles.avgsize=512000000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=false """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.cbo.enable=true """)
             spark.sql(""" set hive.compute.query.using.stats=true """)
             spark.sql(""" set hive.stats.fetch.column.stats=true """)
             spark.sql(""" set hive.stats.fetch.partition.stats=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.exec.dynamic.partition=true """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.support.concurrency = false """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.applaunch_all partition (month, year, license_type)
SELECT 
DISTINCT
member_guid,
'NULL' AS thor_ver, 
cast('NULL' as int) AS thor_install_status,
cast(split(event_org_guid,'@')[0] as int) as org_id,
source_version AS CC_ver, 
cast('NULL' as bigint) AS launch_count_epochtime,
event_workflow  AS user_action,
source_name AS app_leid,
cast('NULL' as int) AS launch_count, 
event_device_guid AS machine_id,
ngl_license_id AS serialnum, 
source_platform as os_platform,
ngl_operating_mode as operating_mode,  
source_os_version AS os_version, 
cast(event_date as date) AS date, 
month(event_date) AS month, 
year(event_date) AS year, 
'NGL' AS license_type
FROM darwin.ngl_cops_events
WHERE event_date >= date_add(last_day(add_months(current_date, -3)),1) 
and ngl_operating_mode not like '%FRL%'
and event_category = 'SERVICE'
and event_subcategory = 'INITIAL'
and event_type = 'api'
and event_subtype = 'response'
and event_language != 'null' """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()