# Databricks notebook source
# MAGIC %sql
# MAGIC Refresh table ocf_analytics.type2emap;
# MAGIC Refresh table ocf_analytics.type2emap;
# MAGIC Refresh table mdpd_stage.scd_seat_provisioning;
# MAGIC Refresh table ocf_analytics.vw_type2e_profile_reference;
# MAGIC Refresh table mdpd_stage.scd_seat_provisioning;
# MAGIC Refresh table ocf_analytics.dim_seat;
# MAGIC Refresh table csmb.vw_ccm_pivot4_all;
# MAGIC Refresh table ocf_analytics.vw_type2e_profile_reference;
# MAGIC Refresh table b2b.team_seats_by_provisioning;
# MAGIC Refresh table ids_coredata.dim_date;
# MAGIC Refresh table ids_coredata.dim_country;
# MAGIC Refresh table csmb_app.fact_csmb_subscription_detail;
# MAGIC Refresh table mdpd_stage.scd_seat_provisioning;

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             
             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')

             #spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             #spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             #spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" WITH 
	snapshot as (
		SELECT max(date_date) as last_saturday, max(fiscal_yr_and_wk_desc) this_week
		from Ids_coredata.dim_date
		where TO_DATE(date_date) <= CURRENT_DATE()
		and UPPER(day_name) = 'FRIDAY'),
	type_2e_adjustment_code AS (
		SELECT distinct 
			auth_id,
			profile_id,
			delegation_start_date,
			migration_date
		from (
			select distinct 
				contract_id,
				seat_id,
				member_guid as auth_id,
				t2el.profile_id,
				TO_DATE(startdate_dttm) as delegation_start_date,
				TO_DATE(enddate_dttm) as migration_date,
				ROW_NUMBER() OVER(PARTITION by t2el.profile_id order by TO_DATE(enddate_dttm) desc) as rownum
			from mdpd_stage.scd_seat_provisioning scd
			inner join ocf_analytics.vw_type2e_profile_reference t2el 
			on UPPER(t2el.auth_id) = UPPER(scd.member_guid)
			cross join snapshot dt
			where 1=1
			and UPPER(contract_type) in ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION')
			and UPPER(seat_delegation_status) = 'ASSIGNED'  
			and UPPER(seat_status) = 'ACTIVE'
			and TO_DATE(enddate_dttm) between DATE_SUB(TO_DATE(dt.last_saturday),60) AND TO_DATE(dt.last_saturday) 
			and t2el.profile_id is not NULL) migrated 
		where rownum = 1) 
INSERT OVERWRITE TABLE b2b.ss_sustained_base PARTITION(snapshot_date, snapshot_period)
SELECT 
	count(distinct scd_prov.member_guid) as members,
	sum(scd_prov.seat_fwk_begin_arr) as seat_fwk_begin_arr,
	datediff(TO_DATE(dt.last_saturday), TO_DATE(scd_prov.delegation_start_date)) as seat_assigned_duration,
	datediff(TO_DATE(scd_prov.delegation_end_date), TO_DATE(dt.last_saturday)) as seat_delegation_end_duration,
	datediff(TO_DATE(dt.last_saturday), TO_DATE(team_seats_by_provisioning.seat_creation_date)) as seat_creation_duration,
	datediff(TO_DATE(team_seats_by_provisioning.seat_cancelled_date), TO_DATE(dt.last_saturday)) as seat_cancel_duration,
	scd_prov.product_name,
	scd_prov.seat_status as current_seat_status,
	scd_prov.seat_delegation_status as current_seat_delegation_status,
	scd_prov.geo,
	scd_prov.entitlement_type,
	scd_prov.market_segment,
	scd_prov.route_to_market,
	scd_prov.contract_type,
	scd_prov.regular_vs_promotion,
	scd_prov.cloud_type,
	countries.geo_code,
	countries.market_area_code,
	countries.market_area_description AS market_area_description,
	scd_prov.subs_offer,
	scd_prov.cc_segment,
	scd_prov.cc_segment_offer,
	scd_prov.product_name_description,
	hau.no_of_active_days_28_days,
	hau.no_of_products_used_28_days,
	hau.products_used_28_days,
	hau.no_of_active_days_60_days,
	hau.no_of_products_used_60_days,
	hau.products_used_60_days,
	hau.no_of_active_days_180_days,
	t2e_migration_status,
	dt.last_saturday,
	dt.this_week
from (
    SELECT distinct
		scd.contract_id,
        scd.seat_id,
        scd.member_guid,
        if(t2el.profile_id is NULL,scd.member_guid,t2el.auth_id) as auth_id,
		scd.product_name,
		scd.seat_status,
		scd.seat_delegation_status,
		scd.geo,
		scd.country_code,
		scd.entitlement_type,
		scd.market_segment,
		scd.route_to_market,
		scd.contract_type,
		scd.regular_vs_promotion,
		scd.cloud_type,
		scd.subs_offer,
		scd.cc_segment,
		scd.cc_segment_offer,
		scd.product_name_description,
		scd.seat_fwk_begin_arr,
		if(scd.delegation_start_date between DATE_SUB(TO_DATE(dt.last_saturday),60) AND TO_DATE(dt.last_saturday) and TO_DATE(type_2e.delegation_start_date) is not NULL,
			TO_DATE(type_2e.delegation_start_date),
			TO_DATE(scd.delegation_start_date)) as delegation_start_date,
		scd.delegation_end_date,
		CASE 
			WHEN t2el.profile_id is not NULL and UPPER(action_type) = 'MIGRATION' THEN 'Migrated'
			WHEN t2el.profile_id is not NULL and UPPER(action_type) = 'NEW' THEN 'New T2E'
			ELSE 'Not-Migrated' END as t2e_migration_status    
    from (
		select distinct
			contract_id,
            seat_id,
            member_guid,
            delegation_start_date,
            delegation_end_date,
			product_name,
			seat_status,
			seat_delegation_status,
			geo,
			country_code,
			entitlement_type,
			market_segment,
			route_to_market,
			contract_type,
			regular_vs_promotion,
			cloud_type,
			subs_offer,
			cc_segment,
			cc_segment_offer,
			product_name_description,
			seat_fwk_begin_arr
        from (
            select distinct 
                scd_prov.contract_id,
				scd_prov.seat_id, 
				scd_prov.member_guid,
				TO_DATE(scd_prov.startdate_dttm) as delegation_start_date,
				TO_DATE(scd_prov.enddate_dttm) as delegation_end_date,
				seat.product_name,
				seat.seat_status,
				seat.seat_delegation_status,
				seat.geo,
				seat.country_code,
				seat.entitlement_type,
				seat.market_segment,
				seat.route_to_market,
				seat.contract_type,
				seat.regular_vs_promotion,
				seat.cloud_type,
				pivot.subs_offer,
				pivot.cc_segment,
				pivot.cc_segment_offer,
				pivot.product_name_description,
				pivot.seat_fwk_begin_arr,
				ROW_NUMBER() OVER(PARTITION by scd_prov.member_guid order by pivot.seat_fwk_begin_arr desc, TO_DATE(scd_prov.startdate_dttm) desc) as rownum  
            from  mdpd_stage.scd_seat_provisioning scd_prov
            left outer join ocf_analytics.dim_seat seat on scd_prov.seat_id = seat.seat_id 
            LEFT OUTER JOIN (
				select 
					subscription_account_guid,
					product_name,
					sum(fwk_end_arr_cfx)/sum(fwk_end_active) seat_fwk_begin_arr,
					max(subs_offer) subs_offer,
					max(cc_segment) cc_segment,
					max(cc_segment_offer) cc_segment_offer,
					max(cloud_type_filter) cloud_type_filter,
					max(product_name_description) product_name_description
				from csmb.vw_ccm_pivot4_all pivot 
				cross join snapshot dt
				where 1=1
				and date_key = translate(dt.last_saturday,'-','')
				and TO_DATE(date_Date) = TO_DATE(dt.last_saturday)
				and UPPER(source_type) = 'TM'
				GROUP BY 
					subscription_account_guid,
					product_name	) pivot 
			on UPPER(pivot.subscription_account_guid) = UPPER(seat.subscription_account_guid)
			and UPPER(pivot.product_name) = UPPER(seat.product_name)
			cross join snapshot dt
			where 1=1
			and UPPER(scd_prov.contract_type) in ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION')
			and (UPPER(scd_prov.seat_status) = 'ACTIVE' and UPPER(scd_prov.seat_delegation_status) = 'ASSIGNED')  
			and TO_DATE(scd_prov.startdate_dttm) <= TO_DATE(dt.last_saturday)
			and TO_DATE(scd_prov.enddate_dttm) > TO_DATE(dt.last_saturday)	)scd
        where rownum = 1	) scd
    left outer join  type_2e_adjustment_code type_2e on UPPER(type_2e.profile_id) = UPPER(scd.member_guid)
    left OUTER JOIN ocf_analytics.vw_type2e_profile_reference t2el on UPPER(t2el.profile_id) = UPPER(scd.member_guid)
	cross join snapshot dt	) scd_prov 
left outer join b2b.team_seats_by_provisioning team_seats_by_provisioning 
on scd_prov.seat_id = team_seats_by_provisioning.seat_id 
LEFT OUTER JOIN ids_coredata.dim_country countries 
ON scd_prov.country_code = countries.country_code_iso2
LEFT OUTER JOIN (
	select 
		auth_id,
		sort_array(collect_set(hau.source_name)) as products_used_180_days,
		sort_array(collect_set(if(TO_DATE(hau.event_date) between date_sub(TO_DATE(dt.last_saturday),60) and TO_DATE(dt.last_saturday), hau.source_name, NULL))) as products_used_60_days,
		sort_array(collect_set(if(TO_DATE(hau.event_date) between date_sub(TO_DATE(dt.last_saturday),28) and TO_DATE(dt.last_saturday), hau.source_name, NULL))) as products_used_28_days,
		count(distinct hau.source_name) as no_of_products_used_180_days,
		count(distinct if(TO_DATE(hau.event_date) between date_sub(TO_DATE(dt.last_saturday),60) and TO_DATE(dt.last_saturday), hau.source_name,NULL)) as no_of_products_used_60_days,
		count(distinct if(TO_DATE(hau.event_date) between date_sub(TO_DATE(dt.last_saturday),28) and TO_DATE(dt.last_saturday), hau.source_name,NULL)) as no_of_products_used_28_days,
		count(distinct hau.event_date) as no_of_active_days_180_days,
		count(distinct if(TO_DATE(hau.event_date) between date_sub(TO_DATE(dt.last_saturday),60) and TO_DATE(dt.last_saturday), hau.event_date, NULL)) as no_of_active_days_60_days,
		count(distinct if(TO_DATE(hau.event_date) between date_sub(TO_DATE(dt.last_saturday),28) and TO_DATE(dt.last_saturday), hau.event_date, NULL)) as no_of_active_days_28_days
    from (
		SELECT distinct
			member_guid,
			if(type_2e.profile_id is NULL,hau.member_guid,type_2e.auth_id) as auth_id,
			source_name,
			event_date
		from dms.user_activity hau 
		left outer join ocf_analytics.vw_type2e_profile_reference type_2e
		on upper(hau.member_guid) = upper(type_2e.profile_id)
		cross join snapshot dt
		where 1=1 
		and hau.member_guid is not NULL 
		and hau.member_guid != ''
		and TO_DATE(hau.event_date) between date_sub(TO_DATE(dt.last_saturday),180) and TO_DATE(dt.last_saturday)
		and UPPER(hau.event_category) = 'DESKTOP'	) hau 
	cross join snapshot dt
	GROUP BY    
		auth_id	) hau 
on UPPER(hau.auth_id) = UPPER(scd_prov.auth_id)
cross join snapshot dt
group by 
    datediff(TO_DATE(dt.last_saturday), TO_DATE(scd_prov.delegation_start_date)) ,
	datediff(TO_DATE(scd_prov.delegation_end_date), TO_DATE(dt.last_saturday)) ,
	datediff(TO_DATE(dt.last_saturday), TO_DATE(team_seats_by_provisioning.seat_creation_date)) ,
	datediff(TO_DATE(team_seats_by_provisioning.seat_cancelled_date), TO_DATE(dt.last_saturday)) ,
	scd_prov.product_name,
	scd_prov.seat_status,
	scd_prov.seat_delegation_status,
	scd_prov.geo,
	scd_prov.entitlement_type,
	scd_prov.market_segment,
	scd_prov.route_to_market,
	scd_prov.contract_type,
	scd_prov.regular_vs_promotion,
	scd_prov.cloud_type,
	countries.geo_code,
	countries.market_area_code,
	countries.market_area_description,
	scd_prov.subs_offer,
	scd_prov.cc_segment,
	scd_prov.cc_segment_offer,
	scd_prov.product_name_description,
	hau.no_of_active_days_28_days,
	hau.no_of_products_used_28_days,
	hau.products_used_28_days,
	hau.no_of_active_days_60_days,
	hau.no_of_products_used_60_days,
	hau.products_used_60_days,
	hau.no_of_active_days_180_days,
	t2e_migration_status,
	dt.last_saturday,
	dt.this_week """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()