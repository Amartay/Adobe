# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" Insert overwrite table b2b.ss_sustained_prod_used
Select distinct source_name 
from dms.user_activity 
where event_category = 'DESKTOP' """)
             spark.sql(""" drop table if exists b2b.ss_sustained_base_aggr """)
             spark.sql(""" create table  b2b.ss_sustained_base_aggr AS 
select 
	snapshot_date,
	snapshot_period,
	subs_offer,
	cc_segment_offer,
	cc_segment,
	product_name_description,
	market_segment,
	route_to_market,
	contract_type,
	cloud_type,
	current_seat_status,
	current_seat_delegation_status,
	geo_code,
	market_area_code,
	market_area_description,
	t2e_migration_status,
        products_used_28_days,
    products_used_60_days,
	CASE 
		WHEN seat_assigned_duration is not NULL and seat_assigned_duration > 60 THEN '60+' 
		ELSE '<=60' 
	END as seat_assigned_duration,
	CASE 
		WHEN seat_cancel_duration is NULL THEN 'Not Cancelled'
		WHEN seat_cancel_duration <= 30 THEN '30'
		WHEN seat_cancel_duration <= 60 THEN '60'
		WHEN seat_cancel_duration <= 90 THEN '90'
		WHEN seat_cancel_duration <= 397 THEN '397'
		ELSE '397+'
	END as seat_cancelled_duration,
	CASE 
		WHEN seat_delegation_end_duration > 2900000 THEN 'Assigned'
		WHEN seat_delegation_end_duration <= 30 THEN '30'
		WHEN seat_delegation_end_duration <= 60 THEN '60'
		WHEN seat_delegation_end_duration <= 90 THEN '90'
		WHEN seat_delegation_end_duration <= 397 THEN '397'
		ELSE '397+'
	END as seat_delegation_end_duration,
	CASE 
		WHEN no_of_products_used_28_days is Null or no_of_products_used_28_days = 0 THEN 'No Usage'
		WHEN no_of_products_used_28_days = 1 THEN '1'
		WHEN no_of_products_used_28_days = 2 THEN '2'
		WHEN no_of_products_used_28_days = 3 THEN '3'
		ELSe '4+'
	END  as no_of_products_used_28_days,
	CASE 
		WHEN no_of_active_days_28_days is NULL or no_of_active_days_28_days = 0 THEN '0'
		WHEN no_of_active_days_28_days = 1 THEN '1'
		WHEN no_of_active_days_28_days = 2 THEN '2'
		WHEN no_of_active_days_28_days between 3 and 5 THEN '3-5'
		WHEN no_of_active_days_28_days between 6 and 10 THEN '6-10'
		WHEN no_of_active_days_28_days between 11 and 14 THEN '11-14'
		ELSE '14+'
	END as 28_days_active_days,
	CASE 
		WHEN no_of_active_days_60_days is NULL or no_of_active_days_60_days = 0 THEN '0'
		WHEN no_of_active_days_60_days = 1 THEN '1'
		WHEN no_of_active_days_60_days = 2 THEN '2'
		ELSE '3+'
	END as 60_days_active_days,
	CASE 
		WHEN no_of_active_days_180_days is NULL or no_of_active_days_180_days = 0 THEN 'Inactive'
		ELSE 'Active'
	END as 180_days_active_status,
	sum(members) as total_members,
	sum(seat_fwk_begin_arr) as total_fwk_begin_arr
from b2b.ss_sustained_base
GROUP BY 
    snapshot_date,
	snapshot_period,
	subs_offer,
	cc_segment_offer,
	cc_segment,
	product_name_description,
	market_segment,
	route_to_market,
	contract_type,
	cloud_type,
	current_seat_status,
	current_seat_delegation_status,
	geo_code,
	market_area_code,
	market_area_description,
	t2e_migration_status,
        products_used_28_days,
    products_used_60_days,
	CASE 
		WHEN seat_assigned_duration is not NULL and seat_assigned_duration > 60 THEN '60+' 
		ELSE '<=60' 
	END,
	CASE 
		WHEN seat_cancel_duration is NULL THEN 'Not Cancelled'
		WHEN seat_cancel_duration <= 30 THEN '30'
		WHEN seat_cancel_duration <= 60 THEN '60'
		WHEN seat_cancel_duration <= 90 THEN '90'
		WHEN seat_cancel_duration <= 397 THEN '397'
		ELSE '397+'
	END,
	CASE 
		WHEN seat_delegation_end_duration > 2900000 THEN 'Assigned'
		WHEN seat_delegation_end_duration <= 30 THEN '30'
		WHEN seat_delegation_end_duration <= 60 THEN '60'
		WHEN seat_delegation_end_duration <= 90 THEN '90'
		WHEN seat_delegation_end_duration <= 397 THEN '397'
		ELSE '397+'
	END,
	CASE 
		WHEN no_of_products_used_28_days is Null or no_of_products_used_28_days = 0 THEN 'No Usage'
		WHEN no_of_products_used_28_days = 1 THEN '1'
		WHEN no_of_products_used_28_days = 2 THEN '2'
		WHEN no_of_products_used_28_days = 3 THEN '3'
		ELSE '4+'
	END,
	CASE 
		WHEN no_of_active_days_28_days is NULL or no_of_active_days_28_days = 0 THEN '0'
		WHEN no_of_active_days_28_days = 1 THEN '1'
		WHEN no_of_active_days_28_days = 2 THEN '2'
		WHEN no_of_active_days_28_days between 3 and 5 THEN '3-5'
		WHEN no_of_active_days_28_days between 6 and 10 THEN '6-10'
		WHEN no_of_active_days_28_days between 11 and 14 THEN '11-14'
		ELSE '14+'
	END,
	CASE 
		WHEN no_of_active_days_60_days is NULL or no_of_active_days_60_days = 0 THEN '0'
		WHEN no_of_active_days_60_days = 1 THEN '1'
		WHEN no_of_active_days_60_days = 2 THEN '2'
		ELSE '3+'
	END,
	CASE 
		WHEN no_of_active_days_180_days is NULL or no_of_active_days_180_days = 0 THEN 'Inactive'
		ELSE 'Active'
	END """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()