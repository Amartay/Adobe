# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" drop table if exists b2b.smb_renewals_w_deployment_firmo_aggregated """)
             spark.sql(""" create table b2b.smb_renewals_w_deployment_firmo_aggregated AS
SELECT
       renewal_qtr,
       renewal_wk,
       contract_id,
       subs_offer,  
       cc_segment,
       market_segment,
       product_category,
       product_name_description,
       usage_trend,
       max(contract_type) as contract_type,
       max(route_to_market) as route_to_market,
       max(cc_phone_vs_web) as cc_phone_vs_web,
       max(industry) as industry,
       max(derived_contract_start_date) as derived_contract_start_date,
       max(derived_contract_end_date) as derived_contract_end_date,
       max(renewal_counter) as renewal_counter,
       max(billing_payment_category) as billing_payment_category,
       max(geo) as geo,
       max(market_area_description) as market_area_description,             
       max(data_source_type) as data_source_type,
       max(billing_plan_type) as billing_plan_type,
       max(distributor) as distributor, 
       max(reseller) as reseller, 
       max(partner_level) as partner_level, 
       max(end_user) as end_user,
max(industry) as line_of_business ,
max(employee_range) as employee_range,
max(revenue_range)  as revenue_range,
max(adobe_acrobat) as adobe_acrobat,
max(photoshop) as photoshop,
max(adobe_stock) as adobe_stock,
max(adobe_creative_cloud) as adobe_creative_cloud,
max(digital_media) as digital_media,
max(seat_purchased) as seats_purchased,
max(seat_deployed) as seats_deployed,
max(churn_score) as churn_score,
max(percentile_score) as percentile_score,
max(churn_top_reason) as churn_top_reason,   
max(mdpd_phone_permission) as mdpd_phone_permission,
max(mdpd_email_permission) as mdpd_email_permission,
max(app_launches) as app_launches,
max(acrobat_launch_days) acrobat_launch_days,
max(collab_service_usage) as collab_service_usage,
max(app_launches_days) as app_launches_days,
max(collab_service_usage_days) as collab_service_usage_days,
min(first_mid_term_explicit_cancel_date) first_mid_term_explicit_cancel_date,
min(first_mid_term_cc_failure_cancel_date) first_mid_term_cc_failure_cancel_date,
min(first_pivot_cancel_date) first_pivot_cancel_date,
sum(term_begin_active_count) as term_begin_active_count,
sum(term_end_active_count) as  term_end_active_count,
sum(expansion_at_renewal_same) as  expansion_at_renewal_same,
sum(expansion_at_renewal_diff) as  expansion_at_renewal_diff,
sum(mid_term_migration_to) as  mid_term_migration_to,
sum(mid_term_reactivation) as  mid_term_reactivation,
sum(mid_term_renewal_to) as  mid_term_renewal_to,
sum(mid_term_cancel_explicit) as  mid_term_cancel_explicit,
sum(mid_term_cancel_cc_failure) as  mid_term_cancel_cc_failure,
sum(mid_term_partial_cancel_explicit) as  mid_term_partial_cancel_explicit,
sum(mid_term_partial_cancel_cc_failure) as  mid_term_partial_cancel_cc_failure,
sum(mid_term_returns) as  mid_term_returns,
sum(end_term_migration_to) as  end_term_migration_to,
sum(end_term_migration_from) as  end_term_migration_from,
sum(end_term_cancel) as  end_term_cancel,
sum(end_term_cancel_explicit) as  end_term_cancel_explicit,
sum(end_term_cancel_cc_failure) as  end_term_cancel_cc_failure,
sum(end_term_partial_cancel_explicit) as  end_term_partial_cancel_explicit,
sum(end_term_partial_cancel_cc_failure) as  end_term_partial_cancel_cc_failure,
sum(end_term_returns) as  end_term_returns,
sum(end_term_reactivation) as  end_term_reactivation,
sum(end_term_renewal_to) as  end_term_renewal_to,
sum(end_term_renewal_from) as  end_term_renewal_from,
sum(term_begin_active) as  term_begin_active,
sum(up_for_renewal) as  up_for_renewal,
sum(term_end_active) as  term_end_active,
sum(term_end_renewal) as  term_end_renewal,
sum(term_end_active_post_reactivation) as  term_end_active_post_reactivation,
sum(term_end_arr) as  term_end_arr,
sum(expansion_at_renewal_same_arr) as  expansion_at_renewal_same_arr,
sum(expansion_at_renewal_diff_arr) as  expansion_at_renewal_diff_arr,
sum(mid_term_migration_to_arr) as  mid_term_migration_to_arr,
sum(mid_term_reactivation_arr) as  mid_term_reactivation_arr,
sum(mid_term_renewal_to_arr) as  mid_term_renewal_to_arr,
sum(mid_term_cancel_explicit_arr) as  mid_term_cancel_explicit_arr,
sum(mid_term_cancel_cc_failure_arr) as  mid_term_cancel_cc_failure_arr,
sum(mid_term_partial_cancel_explicit_arr) as  mid_term_partial_cancel_explicit_arr,
sum(mid_term_partial_cancel_cc_failure_arr) as  mid_term_partial_cancel_cc_failure_arr,
sum(mid_term_migration_from_arr) as  mid_term_migration_from_arr,
sum(mid_term_renewal_from_arr) as  mid_term_renewal_from_arr,
sum(mid_term_returns_arr) as  mid_term_returns_arr,
sum(end_term_migration_from_arr) as  end_term_migration_from_arr,
sum(end_term_cancel_arr) as  end_term_cancel_arr,
sum(end_term_cancel_explicit_arr) as  end_term_cancel_explicit_arr,
sum(end_term_cancel_cc_failure_arr) as  end_term_cancel_cc_failure_arr,
sum(end_term_partial_cancel_explicit_arr) as  end_term_partial_cancel_explicit_arr,
sum(end_term_partial_cancel_cc_failure_arr) as  end_term_partial_cancel_cc_failure_arr,
sum(end_term_migration_to_arr) as  end_term_migration_to_arr,
sum(end_term_reactivation_arr) as  end_term_reactivation_arr,
sum(end_term_renewal_to_arr) as  end_term_renewal_to_arr,
sum(end_term_renewal_from_arr) as  end_term_renewal_from_arr,
sum(end_term_returns_arr) as  end_term_returns_arr,
sum(annual_inactive_arr) as  annual_inactive_arr,
sum(annual_active_arr) as  annual_active_arr,
sum(term_begin_arr) as  term_begin_arr,
sum(term_end_renewal_arr) as  term_end_renewal_arr,
sum(term_end_active_arr) as  term_end_active_arr,
sum(up_for_renewal_arr) as  up_for_renewal_arr,
sum(term_end_active_post_reactivation_arr) as  term_end_active_post_reactivation_arr,
sum(annual_active) as annual_active,
sum(annual_inactive) as annual_inactive,
sum(gross_new_arr) gross_new_arr,
sum(net_cancelled_arr) net_cancelled_arr,
sum(reactivated_arr) reactivated_arr,
sum(returns_arr) returns_arr
FROM b2b.smb_renewal_churn_deploy_firmo
where renewal_qtr >= '2018-Q1'
group by renewal_qtr,
         renewal_wk,
         contract_id,
         subs_offer,
         cc_segment,
         market_segment,
         product_category,
         product_name_description,
         usage_trend """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()