# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)

             spark.sql(""" drop table if exists contract_dsnp """)
             spark.sql(""" create table contract_dsnp as 
select * from
(select distinct  churn.contract_id,
                  round(churn.score,4) as churn_score,
                  churn.percentile_score as percentile_score,
                  churn.top_reason_code as churn_top_reason,
                  TO_DATE(churn.file_date) as file_date,
                  ROW_NUMBER() OVER(PARTITION BY churn.contract_id order BY TO_DATE(churn.file_date) desc) as rownum
        FROM b2b_stg.pp_smb_contract_renewal renewal
        INNER JOIN
                 (select 
                  subscription_id as contract_id, 
                  score,  
                  percentile_score, 
                  regexp_replace(split(reason_code,'\\|')[0], ':\\d+$', '') as top_reason_code,
        TO_DATE(score_date) as file_date
        from dsnp_scores.cccm_scores
        where model_type='CCT_CHURN_YEARLY'
                  ) churn
        on churn.contract_id=renewal.contract_id          
        where TO_DATE(churn.file_date) <= date_sub(TO_DATE(renewal.renewal_date),60)
        )x where x.rownum=1 """)

             
             spark.sql(""" drop table if exists b2b.smb_renewal_churn_deploy_firmo """)
             spark.sql(""" create table b2b.smb_renewal_churn_deploy_firmo as
        Select
        renewal.*
        , industry
        , sic_industry
        , line_of_business
        , employee_range
        , revenue_range
        , company_age
        , adobe_acrobat
        , photoshop
        , adobe_stock
        , adobe_creative_cloud
        , digital_media
        , COALESCE(seat_purchased,0) + COALESCE(ent_seat_purchased,0) as seat_purchased
        , COALESCE(seat_deployed,0) + COALESCE(ent_seat_deployed,0) as seat_deployed
        , COALESCE(current_seat_active,0) + COALESCE(current_ent_membership_count,0) as current_seat_active
        , COALESCE(current_seat_deployed,0) + COALESCE(current_ent_delegation_count,0) as current_seat_deployed
        ,churn_score
        ,percentile_score
        ,churn_top_reason
        ,optin.mdpd_phone_permission
        ,optin.mdpd_email_permission
        ,optin.mdpd_phone
        ,app_launches
        ,acrobat_launch_days
        ,collab_service_usage
        ,app_launches_days
        ,collab_service_usage_days
        ,usage_trend
        from b2b_stg.pp_smb_contract_renewal renewal
        LEFT OUTER JOIN 
        contract_dsnp churn 
        ON churn.contract_id = renewal.contract_id      
        LEFT JOIN
        (
        Select
        contract_id
        , COUNT(DISTINCT(CASE WHEN seat_status = 'ACTIVE SEAT' THEN seat_id ELSE NULL END)) current_seat_active
        , COUNT(DISTINCT(CASE WHEN seat_status = 'ACTIVE SEAT'and seat_delegation_status='ASSIGNED' THEN seat_id ELSE NULL END)) current_seat_deployed
        from ocf_analytics.dim_seat
        group by contract_id
        )seat on renewal.contract_id=seat.contract_id
        LEFT JOIN
       (select contract_id,
       sum(pro_membership_count) as current_ent_membership_count,
       sum(del_membership_count) as current_ent_delegation_count,
        TO_DATE(row_insertion_dttm) row_insertion_dttm,
        ROW_NUMBER() OVER(PARTITION BY contract_id ORDER BY row_insertion_dttm desc) rownum
        from b2b.snapshot_fact_dce_membership_count dce 
        group by contract_id,
        row_insertion_dttm
union all 
select contract_id,
       sum(pro_membership_count) as current_ent_membership_count,
       sum(del_membership_count) as current_ent_delegation_count,
       TO_DATE(row_insertion_dttm) row_insertion_dttm,
        ROW_NUMBER() OVER(PARTITION BY contract_id ORDER BY row_insertion_dttm desc) rownum
        from b2b.snapshot_fact_cce_membership_count dce 
        group by contract_id,
                 row_insertion_dttm) enterprise_current_deployment on renewal.contract_id = enterprise_current_deployment.contract_id and enterprise_current_deployment.rownum = 1
LEFT JOIN
(
    Select
        renewal.contract_id
        ,renewal_date
        ,COUNT(DISTINCT (if(UPPER(seat_status) = 'ACTIVE',seat.seat_id,NULL))) seat_purchased
        ,COUNT(DISTINCT(CASE WHEN UPPER(seat.seat_delegation_status)='ASSIGNED' and UPPER(seat_status) = 'ACTIVE' THEN seat_id ELSE NULL END)) seat_deployed
    from b2b_stg.pp_smb_contract_renewal renewal
    INNER JOIN mdpd_stage.scd_seat_provisioning seat ON renewal.contract_id=seat.contract_id
    where TO_DATE(seat.startdate_dttm) < date_sub(if(TO_DATE(renewal.renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal.renewal_date)),90)
          and TO_DATE(seat.enddate_dttm) >= date_sub(if(TO_DATE(renewal.renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal.renewal_date)),90)            
    group by renewal.contract_id, renewal_date
)seat_provisioning on renewal.contract_id=seat_provisioning.contract_id and renewal.renewal_date=seat_provisioning.renewal_date
LEFT JOIN
(
    Select
        renewal.contract_id
        ,renewal_date
        ,as_of_date
        ,sum(pro_membership_count) as ent_seat_purchased
        ,sum(del_membership_count) as ent_seat_deployed
        ,ROW_NUMBER() OVER(PARTITION BY renewal.contract_id,renewal_date ORDER BY as_of_date desc) as rownum
    from b2b_stg.pp_smb_contract_renewal renewal
    INNER JOIN (select contract_id,pro_membership_count,del_membership_count,as_of_date from b2b.snapshot_fact_cce_membership_count union all  
                select contract_id,pro_membership_count,del_membership_count,as_of_date from b2b.snapshot_fact_dce_membership_count)seat ON renewal.contract_id=seat.contract_id
    where TO_DATE(seat.as_of_date) between date_sub(if(TO_DATE(renewal.renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal.renewal_date)),120) and date_sub(if(TO_DATE(renewal.renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal.renewal_date)),90)
    group by renewal.contract_id, renewal_date, as_of_date
)ent_seat_provisioning on renewal.contract_id=ent_seat_provisioning.contract_id and renewal.renewal_date=ent_seat_provisioning.renewal_date and ent_seat_provisioning.rownum = 1
LEFT OUTER JOIN
(SELECT contract_id,
        renewal_date,
        max(acrobat_launch_days) acrobat_launch_days,
        max(app_launches) app_launches,
        max(app_launches_days) app_launches_days,
        max(collab_service_usage) collab_service_usage,
        max(collab_service_usage_days) collab_service_usage_days
FROM b2b_stg.pp_reseller_product_launches
group by contract_id,
         renewal_date) usage ON usage.contract_id = renewal.contract_id and usage.renewal_date = renewal.renewal_date
        LEFt JOIN 
            (
            Select unique_contract.* from
                (
                Select  contract_id
                        , industry
                        , sic_industry
                        , line_of_business
                        , employee_range
                        , revenue_range
                        , company_age
                        , adobe_acrobat
                        , photoshop
                        , adobe_stock
                        , adobe_creative_cloud
                        , digital_media
                        ,ROW_NUMBER() OVER(PARTITION BY contract_id ORDER BY revenue_range DESC) as rownum
                from b2b.sp_firmographics_smb_contract_details
                group by contract_id
                        , industry
                        , sic_industry
                        , line_of_business
                        , employee_range
                        , revenue_range
                        ,company_age
                        , adobe_acrobat
                        , photoshop
                        , adobe_stock
                        , adobe_creative_cloud
                        , digital_media
                )unique_contract where rownum=1
            )firmo on renewal.contract_id=firmo.contract_id
LEFT JOIN
    (SELECT DISTINCT contract_id
                    , coalesce(mdpd_segmentation.permission_phone, mdpd_enterprise.permission_phone) mdpd_phone_permission
                    , coalesce(mdpd_segmentation.permission_email, mdpd_enterprise.permission_email) mdpd_email_permission
                    , coalesce(mdpd_segmentation.phone, mdpd_enterprise.phone,mdpd_enterprise.business_trial_phone)mdpd_phone
     from ocf_analytics.dim_contract cont
     left join
    (
        Select * from
        (
            Select segment.* , row_number() over(partition by user_guid order by permission_phone_date DESC) as rownum 
             from
                (
                  Select * from mdpd_target.smb_segmentation
                )segment
        )mdpd_segment
        where rownum = 1
    )mdpd_segmentation on upper(cont.enrollee_id)=upper(mdpd_segmentation.user_guid)
    left join
    (
        Select * from
        (
            Select ent.* , row_number() over(partition by user_guid order by permission_phone_date DESC) as rownum 
             from
                (
                  Select * from mdpd_target.enterprise_contact_composite
                )ent
        )mdpd_ent
        where rownum = 1
    )mdpd_enterprise on upper(cont.enrollee_id)=upper(mdpd_enterprise.user_guid)
    where (cont.contract_id<>NULL or cont.contract_id<>'') 
        and cont.contract_type in ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION')
    )optin on  renewal.contract_id=optin.contract_id   
left outer join b2b_stg.pp_past_180_days_usage_trend usage_trend on usage_trend.contract_id = renewal.contract_id and usage_trend.renewal_date = renewal.renewal_date """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()