# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" drop table if exists b2b_stg.pp_smb_contract_renewal """)
             spark.sql(""" create table b2b_stg.pp_smb_contract_renewal AS 
SELECT 
	ufr.*, 
	dim_date.fiscal_yr_and_qtr_desc as renewal_qtr,
	dim_date.fiscal_yr_and_wk_desc as renewal_wk,
	contract.contract_id,
	contract.contract_type,
	contract.billing_payment_category,
	pivot.geo,
	pivot.market_area_description,
	pivot.market_segment,
	pivot.product_name_description,
	pivot.product_name,
	pivot.promo_type,
	pivot.subs_offer,
	pivot.cc_phone_vs_web,
	pivot.route_to_market,
	pivot.gross_new_arr,
	pivot.net_cancelled_arr,
	pivot.reactivated_arr,
	pivot.returns_arr,
	pivot.first_pivot_cancel_date,
	pivot.product_config,
	contract_partner.distributor, 
	contract_partner.reseller, 
	contract_partner.partner_level, 
	contract_partner.end_user,
	contract_partner.first_name,
	contract_partner.last_name,
	contract_partner.telephone_number,
	contract_partner.email_id
FROM (
	SELECT
		subscription_id,
		team_group_id,
		contract_start_date,
		contract_end_date,
		derived_contract_start_date,
		derived_contract_end_date,
		data_source_type,
		TO_DATE(renewal_date) as renewal_date,
		renewal_counter,
		stock_flag,
		cloud_type,
		cc_segment,
		product_category,
		billing_plan_type,
		min(if(mid_term_cancel_explicit_arr > 0 or mid_term_partial_cancel_explicit_arr > 0, TO_DATE(date_date), NULL)) as first_mid_term_explicit_cancel_date,
		min(if(mid_term_cancel_cc_failure_arr > 0 or mid_term_partial_cancel_cc_failure_arr > 0, TO_DATE(date_date), NULL)) as first_mid_term_cc_failure_cancel_date,
		sum(init_purchase) as init_purchase,
		sum(add_on_purchase) as add_on_purchase,
		sum(term_begin_active_count) as term_begin_active_count,
		sum(term_end_active_count) as  term_end_active_count,
		sum(expansion_at_renewal_same) as  expansion_at_renewal_same,
		sum(expansion_at_renewal_diff) as  expansion_at_renewal_diff,
		sum(mid_term_migration_to) as  mid_term_migration_to,
		sum(mid_term_reactivation) as  mid_term_reactivation,
		sum(mid_term_renewal_to) as  mid_term_renewal_to,
		sum(mid_term_cancel_explicit) as  mid_term_cancel_explicit,
		sum(mid_term_cancel_cc_failure) as  mid_term_cancel_cc_failure,
		sum(mid_term_partial_cancel_explicit) as  mid_term_partial_cancel_explicit,
		sum(mid_term_partial_cancel_cc_failure) as  mid_term_partial_cancel_cc_failure,
		sum(mid_term_returns) as  mid_term_returns,
		sum(end_term_migration_to) as  end_term_migration_to,
		sum(end_term_migration_from) as  end_term_migration_from,
		sum(end_term_cancel) as  end_term_cancel,
		sum(end_term_cancel_explicit) as  end_term_cancel_explicit,
		sum(end_term_cancel_cc_failure) as  end_term_cancel_cc_failure,
		sum(end_term_partial_cancel_explicit) as  end_term_partial_cancel_explicit,
		sum(end_term_partial_cancel_cc_failure) as  end_term_partial_cancel_cc_failure,
		sum(end_term_returns) as  end_term_returns,
		sum(end_term_reactivation) as  end_term_reactivation,
		sum(end_term_renewal_to) as  end_term_renewal_to,
		sum(end_term_renewal_from) as  end_term_renewal_from,
		sum(term_begin_active) as  term_begin_active,
		sum(up_for_renewal) as  up_for_renewal,
		sum(term_end_active) as  term_end_active,
		sum(term_end_renewal) as  term_end_renewal,
		sum(term_end_active_post_reactivation) as  term_end_active_post_reactivation,
		sum(term_end_arr) as  term_end_arr,
		sum(expansion_at_renewal_same_arr) as  expansion_at_renewal_same_arr,
		sum(expansion_at_renewal_diff_arr) as  expansion_at_renewal_diff_arr,
		sum(mid_term_migration_to_arr) as  mid_term_migration_to_arr,
		sum(mid_term_reactivation_arr) as  mid_term_reactivation_arr,
		sum(mid_term_renewal_to_arr) as  mid_term_renewal_to_arr,
		sum(mid_term_cancel_explicit_arr) as  mid_term_cancel_explicit_arr,
		sum(mid_term_cancel_cc_failure_arr) as  mid_term_cancel_cc_failure_arr,
		sum(mid_term_partial_cancel_explicit_arr) as  mid_term_partial_cancel_explicit_arr,
		sum(mid_term_partial_cancel_cc_failure_arr) as  mid_term_partial_cancel_cc_failure_arr,
		sum(mid_term_migration_from_arr) as  mid_term_migration_from_arr,
		sum(mid_term_renewal_from_arr) as  mid_term_renewal_from_arr,
		sum(mid_term_returns_arr) as  mid_term_returns_arr,
		sum(end_term_migration_from_arr) as  end_term_migration_from_arr,
		sum(end_term_cancel_arr) as  end_term_cancel_arr,
		sum(end_term_cancel_explicit_arr) as  end_term_cancel_explicit_arr,
		sum(end_term_cancel_cc_failure_arr) as  end_term_cancel_cc_failure_arr,
		sum(end_term_partial_cancel_explicit_arr) as  end_term_partial_cancel_explicit_arr,
		sum(end_term_partial_cancel_cc_failure_arr) as  end_term_partial_cancel_cc_failure_arr,
		sum(end_term_migration_to_arr) as  end_term_migration_to_arr,
		sum(end_term_reactivation_arr) as  end_term_reactivation_arr,
		sum(end_term_renewal_to_arr) as  end_term_renewal_to_arr,
		sum(end_term_renewal_from_arr) as  end_term_renewal_from_arr,
		sum(end_term_returns_arr) as  end_term_returns_arr,
		sum(annual_inactive_arr) as  annual_inactive_arr,
		sum(annual_active_arr) as  annual_active_arr,
		sum(term_begin_arr) as  term_begin_arr,
		sum(term_end_renewal_arr) as  term_end_renewal_arr,
		sum(term_end_active_arr) as  term_end_active_arr,
		sum(up_for_renewal_arr) as  up_for_renewal_arr,
		sum(term_end_active_post_reactivation_arr) as  term_end_active_post_reactivation_arr,
		sum(annual_active) as annual_active,
		sum(annual_inactive) as annual_inactive
	FROM csmb.vw_fact_retention
	WHERE UPPER(event_type) = 'RETENTION' and UPPER(subscription_type) = 'TM'
	group by 
		subscription_id,
		team_group_id,
		contract_start_date,
		contract_end_date,
		derived_contract_start_date,
		derived_contract_end_date,
		data_source_type,
		TO_DATE(renewal_date),
		renewal_counter,
		stock_flag,
		cloud_type,
		cc_segment,
		product_category,
		billing_plan_type) ufr 
LEFT OUTER JOIN ids_coredata.dim_date dim_date 
ON TO_DATE(ufr.renewal_date) = TO_DATE(dim_date.date_date)
LEFT OUTER JOIN (                                 
    select 
		team_group_id, 
		distributor, 
		reseller, 
		partner_level, 
		end_user, 
		first_name,
		last_name,
		telephone_number,
		upper(email_id) as email_id,
		TO_DATE(order_date) order_date,
		ROW_NUMBER() OVER(PARTITION BY team_group_id ORDER BY TO_DATE(order_date) desc) as rownum
    from csmb.vw_dim_contract_partner
    WHERE UPPER(team_type) = 'TI')contract_partner 
ON ufr.team_group_id = contract_partner.team_group_id 
and contract_partner.rownum = 1
LEFT OUTER JOIN (
	SELECT 
		concat(LPAD(sales_document,10,0), LPAD(sales_document_item,6,0)) as subscription_id,
		renewal_date,
		subscription_account_guid,
		min(if(TO_DATE(pivot.date_date) between TO_DATE(derived_contract_start_date) and TO_DATE(renewal_date) and net_cancelled_arr > 0, TO_DATE(date_date),NULL)) as first_pivot_cancel_date,
		max(market_segment) as market_segment,
		max(product_config) as product_config,
		max(subs_offer) as subs_offer,
		max(market_area_description) as market_area_description,
		max(geo) as geo,
		max(product_name_description) as product_name_description,
		max(product_name) as product_name,
		max(promo_types.promo_type) promo_type,
		max(cc_phone_vs_web) as cc_phone_vs_web,
		max(route_to_market) as route_to_market,
		sum(if(TO_DATE(pivot.date_date) between TO_DATE(derived_contract_start_date) and TO_DATE(renewal_date),net_purchases_arr,0)) as gross_new_arr,
		sum(if(TO_DATE(pivot.date_date) between TO_DATE(derived_contract_start_date) and TO_DATE(renewal_date),net_cancelled_arr,0)) as net_cancelled_arr,
		sum(if(TO_DATE(pivot.date_date) between TO_DATE(derived_contract_start_date) and TO_DATE(renewal_date),reactivated_arr,0)) as reactivated_arr,
		sum(if(TO_DATE(pivot.date_date) between TO_DATE(derived_contract_start_date) and TO_DATE(renewal_date),returns_arr,0)) as returns_arr
	from csmb.vw_ccm_pivot4_all pivot
	inner join (
		select  
			subscription_id,
			TO_DATE(renewal_date) as renewal_date,
			max(derived_contract_end_date) as derived_contract_end_date,
			max(derived_contract_start_date) as derived_contract_start_date
		FROM csmb.vw_fact_retention
		WHERE UPPER(event_type) = 'RETENTION' 
		and UPPER(subscription_type) = 'TM'
		group by 
			subscription_id,
            TO_DATE(renewal_date)) retention 
	on retention.subscription_id = concat(LPAD(pivot.sales_document,10,0), LPAD(pivot.sales_document_item,6,0))
	left outer join (
		Select 
			concat(LPAD(sales_document,10,'0'), LPAD(sales_document_item,6,'0')) subscription_id,
			upper(promo_type) promo_type,
			ROW_NUMBER() OVER(PARTITION BY concat(LPAD(sales_document,10,'0'), LPAD(sales_document_item,6,'0')) ORDER BY date_date desc) as rownum
		from csmb.vw_ccm_pivot4_all
		where upper(stype) = 'TM' ) promo_types
	on promo_types.subscription_id = concat(LPAD(pivot.sales_document,10,0), LPAD(pivot.sales_document_item,6,0))
	and promo_types.rownum = 1
	where upper(pivot.stype) = 'TM'
	group by 
		concat(LPAD(sales_document,10,0), LPAD(sales_document_item,6,0)),
		renewal_date,
		subscription_account_guid ) pivot 
on ufr.subscription_id = pivot.subscription_id and ufr.renewal_date = pivot.renewal_date
LEFT OUTER JOIN (
	SELECT 
		contract.country_code,
        contract.geo,
        contract.contract_id,
        seat.subscription_account_guid,  
        contract.contract_type,
        contract.billing_payment_category
    from ocf_analytics.dim_contract_jem contract
	LEFT OUTER JOIN (
		select distinct 
			subscription_account_guid,
			contract_id
		from ocf_analytics.dim_seat seat )seat 
	ON seat.contract_id = contract.contract_id
	where contract.contract_type in ('INDIRECT_ORGANIZATION', 'DIRECT_ORGANIZATION')) contract 
ON contract.subscription_account_guid = pivot.subscription_account_guid """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()