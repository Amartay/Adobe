# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.execution.engine=mr """)
             spark.sql(""" SET hive.support.concurrency=false """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" drop table if exists b2b_stg.pp_reseller_product_launches """)
             spark.sql(""" create table b2b_stg.pp_reseller_product_launches AS
 SELECT contract_id,
         TO_DATE(renewal_date) renewal_date,
        count(distinct product) as products_launched,
         count(distinct if(UPPER(category) in ('ACROBAT_SESSION'),partition_date,NULL)) as acrobat_launch_days,
         count(distinct if(UPPER(category) in ('ACROBAT_SESSION','HIGHBEAM_SESSION','THOR_APP_LAUNCH','NGL_APP_LAUNCH','INGEST_APP_LAUNCH'),partition_date,NULL)) as app_launches_days,
         sum(if(UPPER(category) in ('ACROBAT_SESSION','HIGHBEAM_SESSION','THOR_APP_LAUNCH','NGL_APP_LAUNCH','INGEST_APP_LAUNCH'),activity_count,0)) as app_launches,
         count(distinct if(UPPER(CATEGORY) in ('CC_GET_ASSETS','CC_ADD_ASSETS','CC_COLLAB_SERVICE_FOLDER','CC_COLLAB_SERVICE_LIBRARY','CC_COLLAB_SERVICE_SENDLINK_ACTIVITY') ,partition_date,NULL)) as collab_service_usage_days,
         sum(if(UPPER(CATEGORY) in ('CC_GET_ASSETS','CC_ADD_ASSETS','CC_COLLAB_SERVICE_FOLDER','CC_COLLAB_SERVICE_LIBRARY','CC_COLLAB_SERVICE_SENDLINK_ACTIVITY') ,activity_count,0)) as collab_service_usage
  FROM 
  (SELECT distinct renewals.contract_id,
        CASE
                    WHEN t2el.profile_id IS NULL THEN scd.member_guid
                    ELSE t2el.auth_id
          END as member_guid,
        renewal_date,
        first_mid_term_explicit_cancel_date,
        first_pivot_cancel_date,
        route_to_market
  from (SELECT   contract_id,
                         renewal_date,
                         min(route_to_market) as route_to_market,
                         min(first_mid_term_explicit_cancel_date) as first_mid_term_explicit_cancel_date,
                         min(first_pivot_cancel_date) first_pivot_cancel_date
              FROM b2b_stg.pp_smb_contract_renewal
              group by contract_id, 
                       renewal_date) renewals
        inner join  mdpd_stage.scd_seat_provisioning  scd ON scd.contract_id = renewals.contract_id
         LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el
          ON (scd.member_guid = t2el.profile_id)
        where (UPPER(scd.seat_delegation_Status) = 'ASSIGNED' and UPPER(scd.seat_status) = 'ACTIVE')
               and if(UPPER(route_to_market) = 'RESELLER',TO_DATE(scd.startdate_dttm) < if(TO_DATE(renewals.renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewals.renewal_date))
                   and TO_DATE(scd.enddate_dttm) > date_sub(if(TO_DATE(renewals.renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewals.renewal_date)),90),
                   TO_DATE(scd.startdate_dttm) < if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date)))
                   and TO_DATE(scd.enddate_dttm) > date_sub(if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date))),90))
        UNION ALL
        SELECT distinct renewals.contract_id,
        CASE
                    WHEN t2el.profile_id IS NULL THEN scd.member_guid
                    ELSE t2el.auth_id
          END as member_guid,
        renewal_date,
        first_mid_term_explicit_cancel_date,
        first_pivot_cancel_date,
        route_to_market
        from (
        SELECT   contract_id,
                         renewal_date,
                         min(route_to_market) as route_to_market,
                         min(first_mid_term_explicit_cancel_date) as first_mid_term_explicit_cancel_date,
                         min(first_pivot_cancel_date) first_pivot_cancel_date
              FROM b2b_stg.pp_smb_contract_renewal
              group by contract_id, 
                       renewal_date) renewals
        inner join  b2b.ent_vip_scd_member_delegation  scd ON scd.contract_id = renewals.contract_id
         LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el
          ON (scd.member_guid = t2el.profile_id)
        where if(UPPER(route_to_market) = 'RESELLER',TO_DATE(scd.start_dttm) < if(TO_DATE(renewals.renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewals.renewal_date))
                   and TO_DATE(scd.end_dttm) > date_sub(if(TO_DATE(renewals.renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewals.renewal_date)),90),
                   TO_DATE(scd.start_dttm) < if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date)))
                   and TO_DATE(scd.end_dttm) > date_sub(if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date))),90))
        ) seat
  INNER JOIN (SELECT CASE
                    WHEN t2el.profile_id IS NULL THEN fua.member_guid
                    ELSE t2el.auth_id
          END as member_guid,
                     category,
                     product,
                     TO_DATE(partition_date) as partition_date,
                     activity_count
            FROM ocf_analytics.fact_user_activity fua
            LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el
          ON (fua.member_guid = t2el.profile_id)
            WHERE upper(category) in ('ACROBAT_SESSION','HIGHBEAM_SESSION','THOR_APP_LAUNCH','NGL_APP_LAUNCH','INGEST_APP_LAUNCH','CC_GET_ASSETS','CC_ADD_ASSETS','CC_COLLAB_SERVICE_FOLDER','CC_COLLAB_SERVICE_LIBRARY','CC_COLLAB_SERVICE_SENDLINK_ACTIVITY')
            and TO_DATE(partition_date) >= TO_DATE('2017-11-30')
            ) hb_launch ON hb_launch.member_guid = seat.member_guid
  WHERE  if(UPPER(route_to_market) = 'RESELLER',TO_DATE(partition_date) between date_sub(if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date)),90) and if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date)),
            TO_DATE(partition_date) between date_sub(if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date))), 90) 
                                   and if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date))))
  group by contract_id,
           TO_DATE(renewal_date) """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()