# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET mapred.output.compression.type=BLOCK """)
             spark.sql(""" SET hive.exec.reducers.bytes.per.reducer=268435456 """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" set hive.support.concurrency=false """)
             spark.sql(""" drop table  if exists b2b.gl_in_cltv_dash_end_tbl """)
             spark.sql(""" create table  b2b.gl_in_cltv_dash_end_tbl as
select 
    pvt1.crm_customer_guid,
    case when pvt1.subs_offer = ('DCI Single App') then 'DC_products'
        else 'CC_products' end as product_category,
    pvt1.fiscal_yr_and_per_desc as fiscal_yr_and_per_desc,
    max(pvt1.geo) as geo,
    max(pvt1.market_area) as market_area,
    max(pvt1.market_segment) as market_segment,
    sum(pvt1.fmnth_end_active) as fmnth_end_active,
    sum(pvt1.fmnth_end_arr_cfx) as fmnth_end_arr_cfx
from
(SELECT  pvt.crm_customer_guid,
                fiscal_yr_and_per_desc,
                pvt.geo,
                pvt.market_area,
                pvt.market_segment,
                pvt.subs_offer,
                sum(fmnth_end_active) as fmnth_end_active,
                sum(fmnth_end_arr_cfx) as fmnth_end_arr_cfx
        FROM csmb.vw_ccm_pivot4_all as pvt
        WHERE 1=1
            and pvt.fiscal_yr_desc >= '2021'
            and pvt.event_source = 'SNAPSHOT'
            and stype = 'IN'
            and UPPER(pvt.market_segment) in ('COMMERCIAL')    
        GROUP BY 1,2,3,4,5,6
        ) pvt1
group by   pvt1.crm_customer_guid,
    case when pvt1.subs_offer = ('DCI Single App') then 'DC_products'
        else 'CC_products' end,
    pvt1.fiscal_yr_and_per_desc """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

