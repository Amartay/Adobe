# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET mapred.output.compression.type=BLOCK """)
             spark.sql(""" SET hive.exec.reducers.bytes.per.reducer=268435456 """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" set hive.support.concurrency=false """)
             spark.sql(""" drop table  if exists b2b.gl_in_cltv_final """)
             spark.sql(""" create table b2b.gl_in_cltv_final as
select
end_pvt.fiscal_yr_and_per_desc,
end_pvt.product_category,
end_pvt.geo,
end_pvt.market_area,
end_pvt.market_segment,
count(distinct end_pvt.crm_customer_guid) as customers,
sum(fmnth_end_active) as fmnth_end_active,
sum(fmnth_end_arr_cfx) as fmnth_end_arr_cfx,
sum(net_purchases) as init_purchase_unit,
sum(net_purchases_arr_cfx) as init_purchase_arr,
sum(life_time_value) as life_time_value
from b2b.gl_in_cltv_dash_end_tbl end_pvt
left outer join b2b.gl_in_cltv_dash_init_tbl init_pvt on end_pvt.crm_customer_guid = init_pvt.crm_customer_guid and end_pvt.product_category = init_pvt.product_category
LEFT OUTER JOIN (
    SELECT              member_guid,
                       dim_date.fiscal_yr_and_per_desc, 
                       case when model_type = 'DCI_CLTV' then 'DC_products'
                            else 'CC_products' end as product_category,
                       max(life_time_value) as life_time_value
                       from dsnp_scores.cccm_cltv_scores cltv
                       inner join (
                           select date(date_date) as date_date,
                                  fiscal_yr_and_per_desc
                                  from ids_coredata.dim_date
                            where fiscal_yr_desc >= '2021' 
                            and  fiscal_wk_in_per = fiscal_weeks_in_per
                       )dim_date on date(cltv.score_date) = date(dim_date.date_date)
                       group by 1,2,3
)cltv_table on end_pvt.crm_customer_guid = cltv_table.member_guid 
           and end_pvt.fiscal_yr_and_per_desc = cltv_table.fiscal_yr_and_per_desc 
           and end_pvt.product_category = cltv_table.product_category
group by 1,2,3,4,5 """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()
