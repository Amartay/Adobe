# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)

             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')             
            #  spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            #  spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            #  spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.smb_all_contracts_details """)
             spark.sql(""" create table b2b.smb_all_contracts_details AS 
select b2b.*,
       org.ech_parent_id,
       org.ech_parent_name,
       org.ech_parent_country_code,
       org.ech_parent_market_area_code,
       org.ech_parent_market_area_description,
       org.ech_parent_geo_code,
       org.ech_parent_industry,
       org.ech_parent_tot_emp_cont,
       org.ech_parent_annual_sales_usd,
       org.end_user_id,
       org.end_user_name,
       org.org_id,
       org.ech_sub_id,
       org.ech_sub_name,
       org.ech_sub_industry,
       org.ech_sub_tot_emp_cont,
       org.ech_sub_annual_sales_usd,
       org.mm_flag,
       org.dme_acct_segment,
       contracts_dim_date.fiscal_currnt_yr_to_dt_flg,
       contracts_dim_date.fiscal_currnt_qtd,
       contracts_dim_date.fiscal_wk_in_qtr,
       contracts_dim_date.fiscal_wk_in_yr,
       contracts_dim_date.fiscal_per_name,
       contracts_dim_date.fiscal_yr_and_per_long_desc as fiscal_yr_month_desc,
       contracts_dim_date.fiscal_qtr_qtd_flag,
       contracts_dim_date.fiscal_yr_ytd_flag,
       contracts_dim_date.fiscal_prv_yr_flag,
       contracts_dim_date.prv_qtr_flag,
       contracts_dim_date.prv_yr_currnt_qtd_flag,
       contracts_dim_date.fiscal_qtr_name,
       contracts_dim_date.day_name,
       contracts_dim_date.fiscal_yr_desc,
       seats_dim_date.fiscal_currnt_yr_to_dt_flg as seat_creation_currnt_yr_to_dt_flag,
       seats_dim_date.fiscal_currnt_qtd as seat_creation_currnt_qtd,
       seats_dim_date.fiscal_wk_in_qtr as seat_creation_wk_in_qtr,
       seats_dim_date.fiscal_wk_in_yr as seat_creation_wk_in_yr,
       seats_dim_date.fiscal_per_name as seat_creation_month_name,
       seats_dim_date.fiscal_yr_and_per_long_desc as seat_creation_yr_month_desc,
       seats_dim_date.fiscal_qtr_qtd_flag as seat_creation_qtr_qtd_flag,
       seats_dim_date.fiscal_yr_ytd_flag as seat_creation_yr_ytd_flag,
       seats_dim_date.fiscal_prv_yr_flag as seat_creation_prv_yr_flag,
       seats_dim_date.prv_qtr_flag as seat_creation_prv_qtr_flag,
       seats_dim_date.prv_yr_currnt_qtd_flag as seat_creation_prv_yr_currnt_qtd_flag,
       seats_dim_date.fiscal_qtr_name as seat_creation_fiscal_qtr_name,
       seats_dim_date.day_name as seat_creation_day_name,
       seats_dim_date.fiscal_yr_desc as seat_creation_yr
from 
(select contract_start_fiscal_week          ,
  contract_start_fiscal_quarter       ,
  seat_start_fiscal_week              ,
  seat_start_fiscal_qtr               ,
  contract_week_ending_date           ,
  contract_current_quarter_flag       ,
  contract_type                       ,
  cohort_data.contract_id                         ,
  enrollee_id                         ,
  migrated_contract_yn                ,
  contract_created_date               ,
  anniversary_date                    ,
  previous_anniversary_date           ,
  next_anniversary_date               ,
  billing_frequency                   ,
  billing_status                      ,
  billing_payment_category            ,
  first_contract_termstartdate        ,
  is_inactive_contract                ,
  geo_code                            ,
  market_area_code                    ,
  market_area_description             ,
  purchasedentitlement_id             ,
  market_segment                      ,
  entitlement_period                  ,
  entitlement_type                    ,
  route_to_market                     ,
  product_name                        ,
  regular_vs_promotion                ,
  current_seat_status                 ,
  current_seat_delegation_status      ,
  seat_assigned_date                  ,
  seat_creation_date                  ,
  seat_cancel_date                    ,
  total_seats_per_contract            ,
  cancelled_seats_per_contract        ,
  job                                 ,
  skill                               ,
  first_launch_date                   ,
  last_launch_date                    ,
  total_launch_days                   ,
  total_launches                      ,
  first_7_day_launch_days             ,
  first_7_day_launches                ,
  first_28_day_launch_days            ,
  first_28_day_launches               ,
  first_60_day_launch_days            ,
  first_60_day_launches               ,
  first_7_day_launched_products_count ,
  first_28_day_launched_products_count ,
  first_60_day_launched_products_count ,
  28d_highest_single_product_active_days  ,
  most_launched_product_next_28days    ,
  first_service_usage_date             ,
  first_90_cclibrary_usage_days        ,
  first_90_cloud_docs_usage_days       ,
  first_90_fonts_usage_days            ,
  first_90_behance_usage_days          ,
  first_90_portfolio_usage_days        ,
  first_90_learn_usage_days            ,
  first_90_neural_filters_usage_days   ,
  first_7_days_active_service_days     ,
  first_28_days_active_service_days    ,
  first_60_day_active_service_days     ,
  first_90_day_active_service_days     ,
  product_name_description            ,
  subs_offer                          ,
  cc_segment                          ,
  cc_segment_offer                    ,
  cloud_type_filter                   ,
  org_name as non_firmo_org_name,
  industry as firmo_industry,
  employee_range as firmo_employee_range,
  revenue_range as firmo_revenue_range,
  phones_vs_web,
  switchers_enrollee.switcher_contract_by_enrollee,
  switchers_domain.switcher_contract_by_domain,
  count(distinct seat_id) as seats,
  sum(seat_level_pivot_arr) as seat_level_pivot_arr ,
  sum(seat_level_fwk_begin_arr)  as seat_level_fwk_begin_arr,
  sum(if(current_seat_delegation_status = 'ASSIGNED' and UPPER(current_seat_status) = 'ACTIVE SEAT', 
                                                        CASE WHEN UPPER(skill) = 'BEGINNER'
                                                           THEN 1
                                                           WHEN UPPER(skill) = 'INTERMEDIATE' or UPPER(skill) = 'MIXED'
                                                           THEN 2
                                                           WHEN UPPER(skill) = 'EXPERIENCED'
                                                           THEN 3
                                                           ELSE 0
                                                        END,0)) as seat_level_skill_set,
  count(distinct if(UPPER(current_seat_delegation_status) = 'ASSIGNED' and UPPER(current_seat_status) = 'ACTIVE SEAT', seat_id,NULL)) as current_assiged_seat_count        
from b2b.b2b_cohort_data cohort_data
left outer join (select distinct contract_id, 
                       switcher_contract_by_enrollee_id as switcher_contract_by_enrollee
                from b2b.tm_new_contracts_switchers_by_enrollee
                ) as switchers_enrollee ON switchers_enrollee.contract_id = cohort_data.contract_id
left outer join (select distinct contract_id, 
                       switcher_contract_by_domain
                from b2b.tm_new_contracts_switchers_by_domain
                ) as switchers_domain ON switchers_domain.contract_id = cohort_data.contract_id
group by contract_start_fiscal_week          ,
  contract_start_fiscal_quarter       ,
  seat_start_fiscal_week              ,
  seat_start_fiscal_qtr               ,
  contract_week_ending_date           ,
  contract_current_quarter_flag       ,
  contract_type                       ,
  cohort_data.contract_id                         ,
  enrollee_id                         ,
  migrated_contract_yn                   ,
  contract_created_date               ,
  anniversary_date                    ,
  previous_anniversary_date           ,
  next_anniversary_date               ,
  billing_frequency                   ,
  billing_status                      ,
  billing_payment_category            ,
  first_contract_termstartdate        ,
  is_inactive_contract                ,
  geo_code                            ,
  market_area_code                    ,
  market_area_description             ,
  purchasedentitlement_id             ,
  market_segment                      ,
  entitlement_period                  ,
  entitlement_type                    ,
  route_to_market                     ,
  product_name                        ,
  regular_vs_promotion                ,
  current_seat_status                 ,
  current_seat_delegation_status      ,
  seat_assigned_date                  ,
  seat_creation_date                  ,
  seat_cancel_date                    ,
  total_seats_per_contract            ,
  cancelled_seats_per_contract        ,
  job                                 ,
  skill                               ,
  first_launch_date                   ,
  last_launch_date                    ,
  total_launch_days                   ,
  total_launches                      ,
  first_7_day_launch_days             ,
  first_7_day_launches                ,
  first_28_day_launch_days            ,
  first_28_day_launches               ,
  first_60_day_launch_days            ,
  first_60_day_launches               ,
  first_7_day_launched_products_count ,
  first_28_day_launched_products_count ,
  first_60_day_launched_products_count ,
  28d_highest_single_product_active_days  ,
  most_launched_product_next_28days    ,
  first_service_usage_date             ,
  first_90_cclibrary_usage_days        ,
  first_90_cloud_docs_usage_days       ,
  first_90_fonts_usage_days            ,
  first_90_behance_usage_days          ,
  first_90_portfolio_usage_days        ,
  first_90_learn_usage_days            ,
  first_90_neural_filters_usage_days   ,
  first_7_days_active_service_days     ,
  first_28_days_active_service_days    ,
  first_60_day_active_service_days     ,
  first_90_day_active_service_days     ,
  product_name_description            ,
  subs_offer                          ,
  cc_segment                          ,
  cc_segment_offer                    ,
  cloud_type_filter,
  org_name,
  industry,
  employee_range,
  revenue_range,
  phones_vs_web,
  switchers_enrollee.switcher_contract_by_enrollee,
  switchers_domain.switcher_contract_by_domain
  ) b2b 
left outer join 
(select contract_key,
       as_of_date,
       org.ech_parent_id,
       org.ech_parent_name,
       org.ech_parent_country_code,
       org.ech_parent_market_area_code,
       org.ech_parent_market_area_description,
       org.ech_parent_geo_code,
       org.ech_parent_industry,
       org.ech_parent_tot_emp_cont,
       org.ech_parent_annual_sales_usd,
       org.end_user_id,
       org.end_user_name,
       org.org_id,
       org.org_name,
       org.ech_sub_id,
       org.ech_sub_name,
       org.ech_sub_industry,
       org.ech_sub_tot_emp_cont,
       org.ech_sub_annual_sales_usd,
       org.mm_flag,
       org.dme_acct_segment,
       ROW_NUMBER() OVER(PARTITION BY contract_key ORDER BY TO_DATE(as_of_date) desc) as rownum 
from b2b.ecp_ecc_org_map org) org on b2b.contract_id = org.contract_key and org.rownum = 1
left outer join ids_coredata.dim_date contracts_dim_date on TO_DATE(b2b.contract_created_date) = TO_DATE(contracts_dim_date.date_date) 
left outer join ids_coredata.dim_date seats_dim_date on TO_DATE(b2b.seat_creation_date) = TO_DATE(seats_dim_date.date_date) """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()