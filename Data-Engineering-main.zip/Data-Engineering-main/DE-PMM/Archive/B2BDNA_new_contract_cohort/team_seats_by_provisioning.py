# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join= true """)
             spark.sql(""" SET hive.vectorized.execution.enabled= true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.team_seats_by_provisioning
  SELECT
    contract_id,
    contract_type,
    seat_id,
    MIN(CASE WHEN seat_delegation_status ='ASSIGNED' and seat_status = 'ACTIVE'  THEN member_guid END)  AS member_guid,
    MAX(sellable_sku) AS sellable_sku,
    MIN(CASE WHEN seat_status = 'ACTIVE' THEN startdate_dttm END)   AS seat_creation_date,
    MIN(CASE WHEN active_invite_id is not NULL    THEN startdate_dttm END)   AS seat_invited_date,       
    MIN(CASE WHEN  member_guid is not NULL  THEN startdate_dttm END)   AS seat_assigned_date ,
    MAX(CASE WHEN seat_status <> 'ACTIVE'  THEN startdate_dttm else NULL END)     AS seat_cancelled_date
  FROM (
    SELECT
      prov.contract_id,
      prov.contract_type,
      prov.seat_id,
      prov.member_guid,
      prov.active_invite_id,
      prov.seat_delegation_status,
      prov.Seat_Status,
      TO_DATE(prov.startdate_dttm) AS startdate_dttm,
         TO_DATE(prov.ENDDate_dttm) as EndDate_dttm,
       dim_seat.material_number sellable_sku,
      ROW_NUMBER() OVER(PARTITION BY prov.seat_id, prov.Seat_status,prov.seat_delegation_status ORDER BY prov.startdate_dttm) AS rownum
    FROM
     mdpd_stage.scd_seat_provisioning   prov 
    inner join ocf_analytics.dim_seat dim_seat on prov.seat_id = dim_seat.seat_id
  where dim_seat.contract_type <> 'DIRECT_INDIVIDUAL'
  ) seat_status_dates
  WHERE
    rownum =1
  GROUP BY contract_id, contract_type, seat_id """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

