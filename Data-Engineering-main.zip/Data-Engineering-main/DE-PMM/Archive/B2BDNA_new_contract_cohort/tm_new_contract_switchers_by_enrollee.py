# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)

             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')             
            #  spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            #  spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            #  spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.tm_new_contracts_switchers_by_enrollee """)
             spark.sql(""" create table b2b.tm_new_contracts_switchers_by_enrollee AS 
with cohort_data AS 
(select * from b2b.b2b_cohort_data where contract_start_fiscal_quarter  >= '2021-Q1'), 
cancelled_enrollee_tbl AS 
(select distinct contract_id, 
               full_contract_cancel_dt, 
               enrollee_id
 from b2b.tm_fully_cancelled_contracts
)
select cohort_data.contract_id,
       max(if(cancelled_enrollee_tbl.contract_id is NOT NULL,1,0)) as switcher_contract_by_enrollee_id
from cohort_data
inner join cancelled_enrollee_tbl on UPPER(cohort_data.enrollee_id) = UPPER(cancelled_enrollee_tbl.enrollee_id) 
 WHERE (cancelled_enrollee_tbl.contract_id != cohort_data.contract_id and ABS(datediff(TO_DATE(cohort_data.contract_created_date),TO_DATE(cancelled_enrollee_tbl.full_contract_cancel_dt))) <= 28) 
GROUP BY cohort_data.contract_id """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()