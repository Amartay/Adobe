# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)

             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')

            #  spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            #  spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            #  spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)

             df_pivot=spark.sql(""" select subscription_account_guid,
                 upper(product_name) as product_name,
                 LPAD(material_number,18,0) as material_number,
                 COALESCE(net_purchases_arr_cfx,fwk_begin_arr_cfx,migrated_to_arr_cfx,renewal_to_arr_cfx) as net_purchases_arr,
                 if(migrated_to_arr_cfx > 0 and migrated_to_arr_cfx is not NULL,'Y','N') as migrated_contract_yn,
                 COALESCE(gross_new_subs,fwk_begin_active,migrated_to,renewal_to) as gross_new_subs,
                 date_date,
                 subs_offer,
                 cc_segment,
                 cc_segment_offer,
                 cloud_type_filter,
                 product_category,
                 product_name_description,
                 cc_phone_vs_web,
                 gtm_acct_segment,
                 offer_type_desc,
                 ROW_NUMBER() OVER(PARTITION BY subscription_account_guid,product_name ORDER BY TO_DATE(date_date) asc) as rownum
        
from csmb.vw_ccm_pivot4_all pivot 
where source_type is not null and event_source is not null and date_key is not null and (net_purchases_arr_cfx > 0 or migrated_to_arr_cfx > 0 or fwk_begin_arr_cfx > 0 or renewal_to_arr_cfx > 0) """)
             
             df_pivot.createOrReplaceTempView("df_pivot")

             spark.sql(""" Insert overwrite table b2b.jem_seat_arr_pivot_mapping_tbl
SELECT provisioning.seat_id,
       (pivot.net_purchases_arr/pivot.gross_new_subs) as seat_level_pivot_arr,
       pivot.migrated_contract_yn,
       pivot.subs_offer,
       pivot.cc_segment,
       pivot.cc_segment_offer,
       pivot.product_category,
       pivot.product_name_description,
       pivot.cloud_type_filter,
       pivot.cc_phone_vs_web as phones_vs_web,
       pivot.gtm_acct_segment,
       pivot.offer_type_desc,
       provisioning.seat_creation_date,
       provisioning.seat_cancelled_date,
       pivot.date_date as pivot_first_license_purchase_date,
       ROW_NUMBER() OVER(PARTITION BY provisioning.seat_id ORDER BY TO_DATE(pivot.date_date) asc) as rownum
FROM
(select seat.seat_id,
        seat.subscription_account_guid,
        LPAD(seat.material_number,18,0) as material_number,
        UPPER(seat.product_name) product_name,
        provisioning.seat_cancelled_date,
        provisioning.seat_creation_date 
from b2b.team_seats_by_provisioning provisioning 
inner join ocf_analytics.dim_seat seat on provisioning.seat_id = seat.seat_id
) provisioning
INNER JOIN df_pivot pivot on pivot.subscription_account_guid = provisioning.subscription_account_guid and
                                          pivot.product_name = provisioning.product_name AND
                                          pivot.rownum = 1 """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()