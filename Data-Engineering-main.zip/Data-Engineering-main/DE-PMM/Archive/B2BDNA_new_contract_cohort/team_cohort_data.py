# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)

             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')             
            #  spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            #  spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            #  spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
           
             spark.sql(""" with dowload_temp as (select download.*, 
                      if(t2el.profile_id is NULL, download.member_guid, t2el.auth_id) as auth_id
                      from ocf_analytics.ccmusg_fact_download_info download
                      left outer join  ocf_analytics.vw_type2e_profile_reference t2el ON UPPER(download.member_guid) = UPPER(t2el.profile_id)
                      where download.member_guid is not NULL and download.member_guid != ''
                      ),
      launch_temp as (select launch.*, 
                      if(t2el.profile_id is NULL, launch.member_guid, t2el.auth_id) as auth_id
                      from dms.user_activity launch
                      left outer join  ocf_analytics.vw_type2e_profile_reference t2el ON UPPER(launch.member_guid) = UPPER(t2el.profile_id)
                      where 1=1
            and (launch.member_guid is not NULL and launch.member_guid != '')
                      and UPPER(launch.event_category) = 'DESKTOP'
            AND event_date >= '2018-01-01'
                    ),                 
     team_seat_provisioning_temp as (select prov.*,
                                    if(t2el.profile_id is NULL,prov.member_guid,t2el.auth_id) as auth_id 
                                    from b2b.team_seats_by_provisioning prov
                                    LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el ON (prov.member_guid = t2el.profile_id)
                                    ),
      dim_member_temp as (select member.*,
                        if(t2el.profile_id is NULL,member.member_guid,t2el.auth_id) as auth_id,
                        row_number() over(partition by if(t2el.profile_id is NULL,member.member_guid,t2el.auth_id) order by if(t2el.profile_id is NULL,member.member_guid,t2el.auth_id)) as row_num_member from ocf_analytics.dim_member_cc member
                        left outer join ocf_analytics.vw_type2e_profile_reference t2el ON UPPER(member.member_guid) = UPPER(t2el.profile_id)
                        where member.member_guid is not NULL and member.member_guid != ''
                         ),
      scd_seat_provisioning_temp as (select prov.*,
                                    if(t2el.profile_id is NULL,prov.member_guid,t2el.auth_id) as auth_id 
                                    from mdpd_stage.scd_seat_provisioning prov
                                    LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el ON (prov.member_guid = t2el.profile_id)
                                    ),
       dme_hybrid_active_use_temp as (select hau.*,
                                            if(t2el.profile_id is NULL,hau.member_guid,t2el.auth_id) as auth_id 
                                    from dms.user_activity hau 
                                    LEFT JOIN ocf_analytics.vw_type2e_profile_reference t2el ON (hau.member_guid = t2el.profile_id)
                                    WHERE 1=1
                                    ANd  (hau.member_guid is not NULL and hau.member_guid != '')
                                    AND UPPER(event_category) = 'SERVICE' 
                                    AND UPPER(source_name) in ('CCLIBRARY','CLOUD-DOCS','BEHANCE','PORTFOLIO','FONTS','LEARN','NEURAL-FILTERS')
                  AND event_date >= '2018-01-01'
                                     )                             
                

INSERT OVERWRITE TABLE b2b.b2b_cohort_data
 SELECT period.fiscal_yr_and_wk_desc as contract_start_fiscal_week,
      period.fiscal_yr_and_qtr_desc as contract_start_fiscal_quarter,
       seat_period.fiscal_yr_and_wk_desc as seat_fiscal_wk,
       seat_period.fiscal_yr_and_qtr_desc as seat_fiscal_qtr,
       seat_deploy_period.fiscal_yr_and_wk_desc as seat_deployment_fiscal_wk,
       seat_deploy_period.fiscal_yr_and_qtr_desc as seat_deployment_fiscal_qtr,
       TO_DATE(period.fiscal_wk_ending_date) AS contract_week_ending_date,
       period.fiscal_currnt_qtd AS contract_current_quarter_flag,
       contracts.contract_type,
       contracts.contract_id,
       contracts.enrollee_id,
       TO_DATE(contracts.contract_modified_date) AS contract_modified_date, 
       pivot_mapping.migrated_contract_yn,
       TO_DATE(contracts.contract_created_date) AS contract_created_date,
       TO_DATE(contracts.anniversary_date) AS anniversary_date,
       TO_DATE(contracts.previous_anniversary_date) AS previous_anniversary_date,
       TO_DATE(contracts.next_anniversary_date) AS next_anniversary_date,
       contracts.external_contract_id,
       contracts.owner_id,
       contracts.owner_identity_id,
       contracts.reseller_owner_id,
       contracts.billing_frequency,
       contracts.billing_status,
       contracts.billing_payment_category,
       TO_DATE(seat_payment.first_contract_startdate) AS first_contract_startdate,
       IF(all_contract.seat_count-all_contract.seat_cancelled <= 0, 'Y', 'N') AS is_inactive_contract,
       countries.geo_code,
       countries.market_area_code,
       countries.market_area_description AS market_area_description,
       seat.purchasedentitlement_id,
       seat.market_segment,
       seat.entitlement_period,
       seat.entitlement_type,
       seat.route_to_market,
       seat.product_name,
       seat.regular_vs_promotion,
       seat.seat_id,
       seat.seat_status,
       seat.seat_delegation_status,
       TO_DATE(seat.seat_last_modifieddate) AS seat_last_modifieddate,
       seat.member_guid as current_assigned_member_guid,
       seat_provisioning.member_guid as first_assigned_member_guid ,
       seat_provisioning.seat_assigned_date as seat_assigned_date,
       seat_provisioning.seat_creation_date as seat_creation_date,
       TO_DATE(seat_provisioning.seat_cancelled_date) AS seat_cancel_date,
       all_contract.seat_count,
       all_contract.seat_cancelled,
       dm.job,
       dm.skill,
       TO_DATE(dl.first_download_date),
       TO_DATE(dl.last_download_date),
       TO_DATE(dl.first_download_date_after_assignment),
       TO_DATE(hb_launch.first_launch_date),
       TO_DATE(hb_launch.last_launch_date),
        hb_launch.total_launch_days,
        hb_launch.total_launches,
        hb_launch.first_7_day_launch_days,
        hb_launch.first_7_day_launches,
        hb_launch.first_28_day_launch_days,
        hb_launch.first_28_day_launches,
        hb_launch.first_60_day_launch_days,
        hb_launch.first_60_day_launches,
        hb_launch.first_7_day_launched_products_count,
        hb_launch.first_28_day_launched_products_count,
        hb_launch.first_60_day_launched_products_count,
        repeat_launch_28days.28d_highest_single_product_active_days,
        repeat_launch_28days.most_launched_product_next_28days,
        TO_DATE(hau.first_service_usage_date),
        hau.first_90_cclibrary_usage_days,
        hau.first_90_cloud_docs_usage_days,
        hau.first_90_fonts_usage_days,
        hau.first_90_behance_usage_days,
        hau.first_90_portfolio_usage_days,
        hau.first_90_learn_usage_days,
        hau.first_90_neural_filters_usage_days,
        hau.first_7_days_active_service_days,
        hau.first_28_days_active_service_days,
        hau.first_60_day_active_service_days,
        hau.first_90_day_active_service_days,
        pivot_mapping.seat_level_pivot_arr,
        pivot_mapping.product_name_description,
        pivot_mapping.subs_offer,
        pivot_mapping.cc_segment,
        pivot_mapping.cc_segment_offer,
        pivot_mapping.cloud_type_filter,
        firmographics.org_name,
        firmographics.industry,
        firmographics.employee_range,
        firmographics.revenue_range,
        current_arr.seat_level_fwk_begin_arr,
        pivot_mapping.phones_vs_web
FROM (select * from ocf_analytics.dim_contract_jem where contract_type != 'DIRECT_INDIVIDUAL') contracts
LEFT OUTER JOIN (select min(term_startdate) as first_contract_startdate, 
                      contract_id from ocf_analytics.scd_seat_payment 
                where payment_status = 'PAID SEAT' 
                group by contract_id) seat_payment ON contracts.contract_id = seat_payment.contract_id
LEFT OUTER JOIN (
                SELECT
                    contract_id,
                    org_name,
                    industry,
                    employee_range,
                    revenue_range,
                    ROW_NUMBER() OVER(PARTITION BY contract_id ORDER BY revenue_range DESC) as r_num
                FROM
                    b2b.sp_firmographics_smb_contract_details
            ) firmographics on contracts.contract_id = firmographics.contract_id and firmographics.r_num = 1
LEFT OUTER JOIN
  ( SELECT contract_id,
    COUNT(DISTINCT seat_id) seat_count,
    COUNT(DISTINCT(CASE WHEN seat_status != 'ACTIVE SEAT' THEN seat_id ELSE NULL END)) seat_cancelled
FROM ocf_analytics.dim_seat
where 
contract_type != 'DIRECT_INDIVIDUAL' 
GROUP BY contract_id)all_contract ON contracts.contract_id = all_contract.contract_id
LEFT OUTER JOIN ocf_analytics.dim_seat seat ON contracts.contract_id = seat.contract_id
LEFT OUTER JOIN team_seat_provisioning_temp seat_provisioning ON seat.seat_id = seat_provisioning.seat_id 
INNER JOIN Ids_coredata.dim_date period on to_date(contracts.contract_created_date) = period.date_date
LEFT OUTER JOIN Ids_coredata.dim_date seat_period on to_date(seat_provisioning.seat_creation_date) = seat_period.date_date
LEFT OUTER JOIN Ids_coredata.dim_date seat_deploy_period on to_date(seat_provisioning.seat_assigned_date) = seat_deploy_period.date_date
LEFT OUTER JOIN Ids_coredata.dim_country countries ON contracts.country_code = countries.country_code_iso2
LEFT OUTER JOIN dim_member_temp dm ON upper(seat_provisioning.auth_id) = upper(dm.auth_id) and row_num_member = 1
LEFT OUTER JOIN
  (SELECT seat_id, 
          min(if(TO_DATE(first_download_date) >= TO_DATE(seat_assigned_date),first_download_date,NULL)) as first_download_date_after_assignment,
          min(first_download_date) as first_download_date,
          max(first_download_date) as last_download_date
   FROM 
  (SELECT 
          download.auth_id,
          dl_end_date as first_download_date,
          product_name,
          prov.seat_id,
          seat_assigned_date
   FROM dowload_temp download
   INNER JOIN scd_seat_provisioning_temp prov ON prov.auth_id= download.auth_id
   INNER JOIN b2b.team_seats_by_provisioning  seat_prov ON prov.seat_id = seat_prov.seat_id
   where 
         if(TO_DATE(seat_cancelled_date) is NOT NULL,if(TO_DATE(dl_end_date) <= TO_DATE(seat_cancelled_date), TRUE, FALSE), TRUE)) download
   GROUP BY seat_id) dl ON seat.seat_id = dl.seat_id
LEFT OUTER JOIN
( SELECT seat_id, 
        count(distinct partition_date) as total_launch_days,
        sum(activity_count) as total_launches,
        count(distinct if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),7),product,0)) as first_7_day_launched_products_count,
        count(distinct if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),28),product,0)) as first_28_day_launched_products_count,
        count(distinct if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),60),product,0)) as first_60_day_launched_products_count,
        sum(if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),7),activity_count,0)) as first_7_day_launches,
        count(distinct if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),7),partition_date,NULL)) as first_7_day_launch_days,
        sum(if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),28),activity_count,0)) as first_28_day_launches,
        count(distinct if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),28),partition_date,NULL)) as first_28_day_launch_days,
        sum(if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),60),activity_count,0)) as first_60_day_launches,
        count(distinct if(TO_DATE(partition_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),60),partition_date,NULL)) as first_60_day_launch_days,
        min(partition_date) as first_launch_date,
        max(partition_date) as last_launch_date
FROM
  (SELECT distinct 
         hau.auth_id,
          event_date as partition_date,
          prov.seat_id,
          seat_prov.seat_assigned_date,
          hau.num_events as activity_count,
          hau.source_name as product
  FROM launch_temp hau
  INNER JOIN (select distinct seat_id,
                     auth_id,
                     startdate_dttm as start_dttm, 
                     enddate_dttm end_dttm 
             from scd_seat_provisioning_temp
           ) prov ON prov.auth_id = hau.auth_id
  INNER JOIN b2b.team_seats_by_provisioning  seat_prov ON prov.seat_id = seat_prov.seat_id
   WHERE 1=1 
   and (TO_DATE(event_date) >= TO_DATE(seat_assigned_date) and 
    if(TO_DATE(seat_cancelled_date) is NOT NULL,if(TO_DATE(event_date) <= TO_DATE(seat_cancelled_date), TRUE, FALSE), TRUE))
  and (TO_DATE(event_date) between TO_DATE(start_dttm) and TO_DATE(end_dttm))
  ) launch
  GROUP BY seat_id
  ) hb_launch ON (seat.seat_id = hb_launch.seat_id)
LEFT OUTER JOIN
(SELECT seat_id, 
       product as most_launched_product_next_28days,
       no_of_launches_per_product as 28d_highest_single_product_active_days,
        ROW_NUMBER() OVER(PARTITION BY seat_id ORDER BY no_of_launches_per_product desc) as rownum
FROM
  (SELECT        
          prov.seat_id,
          fua.source_name as product,
          count(distinct if(TO_DATE(event_date) between date_add(TO_DATE(seat_assigned_date),8) and date_add(TO_DATE(seat_assigned_date),36),event_date,NULL)) as no_of_launches_per_product
  FROM launch_temp fua
  INNER JOIN (select distinct seat_id,
                    auth_id,
                     startdate_dttm as start_dttm, 
                     enddate_dttm end_dttm 
             from scd_seat_provisioning_temp
            ) prov ON prov.auth_id= fua.auth_id
  INNER JOIN b2b.team_seats_by_provisioning  seat_prov ON prov.seat_id = seat_prov.seat_id
   WHERE 1=1
   and (TO_DATE(event_date) >= TO_DATE(seat_assigned_date) and 
    if(TO_DATE(seat_cancelled_date) is NOT NULL,if(TO_DATE(event_date) <= TO_DATE(seat_cancelled_date), TRUE, FALSE), TRUE))
    and (TO_DATE(event_date) between TO_DATE(start_dttm) and TO_DATE(end_dttm))
    group by prov.seat_id,
          fua.source_name
  ) launch 
)repeat_launch_28days ON (repeat_launch_28days.seat_id = seat.seat_id and repeat_launch_28days.rownum = 1)
LEFT OUTER JOIN
(select prov.seat_id,
        min(event_date) as first_service_usage_date,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),90) and UPPER(source_name) = 'CCLIBRARY',event_date,NULL)) first_90_cclibrary_usage_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),90) and UPPER(source_name) = 'CLOUD-DOCS',event_date,NULL)) first_90_cloud_docs_usage_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),90) and UPPER(source_name) = 'FONTS',event_date,NULL)) first_90_fonts_usage_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),90) and UPPER(source_name) = 'BEHANCE',event_date,NULL)) first_90_behance_usage_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),90) and UPPER(source_name) = 'PORTFOLIO',event_date,NULL)) first_90_portfolio_usage_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),90) and UPPER(source_name) = 'NEURAL-FILTERS',event_date,NULL)) first_90_neural_filters_usage_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),90) and UPPER(source_name) = 'LEARN',event_date,NULL)) first_90_learn_usage_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),7),event_date,NULL)) first_7_days_active_service_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),28),event_date,NULL)) first_28_days_active_service_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),60),event_date,NULL)) first_60_day_active_service_days,
        count(distinct if(TO_DATE(event_date) between TO_DATE(seat_assigned_date) and date_add(TO_DATE(seat_assigned_date),90),event_date,NULL)) first_90_day_active_service_days
  from dme_hybrid_active_use_temp hau 
  inner join  (select distinct seat_id,
                      auth_id,
                     startdate_dttm as start_dttm, 
                     enddate_dttm end_dttm 
             from scd_seat_provisioning_temp
              ) prov ON prov.auth_id = hau.auth_id
    INNER JOIN b2b.team_seats_by_provisioning  seat_prov ON prov.seat_id = seat_prov.seat_id
  WHERE TO_DATE(hau.event_date) between TO_DATE(prov.start_dttm) and TO_DATE(prov.end_dttm)
  AND (TO_DATE(hau.event_date) >= TO_DATE(seat_assigned_date) and 
    if(TO_DATE(seat_cancelled_date) is NOT NULL,if(TO_DATE(hau.event_date) <= TO_DATE(seat_cancelled_date), TRUE, FALSE), TRUE))
  GROUP BY prov.seat_id
  ) hau on hau.seat_id = seat.seat_id
LEFT OUTER JOIN
b2b.jem_seat_arr_pivot_mapping_tbl pivot_mapping on pivot_mapping.seat_id = seat.seat_id and pivot_mapping.rownum = 1
LEFT OUTER JOIN
b2b.current_active_arr_per_seat current_arr on current_arr.seat_id = seat.seat_id """)
             spark.sql(""" drop table if exists b2b.b2b_cohort_data_final """)
             spark.sql(""" create table  b2b.b2b_cohort_data_final AS
select * from b2b.b2b_cohort_data where seat_start_fiscal_qtr >= '2018-Q1' or seat_start_fiscal_qtr is NULL """)
             

            
             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()