# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
import pandas as pd
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             #dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             #RUN_DATE = dbutils.widgets.get("RUN_DATE")
             #B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             #RUN_DATE = B2B_RUN_DATE
             

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))
             spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_partition_dates''')
             spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_raw_events_stg3''')
             spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_raw_events_stg4''')
             spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_invocationlogs''')
             spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_rhpfavtools''')
             spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_web ''')
             spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_agreement ''')

             #Variables to be used to extract data by partition

             spark.sql(''' CREATE TABLE b2b_stg.hva_acro_partition_dates AS
WITH
    dates AS (
        SELECT
            to_date('{B2B_RUN_DATE}') d1, 
            trunc (add_months('{B2B_RUN_DATE}', -1), 'MM') d2)
SELECT
        substr (d1, 1, 4) AS year1,
        substr (d2, 1, 4) AS year2,
        substr (d1, 1, 7) AS monthkey1,
        substr (d2, 1, 7) AS monthkey2,
        cast (cast (substr (d1, 6, 2) AS INT) AS STRING) AS month1,
        cast (cast (substr (d2, 6, 2) AS INT) AS STRING) AS month2,
        date (d2) AS first_day_prev_month,
        cast (d2 AS STRING) AS from_date_string,
        cast (d1 AS STRING) AS to_date_string
FROM    dates '''.format(B2B_RUN_DATE = B2B_RUN_DATE))

             #Extract all usage data we will need for High Value Tool reporting
             #It allows us to look at only relevant usage in subsequent queries

             df = spark.sql(""" select monthkey1,monthkey2,month1,month2,year1,year2,cast(first_day_prev_month as string) first_day_prev_month from b2b_stg.hva_acro_partition_dates  """).toPandas()
             
             year_list = tuple(set(df.loc[0,['year1', 'year2']].values.flatten().tolist()))
             if len(year_list) == 1:
                 year_list = "('"+ str(tuple(year_list)[0])+ "')"
             else:
                 year_list = tuple(year_list)
             print(year_list)
             
             month_list = tuple(set(df.loc[0,['month1', 'month2']].values.flatten().tolist()))
             print(month_list)
             
             monthkey_list = tuple(set(df.loc[0,['monthkey1', 'monthkey2']].values.flatten().tolist()))
             print(monthkey_list)
             
             first_day_prev_month = tuple(set(df.loc[0,['first_day_prev_month']].values.flatten().tolist()))
             if len(first_day_prev_month) == 1:
                 first_day_prev_month = "('"+ str(tuple(first_day_prev_month)[0])+ "')"
             else:
                 first_day_prev_month = tuple(first_day_prev_month)
                 first_day_prev_month = first_day_prev_month[2:-2]
             print(first_day_prev_month)

             spark.sql("""
          CREATE TABLE b2b_stg.hva_acro_raw_events_stg3 AS
    SELECT DISTINCT
            u.pguid,
            m.hv_tool,
            m.hv_category,
            date (substr (u.featuretime, 1, 10)) AS event_date
        FROM
            (select distinct pguid,featuretime,category,subcategory,featurename,year,month,monthkey 
            from dc_acrobatstar.feature
            where year in {year_list}
            and month in {month_list} 
            and monthkey in {monthkey_list}
            and date (substr (featuretime, 1, 10)) >= '{first_day_prev_month}'
            ) AS u
        JOIN b2b_stg.hva_acro_raw_events_mapping AS m
             ON u.category    = m.category
            AND u.subcategory = m.subcategory
            AND u.featurename = m.featurename
          """.format(year_list = year_list, month_list = month_list, monthkey_list = monthkey_list, first_day_prev_month = first_day_prev_month))

             #Extract corresponding member_guid

             spark.sql('''CREATE TABLE b2b_stg.hva_acro_raw_events_stg4 AS
    SELECT DISTINCT 
            split(h.member_guid,'@')[0] as member_guid,
            u.hv_tool,
            u.hv_category,
            u.event_date
        FROM
            b2b_stg.hva_acro_raw_events_stg3 u
        JOIN hb_monitor.user_mapping_snapshot h ON h.pguid = u.pguid
        -- JOIN b2b_stg.hb_monitor_user_mapping_snapshot h ON h.pguid = u.pguid
        JOIN b2b.b2b_users AS m
             ON m.member_guid = split(h.member_guid,'@')[0]
            AND m.as_of_date = '{B2B_RUN_DATE}'
            AND m.contract_offer_type in ('TEAM_DIRECT','VIP','VIPMP') '''.format(B2B_RUN_DATE = B2B_RUN_DATE))

             #Extract data from alternative sources of events
             #As we only looking for limited number of events, the logic is simpler

             spark.sql(''' CREATE TABLE b2b_stg.hva_acro_invocationlogs AS
    SELECT DISTINCT 
            split(h.member_guid,'@')[0] as member_guid,
            CASE
                WHEN u.featurename IN 
                    ( 'SendInBulkApp', 'OpenInWebApp_SendInBulkApp')
                THEN 'BULK_SEND'
                WHEN u.featurename IN 
                    ('CollectPaymentsApp', 'OpenInWebApp_CollectPaymentsApp')
                THEN 'COLLECT_PAYMENTS'
                WHEN u.featurename IN 
                    ('AddSignBrandingApp', 'OpenInWebApp_AddSignBrandingApp')
                THEN 'CUSTOM_BRANDING'
                WHEN u.featurename IN 
                    ('CreateWebFormApp', 'OpenInWebApp_CreateWebFormApp')
                THEN 'PREPARE_WEB_FORMS'
            END AS hv_tool,
            'FORMS_AND_SIGNATURES' AS hv_category,
            date (substr (u.grouptime, 1, 10)) AS event_date
        FROM
            dc_acrobatstar.invocationlogs u
            -- b2b_stg.dc_acrobatstar_invocationlogs u
        -- JOIN b2b_stg.hb_monitor_user_mapping_snapshot h ON h.pguid = u.pguid
        JOIN hb_monitor.user_mapping_snapshot h ON h.pguid = u.pguid
        CROSS JOIN b2b_stg.hva_acro_partition_dates d
        WHERE u.monthkey  IN (d.monthkey1, d.monthkey2)
        AND u.year        IN (d.year1, d.year2)
        AND u.month       IN (d.month1, d.month2)
        AND date (substr (u.grouptime, 1, 10)) >= d.first_day_prev_month
        AND u.category    = 'ToolCenter'
        AND u.subcategory = 'Invoked'
        AND u.featurename IN (
            'CollectPaymentsApp',
            'AddSignBrandingApp',
            'SendInBulkApp',
            'CreateWebFormApp',
            'OpenInWebApp_CollectPaymentsApp',
            'OpenInWebApp_AddSignBrandingApp',
            'OpenInWebApp_SendInBulkApp',
            'OpenInWebApp_CreateWebFormApp') ''')

             spark.sql(''' CREATE TABLE b2b_stg.hva_acro_rhpfavtools AS
    SELECT DISTINCT 
            split(h.member_guid,'@')[0] as member_guid,
            CASE
                WHEN u.event IN ( 'SendInBulkApp')
                THEN 'BULK_SEND'
                WHEN u.event IN ('CollectPaymentsApp')
                THEN 'COLLECT_PAYMENTS'
                WHEN u.event IN ('AddSignBrandingApp')
                THEN 'CUSTOM_BRANDING'
                WHEN u.event IN  ('CreateWebFormApp')
                THEN 'PREPARE_WEB_FORMS'
            END AS hv_tool,
            'FORMS_AND_SIGNATURES' AS hv_category,
            date (substr (u.grouptime, 1, 10)) AS event_date
        FROM
            -- b2b_stg.dc_acrobatstar_rhpfavtools u
            dc_acrobatstar.rhpfavtools u
        -- JOIN b2b_stg.hb_monitor_user_mapping_snapshot h ON h.pguid = u.pguid
        JOIN hb_monitor.user_mapping_snapshot h ON h.pguid = u.pguid
        CROSS JOIN b2b_stg.hva_acro_partition_dates d
        WHERE u.monthkey  IN (d.monthkey1, d.monthkey2)
        AND u.year        IN (d.year1, d.year2)
        AND u.month       IN (d.month1, d.month2)
        AND date (substr (u.grouptime, 1, 10)) >= d.first_day_prev_month
        AND LOWER (u.rhp_state) = 'rhpexpanded'
        AND u.event IN ('CollectPaymentsApp', 'AddSignBrandingApp', 'SendInBulkApp', 'CreateWebFormApp') ''')

             spark.sql(''' CREATE TABLE b2b_stg.hva_acro_agreement AS
WITH agreements AS (
    SELECT DISTINCT 
            substr (u.originator_adobe_guid, 1, 24) as member_guid,
            u.agreement_sent_for_esignature,
            u.agreement_is_megasign_child,
            date (substr (u.created, 1, 10)) AS event_date
        FROM
            a_sign_pub.agreement u
        JOIN b2b.b2b_users AS m
             ON m.member_guid = substr (u.originator_adobe_guid, 1, 24)
            AND m.as_of_date = '{B2B_RUN_DATE}'
            AND m.contract_offer_type in ('TEAM_DIRECT','VIP','VIPMP')
        CROSS JOIN b2b_stg.hva_acro_partition_dates d
        WHERE substr (u.created, 1, 10) >= d.from_date_string
        AND   substr (u.created, 1, 10) <= d.to_date_string
        AND u.status IN (
                'WAITING_FOR_SIGNATURES',
                'SIGNED',
                'EXPIRED',
                'WAITING_FOR_REVIEW',
                'ABANDONED')
        AND u.origination_type <> 'WELCOME'
        AND u.agreement_should_be_ignored = 0
        AND (   u.agreement_sent_for_esignature = 1
            OR  u.agreement_is_megasign_child = 1)
)
SELECT
        member_guid,
        'REQUEST_E_SIGNATURE' AS hv_tool,
        'FORMS_AND_SIGNATURES' AS hv_category,
        event_date
FROM    agreements
WHERE   agreement_sent_for_esignature = 1
UNION ALL
SELECT
        member_guid,
        'BULK_SEND' AS hv_tool,
        'FORMS_AND_SIGNATURES' AS hv_category,
        event_date
FROM    agreements
WHERE   agreement_is_megasign_child = 1 '''.format(B2B_RUN_DATE = B2B_RUN_DATE))

             spark.sql(''' CREATE TABLE b2b_stg.hva_acro_web AS
    SELECT
            UPPER (SUBSTR (p.post_evar12, 1, 24)) as member_guid,
            CASE
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/public/compose%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Email Added%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Subject Updated%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Message Updated%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:File Uploaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/sendProgress%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/documentEdit%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/authoringv4%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/postSend%'
                THEN 'REQUEST_E_SIGNATURE'
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:compose:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:authoring:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:review:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:confirmation:loaded%'
                THEN 'BULK_SEND'
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_mrchId:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_pbcKey:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_prvKey:chg%'
                THEN 'COLLECT_PAYMENTS'
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_lgUpld:done%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_hostName:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_cmpName:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%adm_acSetup_cnAllUsrs:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%adm_acSetup_cnAllUsrs:uchk%'
                THEN 'CUSTOM_BRANDING'
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:compose:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:authoring:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:confirmation:loaded%'
                THEN 'PREPARE_WEB_FORMS'
            END AS hv_tool,
            'FORMS_AND_SIGNATURES' AS hv_category,
            date (p.click_date) AS event_date
        FROM
            aa_ingest.sc_visitor_click_history_parquet_apr2022 p
        CROSS JOIN b2b_stg.hva_acro_partition_dates d
        WHERE
            p.report_suite = 'adbdcwebprod'
        AND p.post_evar7 = 'authenticated'
        AND p.click_date >= d.from_date_string
        AND p.click_date <= d.to_date_string
        AND (  CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/public/compose%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Email Added%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Subject Updated%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Message Updated%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:File Uploaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/sendProgress%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/documentEdit%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/authoringv4%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/postSend%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:compose:loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:authoring:loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:review:loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:confirmation:loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_lgUpld:done%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_hostName:chg%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_cmpName:chg%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%adm_acSetup_cnAllUsrs:chg%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%adm_acSetup_cnAllUsrs:uchk%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:compose:loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:authoring:loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:confirmation:loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_loaded%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_mrchId:chg%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_pbcKey:chg%'
            OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_prvKey:chg%') ''')

             #Populate permanent table
             spark.sql(''' INSERT OVERWRITE TABLE b2b.hva_acro_raw_events partition(month, year, monthkey, data_source)
    SELECT DISTINCT * FROM
    (SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'feature' as data_source
    FROM b2b_stg.hva_acro_raw_events_stg4
    UNION ALL
    SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'web' as data_source
    FROM b2b_stg.hva_acro_web
    UNION ALL
    SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'rhpfavtools' as data_source
    FROM b2b_stg.hva_acro_rhpfavtools
    UNION ALL
    SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'invocationlogs' as data_source
    FROM b2b_stg.hva_acro_invocationlogs
    UNION ALL
    SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'agreements' as data_source
    FROM b2b_stg.hva_acro_agreement) ''')


             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()
