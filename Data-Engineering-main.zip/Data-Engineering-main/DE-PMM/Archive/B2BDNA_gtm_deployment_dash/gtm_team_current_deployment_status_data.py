# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")
            

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET mapred.output.compression.type=BLOCK """)
             spark.sql(""" SET hive.exec.reducers.bytes.per.reducer=50000000 """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" set hive.support.concurreny=false """)
             spark.sql(""" set hive.auto.convert.join.noconditionaltask=false """)
             spark.sql(""" drop table if exists b2b.team_current_deployment_status_data; """)
             spark.sql(""" create table  b2b.team_current_deployment_status_data
(
             contract_type                          string,  
             contract_id                            string,  
             purchasedentitlement_id                string,  
             seat_id                                string,  
             seat_createddate                       date,   
             seat_last_modifieddate                 date,                               
             seat_status                            string,  
             seat_delegation_status                 string,  
             material_number                        string,  
             member_guid                            string,  
             country_code                           string,  
             geo                                    string,  
             entitlement_type                       string,  
             entitlement_period                     string,  
             market_segment                         string,
             route_to_market                        string,  
             product_name                           string,  
             regular_vs_promotion                   string,  
             cloud_type                             string,  
             subscription_account_guid              string,
             seat_type                              string,
             contract_geo_code                      string,
             contract_market_area_code              string,
             contract_country                       string,
             seat_geo_code                          string,
             seat_market_area_code                  string,
             seat_creation_week                     string,
             seat_creation_qtr                      string,
             contract_created_date                  date,
             contract_anniversary_date              date,
             contract_previous_anniversary_date     date,
             external_contract_id                   string,
             owner_id                               string,
             owner_identity_id                      string,
             reseller_owner_id                      string,
             billing_frequency                      string,
             billing_status                         string,
             billing_payment_category               string,
             enrollee_id                            string,
             enrollee_adobe_id                      string,
             enrollee_email                         string,
             enrollee_name                          string,
             opt_in_email                           string,
             force_opt_in_date                      string,
             dist_market_area                       string, 
             dist_region                            string,                     
             dist_geo                               string, 
             dist_name                              string,                              
             customer_name                          string,         
             reseller_name                          string,                
             original_contract_start_date           date,        
             enroll_country                         string,         
             enroll_name1                           string,   
             enroll_name2                           string,
             enroll_email                           string,    
             reseller_rollup_id                     string,     
             enroll_contact_number                  string,
             reseller_channel_program_level         string,
             vip_owner                              string,
             team_manager                           string,
             sales_manager                          string,
             cam_geo                                string,
             product_config                         string,
             cc_segment_offer                       string,
             cc_segment                             string,
             subs_offer                             string,
             device_vs_named                        string,
             industry                               string,
             employee_range                         string,
             payment_status                         string,
             launch_count                           bigint,
             launch_count_desktop                   bigint,
             launch_count_desktop_365                  bigint
) """)
             spark.sql(""" INSERT into TABLE b2b.team_current_deployment_status_data 
SELECT       seat.contract_type                          ,  
             seat.contract_id                            ,  
             seat.purchasedentitlement_id                ,  
             seat.seat_id                                ,  
             TO_DATE(seat.seat_createddate) as seat_createddate                       ,   
             TO_DATE(seat.seat_last_modifieddate) as seat_last_modifieddate                 ,                               
             seat.seat_status                            ,  
             seat.seat_delegation_status                 ,  
             seat.material_number                        ,  
             seat.member_guid                            ,  
             seat.country_code                           ,  
             seat.geo                                    ,  
             seat.entitlement_type                       ,  
             seat.entitlement_period                     ,  
             seat.market_segment                         ,
             seat.route_to_market                        ,  
             seat.product_name                           ,  
             seat.regular_vs_promotion                   ,  
             seat.cloud_type                             ,  
             seat.subscription_account_guid              ,
             seat.seat_type,
             countries.geo_code as contract_geo_code,
             countries.market_area_code as contract_market_area_code,
             contracts.country_code as contract_country,
             s_countries.geo_code as seat_geo_code,
             s_countries.market_area_code as seat_market_area_code,
             d.fiscal_yr_and_wk_desc as seat_creation_week,
             d.fiscal_yr_and_qtr_desc as seat_creation_qtr,
             TO_DATE(contracts.contract_created_date) as contract_created_date,
             TO_DATE(contracts.anniversary_date) as contract_anniversary_date,
             TO_DATE(contracts.previous_anniversary_date) as contract_previous_anniversary_date,
             contracts.external_contract_id,
             contracts.owner_id,
             contracts.owner_identity_id,
             contracts.reseller_owner_id,
             contracts.billing_frequency,
             contracts.billing_status,
             contracts.billing_payment_category,
             contracts.enrollee_id,
             mdpd.adobe_id as enrollee_adobe_id,
             mdpd.email as enrollee_email,
             concat(mdpd.first_name," ",mdpd.last_name) as enrollee_name,
             mdpd.opt_in_email,
             mdpd.force_opt_in_date,
             sales_dist.market_area_code AS dist_market_area, 
            sales_dist.region_code AS dist_region,                     
            sales_dist.geo_code AS dist_geo, 
            vip.dist_name,                              
            vip.CUSTOMERNAME,         
            vip.RESELLERNAME,                
            TO_DATE(vip.original_contract_start_date) as original_contract_start_date,        
            vip.enroll_country,         
            vip.enroll_name1,                
            vip.enroll_name2,
            vip.enroll_email,    
            vip.Reseller_Roll_Up_Id,     
            vip.enroll_contact_number,
            vip.Reseller_Channel_Prog_Level,
            cam_mapping.vipowner,
            cam_mapping.teammanager,
            cam_mapping.salesmanager,
            cam_mapping.geo as cam_geo,
            pivot.product_config,
            pivot.cc_segment_offer,
            pivot.cc_segment,  
            pivot.subs_offer,                             
            case
			    when pivot.cc_segment_offer in ('HED CCDA Complete', 'HED CCDA Single App') then 'DEVICE'
			    when pivot.cc_segment = 'K12+EEA' and pivot.subs_offer = 'CCT Complete' then 'DEVICE'
			    else 'NAMED'
		    end device_vs_named,     
		    fg.industry,
            fg.employee_range,
            seat_payment.payment_status,
            if(act.member_guid is NULL,0,launch_count) as launch_count,
            if(act_desktop.member_guid is NULL,0,act_desktop.launch_count_desktop) as launch_count_desktop,
            if(act_desktop_365.member_guid is NULL,0,act_desktop_365.launch_count_desktop) as launch_count_desktop_365
    FROM 
    (SELECT *
          FROM --ocf_analytics.dim_contract 
          ocf_analytics.dim_contract_jem contracts
          WHERE contract_type != 'DIRECT_INDIVIDUAL') contracts
    INNER JOIN (select seat.*,
                IF(substr(seat_createddate,1,10) = (min(substr(seat_createddate,1,10)) over(partition by seat.contract_id order by NULL)),"Initial Purchased","Add-on Seat") as seat_type,
                IF(UPPER(contract.contract_type) = "DIRECT_ORGANIZATION", LPAD(contract.external_contract_id,10,0),if(UPPER(contract.contract_type) = "INDIRECT_ORGANIZATION",contract.contract_id,NULL)) as fin_contract_id 
                from ocf_analytics.dim_seat seat
                INNER JOIN ocf_analytics.dim_contract_jem contract ON seat.contract_id = contract.contract_id
                )seat
    ON contracts.contract_id = seat.contract_id
    LEFT OUTER JOIN 
    (SELECT  seat_id,
        payment_status,
        ROW_NUMBER() OVER(PARTITION BY seat_id ORDER BY enddate_dttm desc) as rownum
     FROM ocf_analytics.scd_seat_payment) seat_payment ON seat.seat_id = seat_payment.seat_id and seat_payment.rownum = 1
    LEFT OUTER JOIN Ids_coredata.dim_country countries
    ON contracts.country_code = countries.country_code_iso2
    LEFT OUTER JOIN Ids_coredata.dim_country s_countries
    ON seat.country_code = s_countries.country_code_iso2
    LEFT JOIN csmb.vw_deployment_report  vip 
    --ON ( vip.vip_contract = contracts.contract_id )
    ON ( vip.CONTRACT_ID = contracts.contract_id )
    LEFT JOIN b2b_stg.smb_vip_cam_mapping cam_mapping 
    ON (cam_mapping.vipcontract = contracts.contract_id)
    LEFT JOIN ids_coredata.dim_country sales_dist 
    ON ( sales_dist.country_code_iso2 = vip.billing_country )
    LEFT JOIN ids_coredata.dim_date d
    ON TO_DATE(seat.seat_createddate) = TO_DATE(d.date_date)
    LEFT JOIN mdpd_target.mdpd_user_ww mdpd
    ON contracts.enrollee_id = mdpd.user_guid
    LEFT OUTER JOIN
    (SELECT 
            max(product_config) as product_config,
            max(cc_segment) as cc_segment,
            max(subs_offer) as subs_offer,
            max(cc_segment_offer) as cc_segment_offer,
            subscription_account_guid,
            if(vip_contract is NULL or vip_contract = '', LPAD(sales_document,10,0),if(vip_contract is not null and vip_contract != '', vip_contract,NULL)) as contract_id
     FROM csmb.vw_ccm_pivot4_all
     WHERE date_key >= --translate(substring(date_add(from_unixtime( unix_timestamp(CAST( AS TIMESTAMP))),-60),1,10),"-","") 
     TRANSLATE(SUBSTRING(DATE_ADD(FROM_UNIXTIME(UNIX_TIMESTAMP()), -60),1,10),"-","")
     GROUP BY if(vip_contract is NULL or vip_contract = '', LPAD(sales_document,10,0),if(vip_contract is not null and vip_contract != '', vip_contract,NULL)),
             subscription_account_guid) pivot 
             ON seat.fin_contract_id = pivot.contract_id and seat.subscription_account_guid = pivot.subscription_account_guid
    LEFT OUTER JOIN
    (
      SELECT member_guid,sum(activity_count) as launch_count
      FROM ocf_analytics.fact_user_activity
      WHERE partition_date >= date_add(from_unixtime(unix_timestamp()), -30)
      GROUP BY member_guid
    )act
    ON seat.member_guid = act.member_guid 
    LEFT OUTER JOIN
    (
      SELECT member_guid,sum(activity_count) as launch_count_desktop
      FROM ocf_analytics.fact_user_activity
      WHERE partition_date >= date_add(from_unixtime( unix_timestamp()),-30)
      AND category IN ("HIGHBEAM_SESSION","ACROBAT_SESSION")
      GROUP BY member_guid
    )act_desktop
    ON seat.member_guid = act_desktop.member_guid 
    LEFT OUTER JOIN
    (
      SELECT member_guid,sum(activity_count) as launch_count_desktop
      FROM ocf_analytics.fact_user_activity
      WHERE partition_date >= date_add(from_unixtime( unix_timestamp()),-365)
      AND category IN ("HIGHBEAM_SESSION","ACROBAT_SESSION")
      GROUP BY member_guid
    )act_desktop_365
    ON seat.member_guid = act_desktop_365.member_guid 
    LEFT OUTER JOIN 
    (
        SELECT domain,max(industry) as industry,max(employee_range) as employee_range
        FROM b2b.sp_smb_firmographics
        GROUP BY domain 
    )fg
    ON UPPER(fg.domain) = UPPER(substr(mdpd.email, -1*(length(mdpd.email) - instr(mdpd.email, '@'))))
    WHERE seat.seat_status = 'ACTIVE SEAT' """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()