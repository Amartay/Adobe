# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET mapred.job.queue.name= root.scheduled.P2 """)
             spark.sql(""" set hive.optimize.skewjoin=false """)
             spark.sql(""" set hive.auto.convert.join=false """)
             spark.sql(""" insert overwrite table b2b.bob_fy2020_q1_v5_dedup
select distinct
		geo,
		account_id,
		account_name,
		seat_band,
		account_type,
		final_team,
 		csam,
		csam_email
from b2b.ww_bob_current_qtr """)
             spark.sql(""" insert overwrite table b2b.bob_fy2020_q1_domain
select 	A.geo,
		A.account_id,
		A.account_name,
		A.seat_band,
		A.account_type,
		A.final_team,
		A.csam,
		A.csam_email,
		B.account_name__c,
		B.contract_id__c,
		B.account_status__c,
		B.name,
		C.contract_type,
		C.enrollee_id,
		C.contract_created_date,
		C.reseller_owner_id,
		C.billing_status,
		D.pers_email as email,
		case when D.pers_email IS NULL then 'NA' else lower(split(D.pers_email, "@")[1]) end as email_domain_full,
		case when isp.isp_domains is NULL then "N" else "Y" end as member_isp_flag,
		E.count_account
from  b2b.bob_fy2020_q1_v5_dedup A
left outer join replicn_sfdc.sfdc_post_sales__c B
on A.account_id = B.account_name__c
left outer join ocf_analytics.dim_contract_jem C
on B.contract_id__c = C.contract_id
left join (select * from ocf_analytics.dim_user_lvt_profile	 x
          where split(x.pers_email, '[\@]')[1] <> 'adobe.com' and LENGTH(x.pers_email)<>0) D
on C.enrollee_id = D.user_guid
left join b2b.sai_isp_domains isp 
on lower(isp.isp_domains) = lower(split(D.pers_email, "@")[1])
left outer join (select account_id,count(account_id) as count_account 
				from b2b.bob_fy2020_q1_v5_dedup 
				group by account_id) E
on A.account_id = E.account_id """)
             spark.sql(""" drop table if exists b2b.bob_fy2020_q1_domain_stage1 """)
             spark.sql(""" create table b2b.bob_fy2020_q1_domain_stage1 as
select A.*,
		B.count_account_in_domain,
		C.count_domain_in_account,
		D.total_active_seats_today
from b2b.bob_fy2020_q1_domain A
left outer join (select lower(email_domain_full) as email_domain_full,count(distinct account_id) as count_account_in_domain 
				 from b2b.bob_fy2020_q1_domain where contract_id__c is not null
				 group by lower(email_domain_full)) B
on lower(A.email_domain_full) = lower(B.email_domain_full)
left outer join (select account_id,count(distinct lower(email_domain_full)) as count_domain_in_account 
				 from b2b.bob_fy2020_q1_domain where contract_id__c is not null
				 group by account_id) C
on A.account_id = C.account_id
left outer join b2b.contract_level_agg_all_v1 D
on A.contract_id__c = D.contract_id """)
             spark.sql(""" drop table if exists b2b.bob_fy2020_q1_domain_stage2 """)
             spark.sql(""" create table b2b.bob_fy2020_q1_domain_stage2 as
select 	email_domain_full,
		account_id,
		account_name,
		csam,
		sum(total_active_seats_today) as seat_count
from b2b.bob_fy2020_q1_domain_stage1 A
where member_isp_flag = "N"
group by email_domain_full,
		account_id,
		account_name,
		csam """)
             spark.sql(""" insert overwrite table b2b.bob_fy2020_q1_domain_stage3
select  A.email_domain_full,
		A.account_id,
		A.account_name,
		A.csam,
		B.domain_name__c, 
        B.id, 
        B.csam__c, 
        B.csam_assignment_date__c, 
		C.name as csam_name,
		(case 
			when A.csam = 'Unassigned' then C.name
			when A.csam is not null then A.csam
			when A.csam is null and C.name is not null then C.name
			else null 
		end) as csam_updated,
		sum(1) as counter
from b2b.bob_fy2020_q1_domain_stage2 A
left outer join replicn_sfdc.sfdc_account B
on A.account_id = B.id
left outer join replicn_sfdc.sfdc_user C
on B.csam__c = C.id
group by A.email_domain_full,
		A.account_id,
		A.account_name,
		A.csam,
		B.domain_name__c, 
        B.id, 
        B.csam__c, 
        B.csam_assignment_date__c, 
		C.name,
		(case 
			when A.csam = 'Unassigned' then C.name
			when A.csam is not null then A.csam
			when A.csam is null and C.name is not null then C.name
			else null 
		end) """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

