# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.support.quoted.identifiers = None; """)
             spark.sql(""" drop table if exists b2b.csam_smb_all_cta_table_stage3_tableau """)
             spark.sql(""" create table b2b.csam_smb_all_cta_table_stage3_tableau as
select email_domain,account_name,market_area,contract_flag,cta_acrobat,domain_acro_added_seat_count,industry,acro_employee_range_for_msft_excel,perpetual_flag,acro_penetration,acro_trial,acrobat_comment,cta_cce,cce_employee_range_for_msft_excel,cct_cc_complete_count,quarter_flag,visit_count_in_last_3_months,avg_percentile_score,cei_flag,g_suite,microsoft_azure,office_365,iam,cce_comment,cct_cta,cct_employee_range_for_msft_excel,count_cci_complete,count_single_app,free_active_user,cct_comment,cta_stock,overageflag,stock_pure_play,stock_cci_presence,stock_competitor,stock_cc_complete_count,stock_comment,cta_sign,sign_employee_range_for_msft_excel,power_users,txn50_users,total_sent_for_signature,count_sign_cci,sign_txn_users,sign_comment,finalcomment,contract_id__c from b2b.csam_smb_all_cta_table_stage3
union all
select A.* from
(select email_domain,account_name,market_area,contract_flag,cta_acrobat,domain_acro_added_seat_count,industry,acro_employee_range_for_msft_excel,perpetual_flag,acro_penetration,acro_trial,acrobat_comment,cta_cce,cce_employee_range_for_msft_excel,cct_cc_complete_count,quarter_flag,visit_count_in_last_3_months,avg_percentile_score,cei_flag,g_suite,microsoft_azure,office_365,iam,cce_comment,cct_cta,cct_employee_range_for_msft_excel,count_cci_complete,count_single_app,free_active_user,cct_comment,cta_stock,overageflag,stock_pure_play,stock_cci_presence,stock_competitor,stock_cc_complete_count,stock_comment,cta_sign,sign_employee_range_for_msft_excel,power_users,txn50_users,total_sent_for_signature,count_sign_cci,sign_txn_users,sign_comment,finalcomment,contract_id__c from b2b.csam_smb_all_cta_table_stage3_archived) A
	left outer join (select email_domain, sum(1) as counter 
					from b2b.csam_smb_all_cta_table_stage3
					group by email_domain) B
	on A.email_domain = B.email_domain
	where B.email_domain is null """)
             spark.sql(""" drop table if exists b2b.csam_smb_competitor_info_all """)
             spark.sql(""" create table b2b.csam_smb_competitor_info_all as
with A as (
    Select distinct 
        email_domain,
        account_name as account_id
    from b2b.csam_smb_all_cta_table_stage1),
    B as (
    Select
		email_domain, 
		max(stock_competitor_info) stock_competitor_info
    from cahcsmb.cah_cct_direct_contracts_uqfms_stock_play
    group by email_domain),
    C as (
    Select 
        email_domain,
        max(stock_search) stock_search,
        max(stock_usage) stock_usage
    from b2b.smb_stocks_cta_data3
    group by email_domain)
select 	A.email_domain, 
		A.account_id,
		B.stock_competitor_info,
		C.stock_search,
		C.stock_usage
from A
left outer join B
on upper(A.email_domain) = upper(B.email_domain)
left outer join C
on upper(A.email_domain) = upper(C.email_domain) """)
             spark.sql(""" insert overwrite table b2b.csam_smb_cci_stock_overage_info
select distinct 
        email_domain_full,
        seat_id,
        seat_status,
        overageflag,
        crm_customer_guid,
        sales_document
from b2b.domian_contracts_seat_detail_all_v1 """)
             spark.sql(""" insert overwrite table b2b.csam_smb_active_trialist_info_filtered
select  distinct
       A.email_domain,
       A.member_guid,
       concat(A.last_download," - ",A.last_product) as Download_Product,
       A.last_active as last_usage,
       lvt.email
from b2b.smb_analytics_CCT_active_trialist1 A
left outer join (     select upper(user_guid) member_guid,
                           lower(pers_email) as email,
                           LOWER(regexp_replace (pers_email,'.*@','')) email_domain from ocf_analytics.dim_user_lvt_profile	) lvt
ON upper(lvt.member_guid) = upper(A.member_guid)
inner join b2b.csam_smb_all_cta_table_stage1 B
on upper(A.email_domain) = upper(B.email_domain)
where datediff(current_date(),last_download) < 30 or last_active is not null """)
             spark.sql(""" insert overwrite table b2b.csam_smb_cci_email_info
select 	distinct
		A.email_domain, 
		B.contract_id as contract_id,
		B.email,
		B.product_name,
		C.seat_created_date
from b2b.csam_smb_all_cta_table_stage1 A
inner join b2b.all_domian_contracts_individual_emails_nonISP1 B
on upper(A.email_domain) = upper(B.email_domain)
left outer join (
    SELECT distinct 
        contract_id,
        member_guid,
        product_name,
		substr(seat_createddate,1,10) seat_created_date
   FROM ocf_analytics.dim_seat
   WHERE contract_type IN ('DIRECT_INDIVIDUAL') and seat_status = 'ACTIVE SEAT' ) C
on B.contract_id = C.contract_id
and B.member_guid = C.member_guid
and B.product_name = C.product_name """)
             spark.sql(""" insert overwrite table b2b.all_domian_contracts_cci_users_tou_acceptance
select 	distinct
		A.email_domain,
		B.email,
		nvl(C.tou_accepted,'Inactive User') as tou_accepted
from b2b.csam_smb_all_cta_table_stage1 A
inner join b2b.all_domian_contracts_individual_emails_nonISP1 B
on upper(A.email_domain) = upper(B.email_domain)
left outer join (Select distinct email, tou_accepted
				from b2b.ts_cci_users_all
				where tou_accepted = 'Yes') C
on upper(B.email) = upper(C.email) """)
             spark.sql(""" insert overwrite table b2b.all_domian_contracts_cci_domains_tou_acceptance
select 	distinct
		A.email_domain,
		nvl(B.Total_CCI_Users,'No active users') Total_CCI_Users,
		nvl(B.tou_accepted_users,'No active users') tou_accepted_users,
		nvl(B.tou_not_accepted_users,'No active users') tou_not_accepted_users,
		nvl(B.ToU_Domain_Status,'No active users') ToU_Domain_Status 
from b2b.csam_smb_all_cta_table_stage1 A
left outer join (Select distinct domain, total_cci_users, tou_accepted_users, tou_not_accepted_users, tou_domain_status
                from b2b.ts_cci_domains_all) B
on  upper(A.email_domain) = upper(B.domain) """)
             spark.sql(""" drop table if exists b2b.csam_smb_cci_all_domain_info """)
             spark.sql(""" create table b2b.csam_smb_cci_all_domain_info as
select distinct 
		A.Domain
		,'' as geo
		,B.country_code
		,B.domestic_employees_range as employee_range
		,B.domestic_employees_range_for_msft_excel as employee_range_for_msft_excel
		,B.domestic_ultimate_core_industry as industry
		,'' as line_of_business
		,B.domestic_revenue_range as revenue_range
		,B.naics_description
		,C.g_suite
		,C.microsoft_azure
		,C.office_365
		,C.identity_and_access_management as IAM
		,D.csam
from
(
select distinct lower(domains) as Domain from b2b.acrobat_perpetual_tableau
union all
select distinct lower(email_domain_full) as Domain from b2b.csam_smb_cci_stock_overage_info
union all
select distinct lower(email_domain) as Domain from b2b.csam_smb_cci_email_info
union all
select distinct lower(email_domain) as Domain from b2b.csam_smb_competitor_info_all
union all 
select distinct lower(email_domain) as Domain from b2b.csam_smb_active_trialist_info_filtered) A
left outer join b2b.gtm_firmographics B
on upper(A.domain) = upper(B.domain)
left outer join b2b.csam_smb_technographics_data C
on upper(A.domain) = upper(C.email_domain)
left outer join (select distinct 
						email_domain_full,csam
				from b2b.bob_fy2020_q1_domain) D
on upper(A.domain) = upper(D.email_domain_full) """)
             spark.sql(""" insert overwrite table b2b.csam_smb_basic_domain_info_stage1
SELECT 	B.email_domain_full as contract_domain,
		lvt_profile.email_domain,
		lvt_profile.pers_email as email,
		dim_seat.contract_id,
		dim_seat.member_guid,
		dim_seat.contract_type,
		dim_seat.product_name,
		dim_seat.seat_status
FROM
(    SELECT CASE WHEN seat.member_guid is null or trim(seat.member_guid) = ''  THEN NULL ELSE seat.member_guid END member_guid ,
			seat.contract_id,
			seat.contract_type,
			seat.product_name,
			seat.seat_status
   FROM ocf_analytics.dim_seat seat
   WHERE seat.contract_type IN ('DIRECT_INDIVIDUAL','DIRECT_ORGANIZATION') and seat.seat_status in ("ACTIVE SEAT","CANCELLED SEAT")) dim_seat
   INNER JOIN b2b.all_domian_contracts_individual B
   on dim_seat.contract_id = B.contract_id
   LEFT OUTER JOIN
       (    SELECT UPPER(user_guid) user_guid,
           LOWER(regexp_replace (pers_email,'.*@','')) email_domain,
           pers_email
           FROM ocf_analytics.dim_user_lvt_profile	 where user_guid is not null and trim(user_guid) !=''
        ) lvt_profile
   ON (lvt_profile.user_guid = dim_seat.member_guid) """)
             spark.sql(""" insert overwrite table b2b.csam_smb_basic_domain_info_stage2
select 	A.email_domain,
		A.contract_type,
		A.product_name,
		A.seat_status,
		count(distinct A.member_guid) as user_count
from b2b.csam_smb_basic_domain_info_stage1 A
inner join b2b.csam_smb_cci_all_domain_info B
on upper(A.email_domain) = upper(B.domain)
group by A.email_domain,
		A.contract_type,
		A.product_name,
		A.seat_status """)
             spark.sql(""" insert overwrite table b2b.csam_smb_cct_basic_info_stage3
select 	A.email_domain,
		A.email,
        A.product_name,
		count(distinct A.contract_id) as contract_count
from b2b.csam_smb_basic_domain_info_stage1 A
where A.seat_status = 'ACTIVE SEAT'
and A.contract_type = 'DIRECT_ORGANIZATION'
group by A.email_domain,
        A.email,
        A.product_name """)
             spark.sql(""" drop table if exists b2b.csam_smb_contract_renewal_date1 """)
             spark.sql(""" create table b2b.csam_smb_contract_renewal_date1 as
select 	distinct
		A.email_domain_anniversary,
		(case 
			when A.anniversary_flag = 1 then B.calendar_yr_and_qtr_desc
			when A.next_anniversary_flag = 1 then C.calendar_yr_and_qtr_desc
			else null			
		end) quarter,
		'null' as contract_id,
		A.external_contract_id,
		(case 
			when A.anniversary_flag = 1 then anniversary_date 
			when A.next_anniversary_flag = 1 then next_anniversary_date
			else null
		end) as next_anniversary_date
from b2b.smb_cce_renewal_quarter_stage1 A
left outer join Ids_coredata.dim_date B
on to_date(A.anniversary_date) = to_date(B.date_date)
left outer join Ids_coredata.dim_date C
on to_date(A.next_anniversary_date) = to_date(C.date_date)
where anniversary_flag > 0 or next_anniversary_flag > 0 """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.job_tracking partition (job = 'SMB_Dashboard_Job')
select 'SMB_Dashboard_Job' category, current_date() last_run_date, 'ENDED' status """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------



# COMMAND ----------

