# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.tbl_CancelledUnDeployed """)
             spark.sql(""" create table b2b.tbl_CancelledUnDeployed as 
select  distinct
		a.contract_id,
		enrollee_id as guid, 
		B.pers_email as email,
		case when B.pers_email IS NULL then 'NA' else split(B.pers_email, "@")[1] end as email_domain_full,
		a.contract_created_date,
		a.contract_type,
		c.contract_type as seat_contract_type,
		billing_payment_category,
		C.seat_id
		,C.seat_createddate
		,C.seat_status
		,C.seat_delegation_status
		,C.seat_last_modifieddate
		,C.member_guid
		,C.regular_vs_promotion,
		C.product_name
		,case when mdpd.pers_email IS NULL then NULL else split(mdpd.pers_email, "@")[1]  end as member_domain,
		mdpd.pers_email as member_email
from ocf_analytics.dim_contract_jem A
left join (select * from ocf_analytics.dim_user_lvt_profile x
          where split(x.pers_email, '[\@]')[1] <> 'adobe.com' and LENGTH(x.pers_email)<>0) B
on A.enrollee_id = B.user_guid
LEFT join ocf_analytics.dim_seat C 
on A.contract_id = C.contract_id
left join (select * from ocf_analytics.dim_user_lvt_profile x
          where split(x.pers_email, '[\@]')[1] <> 'adobe.com' and LENGTH(x.pers_email)<>0) mdpd
on C.member_guid=mdpd.user_guid
inner join b2b.csam_smb_cta_table_base base
on split(B.pers_email, "@")[1] =  base.email_domain """)
             spark.sql(""" drop table if exists b2b.tbl_CancelledUnDeployed_RawData """)
             spark.sql(""" create table b2b.tbl_CancelledUnDeployed_RawData as
select *,case when (seat_status in ('CANCELLED SEAT','CANCELLING SEAT')
and seat_last_modifieddate > date_sub(current_date(),30)) then 'Cancelled'
else 'UnDeployed' end As status
from b2b.tbl_CancelledUnDeployed
where 
(seat_status in ('CANCELLED SEAT','CANCELLING SEAT')
and seat_last_modifieddate > date_sub(current_date(),30))
or (upper(seat_status) in ('ACTIVE SEAT','DECLINED SEAT') and 
upper(seat_delegation_status) in ('INVITED','UNASSIGNED')) """)
             spark.sql(""" drop table if exists b2b.tbl_cancelled_undeployed_count """)
             spark.sql(""" create table b2b.tbl_cancelled_undeployed_count as 
select email_domain_full,contract_id,contract_type,count(distinct case when upper(seat_status) in ('CANCELLED SEAT'
,'CANCELLING SEAT')
and seat_last_modifieddate > date_sub(current_date(),30) then seat_id end) cancelled_seats,
count(distinct case when upper(seat_status) in ('ACTIVE SEAT','DECLINED SEAT') and 
upper(seat_delegation_status) in ('INVITED','UNASSIGNED') then 
seat_id end) undeployed_seats
from b2b.tbl_CancelledUnDeployed
group by email_domain_full,contract_id,contract_type """)
             spark.sql(""" drop table if exists b2b.csam_smb_basic_domain_info_stage2_CanUnDepAdded """)
             spark.sql(""" create table b2b.csam_smb_basic_domain_info_stage2_CanUnDepAdded as
select email_domain,contract_type,product_name,seat_status,user_count
from b2b.csam_smb_basic_domain_info_stage2
union all
select email_domain_full email_domain,contract_type,'' product_name,'Cancelled' seat_status,
count(distinct case when upper(seat_status) in ('CANCELLED SEAT','CANCELLING SEAT')
and seat_last_modifieddate > date_sub(current_date(),30) then seat_id end) user_count
from b2b.tbl_CancelledUnDeployed
group by email_domain_full,contract_type,''
union all 
select email_domain_full email_domain,contract_type,'' product_name,'UnDeployed' seat_status,
count(distinct case when upper(seat_status) in ('ACTIVE SEAT','DECLINED SEAT') and 
upper(seat_delegation_status) in ('INVITED','UNASSIGNED') then 
seat_id end) user_count
from b2b.tbl_CancelledUnDeployed
group by email_domain_full,contract_type,'' """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

