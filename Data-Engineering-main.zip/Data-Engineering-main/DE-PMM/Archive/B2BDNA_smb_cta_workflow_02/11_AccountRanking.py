# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.smb_cta_ranking1 """)
             spark.sql(""" create table b2b.smb_cta_ranking1 as
select distinct email_domain,
    case 
        when cta_acrobat = 'High' then 3
        when cta_acrobat = 'Medium' then 2
        when cta_acrobat = 'Low' then 1
    else 0 end as acrobat_score,
    case 
        when cta_cce = 'High' then 3
        when cta_cce = 'Medium' then 2
        when cta_cce = 'Low' then 1
    else 0 end as cce_score,
    case 
        when cta_cct = 'High' then 3
        when cta_cct = 'Medium' then 2
        when cta_cct = 'Low' then 1
    else 0 end as cct_score,
    case 
        when cta_stock = 'High' then 3
        when cta_stock = 'Medium' then 2
        when cta_stock = 'Low' then 1
    else 0 end as stock_score,
    case 
        when cta_sign = 'High' then 3
        when cta_sign = 'Medium' then 2
        when cta_sign = 'Low' then 1
    else 0 end as sign_score
from b2b.csam_smb_all_cta_table_stage4_intermediate """)
             spark.sql(""" drop table if exists b2b.smb_cta_ranking2 """)
             spark.sql(""" create table b2b.smb_cta_ranking2 as
select email_domain,
    max(acrobat_score) acrobat_score,
    max(cce_score) cce_score,
    max(cct_score) cct_score,
    max(stock_score) stock_score,
    max(sign_score) sign_score,
    (max(acrobat_score) + max(cce_score) + max(cct_score) + max(stock_score) + max(sign_score)) as total_score
from b2b.smb_cta_ranking1 A
group by email_domain """)
             spark.sql(""" drop table if exists b2b.smb_cta_ranking3 """)
             spark.sql(""" create table b2b.smb_cta_ranking3 as
select A.email_domain,
    C.name as SFDC_Name,
	E.geo,
	E.final_team as team,
	E.csam_email,
    D.csam_updated as csam,
	concat(F.billing_payment_category,"-",F.billing_frequency) as billing_payment,
    B.cta_acrobat,
    B.cta_cce,
    B.cta_cct,
    B.cta_stock,
    B.cta_sign,
    A.total_score + if(stock_score=0, 0, 3) + if(acrobat_score=0, 0, 6) + if(cce_score=0, 0, 9) + if(cct_score=0, 0, 12) + 
        if(sign_score=0, 0, 15) as combined_final_rank
from b2b.smb_cta_ranking2 A
left outer join b2b.csam_smb_all_cta_table_stage4_intermediate B
on A.email_domain = B.email_domain
left outer join (
    select distinct account_name__c,contract_id__c,name
	from replicn_sfdc.sfdc_post_sales__c) C
on B.account_id = C.account_name__c 
and B.contract_id__c = C.contract_id__c
left outer join b2b.bob_fy2020_q1_domain_stage3 D
on upper(A.email_domain) = upper(D.email_domain_full) 
and B.account_id = D.account_id
left outer join (SELECT distinct geo, account_id, email_domain_full, csam, csam_email, final_team
	from b2b.bob_fy2020_q1_domain) E
on upper(A.email_domain) = upper(E.email_domain_full) 
and B.account_id = E.account_id 
and upper(D.csam_updated) = upper(E.csam)
left outer join (select * from ocf_analytics.dim_contract_jem where contract_type = 'DIRECT_ORGANIZATION') F 
on B.contract_id__c = F.contract_id """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

