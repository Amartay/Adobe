# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.csam_smb_competitor_info_all_archive """)
             spark.sql(""" drop table if exists b2b.csam_smb_cci_stock_overage_info_archive """)
             spark.sql(""" drop table if exists b2b.csam_smb_active_trialist_info_filtered_archive """)
             spark.sql(""" drop table if exists b2b.csam_smb_cci_email_info_archive """)
             spark.sql(""" drop table if exists b2b.csam_smb_cci_all_domain_info_archive """)
             spark.sql(""" drop table if exists b2b.csam_smb_basic_domain_info_stage1_archive """)
             spark.sql(""" drop table if exists b2b.csam_smb_basic_domain_info_stage2_archive """)
             spark.sql(""" drop table if exists b2b.csam_smb_cct_basic_info_stage3_archive """)
             spark.sql(""" drop table if exists b2b.csam_smb_contract_renewal_date1_archive """)
             spark.sql(""" drop table if exists b2b.all_domian_contracts_cci_users_tou_acceptance_archive """)
             spark.sql(""" drop table if exists b2b.all_domian_contracts_cci_domains_tou_acceptance_archive """)
             spark.sql(""" create table b2b.csam_smb_competitor_info_all_archive as 
select * from b2b.csam_smb_competitor_info_all """)
             spark.sql(""" create table b2b.csam_smb_cci_stock_overage_info_archive as 
select * from b2b.csam_smb_cci_stock_overage_info """)
             spark.sql(""" create table b2b.csam_smb_active_trialist_info_filtered_archive as 
select * from b2b.csam_smb_active_trialist_info_filtered """)
             spark.sql(""" create table b2b.csam_smb_cci_email_info_archive as 
select * from b2b.csam_smb_cci_email_info """)
             spark.sql(""" create table b2b.csam_smb_cci_all_domain_info_archive as 
select * from b2b.csam_smb_cci_all_domain_info """)
             spark.sql(""" create table b2b.csam_smb_basic_domain_info_stage1_archive as 
select * from b2b.csam_smb_basic_domain_info_stage1 """)
             spark.sql(""" create table b2b.csam_smb_basic_domain_info_stage2_archive as 
select * from b2b.csam_smb_basic_domain_info_stage2 """)
             spark.sql(""" create table b2b.csam_smb_cct_basic_info_stage3_archive as
select * from b2b.csam_smb_cct_basic_info_stage3 """)
             spark.sql(""" create table b2b.csam_smb_contract_renewal_date1_archive as 
select * from b2b.csam_smb_contract_renewal_date1 """)
             spark.sql(""" create table b2b.all_domian_contracts_cci_users_tou_acceptance_archive as
select * from b2b.all_domian_contracts_cci_users_tou_acceptance """)
             spark.sql(""" create table b2b.all_domian_contracts_cci_domains_tou_acceptance_archive as
select * from b2b.all_domian_contracts_cci_domains_tou_acceptance """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

