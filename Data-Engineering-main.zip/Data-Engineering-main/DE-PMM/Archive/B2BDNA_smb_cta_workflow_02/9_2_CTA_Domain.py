# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.csam_smb_all_cta_table_stage4_summary """)
             spark.sql(""" create table b2b.csam_smb_all_cta_table_stage4_summary as
select  A.cta_acrobat,
        A.cta_cce,
        A.cta_cct,
        A.cta_stock,
		A.cta_sign,
        (case when B.account_id is not null then "BoB" else "Outside_BoB" end) BoB_flag,
		B.csam,
        to_date(A.partition_date) as partition_date,
        count(distinct A.account_id) as count_account_id,
        count(distinct A.email_domain) as count_domain
from b2b.csam_smb_all_cta_table_stage4_intermediate A
left outer join (select distinct account_id, csam from b2b.bob_fy2020_q1_v5_dedup) B
on A.account_id = B.account_id
group by A.cta_acrobat,
        A.cta_cce,
        A.cta_cct,
        A.cta_stock,
		A.cta_sign,
        (case when B.account_id is not null then "BoB" else "Outside_BoB" end),
		B.csam,
        to_date(A.partition_date) """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.job_tracking partition (job = 'SMB_CTA_Creation_Job')
select 'SMB_CTA_Creation' category, current_date() last_run_date, 'ENDED' status """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()

# COMMAND ----------

