# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET mapred.job.queue.name= root.scheduled.P2 """)
             spark.sql(""" set hive.optimize.skewjoin=false """)
             spark.sql(""" set hive.auto.convert.join=false """)
             spark.sql(""" drop table if exists b2b.csam_smb_all_cta_table_stage1 """)
             spark.sql(""" create table b2b.csam_smb_all_cta_table_stage1 as
select distinct
       A.email_domain,
       A.account_name,
       A.market_area,
       (case when A.count_contract > 1 then "Multiple Contracts" else "Single Contract" end) as Contract_Flag,
       B.CTA_Acrobat,
       B.domain_acro_added_seat_count,
       B.industry,
       B.employee_range_for_msft_excel as Acro_employee_range_for_msft_excel,
       B.Perpetual_flag,
	   B.acro_trial,
	   B.acro_count/B.total_employees*100 as acro_penetration,
       C.CTA_CCE,
       C.employee_range_for_msft_excel as CCE_employee_range_for_msft_excel,
       C.visit_count_in_last_3_months,
       C.avg_percentile_score,
       C.CEI_Flag,
	   C.g_suite,
	   C.microsoft_azure,
	   C.office_365,
	   C.IAM,
	   C.cc_complete_count as CCT_cc_complete_count,
	   C.Quarter_flag,
       D.CCT_CTA,
       D.count_cci_complete,
       D.count_single_app,
       D.free_active_user,
	   D.domestic_employees_range_for_msft_excel as CCT_employee_range_for_msft_excel,
       E.CTA_Stock,
       E.StockCompetitorFlag,
       E.stock_search,
       E.stock_usage,
       E.stock_plans,
       E.stock_others_count,
       E.stock_cct_count,
       E.cc_complete_count as STOCK_cc_complete_count,
       E.OverageFlag,
       E.stock_pure_play,
       E.stock_cci_presence,
       E.stock_competitor,
	   F.cta_sign,
	   F.employee_range_for_msft_excel as Sign_employee_range_for_msft_excel,
	   F.total_sent_for_signature,
	   F.power_users,
	   (F.power_users + F.moderate_users) as txn50_users,
       F.count_sign_cci,
	   (F.power_users + F.moderate_users + F.low_users) as sign_txn_users
from b2b.csam_smb_cta_table_base A
left outer join (select * from b2b.smb_acrobat_cta_data3 where CTA_Acrobat in ('High','Medium','Low')) B 
on upper(A.email_domain) = upper(B.email_domain) and upper(A.account_name) = upper(B.account_name)
left outer join (select * from b2b.smb_cce_cta_data2 where CTA_CCE in ('High','Medium','Low')) C 
on upper(A.email_domain) = upper(C.email_domain) and upper(A.account_name) = upper(C.account_name)
left outer join (select * from b2b.smb_cct_cta_data2 where CCT_CTA in ('High','Medium','Low'))  D 
on upper(A.email_domain) = upper(D.email_domain) and upper(A.account_name) = upper(D.account_name)
left outer join  (select * from b2b.smb_stocks_cta_data3 where CTA_Stock in ('High','Medium','Low')) E
on upper(A.email_domain) = upper(E.email_domain) and upper(A.account_name) = upper(E.account_name)
left outer join  (select * from b2b.sign_cta_data4  
where CTA_Sign in ('High','Medium','Low')) F 
on upper(A.email_domain) = upper(F.email_domain) and upper(A.account_name) = upper(F.account_name) """)
             spark.sql(""" drop table if exists b2b.csam_smb_all_cta_table_stage2 """)
             spark.sql(""" create table b2b.csam_smb_all_cta_table_stage2 as
select temp.*,
        concat("CTA COMMENT - ",
                (case when Acrobat_Comment is not null then Acrobat_Comment else "" end), 
                (case when Stock_Comment is not null then concat(" ** ",Stock_Comment) else "" end),
                (case when CCE_Comment is not null then concat(" ** ",CCE_Comment, " ** ") else "" end),
                (case when CCT_Comment is not null then concat(" ** ",CCT_Comment) else "" end),
				(case when Sign_Comment is not null then concat(" ** ",Sign_Comment) else '' end)) as FinalComment
from
(select email_domain,
        account_name,
        market_area,
        Contract_Flag,
        CTA_Acrobat,
        domain_acro_added_seat_count,
        industry,
        Acro_employee_range_for_msft_excel,
        Perpetual_flag,
		acro_penetration,
		acro_trial,
        (case
            when CTA_Acrobat = "High" or CTA_Acrobat = "Medium" or CTA_Acrobat = "Low" then
            CONCAT("Acrobat_CTA: ",CTA_Acrobat,"{ ",
                            (case
                                when CTA_Acrobat = "High" then CONCAT("Employee Size: ",Acro_employee_range_for_msft_excel, " + ",
									"Perpetual Yes/No: ",Perpetual_flag, " + ","Acrobat Penetration%: ",acro_penetration," + ",
									"Acrobat Trial: ",acro_trial)
                                when CTA_Acrobat = "Medium" then CONCAT("Employee Size: ",Acro_employee_range_for_msft_excel, " + ",
									"Acrobat Penetration%: ",acro_penetration)
                                when CTA_Acrobat = "Low" then CONCAT("Employee Size: ",Acro_employee_range_for_msft_excel, " + ",
									"Industry: ",industry)
                                else null
                            end), " }")
        else null end ) as Acrobat_Comment,
        CTA_CCE,
        CCE_employee_range_for_msft_excel,
		CCT_cc_complete_count,
        quarter_flag,
        visit_count_in_last_3_months,
        avg_percentile_score,
        CEI_Flag,
		g_suite,
	    microsoft_azure,
	    office_365,
	    IAM,
        (case
            when CTA_CCE = "High" or CTA_CCE = "Medium" or CTA_CCE = "Low" then
            CONCAT("CCE_CTA: ",CTA_CCE,"{ ",
                            (case
                                when CTA_CCE = "High" then CONCAT("Employee Size: ",CCE_employee_range_for_msft_excel,
									" + CC Complete count: ",CCT_cc_complete_count," + Renewal Cycle Next/Next+1 Quarter: Yes",
									(case when lower(g_suite) in ('yes','true') then " + Google_Suite: Yes" else "" end),
									(case when lower(microsoft_azure) in ('yes','true') then " + Microsoft_Azure: Yes" else "" end),
									(case when lower(office_365) in ('yes','true') then " + Office_365: Yes" else "" end),
									(case when length(IAM) > 2 then concat(" + IAM: ",IAM) else "" end))
                                when CTA_CCE = "Medium" then CONCAT("Employee Size: ",CCE_employee_range_for_msft_excel,
									" + CC Complete count: ",CCT_cc_complete_count," + Renewal Cycle Next/Next+1 Quarter: Yes",
									(case when lower(g_suite) in ('yes','true') then " + Google_Suite: Yes" else "" end),
									(case when lower(microsoft_azure) in ('yes','true') then " + Microsoft_Azure: Yes" else "" end),
									(case when lower(office_365) in ('yes','true') then " + Office_365: Yes" else "" end),
									(case when length(IAM) > 2 then concat(" + IAM: ",IAM) else "" end))
                                when CTA_CCE = "Low" then CONCAT("Employee Size: ",CCE_employee_range_for_msft_excel,
									" + Renewal Cycle Next/Next+1 Quarter: Yes")
                                else null
                            end), " }")
        else null end ) as CCE_Comment,
        CCT_CTA,
		CCT_employee_range_for_msft_excel,
        count_cci_complete,
        count_single_app,
        free_active_user,
        (case
            when CCT_CTA = "High" or CCT_CTA = "Medium" or CCT_CTA = "Low" then
            CONCAT("CTA_CCT: ",CCT_CTA,"{ ",
                            (case
                                when CCT_CTA = "High" then CONCAT("Employee Size: ",CCT_employee_range_for_msft_excel,
									" + Active CCI Complete: ", case when count_cci_complete is not null then count_cci_complete else 0 end, 
									" + Active CCI Trials: ",case when free_active_user is not null then free_active_user else 0 end)
                                when CCT_CTA = "Medium" then CONCAT("Employee Size: ",CCT_employee_range_for_msft_excel,
									" + Active CCI Complete: ", case when count_cci_complete is not null then count_cci_complete else 0 end, 
									" + Active CCI Trials: ",case when free_active_user is not null then free_active_user else 0 end)
                                when CCT_CTA = "Low" then CONCAT("Active CCI Complete: ", case when count_cci_complete is not null then count_cci_complete else 0 end)
                                else null
                            end), " }")
        else null end ) as CCT_Comment,
        CTA_Stock,
        OverageFlag,
        stock_pure_play,
        stock_cci_presence,
        stock_competitor,
		STOCK_cc_complete_count,
        (case
            when CTA_Stock = "High" or CTA_Stock = "Medium" or CTA_Stock = "Low" then
            CONCAT("Stock_CTA: ",CTA_Stock,"{ ",
                            (case
                                when CTA_Stock = "High" then CONCAT("Stock Overage: Yes"," + Active CCT count: ",STOCK_cc_complete_count)
                                when CTA_Stock = "Medium" then CONCAT("Active CCT count: ",STOCK_cc_complete_count, 
									(case when stock_pure_play =1 then " + Stock Pure Play = Yes" else "" end),
									(case when stock_cci_presence =1 then " + Stock CCI Presence = Yes" else "" end))
                                when CTA_Stock = "Low" then CONCAT("Active CCT count: ",STOCK_cc_complete_count, " + Competitor Presence: Yes" )
                                else null
                            end), " }")
        else null end ) as Stock_Comment,
		cta_sign,
	    Sign_employee_range_for_msft_excel,
	    power_users,
		txn50_users,
		total_sent_for_signature,
		count_sign_cci,
	    sign_txn_users,
		(case
            when CTA_Sign = 'High' or CTA_Sign = 'Medium' or CTA_Sign = 'Low' then
            CONCAT('Sign_CTA: ',CTA_Sign,'{ ',
                            (case
                                when CTA_Sign = 'High' then CONCAT('Employee Size: ',Sign_employee_range_for_msft_excel, 
									' + Power Users with 100+ transactions: ',cast(power_users as string), 
									' + Use of Sent for Signature: Yes')
                                when CTA_Sign = 'Medium' then CONCAT('Employee Size: ',Sign_employee_range_for_msft_excel, 
									' + Users with 50+ transactions: ',cast(txn50_users as string), 
									' + Use of Sent for Signature: Yes')
                                when CTA_Sign = 'Low' then CONCAT('Employee Size: ',Sign_employee_range_for_msft_excel, 
									' + Industry: ',industry, ' + Users with 20+ transactions: ',cast(sign_txn_users as string))
                                else null
                            end), ' }')
        else null end ) as Sign_Comment
from b2b.csam_smb_all_cta_table_stage1) temp
where CTA_Acrobat is not null or CTA_Stock is not null or CCT_CTA is not null or CTA_CCE is not null or CTA_Sign is not null """)
             spark.sql(""" insert overwrite table b2b.csam_smb_cta_table_base_contract 
select  A.email_domain,
		A.account_name,
		A.market_area,
		A.count_contract,
		B.contract_id__c,
		C.total_active_seats_today,
		row_number() over (partition by A.account_name order by total_active_seats_today desc) as RowRank
from b2b.csam_smb_cta_table_base A
left outer join replicn_sfdc.sfdc_post_sales__c B
on A.account_name = B.account_name__c
left outer join b2b.contract_level_cta_base1 C
on B.contract_id__c = C.contract_id
left outer join b2b.bob_fy2020_q1_domain_stage2 D
on upper(A.email_domain) = upper(D.email_domain_full) and A.account_name = D.account_id """)
             spark.sql(""" drop table if exists b2b.csam_smb_all_cta_table_stage3 """)
             spark.sql(""" create table b2b.csam_smb_all_cta_table_stage3 as
select A.*,B.contract_id__c,C.billingcountry as country_code
from b2b.csam_smb_all_cta_table_stage2 A
inner join (select * from b2b.csam_smb_cta_table_base_contract where RowRank = 1)B
on A.email_domain = B.email_domain and A.account_name = B.account_name
left outer join replicn_sfdc.sfdc_account C
on A.account_name = C.id
where A.email_domain is not null and A.account_name is not null """)
             spark.sql(""" drop table if exists b2b.csam_smb_all_cta_table_stage4_intermediate """)
             spark.sql(""" create table b2b.csam_smb_all_cta_table_stage4_intermediate as
select  distinct
		A.email_domain,
      A.contract_id__c,
      A.account_name as account_id,
      A.market_area,
      A.country_code,
      A.contract_flag,
      A.cta_acrobat,
      A.cta_cce,
      A.cct_cta as cta_cct,
      A.cta_stock,
      A.cta_sign,
	  B.total_active_seats_today as seat_count,
	  C.billing_payment_category,
	  D.market_segment,
	  A.Acrobat_Comment,
	  A.CCE_Comment,
	  A.CCT_Comment,
	  A.Stock_Comment,
	  A.Sign_comment,
	  A.finalcomment,
      current_date() as partition_date
from b2b.csam_smb_all_cta_table_stage3 A
left outer join b2b.contract_level_agg_all_v1 B
on upper(A.contract_id__c) = upper(B.contract_id)
left outer join (select * from ocf_analytics.dim_contract_jem where contract_type = 'DIRECT_ORGANIZATION') C
on A.contract_id__c = C.contract_id
left outer join (select * from b2b.smb_analytics_market_segment_map where RowRank = 1) D
on A.email_domain = D.email_domain_full """)
             spark.sql(""" drop table if exists b2b.csam_smb_all_cta_table_stage4_intermediate_tableau """)
             spark.sql(""" create table b2b.csam_smb_all_cta_table_stage4_intermediate_tableau as
select  distinct
		email_domain,
      contract_id__c,
      account_name as account_id,
      market_area,
      contract_flag,
      cta_acrobat,
      cta_cce,
      cct_cta as cta_cct,
      cta_stock,
      cta_sign,
	  Acrobat_Comment,
	  CCE_Comment,
	  CCT_Comment,
	  Stock_Comment,
	  Sign_comment,
	  finalcomment,
       'No Action' as CTA_Action,
       'No Action' as CTA_Status,
      current_date() as partition_date
from b2b.csam_smb_all_cta_table_stage3 A """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()