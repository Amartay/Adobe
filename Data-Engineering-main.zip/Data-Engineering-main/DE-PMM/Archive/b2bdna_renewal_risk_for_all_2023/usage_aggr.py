# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.pp_renewals_aggr_all """)
             spark.sql(""" create table b2b.pp_renewals_aggr_all as 
SELECT contract_id,
         TO_DATE(renewal_date) renewal_date,
         product_name,
         count(distinct if(active_28_days = 'Y' and   partition_date between date_sub(TO_DATE(reference_Date),28) and TO_DATE(reference_Date),partition_date,NULL)) as 28_days_contract_usage,
         count(distinct if(active_90_days = 'Y' and   partition_date between date_sub(date_sub(TO_DATE(reference_Date),90),28) and date_sub(TO_DATE(reference_Date),90),partition_date,NULL)) as 90_days_contract_usage,
         count(distinct if(active_180_days = 'Y' and   partition_date between date_sub(date_sub(TO_DATE(reference_Date),180),28) and date_sub(TO_DATE(reference_Date),180),partition_date,NULL)) as 180_days_contract_usage,
         count(distinct case when active_28_days = 'Y' and 28_member_active > 2 then delegated_seat else null end ) as 28_2plus_usage_seats,
         count(distinct case when active_90_days = 'Y' and 90_member_active > 2 then delegated_seat else null end ) as 90_2plus_usage_seats,
         count(distinct case when active_180_days = 'Y' and 180_member_active > 2 then delegated_seat else null  end ) as 180_2plus_usage_seats
      from b2b.pp_renewals_usage_all renewals
WHERE 1=1
  group by contract_id,
  TO_DATE(renewal_date),
  product_name """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()