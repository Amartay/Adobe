# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.pp_active_delegated_aggr """)
             spark.sql(""" create table b2b.pp_active_delegated_aggr AS 
with renewals AS 
(SELECT   contract_id,
          renewal_date,
          product_name,
         min(if(UPPER(route_to_market) = 'RESELLER',if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date)),
            if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date))))) as reference_date
       from b2b_stg.pp_smb_contract_renewal
       group by contract_id,
                renewal_date,
                product_name
)
SELECT renewals.contract_id,
       renewals.renewal_date,
       renewals.product_name,
count(distinct if(active_28_days = 'Y',active_seat,NULL)) as active_seats_28_days,
count(distinct if(active_90_days = 'Y',active_seat,NULL)) as active_seats_90_days,
count(distinct if(active_180_days = 'Y',active_seat,NULL)) as active_seats_180_days,
count(distinct if(active_28_days = 'Y',delegated_seat,NULL)) as delegated_seats_28_days,
count(distinct if(active_90_days = 'Y',delegated_seat,NULL)) as delegated_seats_90_days,
count(distinct if(active_180_days = 'Y',delegated_seat,NULL)) as delegated_seats_180_days,
count(distinct if(active_28_days = 'Y',member_guid,NULL)) as delegated_members_28_days,
count(distinct if(active_90_days = 'Y',member_guid,NULL)) as delegated_members_90_days,
count(distinct if(active_180_days = 'Y',member_guid,NULL)) as delegated_members_180_days
FROM renewals renewals 
INNER join b2b.pp_at_renewal_Deployed_members_all deployment on renewals.contract_id = deployment.contract_id and renewals.renewal_date = deployment.renewal_date and UPPER(renewals.product_name) = UPPER(deployment.product_name)
GROUP BY renewals.contract_id,
       renewals.renewal_date,
       renewals.product_name """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()