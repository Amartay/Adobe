# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET hive.groupby.orderby.position.alias = true """)
             spark.sql(""" SET hive.auto.convert.join = true """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" drop table if exists b2b.pp_at_renewal_Deployed_members_all """)
             spark.sql(""" create table b2b.pp_at_renewal_Deployed_members_all AS 
with renewals AS
(SELECT   contract_id,
          renewal_date,
          product_name,
          min(if(UPPER(route_to_market) = 'RESELLER',if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date)),
          if(TO_DATE(first_pivot_cancel_date) is not NULL, TO_DATE(first_pivot_cancel_date),if(TO_DATE(renewal_date) > TO_DATE(current_date()),TO_DATE(current_date()),TO_DATE(renewal_date))))) as reference_date
 FROM b2b_stg.pp_smb_contract_renewal renewal 
 WHERE 1= 1 
 group by contract_id, 
          renewal_date,
          product_name
 )
SELECT distinct renewal.contract_id,
         renewal.renewal_date, 
         renewal.product_name,
         scd.seat_id as active_seat,
         if(UPPER(scd.seat_delegation_status) = 'ASSIGNED', scd.seat_id,NULL) as delegated_seat,
         if(UPPER(scd.seat_delegation_status) = 'ASSIGNED', if(type2e.profile_id is NULL, scd.member_guid, type2e.auth_id),NULL) as member_guid,
         if(TO_DATE(startdate_dttm) < date_sub(date_sub(TO_DATE(reference_date),180),28) and TO_DATE(enddate_dttm) > date_sub(TO_DATE(reference_date),180),'Y','N') as active_180_days,
         if(TO_DATE(startdate_dttm) < date_sub(date_sub(TO_DATE(reference_date),90),28) and TO_DATE(enddate_dttm) > date_sub(TO_DATE(reference_date),90),'Y','N') as active_90_days,
         if(TO_DATE(enddate_dttm) > TO_DATE(reference_date),'Y','N') as active_28_days
  from (select seat_id, 
               NULL AS member_guid, 
               startdate_dttm, 
               enddate_dttm,
               'ACTIVE' as seat_status,
               NULL as seat_delegation_status 
        from mdpd_stage.scd_seat_provisioning 
        where UPPER(seat_status) = 'ACTIVE' and UPPER(seat_delegation_status) != 'ASSIGNED'
        UNION ALL   
        select seat_id,
               auth_id as member_guid,
               startdate_dttm,
               enddate_dttm,
               'ACTIVE' as seat_status,
               'ASSIGNED' as seat_delegation_status 
        from b2b.type2e_adjusted_scd_seat_provisioning
        where auth_id is not NULL
        )scd 
  left outer join ocf_analytics.vw_type2e_profile_reference	type2e on UPPER(scd.member_guid) = UPPER(type2e.profile_id)
  INNER JOIN ocf_analytics.dim_seat seat on scd.seat_id = seat.seat_id  
  INNER JOIN renewals renewal on renewal.contract_id = seat.contract_id and renewal.product_name = seat.product_name
  where 1=1
  and TO_DATE(startdate_dttm) < date_sub(TO_DATE(reference_date),31) 
  and TO_DATE(enddate_dttm) > date_sub(TO_DATE(reference_date),210) """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()