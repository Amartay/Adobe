# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.ss_shuri_tm_contracts """)
             spark.sql(""" create table  b2b.ss_shuri_tm_contracts as 
Select 
	shuri.fiscal_yr_desc,
    shuri.fiscal_yr_and_qtr_desc,
    shuri.fiscal_yr_and_wk_desc,
	period2.fiscal_wk_in_yr,
	period2.fiscal_wk_in_qtr,
	period2.fiscal_wk_ending_date,
	period.fiscal_yr_desc as first_contract_start_yr,
	period.fiscal_yr_and_qtr_desc as first_contract_start_yr_and_qtr,
	period.fiscal_yr_and_wk_desc as first_contract_start_yr_and_wk,
	period.fiscal_wk_in_yr as first_contract_start_wk_in_yr,
	period.fiscal_wk_in_qtr as first_contract_start_wk_in_qtr,
	contracts.contract_created_date as first_contract_start_date,
	contracts.contract_type,
    COALESCE(shuri.contract_id,shuri.vip_contract) contract_id,
    shuri.geo,
    shuri.geo_description,
    shuri.market_area,
    shuri.market_area_description,
    shuri.market_segment,
    shuri.route_to_market,
    shuri.phone_vs_web,
    shuri.subs_offer,
    shuri.cc_segment,
    shuri.cc_segment_offer,  
    shuri.promotion,
    shuri.promo_type,
	shuri.offer_type_description,
    shuri.product_name,  	
    shuri.product_name_description, 	  
    shuri.smb_industry,
    shuri.employee_range,
    shuri.revenue_range,
    shuri.csam_bob_flag,
    shuri.init_vs_addl,
    shuri.addon_by,
    shuri.final_team,
    shuri.final_agent,
	seat_count.active_seat_count as current_active_seat_count,
	CASE
		WHEN seat_count.active_seat_count = 1                 THEN '1'
		WHEN seat_count.active_seat_count BETWEEN   2 AND   4 THEN '2 to 4'
		WHEN seat_count.active_seat_count BETWEEN   5 AND   9 THEN '5 to 9'
		WHEN seat_count.active_seat_count BETWEEN  10 AND  49 THEN '10 to 49'
		WHEN seat_count.active_seat_count BETWEEN  50 AND  99 THEN '50 to 99'
		WHEN seat_count.active_seat_count BETWEEN 100 AND 199 THEN '100 to 199'
		WHEN seat_count.active_seat_count BETWEEN 200 AND 299 THEN '200 to 299'
		WHEN seat_count.active_seat_count BETWEEN 300 AND 999 THEN '300 to 999'
		WHEN seat_count.active_seat_count >=1000              THEN '1000+' ELSE '0'
		END AS current_seat_band,
    sum(shuri.fqtr_begin_active) fqtr_begin_active,
    sum(shuri.fqtr_end_active) fqtr_end_active,
    sum(shuri.addl_purchase_diff) addl_purchase_diff,
    sum(shuri.addl_purchase_same) addl_purchase_same,
    sum(shuri.addl_purchase) addl_purchase,
    sum(shuri.compl_cancel_cc_failure) compl_cancel_cc_failure,
    sum(shuri.compl_cancel_explicit) compl_cancel_explicit,
    sum(shuri.partial_cancel_cc_failure) partial_cancel_cc_failure,
    sum(shuri.partial_cancel_explicit) partial_cancel_explicit,
    sum(shuri.gross_cancellations) gross_cancellations,
    sum(shuri.gross_new_subs) gross_new_subs,
    sum(shuri.init_purchase) init_purchase,
    sum(shuri.migrated_from) migrated_from,
    sum(shuri.migrated_subs) migrated_subs,
    sum(shuri.migrated_to) migrated_to,
    sum(shuri.net_cancelled_subs) net_cancelled_subs,
    sum(shuri.net_purchases) net_purchases,
    sum(shuri.reactivated_subs) reactivated_subs,
    sum(shuri.renewal_from) renewal_from,
    sum(shuri.renewal_to) renewal_to,
    sum(shuri.resubscription) resubscription,
    sum(shuri.returns_explicit) returns_explicit,
    sum(shuri.returns_never_paid) returns_never_paid,
    sum(shuri.returns) returns,
    sum(shuri.net_new_subs) net_new_subs,
    sum(shuri.fqtr_begin_arr_cfx) fqtr_begin_arr_cfx,
    sum(shuri.fqtr_end_arr_cfx) fqtr_end_arr_cfx,
    sum(shuri.addl_purchase_arr_cfx) addl_purchase_arr_cfx,
    sum(shuri.cc_failure_cancel_arr_cfx) cc_failure_cancel_arr_cfx,
    sum(shuri.explicit_cancel_arr_cfx) explicit_cancel_arr_cfx,
    sum(shuri.partial_cancel_cc_failure_arr_cfx) partial_cancel_cc_failure_arr_cfx,
    sum(shuri.partial_cancel_explicit_arr_cfx) partial_cancel_explicit_arr_cfx,
    sum(shuri.gross_cancel_arr_cfx) gross_cancel_arr_cfx,
    sum(shuri.gross_new_arr_cfx) gross_new_arr_cfx,
    sum(shuri.init_purchase_arr_cfx) init_purchase_arr_cfx,
    sum(shuri.migrated_from_arr_cfx) migrated_from_arr_cfx,
    sum(shuri.migration_arr_cfx) migration_arr_cfx,
    sum(shuri.migrated_to_arr_cfx) migrated_to_arr_cfx,
    sum(shuri.net_cancelled_arr_cfx) net_cancelled_arr_cfx,
    sum(shuri.net_purchases_arr_cfx) net_purchases_arr_cfx,
    sum(shuri.reactivated_arr_cfx) reactivated_arr_cfx,
    sum(shuri.renewal_from_arr_cfx) renewal_from_arr_cfx,
    sum(shuri.renewal_to_arr_cfx) renewal_to_arr_cfx,
    sum(shuri.resubscription_arr_cfx) resubscription_arr_cfx,
    sum(shuri.explicit_returns_arr_cfx) explicit_returns_arr_cfx,
    sum(shuri.cc_failure_returns_arr_cfx) cc_failure_returns_arr_cfx,
    sum(shuri.returns_arr_cfx) returns_arr_cfx,
    sum(shuri.net_new_arr_cfx) net_new_arr_cfx,
	max(etl_date) etl_date
from b2b.ww_shuri shuri
left outer join (
    Select
        contract_id,
		contract_type,
        to_date(min(contract_created_date)) contract_created_date
    from ocf_analytics.dim_contract
    where contract_id is not null 
		and contract_id != ''
		and contract_type != 'DIRECT_INDIVIDUAL'
	group by contract_id,
		contract_type) contracts
on COALESCE(shuri.contract_id,shuri.vip_contract) = contracts.contract_id
left outer join  (
    Select *
    from ids_coredata.dim_date ) period 
	on contracts.contract_created_date = period.date_date
left outer join  (
    Select DISTINCT
		fiscal_yr_and_wk_desc,
		fiscal_wk_in_yr,
		fiscal_wk_in_qtr,
		fiscal_wk_ending_date
    from ids_coredata.dim_date 
    where fiscal_yr_and_wk_desc >= '2020-01') period2 
	on shuri.fiscal_yr_and_wk_desc = period2.fiscal_yr_and_wk_desc
LEFT OUTER JOIN ( 
	SELECT 
		contract_id,
		COUNT(DISTINCT(CASE WHEN seat_status = 'ACTIVE SEAT' THEN seat_id ELSE NULL END)) active_seat_count
	FROM ocf_analytics.dim_seat where contract_type != 'DIRECT_INDIVIDUAL' 
	GROUP BY 
		contract_id	)seat_count 
	ON COALESCE(shuri.contract_id,shuri.vip_contract) = seat_count.contract_id
where shuri.stype = 'TM'	
group by 
	shuri.fiscal_yr_desc,
    shuri.fiscal_yr_and_qtr_desc,
    shuri.fiscal_yr_and_wk_desc,
	period2.fiscal_wk_in_yr,
	period2.fiscal_wk_in_qtr,
	period2.fiscal_wk_ending_date,
	period.fiscal_yr_desc,
	period.fiscal_yr_and_qtr_desc,
	period.fiscal_yr_and_wk_desc,
	period.fiscal_wk_in_yr,
	period.fiscal_wk_in_qtr,
	contracts.contract_created_date,
	contracts.contract_type,
    COALESCE(shuri.contract_id,shuri.vip_contract),
    shuri.geo,
    shuri.geo_description,
    shuri.market_area,
    shuri.market_area_description,
    shuri.market_segment,
    shuri.route_to_market,
    shuri.phone_vs_web,
    shuri.subs_offer,
    shuri.cc_segment,
    shuri.cc_segment_offer,  
    shuri.promotion,
    shuri.promo_type,
	shuri.offer_type_description,
    shuri.product_name,  	
    shuri.product_name_description,	 	
    shuri.smb_industry,
    shuri.employee_range,
    shuri.revenue_range,
    shuri.csam_bob_flag,
    shuri.init_vs_addl,
    shuri.addon_by,
    shuri.final_team,
    shuri.final_agent,
	seat_count.active_seat_count,
	CASE
		WHEN seat_count.active_seat_count = 1                 THEN '1'
		WHEN seat_count.active_seat_count BETWEEN   2 AND   4 THEN '2 to 4'
		WHEN seat_count.active_seat_count BETWEEN   5 AND   9 THEN '5 to 9'
		WHEN seat_count.active_seat_count BETWEEN  10 AND  49 THEN '10 to 49'
		WHEN seat_count.active_seat_count BETWEEN  50 AND  99 THEN '50 to 99'
		WHEN seat_count.active_seat_count BETWEEN 100 AND 199 THEN '100 to 199'
		WHEN seat_count.active_seat_count BETWEEN 200 AND 299 THEN '200 to 299'
		WHEN seat_count.active_seat_count BETWEEN 300 AND 999 THEN '300 to 999'
		WHEN seat_count.active_seat_count >=1000              THEN '1000+' ELSE '0'
		END """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()