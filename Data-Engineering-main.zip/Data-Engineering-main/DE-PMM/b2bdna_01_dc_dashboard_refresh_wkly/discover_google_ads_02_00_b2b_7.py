# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b.dcia_dcp_dashboard_discover """)
             spark.sql(""" create table b2b.dcia_dcp_dashboard_discover as 
select v.*
    ,case when lower(v.paid_search_campaign) like '%brand%' then 'Brand'
          when lower(v.paid_search_campaign) like '%nbr%'  then 'Non Branded'
          else null
     end as campaign_type
    ,case when lower(v.paid_search_campaign) like '%phrase%'   then 'Phrase'
          when lower(v.paid_search_campaign) like '%exact%' then 'Exact'
          else null
     end as phrase_exact
from 
(
select 
	distinct click_date,date_time,member_guid,new_user_flag,post_pagename,landing_page,custom_button,
	custom_button_pagename,post_page_url,visit_num,prev_page,post_referrer,visit_page_num,cgen_id,post_page_event,
	custom_link,custom_link_pagename,post_evar213,samcap_program_id,samcap_activity_name,samcap_tag_name,
	geo_code,market_area_description,fiscal_wk_and_qtr,fiscal_wk_and_qtr_desc,fiscal_wk_in_per,fiscal_wk_in_qtr,
	fiscal_wk_in_yr,fiscal_yr_and_per,fiscal_yr_and_per_desc,fiscal_yr_and_qtr,fiscal_yr_and_qtr_desc,fiscal_yr_and_wk,
	fiscal_yr_and_wk_desc,fiscal_yr_desc,fiscal_yr_and_mon_desc,marketing_site_sections,site_sub_sections,
	onboarding_sources,credapp_launch,os,device,cred_success_visit,visitor_id,visit_id,hit_id,onboarding_visit,
	loggedin_visit,ts_hit_sec,paid_search_campaign,ltc,ltc_updated,paid_search_campaign_updated
	,case 
		when min_loggedin_time_upd >= min_onboarding_time_upd then 1 else 0 
		end as logins_after_onboarding_pg_flag
	,case
		when min_loggedin_time_upd >= min_onboarding_time_upd and cred_success_visit_post_feb = 1 then 1 else 0 
		end as coversion_B_num_flag
	,case 
		when f.ltc_updated in ('Display', 'Search Paid', 'Paid Social', 'Email') then 'Paid Media'
		when f.ltc_updated in ('Search Natural', 'Refer - AWS', 'Refer - PA', 'Blogs', 'Content', 'Organic Social','Affiliate') then 'Organic'
		when f.ltc_updated in ('Internal Traffic','Traffic - Other Programs','Referrer Unknown','Others','Stage QA- Other_P28508','ABM_Campaign- Other_P28508') then 'Other/No Tracking ID'
		when f.ltc_updated in ('EduCon Dallas- Other_P28508') then 'Events'
	end as marketing_channel
    ,max(cred_success_visit_post_feb) over(partition by f.visit_id order by NULL) as cred_success_visit_post_feb
    ,case 
		when (cast(click_date as date) between cast('2022-01-29' as date) and cast('{RUN_DATE}' as date) and lower(adgroup_name_new) like '%services%') then 'Services'
		when (cast(click_date as date) between cast('2022-01-29' as date) and cast('{RUN_DATE}' as date) and lower(adgroup_name_new) like '%extract%') then 'Extract'
		when (cast(click_date as date) between cast('2022-01-29' as date) and cast('{RUN_DATE}' as date) and lower(adgroup_name_new) like '%embed%') then 'Embed'
		when (cast(click_date as date) between cast('2022-01-29' as date) and cast('{RUN_DATE}' as date) and lower(adgroup_name_new) like '%doc%') then 'Doc Gen'
		when (cast(click_date as date) between cast('2022-01-29' as date) and cast('{RUN_DATE}' as date) and lower(adgroup_name_new) like '%sdk%') then 'Services'
		when lower(paid_search_campaign) like '%services%' then 'Services'
		when lower(paid_search_campaign) like '%extract%' then 'Extract'
		when lower(paid_search_campaign) like '%embed%' then 'Embed'
		when lower(paid_search_campaign) like '%doc%' then 'Doc Gen'
		when lower(paid_search_campaign) like '%sdk%' then 'Services'
		else 'Others'
	end as services
from
(
select e.*,
first_value(ltc) over (partition by visit_id order by date_time desc) as ltc_updated
,first_value(paid_search_campaign) over (partition by visit_id order by date_time desc) as paid_search_campaign_updated
,min(cast(min_onboarding_time as timestamp)) over (partition by e.visit_id order by NULL) as min_onboarding_time_upd
,min(cast(min_loggedin_time as timestamp)) over (partition by e.visit_id order by NULL) as min_loggedin_time_upd
from  
(select
	distinct click_date,date_time,member_guid,new_user_flag,post_pagename,landing_page,custom_button,custom_button_pagename,post_page_url,visit_num,prev_page,post_referrer,visit_page_num,a.cgen_id,post_page_event,custom_link,custom_link_pagename,post_evar213,b.samcap_program_id,b.samcap_activity_name,b.samcap_tag_name,adgroup_name_new,geo_code,market_area_description,fiscal_wk_and_qtr,fiscal_wk_and_qtr_desc,fiscal_wk_in_per,fiscal_wk_in_qtr,fiscal_wk_in_yr,fiscal_yr_and_per,fiscal_yr_and_per_desc,fiscal_yr_and_qtr,fiscal_yr_and_qtr_desc,fiscal_yr_and_wk,fiscal_yr_and_wk_desc,fiscal_yr_desc,fiscal_yr_and_mon_desc,marketing_site_sections,site_sub_sections,onboarding_sources,credapp_launch,os,device,cred_success_visit,visitor_id,a.visit_id,hit_id,onboarding_visit,loggedin_visit
	, unix_timestamp(CAST(cast(date_time as timestamp) AS TIMESTAMP)) - lag( unix_timestamp(CAST(cast(date_time	as timestamp) AS TIMESTAMP))) over (partition by a.visit_id order by date_time) as ts_hit_sec
	,case
		when (cast(a.click_date as date) between cast('2022-01-29' as date) and cast('{RUN_DATE}' as date) and c.adgroup_name_new is not null) then c.adgroup_name_new
		when b.samcap_program_id = 'P28508' and  b.samcap_tag_name like '%_WP_%' and b.samcap_tag_name like '%DC Platforms_SEM_%' then concat('WP', split(b.samcap_tag_name, '_WP')[1])
                when b.samcap_program_id = 'P28508' and b.samcap_tag_name like '%_GG_%' and  b.samcap_tag_name like '%DC Platforms_SEM_%' then concat('GG', split(b.samcap_tag_name, '_GG')[1])
                when b.samcap_program_id = 'P28508' and b.samcap_tag_name like '%_BNG_%' and b.samcap_tag_name like '%DCP_SEM%' then concat('BNG', split(b.samcap_tag_name, '_BNG')[1])
		when b.samcap_program_id = 'P28508' and b.samcap_activity_name is not null and b.samcap_activity_name <> '' then b.samcap_activity_name
		when b.samcap_program_id <> 'P28508' and b.samcap_program_id is not null  then 'Other Programs'  
		else null
	end as paid_search_campaign
	,case
		when (cast(a.click_date as date) between cast('2022-01-29' as date) and cast('{RUN_DATE}' as date) and c.adgroup_name_new is not null) then 'Search Paid'
		when b.samcap_program_id = 'P28508' and (b.samcap_activity_name like 'DCP_SEM%' or b.samcap_activity_name like '%Google Ads SEM%') then 'Search Paid'
		when b.samcap_program_id = 'P28508' and (b.samcap_activity_name like 'Q221 Stack Overflow Campaign%' or b.samcap_activity_name like '%Display%') then 'Display'
		when b.samcap_program_id = 'P28508' and (b.samcap_activity_name like '%DCP_PaidSocial%' or b.samcap_activity_name like '%Social%') then 'Paid Social'
		when b.samcap_program_id = 'P28508' and b.samcap_activity_name like '%Email%' then 'Email' 
		when (b.samcap_program_id = 'P28508' and b.samcap_activity_name like '%DCP_AWS%') or (a.post_referrer like '%aws.amazon.com%') then 'Refer - AWS'
		when (b.samcap_program_id = 'P28508' and b.samcap_activity_name like '%DCP_PA%') or (a.post_referrer like '%flow.microsoft.com%' or a.post_referrer like '%docs.microsoft.com%') then 'Refer - PA'
		when (b.samcap_program_id = 'P28508' and b.samcap_activity_name like '%Blog%') or (a.post_referrer like '%medium.com%') then 'Blogs' 
		when b.samcap_program_id = 'P28508' and b.samcap_activity_name like '%DCP_Content%' then 'Content'
		when b.samcap_program_id = 'P28508' and (b.samcap_activity_name like '%DCP_OrganicSocial%') then 'Organic Social'
		when b.samcap_program_id = 'P28508' and (b.samcap_activity_name like '%Partner%' or b.samcap_activity_name like '%Other%') then 'Affiliate'
		when b.samcap_program_id = 'P28508' then concat(b.samcap_activity_name,'- Other_P28508')
		when a.ltc = 'Search Natural' then 'Search Natural'
		when (b.samcap_program_id <> 'P28508' and b.samcap_program_id <> '' and b.samcap_program_id is not null) then 'Traffic - Other Programs'  
		when (a.post_referrer like '%developer.adobe.com%' or a.post_referrer like '%adobe.io%' or a.post_referrer like '%documentcloud.adobe.com%' or a.post_referrer like '%adobeid-na1.services.adobe.com%'or a.post_referrer like '%adobe.com%') then 'Internal Traffic'   
		when a.post_referrer <> '' then 'Referrer Unknown'  
		else 'Others'
		end as ltc
	,case 
		when onboarding_visit = 1 then min(cast(date_time as timestamp)) over (partition by a.visit_id,onboarding_visit order by NULL) 
		else null
		end as min_onboarding_time
	,case 
		when loggedin_visit = 1 then min(cast(date_time as timestamp)) over (partition by a.visit_id,loggedin_visit order by NULL)
		else null 
		end as 	min_loggedin_time
	,case when cred_success_visit = 1 and click_date >= '2022-02-01' then 1 else null end as cred_success_visit_post_feb
from
	(
	select * from b2b_stg.dcia_dcp_db_discover_t1
	union all
	select * from b2b_stg.dcia_dcp_db_discover_t2) a
	left join
		(select
			key
			,samcap_activity_name
			,samcap_tag_name
			,samcap_program_id
		from
			(select 
				key
				,samcap_activity_name 
				,samcap_tag_name
				,samcap_program_id
				,row_number() over (partition by key order by click_date desc) as rk 
			from 
				ocf.sc_external_campaigns
			where 
				key is not null and key <> ''
				and samcap_program_id is not NULL and samcap_program_id <> ''
				and samcap_activity_id is not null and samcap_activity_id <> '' 
				and samcap_activity_name is not null and samcap_activity_name <> ''
				and samcap_tag_name is not null and samcap_tag_name <> ''
				and report_suite = 'adbadobenonacdcprod'
			)
		where rk = 1
		) b
		on a.cgen_id = b.key
	left join b2b_stg.discover_ga_pre_final c on a.visit_id = c.visit_id
	)e
	)f
)v """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC 			key
# MAGIC 			,samcap_activity_name
# MAGIC 			,samcap_tag_name
# MAGIC 			,samcap_program_id
# MAGIC 		from
# MAGIC 			(select 
# MAGIC 				key
# MAGIC 				,samcap_activity_name 
# MAGIC 				,samcap_tag_name
# MAGIC 				,samcap_program_id
# MAGIC 				,row_number() over (partition by key order by click_date desc) as rk 
# MAGIC 			from 
# MAGIC 				ocf.sc_external_campaigns
# MAGIC 			where 
# MAGIC 				key is not null and key <> ''
# MAGIC 				and samcap_program_id is not NULL and samcap_program_id <> ''
# MAGIC 				and samcap_activity_id is not null and samcap_activity_id <> '' 
# MAGIC 				and samcap_activity_name is not null and samcap_activity_name <> ''
# MAGIC 				and samcap_tag_name is not null and samcap_tag_name <> ''
# MAGIC 				and report_suite = 'adbadobenonacdcprod'
# MAGIC 			)
# MAGIC 		where rk = 1 and key = '12B9DX5P'

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct cgen_id from b2b_stg.dcia_dcp_db_discover_t2 where cgen_id in ('12B9DX5P', 'TY6XKW45')