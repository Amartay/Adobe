# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b_stg.year_index_discover """)
             spark.sql(""" create table b2b_stg.year_index_discover as
select 
    fiscal_yr_desc
    ,row_number() over (order by fiscal_yr_desc desc) as index 
from 
    (       
	select 
		distinct fiscal_yr_desc
	from 
		ids_coredata.dim_date 
	where 
		date_date >= '2019-11-30'
		and date(date_date) <= (select max(date(date_date)) from b2b_stg.dcia_dcp_db_date)
    ) t1 """)
             spark.sql(""" drop table if exists b2b_stg.quarter_index_discover """)
             spark.sql(""" create table b2b_stg.quarter_index_discover as
select 
	fiscal_yr_and_qtr_desc
    ,row_number() over (order by fiscal_yr_and_qtr_desc desc) as index   
from 
    (       
	select 
		distinct fiscal_yr_and_qtr_desc
	from 
		ids_coredata.dim_date 
	where 
		date_date >= '2019-11-30'
		and date(date_date) <= (select max(date(date_date)) from b2b_stg.dcia_dcp_db_date)
    ) t2 """)
             spark.sql(""" drop table if exists b2b_stg.period_in_quarter_index_discover """)
             spark.sql(""" create table b2b_stg.period_in_quarter_index_discover as
select 
	fiscal_yr_and_qtr_desc
    ,fiscal_yr_and_per_desc
    ,fiscal_yr_and_mon_desc
    ,dense_rank() over (order by fiscal_yr_and_qtr_desc desc) as qtr_index 
    ,row_number() over (partition by fiscal_yr_and_qtr_desc order by fiscal_yr_and_qtr_desc ,fiscal_yr_and_per_desc) as per_index   
from 
    (       
	select 
		distinct fiscal_yr_and_qtr_desc
		,fiscal_yr_and_per_desc
		,case
			when substr(fiscal_yr_and_per_desc, 6, 7) = '01' then concat(fiscal_yr_and_per_desc, ' (Dec)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '02' then concat(fiscal_yr_and_per_desc, ' (Jan)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '03' then concat(fiscal_yr_and_per_desc, ' (Feb)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '04' then concat(fiscal_yr_and_per_desc, ' (Mar)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '05' then concat(fiscal_yr_and_per_desc, ' (Apr)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '06' then concat(fiscal_yr_and_per_desc, ' (May)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '07' then concat(fiscal_yr_and_per_desc, ' (Jun)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '08' then concat(fiscal_yr_and_per_desc, ' (Jul)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '09' then concat(fiscal_yr_and_per_desc, ' (Aug)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '10' then concat(fiscal_yr_and_per_desc, ' (Sep)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '11' then concat(fiscal_yr_and_per_desc, ' (Oct)')
			when substr(fiscal_yr_and_per_desc, 6, 7) = '12' then concat(fiscal_yr_and_per_desc, ' (Nov)')
			else 'Others'
		end as fiscal_yr_and_mon_desc
	from 
		ids_coredata.dim_date
	where 
		date_date >= '2019-11-30'
		and date(date_date) <= (select max(date(date_date)) from b2b_stg.dcia_dcp_db_date)
    ) t3 """)
             spark.sql(""" drop table if exists b2b_stg.week_index_discover """)
             spark.sql(""" create table b2b_stg.week_index_discover as
select 
	fiscal_yr_and_wk_desc
    ,row_number() over (order by fiscal_yr_and_wk_desc desc) as index   
from 
    (       
	select 
		distinct fiscal_yr_and_wk_desc
	from 
		ids_coredata.dim_date 
	where
		date_date >= '2019-11-30'
		and date(date_date) <= (select max(date(date_date)) from b2b_stg.dcia_dcp_db_date)
    ) t4 """)
             spark.sql(""" drop table if exists b2b_stg.week_in_quarter_index_discover """)
             spark.sql(""" create table b2b_stg.week_in_quarter_index_discover as
select 
	fiscal_yr_and_qtr_desc
    ,fiscal_yr_and_wk_desc
    ,dense_rank() over (order by fiscal_yr_and_qtr_desc desc) as qtr_index 
    ,row_number() over (partition by fiscal_yr_and_qtr_desc order by fiscal_yr_and_qtr_desc ,fiscal_yr_and_wk_desc) as wk_index   
from 
    (       
	select 
		distinct fiscal_yr_and_qtr_desc
		,fiscal_yr_and_wk_desc
	from 
		ids_coredata.dim_date
	where 
		date_date >= '2019-11-30'
		and date(date_date) <= (select max(date(date_date)) from b2b_stg.dcia_dcp_db_date)
    ) t5 """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()