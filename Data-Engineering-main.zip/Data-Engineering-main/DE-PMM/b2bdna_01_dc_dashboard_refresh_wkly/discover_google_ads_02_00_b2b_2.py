# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" drop table if exists b2b_stg.ga_t3 """)
             spark.sql(""" create table b2b_stg.ga_t3 as
select cgen_id
	  ,campaign_name_new
	  ,adgroup_name_new 
      ,campaign_type
      ,phrase_exact
from
	(select 
	cgen_id
	,campaign_name_new
	,adgroup_name_new
    ,campaign_type
    ,phrase_exact
	,row_number() over(partition by cgen_id order by cast(month_n as date) desc) AS row_num 
	from b2b_stg.ga_t2)
where row_num = 1 """)
             spark.sql(""" insert into b2b_stg.discover_visit_t1 
select 
    distinct
    concat(cast(sc.post_visid_high as String), '-', cast(sc.post_visid_low as String), '-', cast(sc.visit_num as String), '-', cast(sc.visit_start_time_gmt as String)) as visit_id
    ,sc.page_url
    ,case
when page_url not like '%sdid%' and length( SPLIT(SPLIT(page_url, '\\\?')[1],'&')[0]) = 8 then SPLIT(SPLIT(page_url, '\\\?')[1],'&')[0]
when page_url like '%sdid%' and length( SPLIT(SPLIT(page_url, '\\\?sdid=')[1],'&mv')[0]) = 8 then SPLIT(SPLIT(page_url, '\\\?sdid=')[1],'&mv')[0]
        else null
    end as cgen_id
    ,sc.date_time
    from aa_ingest.sc_visitor_click_history sc 
    where 
		1 = 1
		and sc.exclude_hit = 0
		and sc.hit_source not in (5,7,8,9)
		and sc.report_suite = 'adbadobenonacdcprod'
		and (cast(sc.click_date as date) between (cast('{RUN_DATE}' as date) - interval '6' day) and cast('{RUN_DATE}' as date))
		and (sc.post_pagename like 'developer.adobe.com:document-services%' 
			or sc.post_pagename like 'adobe.io:document-services%' 
			or sc.post_pagename in ('documentcloud.adobe.com:dc-integration-creation-app-cdn:main','documentcloud.adobe.com:dc-integration-creation-app-cdn:awsMarketplaceOnboarding',	
			'documentcloud.adobe.com:dc-integration-creation-app-cdn:powerAutomateOnboarding',
			'community.adobe.com:t5:Document-Cloud-SDK:ct-p:Document-Cloud-SDK','documentcloud.adobe.com:view-sdk-demo:index','documentcloud.adobe.com:dc-visualizer-app:index',
			'documentcloud.adobe.com:dc-docgen-playground:index')
			or sc.post_evar69 like  '%dc-integration-creation-app-cdn:%'
			)
		and sc.domain <> 'adobe.com' """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()