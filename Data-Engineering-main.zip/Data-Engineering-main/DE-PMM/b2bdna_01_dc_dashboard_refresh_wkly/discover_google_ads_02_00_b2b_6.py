# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" insert into b2b_stg.dcia_dcp_db_discover_t2 
select
	b.*
	,case 
		when b.ltc in ('Display', 'Search Paid', 'Paid Social', 'Email') then 'Paid Media'
		when b.ltc in ('Search Natural', 'Refer - AWS', 'Refer - PA', 'Blogs', 'Content', 'Organic Social') then 'Organic'
		else 'Other/No Tracking ID'
	end as marketing_channel
	,case when b.onboarding_sources in ('DC Services Onboarding','AWS Onboarding','PA Onboarding') then 1 else null end as onboarding_visit
	,case when b.member_guid is not null and b.member_guid <> '' then 1 else null end as loggedin_visit
	,null as ts_hit_sec
from  
	(
	select
		distinct cast(sc.click_date as date)
		,sc.date_time
		,sc.post_evar12 as member_guid
		,sc.visid_new as new_user_flag
		,sc.post_pagename
		,sc.first_hit_pagename as landing_page
		,sc.post_prop20 as custom_button
		,sc.post_prop21 as custom_button_pagename
		,sc.post_page_url
		,sc.visit_num
		,sc.post_prop12 as prev_page
		,sc.post_referrer
		,case 
			when ec.samcap_tag_name like '%DC Platforms_SEM_%' then concat('WP', split(samcap_tag_name, '_WP')[1])
			else 'Others'
		 end as paid_search_campaign
		,sc.visit_page_num
		,sc.post_evar6 as cgen_id
		,sc.post_page_event 
		,sc.post_evar80 as custom_link
		,sc.post_evar69 as custom_link_pagename
		,sc.post_evar213
		,ec.samcap_program_id
		,ec.samcap_activity_name
		,ec.samcap_tag_name
		,case 
			when (c.geo_code is null or c.geo_code = '') then 'Unavailable'
			else c.geo_code
		end as geo_code
		,case 
			when (c.market_area_description is null or c.market_area_description = '') then 'Unavailable'
			else c.market_area_description
		end as market_area_description
		,cast(dd.fiscal_wk_and_qtr as int) as fiscal_wk_and_qtr
		,dd.fiscal_wk_and_qtr_desc 
		,cast(dd.fiscal_wk_in_per as int) as fiscal_wk_in_per
		,cast(dd.fiscal_wk_in_qtr as int) as fiscal_wk_in_qtr
		,cast(dd.fiscal_wk_in_yr as int) as fiscal_wk_in_yr
		,cast(dd.fiscal_yr_and_per as int) as fiscal_yr_and_per
		,dd.fiscal_yr_and_per_desc
		,cast(dd.fiscal_yr_and_qtr as int) as fiscal_yr_and_qtr
		,dd.fiscal_yr_and_qtr_desc
		,cast(dd.fiscal_yr_and_wk as int) as fiscal_yr_and_wk
		,dd.fiscal_yr_and_wk_desc
		,cast(dd.fiscal_yr_desc as int) as fiscal_yr_desc
		,case
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '01' then concat(dd.fiscal_yr_and_per_desc, ' (Dec)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '02' then concat(dd.fiscal_yr_and_per_desc, ' (Jan)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '03' then concat(dd.fiscal_yr_and_per_desc, ' (Feb)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '04' then concat(dd.fiscal_yr_and_per_desc, ' (Mar)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '05' then concat(dd.fiscal_yr_and_per_desc, ' (Apr)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '06' then concat(dd.fiscal_yr_and_per_desc, ' (May)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '07' then concat(dd.fiscal_yr_and_per_desc, ' (Jun)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '08' then concat(dd.fiscal_yr_and_per_desc, ' (Jul)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '09' then concat(dd.fiscal_yr_and_per_desc, ' (Aug)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '10' then concat(dd.fiscal_yr_and_per_desc, ' (Sep)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '11' then concat(dd.fiscal_yr_and_per_desc, ' (Oct)')
			when substr(dd.fiscal_yr_and_per_desc, 6, 7) = '12' then concat(dd.fiscal_yr_and_per_desc, ' (Nov)')
			else 'Others'
		end as fiscal_yr_and_mon_desc
		,case
			when ec.samcap_program_id = 'P28508' and (ec.samcap_activity_name like 'Q221 Stack Overflow Campaign%' or ec.samcap_activity_name like 'DCP_Display%') then 'Display'
			when ec.samcap_program_id = 'P28508' and (ec.samcap_activity_name like 'DCP_SEM%' or ec.samcap_activity_name like '%Google Ads SEM%') then 'Search Paid'
			when ec.samcap_program_id = 'P28508' and ec.samcap_activity_name like '%DCP_PaidSocial%' then 'Paid Social'
			when ec.samcap_program_id = 'P28508' and ec.samcap_activity_name like '%DCP_Email%' then 'Email'
			when (ec.samcap_program_id = 'P28508' and ec.samcap_activity_name like '%DCP_AWS%') or (sc.post_referrer like '%aws.amazon.com%') then 'Refer - AWS'
			when (ec.samcap_program_id = 'P28508' and ec.samcap_activity_name like '%DCP_PA%') or (sc.post_referrer like '%flow.microsoft.com%' or sc.post_referrer like '%docs.microsoft.com%') then 'Refer - PA'
			when (ec.samcap_program_id = 'P28508' and ec.samcap_activity_name like '%DCP_Blogs%') or (sc.post_referrer like '%medium.com%') then 'Blogs'
			when ec.samcap_program_id = 'P28508' and ec.samcap_activity_name like '%DCP_Content%' then 'Content'
			when ec.samcap_program_id = 'P28508' and ec.samcap_activity_name like '%DCP_OrganicSocial%' then 'Organic Social'
			when sc.va_closer_id = 2 and sc.click_date >= '2021-06-23' then 'Search Natural'
			else 'Others' 
		end as ltc
		,case 
			when sc.post_pagename in ('developer.adobe.com:document-services:apis:pdf-services','adobe.io:document-services:apis:pdf-services','developer.adobe.com:document-services:apis:pdf-embed','adobe.io:document-services:apis:pdf-embed','developer.adobe.com:document-services:apis:doc-generation','adobe.io:document-services:apis:doc-generation','developer.adobe.com:document-services:apis:pdf-extract','adobe.io:document-services:apis:pdf-extract','developer.adobe.com:document-services:apis:pdf-services','adobe.io:document-services:apis:pdf-services') then 'Site API'
			when sc.post_pagename in ('developer.adobe.com:document-services:pricing:contact','adobe.io:document-services:pricing:contact') then 'Site Contact Sales Form'
			when sc.post_pagename in ('developer.adobe.com:document-services:resources','adobe.io:document-services:resources') then 'Site Developer Resources'
			when sc.post_pagename like 'developer.adobe.com:document-services:docs:overview%' then 'Site Documentation'
			when sc.post_pagename in ('documentcloud.adobe.com:dc-integration-creation-app-cdn:main') then 'Site Credential App'
			when sc.post_pagename in ('developer.adobe.com:document-services') then 'Site Main Services'
			when sc.post_pagename in ('developer.adobe.com:document-services:pricing:main', 'adobe.io:document-services:pricing:main') then 'Site Pricing'
			when sc.post_pagename in ('community.adobe.com:t5:Document-Cloud-SDK:ct-p:Document-Cloud-SDK') then 'Site Support Forum'
			when sc.post_pagename in ('developer.adobe.com:document-services:use-cases:agreements-and-contracts:sales-proposals-and-contracts','adobe.io:document-services:use-cases:agreements-and-contracts:sales-proposals-and-contracts','developer.adobe.com:document-services:use-cases:agreements-and-contracts:legal-contracts','adobe.io:document-services:use-cases:agreements-and-contracts:legal-contracts','developer.adobe.com:document-services:use-cases:agreements-and-contracts:nda-creation','adobe.io:document-services:use-cases:agreements-and-contracts:nda-creation','developer.adobe.com:document-services:use-cases:content-publishing:job-posting','adobe.io:document-services:use-cases:content-publishing:job-posting','developer.adobe.com:document-services:use-cases:agreements-and-contracts:employee-offer-letters','adobe.io:document-services:use-cases:agreements-and-contracts:employee-offer-letters','developer.adobe.com:document-services:use-cases:content-publishing:digital-content-publishing','adobe.io:document-services:use-cases:content-publishing:digital-content-publishing','developer.adobe.com:document-services:use-cases:collaboration:student-teacher-collaboration','adobe.io:document-services:use-cases:collaboration:student-teacher-collaboration','developer.adobe.com:document-services:use-cases:collaboration:review-and-approval','adobe.io:document-services:use-cases:collaboration:review-and-approval','developer.adobe.com:document-services:use-cases:content-and-data-extraction:data-analysis','adobe.io:document-services:use-cases:content-and-data-extraction:data-analysis','developer.adobe.com:document-services:use-cases:financial:invoices','adobe.io:document-services:use-cases:financial:invoices','developer.adobe.com:document-services:use-cases:archiving-and-retrieval:search-and-indexing','adobe.io:document-services:use-cases:archiving-and-retrieval:search-and-indexing','developer.adobe.com:document-services:use-cases:agreements-and-contracts:legal-letters-and-statements','adobe.io:document-services:use-cases:agreements-and-contracts:legal-letters-and-statements','developer.adobe.com:document-services:use-cases:content-and-data-extraction:content-based-process-automation','adobe.io:document-services:use-cases:content-and-data-extraction:content-based-process-automation','developer.adobe.com:document-services:use-cases:content-and-data-extraction:republish-pdf-content','adobe.io:document-services:use-cases:content-and-data-extraction:republish-pdf-content','developer.adobe.com:document-services:use-cases:content-publishing:on-demand-report-creation','adobe.io:document-services:use-cases:content-publishing:on-demand-report-creation','developer.adobe.com:document-services:use-cases:content-publishing:employee-onboarding-materials','adobe.io:document-services:use-cases:content-publishing:employee-onboarding-materials','developer.adobe.com:document-services:use-cases:content-publishing:automated-report-generation','adobe.io:document-services:use-cases:content-publishing:automated-report-generation','developer.adobe.com:document-services:use-cases:content-publishing:employee-letters','adobe.io:document-services:use-cases:content-publishing:employee-letters','developer.adobe.com:document-services:use-cases:content-publishing:course-and-degree-certificate','adobe.io:document-services:use-cases:content-publishing:course-and-degree-certificate','developer.adobe.com:document-services:use-cases:financial:data-analysis-financial','adobe.io:document-services:use-cases:financial:data-analysis-financial','developer.adobe.com:document-services:use-cases:financial:sales-quote','adobe.io:document-services:use-cases:financial:sales-quote','developer.adobe.com:document-services:use-cases:financial:purchase-orders','adobe.io:document-services:use-cases:financial:purchase-orders') then 'Site Use Cases'
			when sc.post_evar69 like '%documentcloud.adobe.com:dc-integration-creation-app-cdn%' then 'Site Credential App'
			when sc.post_pagename in ('documentcloud.adobe.com:dc-visualizer-app:index','documentcloud.adobe.com:dc-docgen-playground:index','documentcloud.adobe.com:view-sdk-demo:index') then 'Playground Pages'
			else 'Other Pages' 
		end as marketing_site_sections
		,case 
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk','developer.adobe.com:document-services') then 'homepage'
			when sc.post_pagename like 'developer.adobe.com:document-services:docs:overview%' then sc.post_pagename
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:pdf-embed','developer.adobe.com:document-services:apis:pdf-embed','adobe.io:document-services:apis:pdf-embed') then 'pdf-embed'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:doc-generation','developer.adobe.com:document-services:apis:doc-generation','adobe.io:document-services:apis:doc-generation') then 'doc-generation'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:pdf-extract','developer.adobe.com:document-services:apis:pdf-extract','adobe.io:document-services:apis:pdf-extract') then 'pdf-extract'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:pdf-services','developer.adobe.com:document-services:apis:pdf-services','adobe.io:document-services:apis:pdf-services') then 'pdf-services'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:gettingstarted','documentcloud.adobe.com:dc-integration-creation-app-cdn:main') then 'Onboarding page'
            when sc.post_pagename like 'documentcloud.adobe.com:dc-integration-creation-app-cdn:%' then 'Onboarding page'
            when sc.post_evar69 like 'documentcloud.adobe.com:dc-integration-creation-app-cdn:%' then 'Onboarding page' 
			when sc.post_pagename in ('documentcloud.adobe.com:dc-visualizer-app:index') then 'dc-visualizer-app'
			when sc.post_pagename in ('documentcloud.adobe.com:dc-docgen-playground:index') then 'dc-docgen-playground'
			when sc.post_pagename in ('documentcloud.adobe.com:view-sdk-demo:index') then 'demo_page'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:pdf-pricing','developer.adobe.com:document-services:pricing:main','adobe.io:document-services:pricing:main') then 'pdf-pricing'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:pdf-resources','developer.adobe.com:document-services:resources','adobe.io:document-services:resources') then 'pdf-resources'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:sales-proposals-and-contracts','developer.adobe.com:document-services:use-cases:agreements-and-contracts:sales-proposals-and-contracts','adobe.io:document-services:use-cases:agreements-and-contracts:sales-proposals-and-contracts') then 'sales-proposals-and-contracts'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:legal-contracts','developer.adobe.com:document-services:use-cases:agreements-and-contracts:legal-contracts','adobe.io:document-services:use-cases:agreements-and-contracts:legal-contracts') then 'legal-contracts'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:nda-creation','developer.adobe.com:document-services:use-cases:agreements-and-contracts:nda-creation','adobe.io:document-services:use-cases:agreements-and-contracts:nda-creation') then 'nda-creation'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:job-posting','developer.adobe.com:document-services:use-cases:content-publishing:job-posting','adobe.io:document-services:use-cases:content-publishing:job-posting') then 'job-posting'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:employee-offer-letters','developer.adobe.com:document-services:use-cases:agreements-and-contracts:employee-offer-letters','adobe.io:document-services:use-cases:agreements-and-contracts:employee-offer-letters') then 'employee-offer-letters'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:digital-content-publishing','developer.adobe.com:document-services:use-cases:content-publishing:digital-content-publishing','adobe.io:document-services:use-cases:content-publishing:digital-content-publishing') then 'digital-content-publishing'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:report-creation-and-editing' ) then 'report-creation-and-editing'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:student-teacher-collaboration','developer.adobe.com:document-services:use-cases:collaboration:student-teacher-collaboration','adobe.io:document-services:use-cases:collaboration:student-teacher-collaboration') then 'student-teacher-collaboration'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:reviews-and-approvals','developer.adobe.com:document-services:use-cases:collaboration:review-and-approval','adobe.io:document-services:use-cases:collaboration:review-and-approval') then 'reviews-and-approvals'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:data-analysis','developer.adobe.com:document-services:use-cases:content-and-data-extraction:data-analysis','adobe.io:document-services:use-cases:content-and-data-extraction:data-analysis') then 'data-analysis'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:invoices','developer.adobe.com:document-services:use-cases:financial:invoices','adobe.io:document-services:use-cases:financial:invoices') then 'invoices'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:search-and-indexing','developer.adobe.com:document-services:use-cases:archiving-and-retrieval:search-and-indexing','adobe.io:document-services:use-cases:archiving-and-retrieval:search-and-indexing') then 'search-and-indexing'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:legal-letters-and-statements','developer.adobe.com:document-services:use-cases:agreements-and-contracts:legal-letters-and-statements','adobe.io:document-services:use-cases:agreements-and-contracts:legal-letters-and-statements') then 'legal-letters-and-statements'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:content-based-process-automation','developer.adobe.com:document-services:use-cases:content-and-data-extraction:content-based-process-automation','adobe.io:document-services:use-cases:content-and-data-extraction:content-based-process-automation') then 'content-based-process-automation'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:republish-pdf-content','developer.adobe.com:document-services:use-cases:content-and-data-extraction:republish-pdf-content','adobe.io:document-services:use-cases:content-and-data-extraction:republish-pdf-content') then 'republish-pdf-content'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:on-demand-report-creation','developer.adobe.com:document-services:use-cases:content-publishing:on-demand-report-creation','adobe.io:document-services:use-cases:content-publishing:on-demand-report-creation') then 'on-demand-report-creation'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:employee-onboarding-materials','developer.adobe.com:document-services:use-cases:content-publishing:employee-onboarding-materials','adobe.io:document-services:use-cases:content-publishing:employee-onboarding-materials') then 'employee-onboarding-materials'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:automated-report-generation','developer.adobe.com:document-services:use-cases:content-publishing:automated-report-generation','adobe.io:document-services:use-cases:content-publishing:automated-report-generation') then 'automated-report-generation'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:employee-letters','developer.adobe.com:document-services:use-cases:content-publishing:employee-letters','adobe.io:document-services:use-cases:content-publishing:employee-letters') then 'employee-letters'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:course-degree-certificate','developer.adobe.com:document-services:use-cases:content-publishing:course-and-degree-certificate','adobe.io:document-services:use-cases:content-publishing:course-and-degree-certificate') then 'course-degree-certificate'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:data-analysis-financial','developer.adobe.com:document-services:use-cases:financial:data-analysis-financial','adobe.io:document-services:use-cases:financial:data-analysis-financial') then 'data-analysis-financial'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:sales-quote','developer.adobe.com:document-services:use-cases:financial:sales-quote','adobe.io:document-services:use-cases:financial:sales-quote') then 'sales-quote'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:purchase-orders','developer.adobe.com:document-services:use-cases:financial:purchase-orders','adobe.io:document-services:use-cases:financial:purchase-orders') then 'purchase-orders'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:form','developer.adobe.com:document-services:pricing:contact','adobe.io:document-services:pricing:contact') then 'contact-sales-form'
			when sc.post_pagename in ('adobe.io:apis:documentcloud:dcsdk:extractbetaform' ) then 'extract-beta-form'
			when sc.post_pagename in ('community.adobe.com:t5:document-services-apis:bd-p:Document-Cloud-SDK','community.adobe.com:t5:Document-Cloud-SDK:ct-p:Document-Cloud-SDK','community.adobe.com:t5:Document-Cloud-SDK:ct-p:Document-Cloud-SDK') then 'document-cloud-sdk'
			when sc.post_pagename like 'developer.adobe.com:document-services:%' then regexp_replace(sc.post_pagename, 'developer.adobe.com:document-services:', '') 
			when sc.post_pagename like 'adobe.io:document-services:%' then regexp_replace(sc.post_pagename, 'adobe.io:document-services:', '') 
			when sc.post_pagename = '' then 'No valid Pagename'
			else sc.post_pagename
		end as site_sub_sections
		,case 
			when sc.post_pagename = 'documentcloud.adobe.com:dc-integration-creation-app-cdn:main' then 'DC Services Onboarding'
			when sc.post_pagename = 'documentcloud.adobe.com:dc-integration-creation-app-cdn:awsMarketplaceOnboarding' then 'AWS Onboarding'
			when sc.post_pagename = 'documentcloud.adobe.com:dc-integration-creation-app-cdn:powerAutomateOnboarding' then 'PA Onboarding'
			else 'Others'
		end as onboarding_sources
		,case
			when sc.post_evar69 = 'documentcloud.adobe.com:dc-integration-creation-app-cdn:main' then 'CredApp Launch(IO site)'
			when sc.post_evar69 = 'documentcloud.adobe.com:dc-integration-creation-app-cdn:awsMarketplaceOnboarding' then 'CredAPP Launch (AWS)'
			when sc.post_evar69 = 'documentcloud.adobe.com:dc-integration-creation-app-cdn:powerAutomateOnboarding' then 'CredApp Launch (PowerAutomate)'
			else 'Others'
		end as credapp_launch
		,case 
			when sc.user_agent like '%Android%' then 'Android'
			when sc.user_agent like '%iPhone%' then 'iOS'
			when sc.user_agent like '%Windows%' then 'Windows'
			when sc.user_agent like '%Macintosh%' then 'MacOS'
			when sc.user_agent like '%Linux%' then 'Linux'
			else 'Others' 
		end as os
		,case 
			when (sc.user_agent like '%Android%' or sc.user_agent like '%iPhone%') then 'Mobile'
			when (sc.user_agent like '%Windows%' or sc.user_agent like '%Macintosh%' or sc.user_agent like '%Linux%') then 'Desktop'
			else 'Others' 
		end as device
		,case when sc.post_evar80 like 'CreateCredentialsSuccess:%' or sc.post_evar80 like 'CreateServicesSdkCredsSuccess:%' then 1 else null end as cred_success_visit
		,concat(cast(sc.post_visid_high as varchar(255)), '-', cast(sc.post_visid_low as varchar(255))) as visitor_id
		,concat(cast(sc.post_visid_high as varchar(255)), '-', cast(sc.post_visid_low as varchar(255)), '-', cast(sc.visit_num as varchar(255)), '-', cast(sc.visit_start_time_gmt as varchar(255))) as visit_id
		,concat(cast(sc.hitid_high as varchar(255)), '-', cast(sc.hitid_low as varchar(255))) as hit_id
	from aa_ingest.sc_visitor_click_history sc
		left join 
			(
			select 
				distinct key 
				,samcap_program_id 
				,samcap_activity_name 
				,samcap_tag_name
				,samcap_landing_page_url 
			from 
				ocf.sc_external_campaigns
			where 
				samcap_program_id is not NULL 
				and samcap_activity_id is not null 
				and samcap_activity_name is not null 
				and samcap_activity_id != '' 
				and samcap_program_id != ''
				and samcap_program_id = 'P28508' 
				and report_suite = 'adbadobenonacdcprod'
			) ec
			on sc.post_evar6 = ec.key
		left join ids_coredata.dim_date dd
			on sc.click_date = dd.date_date
		left join (select * from ids_coredata.dim_country where country_code_iso3 <> '' and country_code_iso3 is not null) c
			on upper(sc.geo_country) = c.country_code_iso3
	where 
		1 = 1
		and sc.exclude_hit = 0
		and sc.hit_source not in (5,7,8,9)
		and sc.report_suite = 'adbadobenonacdcprod'
		and (cast(sc.click_date as date) between DATE_SUB(cast('{RUN_DATE}' as date),6) and cast('{RUN_DATE}' as date)) 
		and (sc.post_pagename like 'developer.adobe.com:document-services%' 
			or sc.post_pagename like 'adobe.io:document-services%' 
			or sc.post_pagename like 'documentservices.adobe.com%'
			or sc.post_pagename in ('documentcloud.adobe.com:dc-integration-creation-app-cdn:main','documentcloud.adobe.com:dc-integration-creation-app-cdn:awsMarketplaceOnboarding',	
			'documentcloud.adobe.com:dc-integration-creation-app-cdn:powerAutomateOnboarding',
			'community.adobe.com:t5:Document-Cloud-SDK:ct-p:Document-Cloud-SDK','documentcloud.adobe.com:view-sdk-demo:index','documentcloud.adobe.com:dc-visualizer-app:index',
			'documentcloud.adobe.com:dc-docgen-playground:index','documentservices.adobe.com:dc-integration-creation-app-cdn:main')
			or sc.post_evar69 like '%dc-integration-creation-app-cdn:%'
			)
		and sc.domain <> 'adobe.com'
	) b """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()

# COMMAND ----------

# %sql
# drop table b2b_stg.dcia_dcp_db_discover_t2;
# CREATE TABLE b2b_stg.dcia_dcp_db_discover_t2(	
#   `click_date` date, 	
#   `date_time` timestamp, 	
#   `member_guid` string, 	
#   `new_user_flag` string, 	
#   `post_pagename` string, 	
#   `landing_page` string, 	
#   `custom_button` string, 	
#   `custom_button_pagename` string, 	
#   `post_page_url` string, 	
#   `visit_num` bigint, 	
#   `prev_page` string, 	
#   `post_referrer` string, 	
#   `paid_search_campaign` string, 	
#   `visit_page_num` bigint, 	
#   `cgen_id` string, 	
#   `post_page_event` bigint, 	
#   `custom_link` string, 	
#   `custom_link_pagename` string, 	
#   `post_evar213` string, 	
#   `samcap_program_id` string, 	
#   `samcap_activity_name` string, 	
#   `samcap_tag_name` string, 	
#   `geo_code` string, 	
#   `market_area_description` string, 	
#   `fiscal_wk_and_qtr` int, 	
#   `fiscal_wk_and_qtr_desc` string, 	
#   `fiscal_wk_in_per` int, 	
#   `fiscal_wk_in_qtr` int, 	
#   `fiscal_wk_in_yr` int, 	
#   `fiscal_yr_and_per` int, 	
#   `fiscal_yr_and_per_desc` string, 	
#   `fiscal_yr_and_qtr` int, 	
#   `fiscal_yr_and_qtr_desc` string, 	
#   `fiscal_yr_and_wk` int, 	
#   `fiscal_yr_and_wk_desc` string, 	
#   `fiscal_yr_desc` int, 	
#   `fiscal_yr_and_mon_desc` string, 	
#   `ltc` varchar(14), 	
#   `marketing_site_sections` varchar(24), 	
#   `site_sub_sections` string, 	
#   `onboarding_sources` varchar(22), 	
#   `credapp_launch` varchar(30), 	
#   `os` varchar(7), 	
#   `device` varchar(7), 	
#   `cred_success_visit` int, 	
#   `visitor_id` string, 	
#   `visit_id` string, 	
#   `hit_id` string, 	
#   `marketing_channel` varchar(20), 	
#   `onboarding_visit` int, 	
#   `loggedin_visit` int, 	
#   `ts_hit_sec` double)
#   stored as PARQUET
#   LOCATION
#   "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/dcia_dcp_db_discover_t2"