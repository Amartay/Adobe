# Databricks notebook source
# from pyspark import SparkContext, SparkConf , StorageLevel
# from pyspark.sql import SparkSession, HiveContext
# from pyspark.sql.functions import *
# from pyspark.sql.types import *
# import logging
# from dateutil.rrule import rrule, MONTHLY
# from datetime import datetime
# import json
# from pyspark.sql import functions
# import sys
# class main() :
#     def __init__(self):
#          try :
#              spark = SparkSession.builder \
#                  .enableHiveSupport() \
#                  .config('hive.exec.dynamic.partition', 'true') \
#                  .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
#                  .config('hive.exec.max.dynamic.partitions', '10000') \
#                  .getOrCreate()
#              log4j = spark._jvm.org.apache.log4j
#              log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
#              spark.sql('SET hive.warehouse.data.skiptrash=true;')
#              spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
#              spark.conf.set('spark.sql.cbo.enabled', True)
#              spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
#              spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
#              spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
#              spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
#              spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
#              spark.sql("set spark.sql.adaptive.enabled=false")

#              dbutils.widgets.text("Custom_Settings", "")

#              Settings = dbutils.widgets.get("Custom_Settings")

#              Set_list = Settings.split(',')
#              if len(Set_list)>0:
#                  for i in Set_list:
#                      if i != "":
#                          print("spark.sql(+i+)")
#                          spark.sql("""{i}""".format(i=i))

#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_db_date """)
#              spark.sql(""" drop table if exists b2b_stg.ga_t2 """)
#              spark.sql(""" drop table if exists b2b_stg.ga_t3 """)
#              spark.sql(""" drop table if exists b2b_stg.discover_visit_t2 """)
#              spark.sql(""" drop table if exists b2b_stg.discover_visit_t3 """)
#              spark.sql(""" drop table if exists b2b_stg.discover_ga_pre_final """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_dashboard_discover """)
#              spark.sql(""" drop table if exists b2b_stg.year_index_discover """)
#              spark.sql(""" drop table if exists b2b_stg.quarter_index_discover """)
#              spark.sql(""" drop table if exists b2b_stg.period_in_quarter_index_discover """)
#              spark.sql(""" drop table if exists b2b_stg.week_index_discover """)
#              spark.sql(""" drop table if exists b2b_stg.week_in_quarter_index_discover """)
#              spark.sql(""" drop table if exists b2b_stg.period_index_discover """)
#              spark.sql(""" drop table if exists b2b_stg.period_title_discover """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_arr_t1 """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_dashboard_arr_t2 """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_dashboard_arr_t2a """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_dashboard_arr_t3 """)
#              spark.sql(""" drop table if exists b2b_stg.year_index_arr """)
#              spark.sql(""" drop table if exists b2b_stg.quarter_index_arr """)
#              spark.sql(""" drop table if exists b2b_stg.period_in_quarter_index_arr """)
#              spark.sql(""" drop table if exists b2b_stg.week_index_arr """)
#              spark.sql(""" drop table if exists b2b_stg.week_in_quarter_index_arr """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_embed_t8 """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_embed_t9 """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_embed_t10 """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_embed_t11 """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_embed_t11a """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_dashboard_embed_t6 """)
#              spark.sql(""" drop table if exists b2b_stg.year_index_embed """)
#              spark.sql(""" drop table if exists b2b_stg.quarter_index_embed """)
#              spark.sql(""" drop table if exists b2b_stg.period_in_quarter_index_embed """)
#              spark.sql(""" drop table if exists b2b_stg.week_index_embed """)
#              spark.sql(""" drop table if exists b2b_stg.week_in_quarter_index_embed """)
#              spark.sql(""" drop table if exists b2b_stg.week_in_year_index_embed """)
#              spark.sql(""" drop table if exists b2b_stg.updated_date_embed """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_usage_t2 """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_usage_t3 """)
#              spark.sql(""" drop table if exists b2b.enterprise_usage_rank """)
#              spark.sql(""" drop table if exists b2b_stg.year_index_try """)
#              spark.sql(""" drop table if exists b2b_stg.quarter_index_try """)
#              spark.sql(""" drop table if exists b2b_stg.period_in_quarter_index_try """)
#              spark.sql(""" drop table if exists b2b_stg.week_index_try """)
#              spark.sql(""" drop table if exists b2b_stg.week_in_quarter_index_try """)
#              spark.sql(""" drop table if exists b2b_stg.period_index_try """)
#              spark.sql(""" drop table if exists b2b_stg.period_title_try """)
#              spark.sql(""" drop table if exists b2b_stg.quarter_index_buy """)
#              spark.sql(""" drop table if exists b2b_stg.period_in_quarter_index_buy """)
#              spark.sql(""" drop table if exists b2b_stg.week_in_quarter_index_buy """)
#              spark.sql(""" drop table if exists b2b_stg.period_index_buy """)
#              spark.sql(""" drop table if exists b2b_stg.period_title_buy """)
#              spark.sql(""" drop table if exists b2b_stg.week_index_buy """)
#              spark.sql(""" drop table if exists b2b_stg.quarter_index_summary """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_db_usage_cr_t1 """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_db_usage_cr_t4 """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_db_usage_cr_t5 """)
#              spark.sql(""" drop table if exists b2b_stg.pdf_services_mai """)
#              spark.sql(""" drop table if exists b2b_stg.embed_mai """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_mai_pdf """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_dashboard_mai_embed """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_dashboard_mai """)
#              spark.sql(""" drop table if exists b2b_stg.etla_accounts_mapping """)
#              spark.sql(""" drop table if exists b2b_stg.enterprise_usage_contracts_1 """)
#              spark.sql(""" drop table if exists b2b.etla_usage_updated """)
#              spark.sql(""" drop table if exists b2b_stg.pdf_services_mai_activation """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_dashboard_mai_pdf_activation """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_executive_summary_dashboard """)
#              spark.sql(""" drop table if exists b2b_stg.dcia_dcp_accessibility_verb """)
#              spark.sql(""" drop table if exists b2b.dcia_dcp_user_usage_t1 """)
#              spark.sql(""" drop table if exists b2b_stg.extract_usage_etla_t1 """)
#              spark.sql(""" drop table if exists b2b.extract_usage_etla_t2 """)
#              spark.sql(""" drop table if exists b2b.extract_usage_users """)

#              try:
#                  dbutils.notebook.exit("SUCCESS")   
#              except Exception as e:                 
#                  print("exception:",e)
#          except Exception as e:
#              dbutils.notebook.exit(e)

# if __name__ == '__main__': 
#         main()

# COMMAND ----------

dbutils.notebook.exit("SUCCESS")