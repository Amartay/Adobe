# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" SET hive.auto.convert.join=FALSE """)
             spark.sql(""" INSERT overwrite TABLE b2b.fact_product_versions partition (asofdate)
SELECT cast(end_user_id as STRING) as end_user_id,
       end_user_name,
       CASE
           WHEN market_segment IN ('COMMERCIAL',
                                   'EDUCATION',
                                   'NON-PROFIT',
                                   'GOVERNMENT') THEN market_segment
           ELSE 'UNKNOWN'
       END AS market_segment,
      CASE
                 WHEN geo IN ('AMER',
                              'ASIA',
                              'JPN',
                              'EMEA') THEN geo
                 ELSE 'UNKNOWN'
             END AS geo,
       product_name,
       TYPE,
       product_ver,
             CASE
                 WHEN upper(os_platform) LIKE '%WIN%' THEN 'WIN'
                 WHEN upper(os_platform) LIKE '%MAC%' THEN 'MAC'
                 ELSE os_platform
             END AS os_platform,
             os_version,
              COUNT (DISTINCT machine_id) AS num_mcs,
             cast('{RUN_DATE}' as date) AS asofdate
FROM b2b.product_os_version_raw
where product_name != 'NA'
GROUP BY end_user_id,
         end_user_name,
         CASE
             WHEN market_segment IN ('COMMERCIAL',
                                     'EDUCATION',
                                     'NON-PROFIT',
                                     'GOVERNMENT') THEN market_segment
             ELSE 'UNKNOWN'
         END,
         product_name,
         TYPE,
         product_ver,
         CASE
             WHEN geo IN ('AMER',
                          'ASIA',
                          'JPN',
                          'EMEA') THEN geo
             ELSE 'UNKNOWN'
         END,
         CASE
             WHEN upper(os_platform) LIKE '%WIN%' THEN 'WIN'
             WHEN upper(os_platform) LIKE '%MAC%' THEN 'MAC'
             ELSE os_platform
         END,
         os_version """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()