# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')

             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","1500")
             spark.conf.set("spark.databricks.delta.autoCompact.enabled", "True")
             spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "True")
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')
             #spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")


             spark.conf.set("spark.sql.statistics.histogram.enabled",True)
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewedJoin.enabled",True)


             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

            
             spark.sql(""" set hive.optimize.distinct.rewrite=true """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.Compress.intermediate=true """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
             spark.sql(""" SET hive.auto.convert.join=true """)
             spark.sql(""" SET hive.merge.mapfiles=true """)
             spark.sql(""" SET hive.merge.mapredfiles=true """)
             spark.sql(""" SET hive.merge.size.per.task=512000000 """)
             spark.sql(""" SET hive.merge.smallfiles.avgsize=512000000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=false """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" set hive.support.concurrency = false """)

             df_applaunch_all = spark.sql(""" 
select 
DISTINCT
substr((params['Adobe_ID']), 1,24) as member_guid,
(params['AAM_OOBE_THOR_INSTALL_VERSION_PVALUE']) as thor_ver,
cast((params['AAM_OOBE_THOR_STATUS_INSTALL_PVALUE']) as int) as thor_install_status,
cast('NULL' as int) as org_id,
(params['LEID']) as CC_ver,
cast((params['OOBE_StartDate']) as bigint) as launch_count_epochtime,
(params['OOBE_User_Action']) as user_action,
(params['OOBE_App_LEID'])as app_leid,
cast((params['OOBE_App_Launch_Count']) as int) as launch_count,
(params['OOBE_MachineID']) as machine_id,
(params['OOBE_Serial']) as serialnum,
regexp_extract((params['OS_Version']),'^([^\:]+)\.?',1) as os_platform,
'AMT_LIB' as operating_mode, 
regexp_replace(regexp_replace((params['OS_Version']),'[a-zA-Z:=]',''),',','.') as os_version,
to_date(timestring) as date,
month(timestring) as month,
year(timestring) as year,
(params['Entitlement_Type']) as license_type
FROM darwin.ets_applaunch_events s
WHERE to_date(s.timestring) >= date_add(last_day(add_months(current_date, -3)),1) """)
             
             df_applaunch_all.createOrReplaceTempView("df_applaunch_all")
             
             
             df_ngl = spark.sql(""" 
SELECT 
DISTINCT
member_guid,
'NULL' AS thor_ver, 
cast('NULL' as int) AS thor_install_status,
cast(split(event_org_guid,'@')[0] as int) as org_id,
source_version AS CC_ver, 
cast('NULL' as bigint) AS launch_count_epochtime,
event_workflow  AS user_action,
source_name AS app_leid,
cast('NULL' as int) AS launch_count, 
event_device_guid AS machine_id,
ngl_license_id AS serialnum, 
source_platform as os_platform,
ngl_operating_mode as operating_mode,  
source_os_version AS os_version, 
cast(event_date as date) AS date, 
month(event_date) AS month, 
year(event_date) AS year, 
'NGL' AS license_type
FROM darwin.ngl_cops_events
WHERE event_date >= date_add(last_day(add_months(current_date, -3)),1) 
and ngl_operating_mode not like '%FRL%'
and event_category = 'SERVICE'
and event_subcategory = 'INITIAL'
and event_type = 'api'
and event_subtype = 'response'
and event_language != 'null' """)
             
             df_ngl.createOrReplaceTempView("df_ngl")
             
             
             df_frl = spark.sql(""" 
SELECT member_guid,
         'NULL' AS thor_ver, 
         cast('NULL' as int) AS thor_install_status,
         cast(split(event_org_guid,'@')[0] as int) as org_id,
         source_version AS CC_ver, 
         cast('NULL' as bigint) AS launch_count_epochtime,
         event_workflow  AS user_action,
         source_name AS app_leid,
         cast('NULL' as int) AS launch_count, 
         event_device_guid AS machine_id,
         ngl_license_id AS serialnum, 
         source_platform as os_platform,
         ngl_operating_mode as operating_mode, 
         source_os_version AS os_version, 
         cast(event_date as date) AS date, 
         month(event_date) AS month, 
         year(event_date) AS year, 
         'FRL' AS license_type
FROM darwin.ngl_cops_events
WHERE event_date >= date_add(last_day(add_months(current_date, -3)),1) 
and ngl_operating_mode like '%FRL%' """)
             
             df_frl.createOrReplaceTempView("df_frl")
             
             
#              df_grace_license = spark.sql(""" 
# SELECT upper(split(ets_cops_events.userguid, '@')[0]) AS member_guid,
#        'NULL' AS thor_ver,
#        cast('NULL' as int) AS thor_install_status,
#       cast(split(params['event.org_guid'],'@')[0] as int)  as org_id,
#        ets_cops_events.params['source.version'] AS CC_ver,
#        cast('NULL' as bigint) AS launch_count_epochtime,
#        params['event.workflow'] as user_action,
#        ets_cops_events.params['source.name'] AS app_leid,
#        cast('NULL' as int) AS launch_count,
#        ets_cops_events.params['event.device_guid'] AS machine_id,
#        ets_cops_events.params['ngl.license_id'] AS serialnum,
#        params['source.platform'] as os_platform,
#        params['ngl.operating_mode'] as operating_mode,
#        ets_cops_events.params['source.os_version'] AS os_version,
#        cast(event_date as date) AS date,
#        month(event_date) AS MONTH,
#        year(event_date) AS YEAR,
#        'GRACE_LICENSE' AS license_type
# FROM darwin.ets_cops_events
# WHERE ets_cops_events.event_code = 'COPS_SERVICE'
#   AND ets_cops_events.params['ngl.license_id'] = 'TEMP_LICENSE_ADHOC'
#   AND ets_cops_events.event_date >= date_add(last_day(add_months(CURRENT_DATE, -3)),1) """)
             
#             df_grace_license.createOrReplaceTempView("df_grace_license")
             

             df_applaunch_all_final = spark.sql("""
                                                select * from df_applaunch_all
                                                union
                                                select * from df_ngl
                                                union
                                                select * from df_frl
                                                --union
                                                --select * from df_grace_license
                                                """)
             
             df_applaunch_all_final.createOrReplaceTempView("df_applaunch_all_final")
             

             spark.sql("""
                       INSERT overwrite TABLE b2b.applaunch_all partition (MONTH, YEAR, license_type)
                       select * from df_applaunch_all_final
                       """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()
