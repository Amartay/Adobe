# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

            
             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")
    
             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.execution.engine = mr """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" drop table if exists b2b_stg.app_launch_90 """)
             spark.sql(""" create table b2b_stg.app_launch_90  AS
SELECT *
FROM b2b.applaunch_all
WHERE date BETWEEN date_sub(CURRENT_DATE,
                            90) AND CURRENT_DATE
  AND YEAR >= '2021' """)
             spark.sql(""" drop table if exists b2b.product_os_version_raw """)
             spark.sql(""" create table  b2b.product_os_version_raw  AS
SELECT *,
       CURRENT_DATE AS asofdate
FROM
  (SELECT DISTINCT end_user_id,
                   end_user_name,
                   market_segment,
                   geo,
                   app_leid,
                   product_name,
                   product_ver,
                   os_platform,
                   os_version,
                   machine_id,
                   TYPE
   FROM
     (SELECT c.end_user_id,
             end_user_name,
             market_segment,
             geo,
             app_leid,
             product_name,
             product_ver,
             os_platform,
             os_version,
             machine_id,
             TYPE,
             ROW_NUMBER() OVER(PARTITION BY product_name,machine_id
                               ORDER BY date DESC) AS rownum
      FROM
        (SELECT DISTINCT cast(end_user AS int) AS end_user_id,
                         end_user_name,
                         market_segment,
                         geo
         FROM enterprise.ca_ent_arr_model_all
         WHERE date_date >= date_sub(CURRENT_DATE,90)
           AND contract_end_date >= date_date )c
      INNER JOIN
        (SELECT serial_number,
                CASE
                    WHEN program_type = 'FLP' THEN 'ETLA_SERIAL'
                    WHEN program_type = 'CLP' THEN 'CLP_SERIAL'
                    WHEN program_type = 'TLP' THEN 'TLP_SERIAL'
                END AS TYPE,
                end_user_id
         FROM b2b.fact_serial_sku_txt) l ON l.end_user_id = c.end_user_id
      INNER JOIN
        (SELECT serialnum,
                product_name,
                app_leid,
                l.version_code AS product_ver,
                os_platform,
                os_version,
                machine_id, date
         FROM b2b_stg.app_launch_90 a
         LEFT JOIN ocf_analytics.dim_product_leid l ON l.leid = UPPER(a.app_leid)
         LEFT JOIN b2b.product_leid_map m ON m.product = l.product_code
         WHERE license_type = 'perpetual' )d ON d.serialnum = l.serial_number)m
   WHERE rownum =1 
   UNION ALL SELECT DISTINCT end_user_id,
                             end_user_name,
                             market_segment,
                             geo,
                             app_leid,
                             product_name,
                             product_ver,
                             os_platform,
                             os_version,
                             machine_id,
                             TYPE
   FROM
     (SELECT c.end_user_id,
             end_user_name,
             market_segment,
             geo,
             app_leid,
             product_name,
             cc_ver AS product_ver,
             os_platform,
             os_version,
             machine_id,
             'ETLA_NUD' AS TYPE,
             ROW_NUMBER() OVER(PARTITION BY product_name, machine_id
                               ORDER BY date DESC) AS rownum
      FROM
        (SELECT DISTINCT cast(end_user AS int) AS end_user_id,
                         end_user_name,
                         market_segment,
                         geo
         FROM enterprise.ca_ent_arr_model_all
         WHERE date_date >= date_sub(CURRENT_DATE,90)
           AND contract_end_date >= date_date )c
      INNER JOIN
        (SELECT DISTINCT member_guid,
                         end_user_id
         FROM b2b.snapshot_fact_enterprise_member_license_delegation d
         LEFT JOIN b2b.enduserid_orgid_mapping o ON d.org_id = o.org_id
         WHERE is_valid = 'Y' and d.asofdate='{RUN_DATE}'
           AND contract_end_date >= CURRENT_DATE
           AND delegation_status = 'ACCEPTED'
           AND contract_offer_type = 'ETLA' )d ON c.end_user_id = d.end_user_id
      INNER JOIN b2b_stg.app_launch_90 a ON d.member_guid = a.member_guid
      LEFT JOIN b2b.product_leid_map m ON m.product = a.app_leid
      WHERE license_type = 'NGL' )i
   WHERE rownum =1 
   UNION ALL SELECT DISTINCT end_user_id,
                             end_user_name,
                             market_segment,
                             geo,
                             app_leid,
                             product_name,
                             product_ver,
                             os_platform,
                             os_version,
                             machine_id,
                             TYPE
   FROM
     (SELECT c.end_user_id,
             end_user_name,
             market_segment,
             geo,
             app_leid,
             product_name,
             l.version_code AS product_ver,
             os_platform,
             os_version,
             machine_id,
             'ETLA_NUD' AS TYPE,
             ROW_NUMBER() OVER(PARTITION BY product_name,machine_id
                               ORDER BY date DESC) AS rownum
      FROM
        (SELECT DISTINCT cast(end_user AS int) AS end_user_id,
                         end_user_name,
                         market_segment,
                         geo
         FROM enterprise.ca_ent_arr_model_all
         WHERE date_date >= date_sub(CURRENT_DATE,90)
           AND contract_end_date >= date_date )c
      INNER JOIN
        (SELECT DISTINCT member_guid,
                         end_user_id
         FROM b2b.snapshot_fact_enterprise_member_license_delegation d
         LEFT JOIN b2b.enduserid_orgid_mapping o ON d.org_id = o.org_id
         WHERE is_valid = 'Y' and d.asofdate='{RUN_DATE}'
           AND contract_end_date >= CURRENT_DATE
           AND contract_offer_type = 'ETLA'
           AND delegation_status = 'ACCEPTED' )d ON c.end_user_id = d.end_user_id
      INNER JOIN b2b_stg.app_launch_90 a ON d.member_guid = a.member_guid
      LEFT JOIN ocf_analytics.dim_product_leid l ON l.leid = UPPER(a.app_leid)
      LEFT JOIN b2b.product_leid_map m ON m.product = l.product_code
      WHERE license_type = 'subscription' )e
   WHERE rownum =1
   UNION ALL SELECT DISTINCT end_user_id,
                             end_user_name,
                             market_segment,
                             geo,
                             app_leid,
                             product_name,
                             product_ver,
                             os_platform,
                             os_version,
                             machine_id,
                             TYPE
   FROM
     (SELECT d.org_id AS end_user_id,
             org_name AS end_user_name,
             market_segment,
             geo_code AS geo,
             app_leid,
             product_name,
             cc_ver AS product_ver,
             os_platform,
             os_version,
             machine_id,
             'EVIP_NUD' AS TYPE,
             ROW_NUMBER() OVER(PARTITION BY product_name, machine_id
                               ORDER BY date DESC) AS rownum
      FROM b2b.snapshot_fact_enterprise_member_license_delegation d
      INNER JOIN b2b_stg.app_launch_90 a ON d.member_guid = a.member_guid
      LEFT JOIN b2b.product_leid_map m ON m.product = a.app_leid
      WHERE a.license_type = 'NGL' and d.asofdate='{RUN_DATE}'
        AND is_valid = 'Y'
        AND contract_end_date >= CURRENT_DATE
        AND delegation_status = 'ACCEPTED'
        AND contract_offer_type = 'EVIP' )i
   WHERE rownum =1 
   UNION ALL SELECT DISTINCT end_user_id,
                             end_user_name,
                             market_segment,
                             geo,
                             app_leid,
                             product_name,
                             product_ver,
                             os_platform,
                             os_version,
                             machine_id,
                             TYPE
   FROM
     (SELECT d.org_id AS end_user_id,
             org_name AS end_user_name,
             market_segment,
             geo_code AS geo,
             app_leid,
             product_name,
             l.version_code AS product_ver,
             os_platform,
             os_version,
             machine_id,
             'EVIP_NUD' AS TYPE,
             ROW_NUMBER() OVER(PARTITION BY product_name, machine_id
                               ORDER BY date DESC) AS rownum
      FROM b2b.snapshot_fact_enterprise_member_license_delegation d
      INNER JOIN b2b_stg.app_launch_90 a ON d.member_guid = a.member_guid
      LEFT JOIN ocf_analytics.dim_product_leid l ON l.leid = UPPER(a.app_leid)
      LEFT JOIN b2b.product_leid_map m ON m.product = l.product_code
      WHERE a.license_type = 'subscription' and d.asofdate='{RUN_DATE}'
        AND is_valid = 'Y'
        AND contract_end_date >= CURRENT_DATE
        AND contract_offer_type = 'EVIP'
        AND delegation_status = 'ACCEPTED' )e
   WHERE rownum =1 ) a """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()