# Databricks notebook source
# MAGIC %python
# MAGIC from email.message import EmailMessage
# MAGIC from pyspark.sql import SparkSession
# MAGIC import smtplib
# MAGIC import pandas
# MAGIC
# MAGIC def send_email():
# MAGIC     # Read the Parquet file into a DataFrame
# MAGIC     # df = spark.sql("select d.`database`, d.tablename,m.last_available_date from b2b.dropped_tables d inner join b2b.master_table_list m on m.`database`= d.`database` and m.tablename=d.tablename ")
# MAGIC     #Added workflow, team details
# MAGIC     df = spark.sql(''' select msk.database,msk.tablename,msk.last_available_date,case when msk.workflow_name is null then "NA" else msk.workflow_name end as workflow_name,case when msk.team is null then "NA" else msk.team end as team from ((select d.`database`, d.tablename,m.last_available_date from b2b.dropped_tables d inner join b2b.master_table_list m on m.`database`= d.`database` and m.tablename=d.tablename) a left join b2b.monitoring_tables mt on a.tablename = mt.table_name) msk ''')
# MAGIC     df3=df.toPandas()
# MAGIC     html_table = df3.to_html(index=False)
# MAGIC     fromaddr = 'do-not-reply-dpaas-dbx@adobe.com'
# MAGIC     toaddrs = "lat57607@adobe.com,dme_b2b_analytics_ops_alerts@adobe.com"
# MAGIC     SMTPServer = 'adobe-com.mail.protection.outlook.com'
# MAGIC     port = 25 #587
# MAGIC     if df.count() != 0:
# MAGIC         html_content = """
# MAGIC         <html>
# MAGIC         <body>
# MAGIC         <pre><b>Hi All, Please find the tables dropped in DBX. 
# MAGIC         {html_table}
# MAGIC         [This is an auto generated email, please do not reply]</b></pre></body></html>""" 
# MAGIC     else:
# MAGIC         html_content = """
# MAGIC         <html>
# MAGIC         <body>
# MAGIC         <pre><b>Hi All, No tables dropped in b2b and b2b_stg schema in DBX. 
# MAGIC         {html_table}
# MAGIC         [This is an auto generated email, please do not reply]</b></pre></body></html>"""
# MAGIC     msg = EmailMessage()
# MAGIC     msg['Subject'] = "Tables dropped in DBX"
# MAGIC     msg['From'] = fromaddr
# MAGIC     msg['To'] = toaddrs
# MAGIC     msg.set_content(html_content.format(html_table=html_table), subtype='html')
# MAGIC     server = smtplib.SMTP(SMTPServer, port)
# MAGIC     server.send_message(msg)
# MAGIC     server.quit()

# COMMAND ----------

from pyspark.sql.types import StringType, DateType, StructType, StructField
final_table = spark.sql("select database,tablename, last_available_date from b2b.master_table_list")
schema = StructType(
    [
        StructField("database", StringType(), True),
        StructField("tablename", StringType(), True),
        StructField("last_available_date", DateType(), True),
    ]
)
drop_table = spark.createDataFrame([], schema)
#drop_table  = spark.sql("select * from b2b.dropped_tables")
spark.sql("show tables in b2b_stg").createOrReplaceTempView("tables_list_b2b_stg")
spark.sql("show tables in b2b").createOrReplaceTempView("tables_list_b2b")

new_tables = spark.sql("(select database,tablename,null as last_available_date from tables_list_b2b_stg where tableName not like '%_on_prem' and isTemporary = false union select database, tablename, null as last_available_date from tables_list_b2b where tableName not like '%_on_prem' and isTemporary = false) except (select database,tablename, null as last_available_date from b2b.master_table_list) ")
new_tables.createOrReplaceTempView("new_tables")
final_table = final_table.union(new_tables)
final_table.write.mode("overwrite").saveAsTable("b2b.master_table_list")
dropped_tables = spark.sql(" select database, tablename, null as last_available_date from (select database,tablename from b2b.master_table_list except (select database,tablename from tables_list_b2b_stg where tableName not like '%_on_prem' and isTemporary = false union select database,tablename from tables_list_b2b where tableName not like '%_on_prem' and isTemporary = false)) ")
drop_table = drop_table.union(dropped_tables)
drop_table.write.mode("overwrite").saveAsTable("b2b.dropped_tables")
spark.sql(""" update b2b.master_table_list set last_available_date = current_Date() -1 where database in (select database from b2b.dropped_tables) and tablename in (select tablename from b2b.dropped_tables) and last_available_date is null """)
send_email()

# COMMAND ----------

#archive tables older than 15 days
insert_df = spark.sql(''' insert into b2b.archived_drop_tables 
select msk.database,msk.tablename,msk.last_available_date,
case when msk.workflow_name is null then "NA" else msk.workflow_name end as workflow_name,
case when msk.team is null then "NA" else msk.team end as team from (
(select d.`database`, d.tablename,m.last_available_date from b2b.dropped_tables d inner join b2b.master_table_list m on m.`database`= d.`database` and m.tablename=d.tablename) a left join b2b.monitoring_tables mt on a.tablename = mt.table_name) msk where date_diff(current_date(),last_available_date) >= 15 ''')

delete_master_df = spark.sql(''' delete from  b2b.master_table_list where tablename in (
select tablename from b2b.archived_drop_tables) and `database` in (select `database` from b2b.archived_drop_tables) ''')
