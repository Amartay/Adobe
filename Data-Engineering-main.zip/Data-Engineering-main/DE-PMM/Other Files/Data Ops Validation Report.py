# Databricks notebook source
from email.message import EmailMessage
from pyspark.sql import SparkSession
import smtplib
import pandas
import datetime as dt     

def send_email():
    df_monitoring_tables = spark.sql("select distinct table_name from b2b.monitoring_tables")
    df_workflow_name = spark.sql("select  * from b2b.monitoring_tables")
    df_result = spark.sql(''' select distinct table_name from b2b_stg.table_stats union  select distinct table_name from b2b_stg.sqoop_table_details union select distinct table_name from b2b_stg.tabledetails_dbx where table_name in ('chorus_calls', 'chorus_calls_participants', 'chorus_calls_trackers', 'chorus_user_daily_events', 'chorus_user_daily_scorecards','manual_file_amer_gbd','mmterritory','rv_td_brdg_org_ecc', 'vw_tf_accountsegmentationsnapshot', 'uda_vw_tf_adobesignconsolidatedarr', 'rv_td_sub', 'mm_growth_baseline', 'csm_euid_orgid') ''')
    df_result = df_result.filter(df_result.table_name != "channel_rone_r360_k12_extract") # Added on a temporary basis will be removed in few days
    df_notpopulated = df_result.exceptAll(df_monitoring_tables)
    df_notpopulated = df_notpopulated.filter(df_notpopulated.table_name.isNotNull())
    df_notpopulated = df_notpopulated.join(df_workflow_name,df_workflow_name.table_name == df_notpopulated.table_name,'left').select(df_notpopulated.table_name,df_workflow_name.workflow_name)
    df3=df_notpopulated.toPandas()
    html_table = df3.to_html(index=False)
    fromaddr = 'do-not-reply-dpaas-dbx@adobe.com'
    toaddrs = "lat57607@adobe.com"
    SMTPServer = 'adobe-com.mail.protection.outlook.com'
    port = 25 #587
    if df_notpopulated.count() != 0:
        html_content = """
        <html>
        <body>
        <pre><b>Hi All, Please find the tables not populated in Ops Report. 
        {html_table}

        Below are the possible reasons why above tables are not populated in  
        1. Workflows might have failed for the latest run or Workflows corresponding to those tables might be running during Job Monitoring Script Execution(in case of truncate and load Tables)

        [This is an auto generated email, please do not reply]</b></pre></body></html>""" 
    else:
        html_content = """
        <html>
        <body>
        <pre><b>Hi All, No tables are missing from Ops Report.
        [This is an auto generated email, please do not reply]</b></pre></body></html>"""
    msg = EmailMessage()
    msg['Subject'] = "Ops Report Validation"
    msg['From'] = fromaddr
    msg['To'] = toaddrs
    msg.set_content(html_content.format(html_table=html_table), subtype='html')
    server = smtplib.SMTP(SMTPServer, port)
    server.send_message(msg)
    server.quit()

# COMMAND ----------

send_email()
