# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

# DBTITLE 1,5% mail alert
# MAGIC %python
# MAGIC from email.message import EmailMessage
# MAGIC import smtplib
# MAGIC
# MAGIC def send_email(body):
# MAGIC     fromaddr = 'do-not-reply-dpaas-dbx@adobe.com'
# MAGIC     toaddrs = "lat57607@adobe.com,lat41525@adobe.com"
# MAGIC     SMTPServer = 'adobe-com.mail.protection.outlook.com'
# MAGIC     port = 25 #587
# MAGIC     html_content = """
# MAGIC     <html>
# MAGIC     <body>
# MAGIC     <pre><b>Hi All, 
# MAGIC     The table "b2b.{TABLE_NAME}" has QC ISSUES for {B2B_RUN_DATE} snapshot date.
# MAGIC     Please find the below details
# MAGIC     {body}
# MAGIC     [This is an auto generated email, please do not reply]</b>
# MAGIC     </pre>
# MAGIC     </body>
# MAGIC     </html>
# MAGIC     """
# MAGIC     msg = EmailMessage()
# MAGIC     msg['Subject'] = " QC ISSUE"
# MAGIC     msg['From'] = fromaddr
# MAGIC     msg['To'] = toaddrs
# MAGIC     msg.set_content(html_content.format(TABLE_NAME= TABLE_NAME,B2B_RUN_DATE=B2B_RUN_DATE,body=body), subtype='html')
# MAGIC     server = smtplib.SMTP(SMTPServer, port)
# MAGIC     server.send_message(msg)
# MAGIC     server.quit()

# COMMAND ----------

# DBTITLE 1,Last 3 weeks QC mail alert
# MAGIC %python
# MAGIC from email.message import EmailMessage
# MAGIC import smtplib
# MAGIC
# MAGIC def qc_mail(subject):
# MAGIC     fromaddr = 'do-not-reply-dpaas-dbx@adobe.com'
# MAGIC     toaddrs = "lat57607@adobe.com,lat41525@adobe.com"
# MAGIC     SMTPServer = 'adobe-com.mail.protection.outlook.com'
# MAGIC     port = 25 #587
# MAGIC     html_content = """
# MAGIC     <html>
# MAGIC     <body>
# MAGIC     <pre><b>Hi All, 
# MAGIC     The table "b2b.{TABLE_NAME}" has QC ISSUE for last 3 weeks.
# MAGIC     PLease find below details 
# MAGIC     {subject}
# MAGIC     [This is an auto generated email, please do not reply]</b>
# MAGIC     </pre>
# MAGIC     </body>
# MAGIC     </html>
# MAGIC     """
# MAGIC     msg = EmailMessage()
# MAGIC     msg['Subject'] = "LAST 3 WEEKS QC ISSUE"
# MAGIC     msg['From'] = fromaddr
# MAGIC     msg['To'] = toaddrs
# MAGIC     msg.set_content(html_content.format(TABLE_NAME= TABLE_NAME,subject=subject), subtype='html')
# MAGIC     server = smtplib.SMTP(SMTPServer, port)
# MAGIC     server.send_message(msg)
# MAGIC     server.quit()

# COMMAND ----------

# DBTITLE 1,WoW Funnel QC
import numpy as np
import datetime,time
from dateutil.relativedelta import relativedelta

prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

msck_df = spark.sql(''' msck repair table b2b.b2b_acro_deployment_adoption_funnel ''')
df = spark.sql(''' select as_of_date ,sum(total_seats_provisioned) as total_seats_provisioned, sum(service_seats_provisioned) as service_seats_provisioned,sum(non_service_seats_provisioned) non_service_seats_provisioned, sum(total_seats_delegated)total_seats_delegated,sum(service_seats_delegated)service_seats_delegated,sum(non_service_seats_delegated)non_service_seats_delegated,sum(non_service_seats_activated)non_service_seats_activated,sum(service_seats_activated)service_seats_activated, sum(frl_machines_deployed)frl_machines_deployed,sum(frl_seats_provisioned)frl_seats_provisioned ,sum(acrobat_desktop_usage)acrobat_desktop_usage,sum(acrobat_mobile_usage)acrobat_mobile_usage,sum(pdf_services_usage)pdf_services_usage,sum(o365_usage) o365_usage, sum(num_users_pdf_services_enabled)num_users_pdf_services_enabled from b2b.b2b_acro_deployment_adoption_funnel where as_of_date in  ('{B2B_RUN_DATE}','{prev_week_date}') group by 1 order by 1 asc '''.format(B2B_RUN_DATE = B2B_RUN_DATE,prev_week_date = prev_week_date))

display(df)
df_pandas = df.select(df.columns[1:]).toPandas()
df_pandas.diff()

df_pandas['WoWTotal_seats_prov'] = np.round(df_pandas['total_seats_provisioned'].pct_change() * 100,2)
df_pandas['WoWservice_Seats_prov'] = np.round(df_pandas['service_seats_provisioned'].pct_change() * 100,2)
df_pandas['WoWnon_Service_seats_prov'] = np.round(df_pandas['non_service_seats_provisioned'].pct_change() * 100,2)
df_pandas['WoWtotal_seats_dele'] = np.round(df_pandas['total_seats_delegated'].pct_change() * 100,2)
df_pandas['WoWservice_seats_dele'] = np.round(df_pandas['service_seats_delegated'].pct_change() * 100,2)
df_pandas['WoWnon_service_Seats_dele'] = np.round(df_pandas['non_service_seats_delegated'].pct_change() * 100,2)
df_pandas['WoWnon_service_seats_acti'] = np.round(df_pandas['non_service_seats_activated'].pct_change() * 100,2)
df_pandas['WoWservice_seats_acti'] = np.round(df_pandas['service_seats_activated'].pct_change() * 100,2)
df_pandas['WoWfrl_machines_deployed'] = np.round(df_pandas['frl_machines_deployed'].pct_change() * 100,2)
df_pandas['WoWfrl_seats_provisioned'] = np.round(df_pandas['frl_seats_provisioned'].pct_change() * 100,2)
df_pandas['WoWacrobat_desktop_usage'] = np.round(df_pandas['acrobat_desktop_usage'].pct_change() * 100,2)
df_pandas['WoWacrobat_mobile_usage'] = np.round(df_pandas['acrobat_mobile_usage'].pct_change() * 100,2)
df_pandas['WoWpdf_services_usage'] = np.round(df_pandas['pdf_services_usage'].pct_change() * 100,2)
df_pandas['WoWo365_usage_mau'] = np.round(df_pandas['o365_usage'].pct_change() * 100,2)
df_pandas['WoWnum_users_pdf_services_enabled'] = np.round(df_pandas['num_users_pdf_services_enabled'].pct_change() * 100,2)
df_pandas = df_pandas.dropna()
final_df = df_pandas.iloc[:, 15:]
display(final_df)

# COMMAND ----------

# DBTITLE 1,Funnel +-5% check
TABLE_NAME = 'b2b_acro_deployment_adoption_funnel'
gt_df = final_df[(final_df.WoWTotal_seats_prov > 5) | (final_df.WoWservice_Seats_prov > 5) | (final_df.WoWnon_Service_seats_prov > 5) | (final_df.WoWtotal_seats_dele > 5) | (final_df.WoWservice_seats_dele > 5) | (final_df.WoWnon_service_Seats_dele > 5) | (final_df.WoWnon_service_seats_acti > 5) | (final_df.WoWnon_service_seats_acti > 5) | (final_df.WoWservice_seats_acti > 5) | (final_df.WoWfrl_machines_deployed > 5) | (final_df.WoWfrl_seats_provisioned > 5) | (final_df.WoWacrobat_desktop_usage > 5) | (final_df.WoWacrobat_mobile_usage > 5) | (final_df.WoWpdf_services_usage > 5) | (final_df.WoWo365_usage_mau > 5) | (final_df.WoWnum_users_pdf_services_enabled > 5) ]
less_df = final_df[(final_df.WoWTotal_seats_prov < -5) | (final_df.WoWservice_Seats_prov < -5) | (final_df.WoWnon_Service_seats_prov < -5) | (final_df.WoWtotal_seats_dele < -5) | (final_df.WoWservice_seats_dele < -5) | (final_df.WoWnon_service_Seats_dele < -5) | (final_df.WoWnon_service_seats_acti < -5) | (final_df.WoWnon_service_seats_acti < -5) | (final_df.WoWservice_seats_acti < -5) | (final_df.WoWfrl_machines_deployed < -5) | (final_df.WoWfrl_seats_provisioned < -5) | (final_df.WoWacrobat_desktop_usage < -5) | (final_df.WoWacrobat_mobile_usage < -5) | (final_df.WoWpdf_services_usage < -5) | (final_df.WoWo365_usage_mau < -5) | (final_df.WoWnum_users_pdf_services_enabled < -5) ]
print(len(gt_df))
print(len(less_df))
if len(gt_df) == 0 and len(less_df) == 0:
    pass
else:
    send_email()
    pass

# COMMAND ----------

# DBTITLE 1,LAST 3 WEEKS FUNNEL METRICS QC
TABLE_NAME = 'b2b_acro_deployment_adoption_funnel'
import datetime,time
from dateutil.relativedelta import relativedelta

one_week_ago = B2B_RUN_DATE - relativedelta(days=7)
two_week_ago = one_week_ago - relativedelta(days=7)
three_week_ago = two_week_ago - relativedelta(days=7)

acro_df = spark.sql(''' select as_of_date ,sum(total_seats_provisioned) as total_seats_provisioned, sum(service_seats_provisioned) as service_seats_provisioned,sum(non_service_seats_provisioned) non_service_seats_provisioned, sum(total_seats_delegated)total_seats_delegated,sum(service_seats_delegated)service_seats_delegated,sum(non_service_seats_delegated)non_service_seats_delegated,sum(non_service_seats_activated)non_service_seats_activated,sum(service_seats_activated)service_seats_activated, sum(frl_machines_deployed)frl_machines_deployed,sum(frl_seats_provisioned)frl_seats_provisioned ,sum(acrobat_desktop_usage)acrobat_desktop_usage,sum(acrobat_mobile_usage)acrobat_mobile_usage,sum(pdf_services_usage)pdf_services_usage,sum(o365_usage) o365_usage, sum(num_users_pdf_services_enabled)num_users_pdf_services_enabled from b2b.b2b_acro_deployment_adoption_funnel where as_of_date in  ('{B2B_RUN_DATE}','{three_week_ago}','{one_week_ago}','{two_week_ago}') group by 1 order by 1 asc '''.format(B2B_RUN_DATE = B2B_RUN_DATE,three_week_ago = three_week_ago,one_week_ago=one_week_ago,two_week_ago=two_week_ago))
acro_df.show()
subject = ''
for i in acro_df.columns[1:]:
    print(i)
    column_value_list = [row[i] for row in acro_df.select(i).collect()]
    print(column_value_list)
    if (column_value_list[3] < column_value_list[2] and column_value_list[2] < column_value_list[1] and column_value_list[1] < column_value_list[0]) :
        a = "values are decreasing for {i} last 3 weeks\n".format(i=i)
        subject = subject+a
        #qc_mail(a)
    else:
        pass
print(len(subject))
if len(subject) == 0:
    pass
else:
    qc_mail(subject)
