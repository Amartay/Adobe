# Databricks notebook source
from datetime import date
from datetime import datetime, timedelta
import json

run_day = date.today().strftime("%A")
today = datetime.today()
days_since_friday = (today.weekday() + 3) % 7
days_since_saturday = (today.weekday() + 2) % 7
last_friday = today - timedelta(days=days_since_friday)
last_saturday = today - timedelta(days=days_since_saturday)
run_date = last_friday.date()
to_date = last_friday.date()
today = today.date()
yesterday = today - timedelta(days = 1)
last_week_friday = today - timedelta(days = 7)


if run_day in ('Monday'):
    is_monday = 1
    TODAY = today
    RUN_DATE = run_date
    FROM_DATE = last_saturday.date() - timedelta(days=7)
    TO_DATE = to_date
    B2B_RUN_DATE = run_date
    YESTERDAY = yesterday
elif run_day in ('Thursday'):
    is_thursday = 1
    TODAY = today
    RUN_DATE = run_date
    FROM_DATE = last_saturday.date() - timedelta(days=7)
    TO_DATE = to_date
    B2B_RUN_DATE = run_date
    YESTERDAY = yesterday
elif run_day in ('Sunday'):
    is_sunday = 1
    TODAY = today
    RUN_DATE = run_date
    FROM_DATE = last_saturday.date() - timedelta(days=7)
    TO_DATE = to_date
    YESTERDAY = yesterday
    B2B_RUN_DATE = run_date
elif run_day in ('Friday'):
    is_friday = 1
    TODAY = today
    FROM_DATE = last_saturday.date() - timedelta(days=7)
    TO_DATE = to_date
    RUN_DATE = run_date
    B2B_RUN_DATE = last_week_friday
    YESTERDAY = yesterday
elif run_day in ('Tuesday'):
    is_tuesday = 1
    TODAY = today
    RUN_DATE = run_date
    B2B_RUN_DATE = run_date
    FROM_DATE = last_saturday.date() - timedelta(days=7)
    TO_DATE = to_date
    YESTERDAY = yesterday
elif run_day in ('Wednesday'):
    is_wednesday = 1
    TODAY = today
    RUN_DATE = run_date
    B2B_RUN_DATE = run_date
    FROM_DATE = last_saturday.date() - timedelta(days=7)
    TO_DATE = to_date
    YESTERDAY = yesterday
elif run_day in ('Saturday'):
    is_saturday =1
    TODAY = today
    RUN_DATE = run_date
    B2B_RUN_DATE = run_date
    FROM_DATE = last_saturday.date() - timedelta(days=7)
    TO_DATE = to_date
    YESTERDAY = yesterday

# COMMAND ----------

def updatee(param_load):
    if run_day in ('Sunday','Monday','Thursday'):
        param_load['RUN_DATE'] = ''
        param_load['TODAY_DATE'] = ''
        param_load['FROM_DATE'] = ''
        param_load['TO_DATE'] = ''
        param_load['YESTERDAY'] = ''
        param_load['B2B_RUN_DATE'] = ''
        if str(param_load['RUN_DATE']) == '' or str(param_load['TODAY_DATE']) == '' or str(param_load['FROM_DATE']) == '' or str(param_load['TO_DATE']) == '' or str(param_load['B2B_RUN_DATE']) == '' or str(param_load['YESTERDAY']) == '':
            param_load['RUN_DATE'] = str(RUN_DATE)
            param_load['TODAY_DATE'] = str(TODAY)
            param_load['FROM_DATE'] = str(FROM_DATE)
            param_load['TO_DATE'] = str(TO_DATE)
            param_load['B2B_RUN_DATE'] = str(B2B_RUN_DATE)
            param_load['YESTERDAY'] = str(YESTERDAY)
    else:
        param_load['RUN_DATE'] = ''
        param_load['TODAY_DATE'] = ''
        param_load['B2B_RUN_DATE'] = ''
        param_load['FROM_DATE'] = ''
        param_load['TO_DATE'] = ''
        if str(param_load['RUN_DATE']) == '' or str(param_load['TODAY_DATE']) == '' or str(param_load['FROM_DATE']) == '' or str(param_load['TO_DATE']) == '' or str(param_load['B2B_RUN_DATE']) == '':
            param_load['RUN_DATE'] = str(RUN_DATE)
            param_load['TODAY_DATE'] = str(TODAY)
            param_load['B2B_RUN_DATE'] = str(B2B_RUN_DATE)
            param_load['FROM_DATE'] = str(FROM_DATE)
            param_load['TO_DATE'] = str(TO_DATE)

# COMMAND ----------

from datetime import date
from datetime import datetime, timedelta
import json

run_month = date.today().strftime("%m")
run_year = date.today().strftime("%Y")
