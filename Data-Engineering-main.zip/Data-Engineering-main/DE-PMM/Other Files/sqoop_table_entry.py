# Databricks notebook source
from pyspark.sql.types import StringType, DateType, StructType, StructField,TimestampType
schema = StructType(
    [
        StructField("start_time", TimestampType(), True),
        StructField("end_time", TimestampType(), True),
        StructField("workflow_name", StringType(), True),
        StructField("table_name", StringType(), True),
        StructField("frequency", StringType(), True)
    ]
)
final_df = spark.createDataFrame([], schema)


dbutils.widgets.text("TABLE_LIST_1", "")
TABLE_LIST_1 = dbutils.widgets.get("TABLE_LIST_1")
dbutils.widgets.text("TABLE_LIST_2", "")
TABLE_LIST_2 = dbutils.widgets.get("TABLE_LIST_2")
dbutils.widgets.text("TABLE_LIST_3", "")
TABLE_LIST_3 = dbutils.widgets.get("TABLE_LIST_3")
dbutils.widgets.text("TABLE_LIST_4", "")
TABLE_LIST_4 = dbutils.widgets.get("TABLE_LIST_4")
dbutils.widgets.text("TABLE_LIST_5", "")
TABLE_LIST_5 = dbutils.widgets.get("TABLE_LIST_5")
dbutils.widgets.text("TABLE_LIST_6", "")
TABLE_LIST_6 = dbutils.widgets.get("TABLE_LIST_6")
dbutils.widgets.text("TABLE_LIST_7", "")
TABLE_LIST_7 = dbutils.widgets.get("TABLE_LIST_7")
dbutils.widgets.text("TABLE_LIST_8", "")
TABLE_LIST_8 = dbutils.widgets.get("TABLE_LIST_8")
dbutils.widgets.text("TABLE_LIST_9", "")
TABLE_LIST_9 = dbutils.widgets.get("TABLE_LIST_9")
dbutils.widgets.text("TABLE_LIST_10", "")
TABLE_LIST_10 = dbutils.widgets.get("TABLE_LIST_10")
dbutils.widgets.text("TABLE_LIST_11", "")
TABLE_LIST_11 = dbutils.widgets.get("TABLE_LIST_11")
dbutils.widgets.text("TABLE_LIST_12", "")
TABLE_LIST_12 = dbutils.widgets.get("TABLE_LIST_12")
dbutils.widgets.text("TABLE_LIST_13", "")
TABLE_LIST_13 = dbutils.widgets.get("TABLE_LIST_13")
dbutils.widgets.text("TABLE_LIST_14", "")
TABLE_LIST_14 = dbutils.widgets.get("TABLE_LIST_14")
dbutils.widgets.text("TABLE_LIST_15", "")
TABLE_LIST_15 = dbutils.widgets.get("TABLE_LIST_15")
dbutils.widgets.text("TABLE_LIST_16", "")
TABLE_LIST_16 = dbutils.widgets.get("TABLE_LIST_16")
dbutils.widgets.text("TABLE_LIST_17", "")
TABLE_LIST_17 = dbutils.widgets.get("TABLE_LIST_17")
dbutils.widgets.text("TABLE_LIST_18", "")
TABLE_LIST_18 = dbutils.widgets.get("TABLE_LIST_18")
dbutils.widgets.text("TABLE_LIST_19", "")
TABLE_LIST_19 = dbutils.widgets.get("TABLE_LIST_19")
dbutils.widgets.text("TABLE_LIST_20", "")
TABLE_LIST_20 = dbutils.widgets.get("TABLE_LIST_20")


sfdc_01_dly = ['uda_replicn_sf_corp_uda_vw_apttusproposalproposal','uda_replicn_sf_corp_uda_vw_adoberole','uda_replicn_sf_corp_uda_vw_account','uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment','uda_replicn_sf_corp_uda_vw_apttusproposalproposallineitem']
deal_list_02 = ['uda_replicn_sf_corp_dbo_products_of_interest__c']
uda_fin_wkly = ['uda_uda_finance_arr_vw_entarr']
ddom_list_01 = ['uda_uda_sales_dbo_vw_td_sellableproduct','uda_uda_sales_dbo_vw_tf_mia_opportunity','uda_uda_marketing_dbo_vw_td_campaign','uda_uda_sales_dbo_vw_td_opportunity']
revenue_planning_subscriptionsfinal_other = ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_other']
foundational_wkly = ['sops_tap_prod_eu_dbo_vw_report_ml_coverage','sops_tap_prod_eu_dbo_vw_report_ml_overlay','sops_tap_prod_eu_dbo_vw_td_employee']
aletryx_migration_wkly = ['uda_parentid_orgid_mapping', 'uda_vw_tf_adobesignmigrationconsolidated', 'sign_uda_accounts', 'rv_td_prnt', 'tbl_anaplanhierarchymapping', 'vw_td_ddomeaccountmastereccsnapshot']
sfdc_02_dly = ['uda_replicn_sf_corp_uda_vw_campaign','uda_replicn_sf_corp_uda_vw_currencytype','uda_replicn_sf_corp_uda_vw_lead','uda_replicn_sf_corp_uda_vw_opportunity','uda_replicn_sf_corp_uda_vw_employeedata']
sap_hana = ['sap_hana_sys_bic_channel_an_channelink_consolidated']
sfdc_03_dly = ['uda_replicn_sf_corp_uda_vw_productsofinterest', 'uda_replicn_sf_corp_uda_vw_opportunitylineitem', 'uda_replicn_sf_corp_uda_vw_product2', 'uda_replicn_sf_corp_uda_vw_opportunityhistory','uda_replicn_sf_corp_uda_vw_user','uda_replicn_sf_corp_uda_vw_userrole']
uda_fin_dly = ['uda_uda_finance_arr_vw_entarr']
ddom_list_02 = ['uda_uda_masterdata_dbo_vw_td_date', 'uda_uda_sales_dbo_vw_td_salesuserrole', 'uda_uda_sales_dbo_vw_td_opportunitystage']
revenue_planning_subscriptionsfinal_dly = ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_actuals']
sfdc_04_dly = ['uda_replicn_sf_corp_uda_vw_contact', 'uda_replicn_sf_corp_uda_vw_customerengagement', 'uda_replicn_sf_corp_uda_vw_leadhistory', 'uda_replicn_sf_corp_uda_vw_adobeterritorymember', 'uda_replicn_sf_corp_uda_vw_campaignmember']
revenue_planning_subscriptionsfinal_weekly_qrf = ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_weekly_qrf']
report_ta_staffing_wkly = ['sops_tap_prod_eu_dbo_vw_report_ta_staffing']
fpa_dbo_productmappings_wkly = ['finsys_dme_b2b_fpa_dbo_productmappings']
emea_reseller_dly = ['emea_reseller_specialist_sfdc_extract']
sales_rep_quota_wkly = ['sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota']
ddom_list_03 = ['uda_dx_tap_prod_dbo_report_p2s_cube','uda_uda_masterdata_dbo_vw_td_account','uda_uda_sales_dbo_vw_td_salesuser']


if TABLE_LIST_1 in ['uda_replicn_sf_corp_uda_vw_apttusproposalproposal,uda_replicn_sf_corp_uda_vw_adoberole,uda_replicn_sf_corp_uda_vw_account,uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment,uda_replicn_sf_corp_uda_vw_apttusproposalproposallineitem']:
    for i in sfdc_01_dly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_01_sa_l1_sfdc_list_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency'''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_2 in ['uda_replicn_sf_corp_dbo_products_of_interest__c']:
    for i in deal_list_02:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_02_deal_list_dashboard_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_3 in ['uda_uda_sales_dbo_vw_td_sellableproduct,uda_uda_sales_dbo_vw_tf_mia_opportunity,uda_uda_marketing_dbo_vw_td_campaign,uda_uda_sales_dbo_vw_td_opportunity']:
    for i in ddom_list_01:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_01_ddom_dashboard_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_4 in ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_other']:
    for i in revenue_planning_subscriptionsfinal_other:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_tm1_revenue_planning_subscriptionsfinal_other" as workflow_name, "{i}" as table_name, "SUNDAY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_5 in ['sops_tap_prod_eu_dbo_vw_report_ml_coverage,sops_tap_prod_eu_dbo_vw_report_ml_overlay,sops_tap_prod_eu_dbo_vw_td_employee']:
    for i in foundational_wkly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2b_foundational_wkly" as workflow_name, "{i}" as table_name, "FRIDAY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_6 in ['uda_parentid_orgid_mapping,uda_vw_tf_adobesignmigrationconsolidated,sign_uda_accounts,rv_td_prnt,tbl_anaplanhierarchymapping,vw_td_ddomeaccountmastereccsnapshot']:
    for i in aletryx_migration_wkly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_aletryx_migration_wkly" as workflow_name, "{i}" as table_name, "MONDAY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_7 in ['uda_replicn_sf_corp_uda_vw_campaign,uda_replicn_sf_corp_uda_vw_currencytype,uda_replicn_sf_corp_uda_vw_lead,uda_replicn_sf_corp_uda_vw_opportunity,uda_replicn_sf_corp_uda_vw_employeedata']:
    for i in sfdc_02_dly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_02_sa_l1_sfdc_list_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_8 in ['sap_hana_sys_bic_channel_an_channelink_consolidated']:
    for i in sap_hana:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_hana_channelink_consolidated_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_9 in ['uda_replicn_sf_corp_uda_vw_productsofinterest,uda_replicn_sf_corp_uda_vw_opportunitylineitem,uda_replicn_sf_corp_uda_vw_product2,uda_replicn_sf_corp_uda_vw_opportunityhistory,uda_replicn_sf_corp_uda_vw_user,uda_replicn_sf_corp_uda_vw_userrole']:
    for i in sfdc_03_dly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_03_sa_l1_sfdc_list_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_10 in ['uda_uda_finance_arr_vw_entarr_dly']:
    for i in uda_fin_dly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_uda_uda_finance_arr_vw_entarr_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)        
elif TABLE_LIST_11 in ['uda_uda_finance_arr_vw_entarr_wkly']:
    for i in uda_fin_wkly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_uda_uda_finance_arr_vw_entarr_wkly" as workflow_name, "{i}" as table_name, "SATURDAY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_12 in ['uda_uda_masterdata_dbo_vw_td_date,uda_uda_sales_dbo_vw_td_salesuserrole,uda_uda_sales_dbo_vw_td_opportunitystage']:
    for i in ddom_list_02:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_02_ddom_dashboard_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_13 in ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_actuals']:
    for i in revenue_planning_subscriptionsfinal_dly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_tm1_revenue_planning_subscriptionsfinal_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_14 in ['uda_replicn_sf_corp_uda_vw_contact,uda_replicn_sf_corp_uda_vw_customerengagement,uda_replicn_sf_corp_uda_vw_leadhistory,uda_replicn_sf_corp_uda_vw_adobeterritorymember,uda_replicn_sf_corp_uda_vw_campaignmember']:
    for i in sfdc_04_dly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_04_sa_l1_sfdc_list_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_15 in ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_weekly_qrf']:
    for i in revenue_planning_subscriptionsfinal_weekly_qrf:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_tm1_revenue_planning_subscriptionsfinal_weekly_qrf" as workflow_name, "{i}" as table_name, "SUNDAY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_16 in ['sops_tap_prod_eu_dbo_vw_report_ta_staffing']:
    for i in report_ta_staffing_wkly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_sops_tap_prod_eu_dbo_vw_report_ta_staffing_wkly" as workflow_name, "{i}" as table_name, "SATURDAY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_17 in ['finsys_dme_b2b_fpa_dbo_productmappings']:
    for i in fpa_dbo_productmappings_wkly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_finsys_dme_b2b_fpa_dbo_productmappings_wkly" as workflow_name, "{i}" as table_name, "MONDAY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_18 in ['emea_reseller_specialist_sfdc_extract']:
    for i in emea_reseller_dly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_emea_reseller_specialist_sfdc_extract_dly" as workflow_name, "{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_19 in ['sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota']:
    for i in sales_rep_quota_wkly:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota_wkly" as workflow_name,"{i}" as table_name, "SATURDAY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)
elif TABLE_LIST_20 in ['uda_dx_tap_prod_dbo_report_p2s_cube,uda_uda_masterdata_dbo_vw_td_account,uda_uda_sales_dbo_vw_td_salesuser']:
    for i in ddom_list_03:
        table_entry = spark.sql('''select current_timestamp() as start_time, current_timestamp() as end_time, "b2bdna_03_ddom_dashboard_dly" as workflow_name,"{i}" as table_name, "DAILY" as frequency '''.format(i = i))
        final_df = final_df.union(table_entry)


final_df.write.format("delta").mode("append").insertInto("b2b.sqoop_table_entries")
final_df.show()
