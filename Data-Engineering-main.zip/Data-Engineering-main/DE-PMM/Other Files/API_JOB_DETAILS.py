# Databricks notebook source
pip
install
databricks_cli

# COMMAND ----------

# MAGIC %run "/b2bdme/SaiKiran/API CREDS"

# COMMAND ----------

import pandas as pd
import json
from databricks_cli.sdk.api_client import ApiClient
from databricks_cli.jobs.api import JobsApi
from databricks_cli.runs.api import RunsApi

api_client = ApiClient(
    host=DATABRICKS_HOST,
    token=DATABRICKS_TOKEN
)

jobs_api = JobsApi(api_client)
runs_api = RunsApi(api_client)
get_jobs = jobs_api.list_jobs()

# COMMAND ----------

result = get_jobs['jobs']
job_list = []
for i in result:
    job_iter = i.get('job_id')
    job_list.append(job_iter)

# COMMAND ----------

# Old Code..dont delete
# runs_list = []
# for i in job_list:
#     job_runs = runs_api.list_runs(job_id=i, active_only=True , completed_only=True, offset=0, limit=1)
#     if len(job_runs) == 2:
#         start_time = job_runs['runs'][0]['start_time']
#         end_time = job_runs['runs'][0]['end_time']
#         run_name = job_runs['runs'][0]['run_name']
#         run_duration = end_time - start_time
#         runs_list.append([start_time, end_time,run_name,run_duration])

# COMMAND ----------

# Old Code..dont delete
# from pyspark.sql.functions import *
# runs_df = spark.createDataFrame(runs_list,['start_time','end_time','run_name','run_duration_minutes'])
# runs_df = runs_df.withColumn('start_time', to_timestamp(col('start_time')/1000))\
#     .withColumn('end_time', to_timestamp(col('end_time')/1000)) \
#     .withColumn('run_name', col('run_name')) \
#     .withColumn('run_duration_minutes',round(col('run_duration_minutes')/(1000*60),2))
# runs_df = runs_df.filter(~col('run_name').rlike('_stg_to_tgt'))
# runs_df.write.mode('overwrite').saveAsTable('b2b_stg.jobdetails_dbx')

# COMMAND ----------

single_task_execution_details = []
job_run_id_list = []
for i in job_list:
    # print(i)
    job_runs = runs_api.list_runs(job_id=i, active_only=False, completed_only=True, offset=0, limit=1)
    # print(job_runs)
    # print(len(job_runs))
    # print(job_runs['runs'][0]['run_id'])
    # print(job_runs['runs'][0]['format'])
    if len(job_runs) != 1:
        if job_runs['runs'][0]['format'] == 'SINGLE_TASK':
            start_time = job_runs['runs'][0]['start_time']
            end_time = job_runs['runs'][0]['end_time']
            run_name = job_runs['runs'][0]['run_name']
            run_duration = end_time - start_time
            single_task_execution_details.append([start_time, end_time, run_name, run_duration])
        else:
            run_id = job_runs['runs'][0]['run_id']
            job_run_id_list.append(run_id)
    else:
        pass  # this is for jobs with no runs where we cant capture any info
# print(job_run_id_list)
# print(single_task_execution_details)

# COMMAND ----------

job_task_run_details = []
for i in job_run_id_list:
    list_task_runs = runs_api.get_run(run_id=i)
    # print(list_task_runs)
    # print(list_run['tasks'])
    job_tasks_details = list_task_runs['tasks']
    # print(job_tasks_details)
    job_task_run_details.append(job_tasks_details)

# COMMAND ----------

run_id_list = []
for run_ids in job_task_run_details:
    for run_id in run_ids:
        # print(run_id['run_id'])
        run_id_list.append(run_id['run_id'])

# print(run_id_list)

# COMMAND ----------

task_execution_details = []
# print(run_id_list)
for task_run in run_id_list:
    list_run = runs_api.get_run(run_id=task_run)
    # print(list_run)
    start_time = list_run['start_time']
    end_time = list_run['end_time']
    run_name = list_run['run_name']
    run_duration = end_time - start_time
    task_execution_details.append([start_time, end_time, run_name, run_duration])

# print(task_execution_details)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

runs_df = spark.createDataFrame(task_execution_details, ['start_time', 'end_time', 'run_name', 'run_duration'])
window = Window.partitionBy("run_name").orderBy(desc("start_time"))
runs_df = runs_df.withColumn('start_time', to_timestamp(col('start_time') / 1000)) \
    .withColumn('end_time', to_timestamp(col('end_time') / 1000)) \
    .withColumn('run_name', col('run_name')) \
    .withColumn('run_duration_minutes', round(col('run_duration') / (1000 * 60), 2)) \
    .withColumn('row_number', row_number().over(window))
# runs_df.show(1000,False)
runs_df = runs_df.filter(~col('run_name').rlike('_stg_to_tgt'))
runs_df = runs_df.filter(runs_df.row_number == 1).select(["start_time", "end_time", "run_name", "run_duration_minutes"])
runs_df.write.mode('overwrite').saveAsTable('b2b_stg.jobdetails_dbx_multiple_tasks')

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

single_task_runs_df = spark.createDataFrame(single_task_execution_details,
                                            ['start_time', 'end_time', 'run_name', 'run_duration'])
window = Window.partitionBy("run_name").orderBy(desc("start_time"))
single_task_runs_df = single_task_runs_df.withColumn('start_time', to_timestamp(col('start_time') / 1000)) \
    .withColumn('end_time', to_timestamp(col('end_time') / 1000)) \
    .withColumn('run_name', col('run_name')) \
    .withColumn('run_duration_minutes', round(col('run_duration') / (1000 * 60), 2)) \
    .withColumn('row_number', row_number().over(window))

# single_task_runs_df.show()
single_task_runs_df = single_task_runs_df.filter(~col('run_name').rlike('_stg_to_tgt'))
single_task_runs_df = single_task_runs_df.filter(single_task_runs_df.row_number == 1).select(
    ["start_time", "end_time", "run_name", "run_duration_minutes"])
single_task_runs_df.write.mode('overwrite').saveAsTable('b2b_stg.jobdetails_dbx_single_tasks')

combined_df = runs_df.union(single_task_runs_df)
combined_df.write.mode('overwrite').saveAsTable('b2b_stg.jobdetails_dbx')
