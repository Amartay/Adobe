# Databricks notebook source
def rm_partition(tab_name):
    filepath="abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b.db/" + tab_name + "/flag=D/"
    latest_file = [ i.name for i in dbutils.fs.ls(filepath) ][-1]
    del_files =[dbutils.fs.rm(filepath + i.name,True) for i in dbutils.fs.ls(filepath) if latest_file not in i.name]

dbutils.widgets.text("TABLE_1", "")
TABLE_1 = dbutils.widgets.get("TABLE_1")
dbutils.widgets.text("TABLE_2", "")
TABLE_2 = dbutils.widgets.get("TABLE_2")
dbutils.widgets.text("TABLE_3", "")
TABLE_3 = dbutils.widgets.get("TABLE_3")
dbutils.widgets.text("TABLE_4", "")
TABLE_4 = dbutils.widgets.get("TABLE_4")
dbutils.widgets.text("TABLE_5", "")
TABLE_5 = dbutils.widgets.get("TABLE_5")
dbutils.widgets.text("TABLE_6", "")
TABLE_6 = dbutils.widgets.get("TABLE_6")
dbutils.widgets.text("TABLE_LIST_1", "")
TABLE_LIST_1 = dbutils.widgets.get("TABLE_LIST_1")
dbutils.widgets.text("TABLE_LIST_2", "")
TABLE_LIST_2 = dbutils.widgets.get("TABLE_LIST_2")
dbutils.widgets.text("TABLE_LIST_3", "")
TABLE_LIST_3 = dbutils.widgets.get("TABLE_LIST_3")
dbutils.widgets.text("TABLE_LIST_4", "")
TABLE_LIST_4 = dbutils.widgets.get("TABLE_LIST_4")
dbutils.widgets.text("TABLE_LIST_5", "")
TABLE_LIST_5 = dbutils.widgets.get("TABLE_LIST_5")
dbutils.widgets.text("TABLE_LIST_6", "")
TABLE_LIST_6 = dbutils.widgets.get("TABLE_LIST_6")
dbutils.widgets.text("TABLE_LIST_7", "")
TABLE_LIST_7 = dbutils.widgets.get("TABLE_LIST_7")
dbutils.widgets.text("TABLE_LIST_8", "")
TABLE_LIST_8 = dbutils.widgets.get("TABLE_LIST_8")
dbutils.widgets.text("TABLE_LIST_9", "")
TABLE_LIST_9 = dbutils.widgets.get("TABLE_LIST_9")
dbutils.widgets.text("TABLE_LIST_10", "")
TABLE_LIST_10 = dbutils.widgets.get("TABLE_LIST_10")
dbutils.widgets.text("TABLE_LIST_11", "")
TABLE_LIST_11 = dbutils.widgets.get("TABLE_LIST_11")
dbutils.widgets.text("TABLE_LIST_12", "")
TABLE_LIST_12 = dbutils.widgets.get("TABLE_LIST_12")
dbutils.widgets.text("TABLE_LIST_13", "")
TABLE_LIST_13 = dbutils.widgets.get("TABLE_LIST_13")
dbutils.widgets.text("TABLE_LIST_14", "")
TABLE_LIST_14 = dbutils.widgets.get("TABLE_LIST_14")
dbutils.widgets.text("TABLE_LIST_15", "")
TABLE_LIST_15 = dbutils.widgets.get("TABLE_LIST_15")
dbutils.widgets.text("TABLE_LIST_16", "")
TABLE_LIST_16 = dbutils.widgets.get("TABLE_LIST_16")
dbutils.widgets.text("TABLE_LIST_17", "")
TABLE_LIST_17 = dbutils.widgets.get("TABLE_LIST_17")
dbutils.widgets.text("TABLE_LIST_18", "")
TABLE_LIST_18 = dbutils.widgets.get("TABLE_LIST_18")
dbutils.widgets.text("TABLE_LIST_19", "")
TABLE_LIST_19 = dbutils.widgets.get("TABLE_LIST_19")
dbutils.widgets.text("TABLE_LIST_20", "")
TABLE_LIST_20 = dbutils.widgets.get("TABLE_LIST_20")



sfdc_01_dly = ['uda_replicn_sf_corp_uda_vw_apttusproposalproposal','uda_replicn_sf_corp_uda_vw_adoberole','uda_replicn_sf_corp_uda_vw_account','uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment','uda_replicn_sf_corp_uda_vw_apttusproposalproposallineitem']
deal_list_02 = ['uda_replicn_sf_corp_dbo_products_of_interest__c']
uda_fin_wkly = ['uda_uda_finance_arr_vw_entarr']
ddom_list_01 = ['uda_uda_sales_dbo_vw_td_sellableproduct','uda_uda_sales_dbo_vw_tf_mia_opportunity','uda_uda_marketing_dbo_vw_td_campaign','uda_uda_sales_dbo_vw_td_opportunity']
revenue_planning_subscriptionsfinal_other = ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_other']
foundational_dly = ['sops_tap_prod_eu_dbo_vw_report_ml_coverage','sops_tap_prod_eu_dbo_vw_report_ml_overlay','sops_tap_prod_eu_dbo_vw_td_employee']
aletryx_migration_wkly = ['uda_parentid_orgid_mapping','uda_vw_tf_adobesignmigrationconsolidated','sign_uda_accounts','rv_td_prnt','tbl_anaplanhierarchymapping','vw_td_ddomeaccountmastereccsnapshot']
sfdc_02_dly = ['uda_replicn_sf_corp_uda_vw_campaign','uda_replicn_sf_corp_uda_vw_currencytype','uda_replicn_sf_corp_uda_vw_lead','uda_replicn_sf_corp_uda_vw_opportunity','uda_replicn_sf_corp_uda_vw_employeedata']
sap_hana = ['sap_hana_sys_bic_channel_an_channelink_consolidated']
sfdc_03_dly = ['uda_replicn_sf_corp_uda_vw_productsofinterest','uda_replicn_sf_corp_uda_vw_opportunitylineitem', 'uda_replicn_sf_corp_uda_vw_product2','uda_replicn_sf_corp_uda_vw_opportunityhistory','uda_replicn_sf_corp_uda_vw_user','uda_replicn_sf_corp_uda_vw_userrole']
uda_fin_dly = ['uda_uda_finance_arr_vw_entarr']
ddom_list_02 = ['uda_uda_masterdata_dbo_vw_td_date', 'uda_uda_sales_dbo_vw_td_salesuserrole', 'uda_uda_sales_dbo_vw_td_opportunitystage']
revenue_planning_subscriptionsfinal_dly = ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_actuals']
sfdc_04_dly = ['uda_replicn_sf_corp_uda_vw_contact', 'uda_replicn_sf_corp_uda_vw_customerengagement', 'uda_replicn_sf_corp_uda_vw_leadhistory', 'uda_replicn_sf_corp_uda_vw_adobeterritorymember', 'uda_replicn_sf_corp_uda_vw_campaignmember']
revenue_planning_subscriptionsfinal_weekly_qrf = ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_weekly_qrf']
report_ta_staffing_wkly = ['sops_tap_prod_eu_dbo_vw_report_ta_staffing']
fpa_dbo_productmappings_wkly = ['finsys_dme_b2b_fpa_dbo_productmappings']
emea_reseller_dly = ['emea_reseller_specialist_sfdc_extract']
sales_rep_quota_wkly = ['sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota']
ddom_list_03 = ['uda_dx_tap_prod_dbo_report_p2s_cube','uda_uda_masterdata_dbo_vw_td_account','uda_uda_sales_dbo_vw_td_salesuser']

if TABLE_LIST_1 in ['uda_replicn_sf_corp_uda_vw_apttusproposalproposal,uda_replicn_sf_corp_uda_vw_adoberole,uda_replicn_sf_corp_uda_vw_account,uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment,uda_replicn_sf_corp_uda_vw_apttusproposalproposallineitem']:
    if TABLE_1 == 'uda_replicn_sf_corp_uda_vw_apttusproposalproposal':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_01_sa_l1_sfdc_list_dly" '''.format(TABLE_1 = TABLE_1))        
    elif TABLE_2 == 'uda_replicn_sf_corp_uda_vw_adoberole':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_01_sa_l1_sfdc_list_dly" '''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'uda_replicn_sf_corp_uda_vw_account':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_01_sa_l1_sfdc_list_dly" '''.format(TABLE_3 = TABLE_3))
        rm_partition('{TABLE_3}'.format(TABLE_3 = TABLE_3))
        df2 = spark.sql('''msck repair table b2b.{TABLE_3}'''.format(TABLE_3 = TABLE_3))
    elif TABLE_4 == 'uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_4}' and workflow_name = "b2bdna_01_sa_l1_sfdc_list_dly" '''.format(TABLE_4 = TABLE_4))
        rm_partition('{TABLE_4}'.format(TABLE_4 = TABLE_4))
        df2 = spark.sql('''msck repair table b2b.{TABLE_4}'''.format(TABLE_4 = TABLE_4))
    elif TABLE_5 == 'uda_replicn_sf_corp_uda_vw_apttusproposalproposallineitem':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_5}' and workflow_name = "b2bdna_01_sa_l1_sfdc_list_dly" '''.format(TABLE_5 = TABLE_5))
        rm_partition('{TABLE_5}'.format(TABLE_5 = TABLE_5))
        df2 = spark.sql('''msck repair table b2b.{TABLE_5}'''.format(TABLE_5 = TABLE_5))
elif TABLE_LIST_2 in ['uda_replicn_sf_corp_dbo_products_of_interest__c']:
    for i in deal_list_02:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_02_deal_list_dashboard_dly" '''.format(i = i))
elif TABLE_LIST_3 in ['uda_uda_sales_dbo_vw_td_sellableproduct,uda_uda_sales_dbo_vw_tf_mia_opportunity,uda_uda_marketing_dbo_vw_td_campaign,uda_uda_sales_dbo_vw_td_opportunity']:
    if TABLE_1 == 'uda_uda_sales_dbo_vw_td_sellableproduct':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_01_ddom_dashboard_dly" '''.format(TABLE_1 = TABLE_1))
        df1 = spark.sql('''msck repair table b2b.{TABLE_1}'''.format(TABLE_1 = TABLE_1))
    elif TABLE_2 == 'uda_uda_sales_dbo_vw_tf_mia_opportunity':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_01_ddom_dashboard_dly" '''.format(TABLE_2 = TABLE_2))
        df2 = spark.sql('''msck repair table b2b.{TABLE_2}'''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'uda_uda_marketing_dbo_vw_td_campaign':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_01_ddom_dashboard_dly" '''.format(TABLE_3 = TABLE_3))
        df3 = spark.sql('''msck repair table b2b.{TABLE_3}'''.format(TABLE_3 = TABLE_3))
    elif TABLE_4 == 'uda_uda_sales_dbo_vw_td_opportunity':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_4}' and workflow_name = "b2bdna_01_ddom_dashboard_dly" '''.format(TABLE_4 = TABLE_4))
        df4 = spark.sql('''msck repair table b2b.{TABLE_4}'''.format(TABLE_4 = TABLE_4))
elif TABLE_LIST_4 in ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_other']:
    for i in revenue_planning_subscriptionsfinal_other:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_tm1_revenue_planning_subscriptionsfinal_other" '''.format(i = i))
elif TABLE_LIST_5 in ['sops_tap_prod_eu_dbo_vw_report_ml_coverage,sops_tap_prod_eu_dbo_vw_report_ml_overlay,sops_tap_prod_eu_dbo_vw_td_employee']:
    if TABLE_1 == 'sops_tap_prod_eu_dbo_vw_report_ml_coverage':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_b2b_foundational_wkly" '''.format(TABLE_1 = TABLE_1))
        df1 = spark.sql('''msck repair table b2b.{TABLE_1}'''.format(TABLE_1 = TABLE_1))
    elif TABLE_2 == 'sops_tap_prod_eu_dbo_vw_report_ml_overlay':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_b2b_foundational_wkly" '''.format(TABLE_2 = TABLE_2))
        df2 = spark.sql('''msck repair table b2b.{TABLE_2}'''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'sops_tap_prod_eu_dbo_vw_td_employee':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_b2b_foundational_wkly" '''.format(TABLE_3 = TABLE_3))
        df3 = spark.sql('''msck repair table b2b.{TABLE_3}'''.format(TABLE_3 = TABLE_3))
elif TABLE_LIST_6 in ['uda_parentid_orgid_mapping,uda_vw_tf_adobesignmigrationconsolidated,sign_uda_accounts,rv_td_prnt, tbl_anaplanhierarchymapping,vw_td_ddomeaccountmastereccsnapshot']:
    if TABLE_1 == 'uda_parentid_orgid_mapping':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_aletryx_migration_wkly" '''.format(TABLE_1 = TABLE_1))
    elif TABLE_2 == 'uda_vw_tf_adobesignmigrationconsolidated':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_aletryx_migration_wkly" '''.format(TABLE_2 = TABLE_2))
        df2 = spark.sql('''msck repair table b2b.{TABLE_2}'''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'sign_uda_accounts':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_aletryx_migration_wkly" '''.format(TABLE_3 = TABLE_3))
        df3 = spark.sql('''msck repair table b2b.{TABLE_3}'''.format(TABLE_3 = TABLE_3))
    elif TABLE_4 == 'rv_td_prnt':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_4}' and workflow_name = "b2bdna_aletryx_migration_wkly" '''.format(TABLE_4 = TABLE_4))
    elif TABLE_5 == 'tbl_anaplanhierarchymapping':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_5}' and workflow_name = "b2bdna_aletryx_migration_wkly" '''.format(TABLE_5 = TABLE_5))
        df5 = spark.sql('''msck repair table b2b.{TABLE_5}'''.format(TABLE_5 = TABLE_5))
    elif TABLE_6 == 'vw_td_ddomeaccountmastereccsnapshot':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_6}' and workflow_name = "b2bdna_aletryx_migration_wkly" '''.format(TABLE_6 = TABLE_6))
        df6 = spark.sql('''msck repair table b2b.{TABLE_6}'''.format(TABLE_6 = TABLE_6))
elif TABLE_LIST_7 in ['uda_replicn_sf_corp_uda_vw_campaign,uda_replicn_sf_corp_uda_vw_currencytype,uda_replicn_sf_corp_uda_vw_lead,uda_replicn_sf_corp_uda_vw_opportunity,uda_replicn_sf_corp_uda_vw_employeedata']:
    if TABLE_1 == 'uda_replicn_sf_corp_uda_vw_campaign':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_02_sa_l1_sfdc_list_dly" '''.format(TABLE_1 = TABLE_1))
    elif TABLE_2 == 'uda_replicn_sf_corp_uda_vw_currencytype':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_02_sa_l1_sfdc_list_dly" '''.format(TABLE_2 = TABLE_2))
        df2 = spark.sql('''msck repair table b2b.{TABLE_2}'''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'uda_replicn_sf_corp_uda_vw_lead':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_02_sa_l1_sfdc_list_dly" '''.format(TABLE_3 = TABLE_3))
    elif TABLE_4 == 'uda_replicn_sf_corp_uda_vw_opportunity':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_4}' and workflow_name = "b2bdna_02_sa_l1_sfdc_list_dly" '''.format(TABLE_4 = TABLE_4))
        df4 = spark.sql('''msck repair table b2b.{TABLE_4}'''.format(TABLE_4 = TABLE_4))
    elif TABLE_5 == 'uda_replicn_sf_corp_uda_vw_employeedata':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_5}' and workflow_name = "b2bdna_02_sa_l1_sfdc_list_dly" '''.format(TABLE_5 = TABLE_5))
        rm_partition('{TABLE_5}'.format(TABLE_5 = TABLE_5))
        df5 = spark.sql('''msck repair table b2b.{TABLE_5}'''.format(TABLE_5 = TABLE_5))
elif TABLE_LIST_8 in ['sap_hana_sys_bic_channel_an_channelink_consolidated']:
    for i in sap_hana:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_hana_channelink_consolidated_dly" '''.format(i = i))
elif TABLE_LIST_9 in ['uda_replicn_sf_corp_uda_vw_productsofinterest,uda_replicn_sf_corp_uda_vw_opportunitylineitem,uda_replicn_sf_corp_uda_vw_product2,uda_replicn_sf_corp_uda_vw_opportunityhistory,uda_replicn_sf_corp_uda_vw_user,uda_replicn_sf_corp_uda_vw_userrole']:
    if TABLE_1 == 'uda_replicn_sf_corp_uda_vw_productsofinterest':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_03_sa_l1_sfdc_list_dly" '''.format(TABLE_1 = TABLE_1))
    elif TABLE_2 == 'uda_replicn_sf_corp_uda_vw_opportunitylineitem':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_03_sa_l1_sfdc_list_dly" '''.format(TABLE_2 = TABLE_2))
        df1 = spark.sql('''msck repair table b2b.{TABLE_2}'''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'uda_replicn_sf_corp_uda_vw_product2':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_03_sa_l1_sfdc_list_dly" '''.format(TABLE_3 = TABLE_3))
    elif TABLE_4 == 'uda_replicn_sf_corp_uda_vw_opportunityhistory':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_4}' and workflow_name = "b2bdna_03_sa_l1_sfdc_list_dly" '''.format(TABLE_4 = TABLE_4))
    elif TABLE_5 == 'uda_replicn_sf_corp_uda_vw_user':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_5}' and workflow_name = "b2bdna_03_sa_l1_sfdc_list_dly" '''.format(TABLE_5 = TABLE_5))
        rm_partition('{TABLE_5}'.format(TABLE_5 = TABLE_5))
        df2 = spark.sql('''msck repair table b2b.{TABLE_5}'''.format(TABLE_5 = TABLE_5))
    elif TABLE_6 == 'uda_replicn_sf_corp_uda_vw_userrole':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_6}' and workflow_name = "b2bdna_03_sa_l1_sfdc_list_dly" '''.format(TABLE_6 = TABLE_6))
        rm_partition('{TABLE_6}'.format(TABLE_6 = TABLE_6))
        df3 = spark.sql('''msck repair table b2b.{TABLE_6}'''.format(TABLE_6 = TABLE_6))
elif TABLE_LIST_10 in ['uda_uda_finance_arr_vw_entarr_dly']:
    for i in uda_fin_dly:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_uda_uda_finance_arr_vw_entarr_dly" '''.format(i = i))
        df10 = spark.sql('''msck repair table b2b.{i}'''.format(i = i))
elif TABLE_LIST_11 in ['uda_uda_finance_arr_vw_entarr_wkly']:
    for i in uda_fin_wkly:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_uda_uda_finance_arr_vw_entarr_wkly" '''.format(i = i))
        df11 = spark.sql('''msck repair table b2b.{i}'''.format(i = i))
elif TABLE_LIST_12 in ['uda_uda_masterdata_dbo_vw_td_date,uda_uda_sales_dbo_vw_td_salesuserrole,uda_uda_sales_dbo_vw_td_opportunitystage']:
    if TABLE_1 == 'uda_uda_masterdata_dbo_vw_td_date':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_02_ddom_dashboard_dly" '''.format(TABLE_1 = TABLE_1))
        df1 = spark.sql('''msck repair table b2b.{TABLE_1}'''.format(TABLE_1 = TABLE_1))
    elif TABLE_2 == 'uda_uda_sales_dbo_vw_td_salesuserrole':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_02_ddom_dashboard_dly" '''.format(TABLE_2 = TABLE_2))
        df1 = spark.sql('''msck repair table b2b.{TABLE_2}'''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'uda_uda_sales_dbo_vw_td_opportunitystage':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_02_ddom_dashboard_dly" '''.format(TABLE_3 = TABLE_3))
        df1 = spark.sql('''msck repair table b2b.{TABLE_3}'''.format(TABLE_3 = TABLE_3))
elif TABLE_LIST_13 in ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_actuals']:
    for i in revenue_planning_subscriptionsfinal_dly:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_tm1_revenue_planning_subscriptionsfinal_dly" '''.format(i = i))
elif TABLE_LIST_14 in ['uda_replicn_sf_corp_uda_vw_contact,uda_replicn_sf_corp_uda_vw_customerengagement,uda_replicn_sf_corp_uda_vw_leadhistory,uda_replicn_sf_corp_uda_vw_adobeterritorymember,uda_replicn_sf_corp_uda_vw_campaignmember']:
    if TABLE_1 == 'uda_replicn_sf_corp_uda_vw_contact':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_04_sa_l1_sfdc_list_dly" '''.format(TABLE_1 = TABLE_1))
    elif TABLE_2 == 'uda_replicn_sf_corp_uda_vw_customerengagement':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_04_sa_l1_sfdc_list_dly" '''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'uda_replicn_sf_corp_uda_vw_leadhistory':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_04_sa_l1_sfdc_list_dly" '''.format(TABLE_3 = TABLE_3))
    elif TABLE_4 == 'uda_replicn_sf_corp_uda_vw_adobeterritorymember':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_4}' and workflow_name = "b2bdna_04_sa_l1_sfdc_list_dly" '''.format(TABLE_4 = TABLE_4))
    elif TABLE_5 == 'uda_replicn_sf_corp_uda_vw_campaignmember':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_5}' and workflow_name = "b2bdna_04_sa_l1_sfdc_list_dly" '''.format(TABLE_5 = TABLE_5))
elif TABLE_LIST_15 in ['finsys_finance_systems_dbo_tm1_revenue_planning_subscriptionsfinal_weekly_qrf']:
    for i in revenue_planning_subscriptionsfinal_weekly_qrf:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_tm1_revenue_planning_subscriptionsfinal_weekly_qrf" '''.format(i = i))
elif TABLE_LIST_16 in ['sops_tap_prod_eu_dbo_vw_report_ta_staffing']:
    for i in report_ta_staffing_wkly:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_sops_tap_prod_eu_dbo_vw_report_ta_staffing_wkly" '''.format(i = i))
        df16 = spark.sql('''msck repair table b2b.{i}'''.format(i = i))
elif TABLE_LIST_17 in ['finsys_dme_b2b_fpa_dbo_productmappings']:
    for i in fpa_dbo_productmappings_wkly:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_finsys_dme_b2b_fpa_dbo_productmappings_wkly" '''.format(i = i))
elif TABLE_LIST_18 in ['emea_reseller_specialist_sfdc_extract']:
    for i in emea_reseller_dly:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_emea_reseller_specialist_sfdc_extract_dly" '''.format(i = i))
elif TABLE_LIST_19 in ['sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota']:
    for i in sales_rep_quota_wkly:
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{i}' and workflow_name = "b2bdna_sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota_wkly" '''.format(i = i))
        df19 = spark.sql('''msck repair table b2b.{i}'''.format(i = i))
elif TABLE_LIST_20 in ['uda_dx_tap_prod_dbo_report_p2s_cube,uda_uda_masterdata_dbo_vw_td_account,uda_uda_sales_dbo_vw_td_salesuser']:
    if TABLE_1 == 'uda_dx_tap_prod_dbo_report_p2s_cube':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_1}' and workflow_name = "b2bdna_03_ddom_dashboard_dly" '''.format(TABLE_1 = TABLE_1))
        df1 = spark.sql('''msck repair table b2b.{TABLE_1}'''.format(TABLE_1 = TABLE_1))
    elif TABLE_2 == 'uda_uda_masterdata_dbo_vw_td_account':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_2}' and workflow_name = "b2bdna_03_ddom_dashboard_dly" '''.format(TABLE_2 = TABLE_2))
        df2 = spark.sql('''msck repair table b2b.{TABLE_2}'''.format(TABLE_2 = TABLE_2))
    elif TABLE_3 == 'uda_uda_sales_dbo_vw_td_salesuser':
        update_entry = spark.sql(''' update b2b.sqoop_table_entries set end_time = current_timestamp()  where table_name = '{TABLE_3}' and workflow_name = "b2bdna_03_ddom_dashboard_dly" '''.format(TABLE_3 = TABLE_3))
        df3 = spark.sql('''msck repair table b2b.{TABLE_3}'''.format(TABLE_3 = TABLE_3))


# COMMAND ----------

from pyspark.sql.functions import *
table_vw = spark.sql("select * from b2b.sqoop_table_entries")
table_det = table_vw.withColumn("execution_time_sec", unix_timestamp(col('end_time')) - unix_timestamp(col('start_time'))) \
    .withColumn('execution_time_min',round(col('execution_time_sec')/60))

# COMMAND ----------

cols = table_det.columns
cols = cols[0:3] + cols[5:7] + cols[3:5]
table_det = table_det[cols]

# COMMAND ----------

spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
table_det.write.format("parquet").mode("overwrite").insertInto("b2b.sqoop_table_details")
