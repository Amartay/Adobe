# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

# import datetime
# B2B_RUN_DATE = datetime.date(2024,2,9)
# print(B2B_RUN_DATE)

# COMMAND ----------

# DBTITLE 1,5% mail alert
from email.message import EmailMessage
import smtplib

def send_email(body):
    fromaddr = 'do-not-reply-dpaas-dbx@adobe.com'
    toaddrs = "lat57607@adobe.com,lat41525@adobe.com,tek43117@adobe.com,lat51306@adobe.com"
    #toaddrs = "lat57607@adobe.com"
    SMTPServer = 'adobe-com.mail.protection.outlook.com'
    port = 25 #587
    html_content = """
    <html>
    <body>
    <pre><b>Hi All, 
    The table "b2b.{TABLE_NAME}" has QC ISSUES for {B2B_RUN_DATE} snapshot date.
    Please find the below details
    {body}
    [This is an auto generated email, please do not reply]</b>
    </pre>
    </body>
    </html>
    """
    msg = EmailMessage()
    msg['Subject'] = " QC ISSUE"
    msg['From'] = fromaddr
    msg['To'] = toaddrs
    msg.set_content(html_content.format(TABLE_NAME= TABLE_NAME,B2B_RUN_DATE=B2B_RUN_DATE,body=body), subtype='html')
    server = smtplib.SMTP(SMTPServer, port)
    server.send_message(msg)
    server.quit()

# COMMAND ----------

# DBTITLE 1,deployment_usage null value QC
deploy_df = spark.sql("select contract_type, sum(cast(provisioned as int)) as provisioned, sum(cast(local_licensed_qty as int)) as local_licensed_qty, sum(cast(delegated as int)) as delegated, sum(cast(activated as int)) as activated, sum(cast(mau as int)) as mau, sum(cast(qau as int)) as qau, sum(cast(rmau as int)) as rmau from b2b.b2b_deployment_usage where as_of_date = '{B2B_RUN_DATE}' group by 1".format(B2B_RUN_DATE = B2B_RUN_DATE))
deploy_df.show()
count_df = deploy_df.filter(deploy_df.delegated.isNull() | deploy_df.activated.isNull() |  deploy_df.mau.isNull() | deploy_df.qau.isNull() | deploy_df.rmau.isNull()).count()
print(count_df)
if count_df == 0:
    pass
else:
    dbutils.notebook.exit("Few metrics have null values")

# COMMAND ----------

# DBTITLE 1,app_usage null value QC
spark.sql(''' refresh table b2b.b2b_app_usage ''')
usage_df = spark.sql(''' select contract_type, sum(cast(app_seats_provisioned as int)) as app_seats_provisioned, sum(cast(app_users_delegated as int)) as app_users_delegated, sum(cast(app_users_activated as int)) as app_users_activated, sum(cast(app_qalu as int)) as app_qalu, sum(cast(app_malu as int)) as app_malu, sum(cast(app_rmalu as int)) as app_rmalu from b2b.b2b_app_usage where as_of_date = '{B2B_RUN_DATE}'  group by 1 '''.format(B2B_RUN_DATE = B2B_RUN_DATE))
usage_df.show()
count_df = usage_df.filter(usage_df.app_seats_provisioned.isNull() | usage_df.app_users_delegated.isNull() |  usage_df.app_users_activated.isNull() | usage_df.app_qalu.isNull() | usage_df.app_malu.isNull() | usage_df.app_rmalu.isNull()).count()
print(count_df)
if count_df == 0:
    pass
else:
    dbutils.notebook.exit("Few metrics have null values")

# COMMAND ----------

# DBTITLE 1,guid_usage_events app_names(Acrobat Reader/Scan) QC
guid_df = spark.sql(''' select * from b2b.b2b_guid_usage_events_stg where as_of_date = '{B2B_RUN_DATE}' and app_name IN ('ACROBAT READER MOBILE','SCAN MOBILE') '''.format(B2B_RUN_DATE = B2B_RUN_DATE)).count()
print(guid_df)
if guid_df != 0:
    pass
else:
    dbutils.notebook.exit("guid table doesnt have acrobat reader entries")

# COMMAND ----------

# DBTITLE 1,app_usage app_name(Acrobat Reader) QC
acro_usage_df = spark.sql("select * from b2b.b2b_app_usage where as_of_date = '{B2B_RUN_DATE}' and app_name = 'ACROBAT READER MOBILE' and offering_type LIKE '%ACRO%' AND app_users_delegated > '0' AND app_malu > '0' ".format(B2B_RUN_DATE = B2B_RUN_DATE)).count()
print(acro_usage_df)
if acro_usage_df != 0:
    pass
else:
    dbutils.notebook.exit("app_usage table doesnt have acrobat reader mobile entries")

# COMMAND ----------

# DBTITLE 1,deployment_usage (assigned vs activation) QC
assigned_deploy = spark.sql("select sum(cast(local_licensed_qty as int))local_licensed_qty, sum(cast(delegated as int))assigned, sum(cast (activated as int))activated from b2b.b2b_deployment_usage where as_of_date = '{B2B_RUN_DATE}' and contract_type = 'VIPMP' ".format(B2B_RUN_DATE = B2B_RUN_DATE))
assigned_deploy.show()
check_assigned_notnull= assigned_deploy.filter(assigned_deploy.assigned.isNull()).count()
print(check_assigned_notnull)
assigned_higher= assigned_deploy.filter(assigned_deploy.assigned > assigned_deploy.activated).count()
print(assigned_higher)
if check_assigned_notnull == 0 and assigned_higher == 1:
    pass
else:
    dbutils.notebook.exit("Assigned value is null ")

# COMMAND ----------

# DBTITLE 1,app_usage (FrameIO vs others) null value QC
frame_df = spark.sql("select app_name, sum(cast(app_seats_provisioned as int)) as app_seats_provisioned, sum(cast(app_users_delegated as int)) as app_users_delegated, sum(cast(app_users_activated as int)) as app_users_activated, sum(cast(app_qalu as int)) as app_qalu, sum(cast(app_malu as int)) as app_malu, sum(cast(app_rmalu as int)) as app_rmalu from b2b.b2b_app_usage where as_of_date = '{B2B_RUN_DATE}' group by 1 having sum(cast(app_users_activated as int)) = 0 and sum(cast(app_qalu as int)) = 0 and sum(cast(app_malu as int)) = 0 and sum(cast(app_rmalu as int)) = 0 ".format(B2B_RUN_DATE = B2B_RUN_DATE))
frame_df.show()
frame_count = frame_df.filter((frame_df.app_malu == 0) & (frame_df.app_qalu == 0) & (frame_df.app_rmalu == 0) & (frame_df.app_users_activated == 0) & (frame_df.app_name == 'FRAME IO ') ).count()
print(frame_count)
if frame_count == 0:
    dbutils.notebook.exit("FRAME IO has non null values")
else:
    pass

# COMMAND ----------

# DBTITLE 1,WoW deployment_usage QC
import numpy as np
import datetime,time
from datetime import datetime
from dateutil.relativedelta import relativedelta

#B2B_RUN_DATE = datetime.strptime(B2B_RUN_DATE, '%Y-%m-%d').date()

prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

df = spark.sql("select as_of_date, sum(cast(provisioned as int)) as provisioned, sum(cast(local_licensed_qty as int)) as local_licensed_qty, sum(cast(delegated as int)) as delegated, sum(cast(activated as int)) as activated, sum(cast(mau as int)) as mau, sum(cast(qau as int)) as qau, sum(cast(rmau as int)) as rmau from b2b.b2b_deployment_usage where as_of_date in ('{B2B_RUN_DATE}','{prev_week_date}') group by 1 order by 1 asc ".format(B2B_RUN_DATE = B2B_RUN_DATE,prev_week_date = prev_week_date))
df.show()
df_pandas = df.select(df.columns[1:]).toPandas()
df_pandas.diff()

df_pandas['WoWP'] = np.round(df_pandas['provisioned'].pct_change() * 100,2)
df_pandas['WoWllq'] = np.round(df_pandas['local_licensed_qty'].pct_change() * 100,2)
df_pandas['WoWdel'] = np.round(df_pandas['delegated'].pct_change() * 100,2)
df_pandas['WoWacti'] = np.round(df_pandas['activated'].pct_change() * 100,2)
df_pandas['WoWmau'] = np.round(df_pandas['mau'].pct_change() * 100,2)
df_pandas['WoWqau'] = np.round(df_pandas['qau'].pct_change() * 100,2)
df_pandas['WoWrmau'] = np.round(df_pandas['rmau'].pct_change() * 100,2)
df_pandas = df_pandas.dropna()
final_df = df_pandas.iloc[:, 7:]
display(final_df)

# COMMAND ----------

# DBTITLE 1,DEPLOYMENT_USAGE 5% CHECK
TABLE_NAME='b2b_deployment_usage'
body = ''
for x,y in final_df.items():
    for z in y:
        if float(z) > 5 or float(z) < -5:
            a = "WoW count for {x} is greater than +-5% \n".format(x=x)
            body = body+a
        else:
            pass
print(len(body))
if len(body) == 0:
    pass
else:
    send_email(body)

# COMMAND ----------

# DBTITLE 1,WoW app_usage QC
import numpy as np
import datetime,time
from dateutil.relativedelta import relativedelta

prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

df = spark.sql(''' select as_of_date, count(org_id) as org_id, count(end_user_id) as end_user_id, count(offer_id) as offer_id,sum(cast(app_seats_provisioned as int)) as app_seats_provisioned, sum(cast(app_users_delegated as int)) as app_users_delegated, sum(cast(app_users_activated as int)) as app_users_activated, sum(cast(app_qalu as int)) as app_qalu, sum(cast(app_malu as int)) as app_malu, sum(cast(app_rmalu as int)) as app_rmalu from b2b.b2b_app_usage where as_of_date in ('{prev_week_date}','{B2B_RUN_DATE}') group by 1 order by 1 asc '''.format(prev_week_date = prev_week_date,B2B_RUN_DATE = B2B_RUN_DATE))
df.show()
df_pandas = df.select(df.columns[1:]).toPandas()
df_pandas.diff()

df_pandas['WoWorg_id'] = np.round(df_pandas['org_id'].pct_change() * 100,2)
df_pandas['WoWenduser'] = np.round(df_pandas['end_user_id'].pct_change() * 100,2)
df_pandas['WoWoffer_id'] = np.round(df_pandas['offer_id'].pct_change() * 100,2)
df_pandas['WoWprov'] = np.round(df_pandas['app_seats_provisioned'].pct_change() * 100,2)
df_pandas['WoWdele'] = np.round(df_pandas['app_users_delegated'].pct_change() * 100,2)
df_pandas['WoWacti'] = np.round(df_pandas['app_users_activated'].pct_change() * 100,2)
df_pandas['WoWqalu'] = np.round(df_pandas['app_qalu'].pct_change() * 100,2)
df_pandas['WoWmalu'] = np.round(df_pandas['app_malu'].pct_change() * 100,2)
df_pandas['WoWrmalu'] = np.round(df_pandas['app_rmalu'].pct_change() * 100,2)
df_pandas = df_pandas.dropna()
final_df = df_pandas.iloc[:, 9:]
display(final_df)

# COMMAND ----------

# DBTITLE 1,APP_USAGE 5% CHECK
TABLE_NAME='b2b_app_usage'
body = ''
for x,y in final_df.items():
    for z in y:
        if float(z) > 5 or float(z) < -5:
            a = "WoW count for {x} is greater than +-5% \n".format(x=x)
            body = body+a
        else:
            pass
print(len(body))
if len(body) == 0:
    pass
else:
    send_email(body)

# COMMAND ----------

# DBTITLE 1,Wow Acrobat/ENT QC for app_usage
import numpy as np
import datetime,time
from dateutil.relativedelta import relativedelta

prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

df = spark.sql(''' select as_of_date,sum(app_malu) as mau,sum(app_qalu) as qau, sum(app_rmalu) as rmau from b2b.b2b_app_usage where as_of_date in ('{prev_week_date}','{B2B_RUN_DATE}') and app_name = 'ACROBAT' and dme_acct_segment = 'ENT' and market_segment in ('COMMERCIAL','GOVERNMENT') group by as_of_date,app_name '''.format(prev_week_date = prev_week_date, B2B_RUN_DATE = B2B_RUN_DATE))
df.show()
df_pandas = df.select(df.columns[1:]).toPandas()
df_pandas.diff()

df_pandas['WoWmau'] = np.round(df_pandas['mau'].pct_change() * 100,2)
df_pandas['WoWqau'] = np.round(df_pandas['qau'].pct_change() * 100,2)
df_pandas['WoWrmau'] = np.round(df_pandas['rmau'].pct_change() * 100,2)
df_pandas = df_pandas.dropna()
final_df = df_pandas.iloc[:, 3:]
display(final_df)

# COMMAND ----------

# DBTITLE 1,WoW Acrobat/SMB QC for app_usage
import numpy as np
import datetime,time
from dateutil.relativedelta import relativedelta

prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

df = spark.sql(''' select as_of_date,sum(app_malu) as mau,sum(app_qalu) as qau, sum(app_rmalu) as rmau from b2b.b2b_app_usage where as_of_date in ('{prev_week_date}','{B2B_RUN_DATE}') and app_name = 'ACROBAT' and dme_acct_segment = 'SMB' and market_segment in ('COMMERCIAL','GOVERNMENT') group by as_of_date,app_name '''.format(prev_week_date = prev_week_date, B2B_RUN_DATE = B2B_RUN_DATE))
df.show()
df_pandas = df.select(df.columns[1:]).toPandas()
df_pandas.diff()

df_pandas['WoWmau'] = np.round(df_pandas['mau'].pct_change() * 100,2)
df_pandas['WoWqau'] = np.round(df_pandas['qau'].pct_change() * 100,2)
df_pandas['WoWrmau'] = np.round(df_pandas['rmau'].pct_change() * 100,2)
df_pandas = df_pandas.dropna()
final_df = df_pandas.iloc[:, 3:]
display(final_df)

# COMMAND ----------

# DBTITLE 1,snapshot_fact_enterprise_member_license_delegation  QC
import numpy as np
import datetime,time
from dateutil.relativedelta import relativedelta

prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

snap_df = spark.sql(''' SELECT asofdate, count(member_guid) as member_guid FROM b2b.snapshot_fact_enterprise_member_license_delegation WHERE delegation_status = 'ACCEPTED' AND is_valid = 'Y' AND asofdate in ('{B2B_RUN_DATE}','{prev_week_date}') AND (contract_offer_type in ('ETLA','CUSTOM VIP') OR upper(offering_name) in ('DOCUMENT CLOUD FREE MEMBERSHIP','FREE MEMBERSHIP','FREE MEMBERSHIP.','CREATIVE CLOUD FREE MEMBERSHIP','CUSTOM FONTS','ADOBE EXPRESS - K-12 CLASSROOMS','ADOBE EXPRESS FOR K-12','ADOBE EXPRESS - K-12') or upper(offering_name) like ('CREATIVE CLOUD SHARED DEVICE ACCESS%')) group by 1 order by 1 asc '''.format(B2B_RUN_DATE = B2B_RUN_DATE,prev_week_date = prev_week_date))

snap_df.show()
df_pandas = snap_df.select(snap_df.columns[1:]).toPandas()
df_pandas.diff()

df_pandas['WoWmember_guid'] = np.round(df_pandas['member_guid'].pct_change() * 100,2)
df_pandas = df_pandas.dropna()
final_df = df_pandas.iloc[:, 1:]
display(final_df)

# COMMAND ----------

# DBTITLE 1,snapshot_fact_enterprise_member_license_delegation 5% check
TABLE_NAME='snapshot_fact_enterprise_member_license_delegation'
body = ''
for x,y in final_df.items():
    for z in y:
        if float(z) > 2.5 or float(z) < -2.5:
            a = "WoW count for {x} is greater than +-2.5% \n".format(x=x)
            body = body+a
        else:
            pass
print(len(body))
if len(body) == 0:
    pass
else:
    send_email(body)

# COMMAND ----------

# DBTITLE 1,Last 3 weeks QC mail alert
from email.message import EmailMessage
import smtplib

def qc_mail(subject):
    fromaddr = 'do-not-reply-dpaas-dbx@adobe.com'
    toaddrs = "lat57607@adobe.com,lat41525@adobe.com,tek43117@adobe.com,lat51306@adobe.com"
    SMTPServer = 'adobe-com.mail.protection.outlook.com'
    port = 25 #587
    html_content = """
    <html>
    <body>
    <pre><b>Hi All, 
    The table "b2b.{TABLE_NAME}" has QC ISSUE for last 3 weeks.
    PLease find below details 
    {subject}
    [This is an auto generated email, please do not reply]</b>
    </pre>
    </body>
    </html>
    """
    msg = EmailMessage()
    msg['Subject'] = "LAST 3 WEEKS QC ISSUE"
    msg['From'] = fromaddr
    msg['To'] = toaddrs
    msg.set_content(html_content.format(TABLE_NAME= TABLE_NAME,subject=subject), subtype='html')
    server = smtplib.SMTP(SMTPServer, port)
    server.send_message(msg)
    server.quit()

# COMMAND ----------

# DBTITLE 1,LAST 3 WEEKS APP USAGE METRICS QC
TABLE_NAME = 'app_usage'
import datetime,time
from dateutil.relativedelta import relativedelta

one_week_ago = B2B_RUN_DATE - relativedelta(days=7)
two_week_ago = one_week_ago - relativedelta(days=7)
three_week_ago = two_week_ago - relativedelta(days=7)

app_usage_df = spark.sql(''' select as_of_date, count(org_id) as org_id, count(end_user_id) as end_user_id, count(offer_id) as offer_id,sum(cast(app_seats_provisioned as int)) as app_seats_provisioned, sum(cast(app_users_delegated as int)) as app_users_delegated, sum(cast(app_users_activated as int)) as app_users_activated, sum(cast(app_qalu as int)) as app_qalu, sum(cast(app_malu as int)) as app_malu, sum(cast(app_rmalu as int)) as app_rmalu from b2b.b2b_app_usage where as_of_date in ('{one_week_ago}','{B2B_RUN_DATE}','{two_week_ago}','{three_week_ago}') group by 1 order by 1 asc '''.format(one_week_ago = one_week_ago,B2B_RUN_DATE = B2B_RUN_DATE,two_week_ago=two_week_ago,three_week_ago=three_week_ago))
app_usage_df.show()
subject = ''
for i in app_usage_df.columns[1:]:
    print(i)
    column_value_list = [row[i] for row in app_usage_df.select(i).collect()]
    print(column_value_list)
    if (column_value_list[3] < column_value_list[2] and column_value_list[2] < column_value_list[1] and column_value_list[1] < column_value_list[0]) :
        a = "values are decreasing for {i} last 3 weeks\n".format(i=i)
        subject = subject+a
    else:
        pass
print(len(subject))
if len(subject) == 0:
    pass
else:
    qc_mail(subject)

# COMMAND ----------

# DBTITLE 1,LAST 3 WEEKS DEPLOYMENT USAGE METRICS QC
TABLE_NAME = 'b2b_deployment_usage'
import datetime,time
from dateutil.relativedelta import relativedelta

one_week_ago = B2B_RUN_DATE - relativedelta(days=7)
two_week_ago = one_week_ago - relativedelta(days=7)
three_week_ago = two_week_ago - relativedelta(days=7)

deploy_df = spark.sql("select as_of_date, sum(cast(provisioned as int)) as provisioned, sum(cast(local_licensed_qty as int)) as local_licensed_qty, sum(cast(delegated as int)) as delegated, sum(cast(activated as int)) as activated, sum(cast(mau as int)) as mau, sum(cast(qau as int)) as qau, sum(cast(rmau as int)) as rmau from b2b.b2b_deployment_usage where as_of_date in ('{B2B_RUN_DATE}','{one_week_ago}','{two_week_ago}','{three_week_ago}') group by 1 order by 1 asc ".format(B2B_RUN_DATE = B2B_RUN_DATE,one_week_ago = one_week_ago,two_week_ago=two_week_ago,three_week_ago=three_week_ago))
deploy_df.show()
subject = ''
for i in deploy_df.columns[1:]:
    print(i)
    column_value_list = [row[i] for row in deploy_df.select(i).collect()]
    print(column_value_list)
    if (column_value_list[3] < column_value_list[2] and column_value_list[2] < column_value_list[1] and column_value_list[1] < column_value_list[0]) :
        a = "values are decreasing for {i} last 3 weeks\n".format(i=i)
        subject = subject+a
    else:
        pass
print(len(subject))
if len(subject) == 0:
    pass
else:
    qc_mail(subject)

# COMMAND ----------

# DBTITLE 1,enterprise.fact_snapshot_org_activation QC
import numpy as np
import datetime,time
import pyspark.sql.functions as f
from dateutil.relativedelta import relativedelta


prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

org_df = spark.sql(''' select snapshot_date,contract_offer_type,count(org_id) as org_id,count(offer_id) as offer_id,count(contract_id) as contract_id from  enterprise.fact_snapshot_org_activation WHERE snapshot_date in ('{B2B_RUN_DATE}') group by 1,2 order by 2 '''.format(B2B_RUN_DATE = B2B_RUN_DATE))

org_df_prev = spark.sql(''' select snapshot_date,contract_offer_type,count(org_id) as org_id,count(offer_id) as offer_id,count(contract_id) as contract_id from  enterprise.fact_snapshot_org_activation WHERE snapshot_date in ('{prev_week_date}') group by 1,2 order by 2 '''.format(prev_week_date = prev_week_date))

org_df.show()
org_df_prev.show()

final_df = org_df.join(org_df_prev, org_df.contract_offer_type == org_df_prev.contract_offer_type,'inner').select(org_df['contract_offer_type'],f.round(((org_df["org_id"] - org_df_prev["org_id"])/(org_df_prev["org_id"]) * 100),2).alias("org_id"),f.round(((org_df["offer_id"] - org_df_prev["offer_id"])/(org_df_prev["offer_id"]) * 100),2).alias("offer_id"),f.round(((org_df["contract_id"] - org_df_prev["contract_id"])/(org_df_prev["contract_id"]) * 100),2).alias("contract_id"))

df_pandas = final_df.select(final_df.columns[1:]).toPandas()

# COMMAND ----------

# DBTITLE 1,enterprise.fact_snapshot_org_activation 4% check
TABLE_NAME='enterprise.fact_snapshot_org_activation'
body = ''
for x,y in df_pandas.items():
    for z in y:
        if float(z) > 4 or float(z) < -4:
            a = "WoW count for {x} is greater than +-4% i.e {z} \n".format(x=x,z=z)
            body = body+a
        else:
            pass
print(len(body))
if len(body) == 0:
    pass
else:
    send_email(body)

# COMMAND ----------

# DBTITLE 1, app_names via app_malu/qalu/rmalu in app_usage  QC for last 3 weeks
import datetime,time
from dateutil.relativedelta import relativedelta

one_week_ago = B2B_RUN_DATE - relativedelta(days=7)
two_week_ago = one_week_ago - relativedelta(days=7)
three_week_ago = two_week_ago - relativedelta(days=7)

final_df = spark.sql(''' select as_of_date,app_name,sum(app_malu) as app_malu,sum(app_qalu) as qalu,sum(app_rmalu) as rmalu from b2b.b2b_app_usage where as_of_date in ('{B2B_RUN_DATE}','{one_week_ago}','{two_week_ago}','{three_week_ago}') group by 1,2 order by 2,1 '''.format(B2B_RUN_DATE=B2B_RUN_DATE,one_week_ago=one_week_ago,two_week_ago=two_week_ago,three_week_ago=three_week_ago))
#final_df.show()
TABLE_NAME = 'b2b_app_usage'
app_list = final_df.select("app_name").distinct().orderBy('app_name').rdd.flatMap(lambda x: x).collect()
print(app_list)
subject = ''
for i in app_list:
    df = final_df.filter(final_df.app_name == i)
    for j in df.columns[2:]:
        #subject = ''
        #print(j)
        column_value_list = [row[j] for row in df.select(j).collect()]
        #print(column_value_list)
        if (column_value_list[3] < column_value_list[2] and column_value_list[2] < column_value_list[1] and column_value_list[1] < column_value_list[0]) :
            a = "values are decreasing for {i} for {j} last 3 weeks\n".format(i=i,j=j)
            subject = subject+a
            #print(subject)
            #print(len(subject))
        else:
            pass
print(len(subject))
if len(subject) == 0:
    pass
else:
    qc_mail(subject)

# COMMAND ----------

# DBTITLE 1,b2b_app_usage org_id wrt contract_type QC
import numpy as np
import datetime,time
import pyspark.sql.functions as f
from dateutil.relativedelta import relativedelta


prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

org_df = spark.sql(''' select as_of_date,contract_type,count(org_id) as org_id,count(offer_id) as offer_id from  b2b.b2b_app_usage WHERE as_of_date in ('{B2B_RUN_DATE}') group by 1,2 order by 2 '''.format(B2B_RUN_DATE = B2B_RUN_DATE))

org_df_prev = spark.sql(''' select as_of_date,contract_type,count(org_id) as org_id,count(offer_id) as offer_id from  b2b.b2b_app_usage WHERE as_of_date in ('{prev_week_date}') group by 1,2 order by 2 '''.format(prev_week_date = prev_week_date))

org_df.show()
org_df_prev.show()

final_df = org_df.join(org_df_prev, org_df.contract_type == org_df_prev.contract_type,'inner').select(org_df['contract_type'],f.round(((org_df["org_id"] - org_df_prev["org_id"])/(org_df_prev["org_id"]) * 100),2).alias("org_id"),f.round(((org_df["offer_id"] - org_df_prev["offer_id"])/(org_df_prev["offer_id"]) * 100),2).alias("offer_id"))

df_pandas = final_df.select(final_df.columns[1:]).toPandas()
display(df_pandas)

# COMMAND ----------

# DBTITLE 1,b2b_app_usage org_id,offer_id wrt contract_type +-5% check
TABLE_NAME='b2b.b2b_app_usage'
body = ''
app_list = final_df.select("contract_type").distinct().orderBy('contract_type').rdd.flatMap(lambda x: x).collect()
for i in app_list:
    df = final_df.filter(final_df.contract_type == i)
    for x in df.columns[1:]:
        column_value_list = [row[x] for row in df.select(x).collect()]
        if (column_value_list[0] > 5 or column_value_list[0] < -5):
            value = column_value_list[0]
            a = "WoW count for {i} for {x} is {value} \n".format(x=x,i=i,value=value)
            body = body+a
        else:
            pass
print(len(body))
if len(body) == 0:
    pass
else:
    send_email(body)

# COMMAND ----------

# DBTITLE 1,app_usage app_name email
from email.message import EmailMessage
import smtplib

def qc_mail(body):
    fromaddr = 'do-not-reply-dpaas-dbx@adobe.com'
    toaddrs = "lat57607@adobe.com,lat41525@adobe.com,tek43117@adobe.com,lat51306@adobe.com"
    SMTPServer = 'adobe-com.mail.protection.outlook.com'
    port = 25 #587
    html_content = """
    <html>
    <body>
    <pre><b>Hi All, 
    The table "b2b.{TABLE_NAME}" wrt app_name has QC ISSUE.
    PLease find below details 
    {body}
    [This is an auto generated email, please do not reply]</b>
    </pre>
    </body>
    </html>
    """
    msg = EmailMessage()
    msg['Subject'] = "B2B_APP_USAGE APP NAME QC ISSUE"
    msg['From'] = fromaddr
    msg['To'] = toaddrs
    msg.set_content(html_content.format(TABLE_NAME= TABLE_NAME,body=body), subtype='html')
    server = smtplib.SMTP(SMTPServer, port)
    server.send_message(msg)
    server.quit()

# COMMAND ----------

# DBTITLE 1,WoW b2b_app_usage wrt app_name
import numpy as np
import datetime,time
import pyspark.sql.functions as f
from dateutil.relativedelta import relativedelta


prev_week_date = B2B_RUN_DATE - relativedelta(days=7)

org_df_app = spark.sql(''' select sum(app_seats_provisioned) as provisioned,sum(app_users_activated) as activated,sum(app_users_delegated) as assigned, sum(app_malu) as malu,sum(app_qalu) as qalu,sum(app_rmalu) as rmalu, app_name from b2b.b2b_app_usage where as_of_date = '{B2B_RUN_DATE}' and market_segment IN ('COMMERCIAL','GOVERNMENT') group by app_name  '''.format(B2B_RUN_DATE = B2B_RUN_DATE))

org_df_prev_app = spark.sql(''' select sum(app_seats_provisioned) as provisioned,sum(app_users_activated) as activated,sum(app_users_delegated) as assigned, sum(app_malu) as malu,sum(app_qalu) as qalu,sum(app_rmalu) as rmalu, app_name from b2b.b2b_app_usage where as_of_date = '{prev_week_date}' and market_segment IN ('COMMERCIAL','GOVERNMENT') group by app_name '''.format(prev_week_date = prev_week_date))

# org_df_app.show()
# org_df_prev_app.show()

final_df_app = org_df_app.join(org_df_prev_app, org_df_app.app_name == org_df_prev_app.app_name,'inner').select(org_df_app['app_name'],f.round(((org_df_app["provisioned"] - org_df_prev_app["provisioned"])/(org_df_prev_app["provisioned"]) * 100),2).alias("provisioned"),f.round(((org_df_app["activated"] - org_df_prev_app["activated"])/(org_df_prev_app["activated"]) * 100),2).alias("activated"),f.round(((org_df_app["assigned"] - org_df_prev_app["assigned"])/(org_df_prev_app["assigned"]) * 100),2).alias("assigned"),f.round(((org_df_app["malu"] - org_df_prev_app["malu"])/(org_df_prev_app["malu"]) * 100),2).alias("malu"),f.round(((org_df_app["qalu"] - org_df_prev_app["qalu"])/(org_df_prev_app["qalu"]) * 100),2).alias("qalu"),f.round(((org_df_app["rmalu"] - org_df_prev_app["rmalu"])/(org_df_prev_app["rmalu"]) * 100),2).alias("rmalu"))

final_df_app = final_df_app.fillna({'provisioned':'0','activated':'0','assigned':'0','malu':'0','qalu':'0','rmalu':'0'})
final_df_app.show(100,False)
df_pandas = final_df_app.select(final_df_app.columns[1:]).toPandas()

# COMMAND ----------

# DBTITLE 1,WoW b2b_app_usage wrt app_name 5% check
TABLE_NAME='b2b_app_usage'
body = ''
app_list = final_df_app.select("app_name").distinct().orderBy('app_name').rdd.flatMap(lambda x: x).collect()
# print(app_list)
for i in app_list:
    df = final_df_app.filter(final_df_app.app_name == i)
    for j in df.columns[1:6]:
        #print(j)
        column_value_list = [row[j] for row in df.select(j).collect()]
        value = column_value_list[0]
        # print(column_value_list[0])
        if float(column_value_list[0]) > 10 or float(column_value_list[0]) < -10:
            a = "WoW count for {j} in {i} is greater than +-10% i.e {value} \n".format(j=j,value=value,i=i)
            body = body+a
            # print(body)
        else:
            pass
print(len(body))
if len(body) == 0:
    pass
else:
    qc_mail(body)

# COMMAND ----------

TABLE_NAME='b2b_app_usage'
body = ''
app_list = final_df_app.select("app_name").distinct().orderBy('app_name').rdd.flatMap(lambda x: x).collect()
# print(app_list)
for i in app_list:
    df = final_df_app.filter(final_df_app.app_name == i)
    for j in df.columns[6:7]:
        #print(j)
        column_value_list = [row[j] for row in df.select(j).collect()]
        value = column_value_list[0]
        # print(column_value_list[0])
        if float(column_value_list[0]) > 15 or float(column_value_list[0]) < -15:
            a = "WoW count for {j} in {i} is greater than +-15% i.e {value} \n".format(j=j,value=value,i=i)
            body = body+a
            # print(body)
        else:
            pass
print(len(body))
if len(body) == 0:
    pass
else:
    qc_mail(body)
