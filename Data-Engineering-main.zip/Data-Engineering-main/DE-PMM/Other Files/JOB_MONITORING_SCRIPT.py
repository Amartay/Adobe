# Databricks notebook source
# DBTITLE 1,Table Monitoring Script
from pyspark.sql.types import StringType, DateType, StructType, StructField
from datetime import date
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

run_month = datetime.now().month
# run_month = date.today().strftime("%m")
run_year = date.today().strftime("%Y")
monthkey = date.today().strftime("%Y-%m")
month = date.today().strftime("%m")

today = datetime.today()
days_since_friday = (today.weekday() + 3) % 7
last_friday = today - timedelta(days=days_since_friday)
run_date = last_friday.date()

current_date = date.today()
now = date.today().strftime("%Y-%m-%d")
first_monday_of_month = datetime(int(run_year), int(month), 7) + timedelta(
    -(datetime(int(run_year), int(month), 7).weekday()))
if current_date == first_monday_of_month.date():
    run_month = run_month - 1
    monthkey = (current_date - relativedelta(months=1)).strftime('%Y-%m')
elif current_date.year != run_date.year:
    run_month = run_date.month
    monthkey = str(run_date.year) + str('-') + str(run_date.month)
    run_year = run_date.year
else:
    run_month = run_month
    monthkey = monthkey

monitoring_tables_df = spark.sql(
    """select schema_name,table_name,frequency,process,workflow_name,dbx_job,team from b2b.monitoring_tables where end_date is NULL"""
).collect()

schema = StructType(
    [
        StructField("table_name", StringType(), True),
        StructField("workflow_name", StringType(), True),
        StructField("snapshot_date", DateType(), True),
        StructField("frequency", StringType(), True),
        StructField("run_date", DateType(), True),
        StructField("dbx_job", StringType(), True),
        StructField("team", StringType(), True),
        StructField("schema_name", StringType(), True)
    ]
)
final_df = spark.createDataFrame([], schema)

for row in monitoring_tables_df:
    schema_name = row["schema_name"]
    table_name = row["table_name"]
    process = row["process"]
    frequency = row["frequency"]
    workflow_name = row["workflow_name"]
    dbx_job = row["dbx_job"]
    team = row["team"]

    try:
        if process.lower() == "hive2" and frequency.lower() == "b2b_daily":
            spark.sql("""show partitions {schema_name}.{table_name}""".format(schema_name=schema_name,
                                                                              table_name=table_name)).createOrReplaceTempView(
                "tmp1")
            spark.sql(
                """ select split(split(partition,"/")[0],"=")[1] as flag, split(split(partition,"/")[1],"=")[1] as as_of_date from tmp1 """).createOrReplaceTempView(
                "tmp2")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/flag=D/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(as_of_date) as date) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team, "{schema_name}" as schema_name from tmp2,run_date""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == "hive2" and frequency.lower() in ("b2b_saturday", "b2b_sunday", "friday"):
            spark.sql("""show partitions {schema_name}.{table_name} """.format(schema_name=schema_name,
                                                                               table_name=table_name)).createOrReplaceTempView(
                "tmp1")
            spark.sql(
                """ select split(split(partition,"/")[0],"=")[1] as flag, split(split(partition,"/")[1],"=")[1] as as_of_date from tmp1 """).createOrReplaceTempView(
                "tmp2")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/flag=W/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(as_of_date) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from tmp2,run_date where flag ='W' """.format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == "uda_uda_finance_arr_vw_entarr":
            if frequency.lower() == "b2b_daily":
                spark.sql("""show partitions {schema_name}.{table_name} """.format(schema_name=schema_name,
                                                                                   table_name=table_name)).createOrReplaceTempView(
                    "tmp1")
                spark.sql(
                    """select split(split(partition,"/")[0],"=")[1] as snapshottype ,split(split(partition,"/")[1],"=")[1] as datedate from tmp1""").createOrReplaceTempView(
                    "tmp2")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/SnapshotType=D/".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(datedate) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team, "{schema_name}" as schema_name from tmp2,run_date where snapshottype = 'D'""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif frequency.lower() == "b2b_saturday":
                spark.sql("""show partitions {schema_name}.{table_name} """.format(schema_name=schema_name,
                                                                                   table_name=table_name)).createOrReplaceTempView(
                    "tmp1")
                spark.sql(
                    """select split(split(partition,"/")[0],"=")[1] as snapshottype ,split(split(partition,"/")[1],"=")[1] as datedate from tmp1""").createOrReplaceTempView(
                    "tmp2")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/SnapshotType=W/".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(datedate) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from tmp2,run_date where snapshottype = 'W' """.format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            else:
                spark.sql("""show partitions {schema_name}.{table_name} """.format(schema_name=schema_name,
                                                                                   table_name=table_name)).createOrReplaceTempView(
                    "tmp1")
                spark.sql(
                    """select split(split(partition,"/")[0],"=")[1] as snapshottype ,split(split(partition,"/")[1],"=")[1] as datedate from tmp1""").createOrReplaceTempView(
                    "tmp2")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/SnapshotType=Q/".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(datedate) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from tmp2,run_date where snapshottype = 'Q' """.format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
        elif process.lower() == "cli" and workflow_name not in (
        "DREMIO_LOAD", 'b2b_source_tables', 'cust_research_tool'):
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("max_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == "cli" and workflow_name == 'DREMIO_LOAD':
            if table_name in ('dc_acrobatstar_feature', 'dc_acrotraystar_create_share_conversion_status',
                              'dc_acrotraystar_create_share_home_click', 'dc_acrotraystar_create_share_saveas_pdf'):
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/year={run_year}/month={run_month}/monthkey={monthkey}".format(
                        table_name=table_name, schema_name=schema_name, run_year=run_year, run_month=run_month,
                        monthkey=monthkey))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif table_name in (
            'hb_monitor_user_mapping_snapshot', 'a_sign_pub_agreement', 'a_sign_setting', 'a_sign_account',
            'a_sign_pod', 'a_sign_agreement_event', 'a_sign_user'):
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
        elif process.lower() == "applaunch_all":
            spark.createDataFrame(
                dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/month={run_month}/year={run_year}/license_type=FRL/".format(
                        schema_name=schema_name, table_name=table_name, run_month=run_month,
                        run_year=run_year))).createOrReplaceTempView("max_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == "fact_user_activity":
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/month={run_month}/year={run_year}/monthkey={monthkey}".format(
                    schema_name=schema_name, table_name=table_name, run_month=run_month, run_year=run_year,
                    monthkey=monthkey))).createOrReplaceTempView("max_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == "enterprise":
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}".format(
                    schema_name=schema_name, table_name=table_name))).createOrReplaceTempView("max_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == 'hive' and table_name in (
        'ca_ent_arr_model_all', 'enterprise_fact_user_activity', 'serial_mau_wau_fisc_wk_end', 'ss_sustained_base'):
            if table_name == "ca_ent_arr_model_all":
                spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                  schema_name=schema_name)).createOrReplaceTempView(
                    "max_date")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}/snapshot_type=W/".format(
                        schema_name=schema_name, table_name=table_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(split(partition,"/")[1],"=")[1])) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif table_name == "enterprise_fact_user_activity":
                spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                  schema_name=schema_name)).createOrReplaceTempView(
                    "max_date")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}".format(
                        schema_name=schema_name, table_name=table_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(split(partition,"/")[1],"=")[1])) as snapshot_date, "{frequency}" as frequency,to_date(max(split(split(partition,"/")[1],"=")[1])) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif table_name in ("serial_mau_wau_fisc_wk_end", "ss_sustained_base"):
                spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                  schema_name=schema_name)).createOrReplaceTempView(
                    "max_date")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(split(partition,"/")[0],"=")[1])) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
        elif process.lower() == 'hive' and table_name in (
        'fact_snapshot_stock_purchased_allocated_consumed', 'fact_product_versions', 'stg_qad',
        'sign_all_users_de_duped_snapshot', 'b2b_ax_app_usage'):
            if table_name in (
            'fact_product_versions', 'stg_qad', 'sign_all_users_de_duped_snapshot', 'b2b_ax_app_usage'):
                spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                  schema_name=schema_name)).createOrReplaceTempView(
                    "max_date")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date((select max(split(partition,"=")[1]) as as_of_date from max_date where split(partition,"=")[1]  NOT IN  (select max(split(partition,"=")[1]) from max_date))) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif table_name == 'fact_snapshot_stock_purchased_allocated_consumed':
                spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                  schema_name=schema_name)).createOrReplaceTempView(
                    "max_date")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date((select max(split(partition,"=")[1]) as as_of_date from max_date where split(partition,"=")[1]  NOT IN  (select max(split(partition,"=")[1]) from max_date))) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
        elif process.lower() == 'hive' and table_name in (
        'sign_uda_accounts', 'vw_td_ddomeaccountmastereccsnapshot', 'uda_vw_tf_adobesignconsolidatedarr',
        'b2b_acom_clickstream_pivot_combined'):
            spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                              schema_name=schema_name)).createOrReplaceTempView(
                "tmp1")
            spark.sql(
                """ select concat(substr(split(partition,'=')[1],1,4),'-',substr(split(partition,'=')[1],5,2),'-',substr(split(partition,'=')[1],7,2)) as as_of_date from tmp1 """).createOrReplaceTempView(
                "tmp2")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,cast(max(as_of_date) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from tmp2,run_date """.format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == 'hive' and table_name in ('uda_vw_tf_adobesignmigrationconsolidated'):
            spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                              schema_name=schema_name)).createOrReplaceTempView(
                "tmp1")
            spark.sql(
                """ select concat(substr(split(partition,'=')[1],1,4),'-',substr(split(partition,'=')[1],5,2),'-',substr(split(partition,'=')[1],7,2)) as as_of_date from tmp1 """).createOrReplaceTempView(
                "tmp2")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date((select max(as_of_date) from tmp2 where as_of_date not in (select max(as_of_date) from tmp2))) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from run_date """.format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == 'hive' and frequency.lower() == "b2b_daily" and table_name in (
        'uda_replicn_sf_corp_uda_vw_apttusproposalproposallineitem', 'uda_uda_sales_dbo_vw_td_sellableproduct',
        'sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota'):
            spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                              schema_name=schema_name)).createOrReplaceTempView(
                "tmp1")
            spark.sql(
                """ select split(split(partition,"/")[0],"=")[1] as flag, split(split(partition,"/")[1],"=")[1] as as_of_date from tmp1 """).createOrReplaceTempView(
                "tmp2")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date((select max(as_of_date) from tmp2 where as_of_date not in (select max(as_of_date) from tmp2))) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from run_date """.format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == 'hive' and frequency.lower() in ('enterprise', 'enterprise_sun_run_fri_snap'):
            spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                              schema_name=schema_name)).createOrReplaceTempView(
                "max_date")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(partition,"=")[1])) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)

        elif process.lower() == 'hive' and table_name in ('amazon_connect_raw_sales', 'fact_oac_call_chat'):
            spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                              schema_name=schema_name)).createOrReplaceTempView(
                "max_date")
            spark.sql(
                """select split(split(partition,"/")[0],"=")[1] as file_type,split(split(partition,"/")[1],"=")[1] as insert_date from max_date""").createOrReplaceTempView(
                "max_date")
            spark.sql(
                """select min(insert_date) as insert_date from (select file_type,max(insert_date) as insert_date from max_date group by file_type)""").createOrReplaceTempView(
                "max_date")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(insert_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)

        elif process.lower() == 'hive':
            spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                              schema_name=schema_name)).createOrReplaceTempView(
                "max_date")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(partition,"=")[1])) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == "cli" and workflow_name == 'b2b_source_tables':
            if schema_name == 'ocf_analytics':
                spark.createDataFrame(dbutils.fs.ls(
                    "abfss://or1-prod-data@azr6665prddpaasocf.dfs.core.windows.net/user/hive/warehouse/ocf/ocf_analytics.db/{table_name}".format(
                        schema_name=schema_name, table_name=table_name))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif table_name == 'dme_customer_profile':
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif schema_name == 'ids_coredata':
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ids_common/{schema_name}.db/{table_name}".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif schema_name == 'ocf':
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ocf/ocf_analytics.db/{table_name}".format(
                        table_name=table_name))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"ocf" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif schema_name == 'gedi_shared':
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@azr6665prddpaasgmi.dfs.core.windows.net/user/hive/warehouse/gmi_eo/{schema_name}.db/{table_name}".format(
                        schema_name=schema_name, table_name=table_name))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif schema_name == 'frameio':
                spark.createDataFrame(dbutils.fs.ls(
                    "abfss://or1-prod-data@azr6665prddpaasframeio.dfs.core.windows.net/user/hive/warehouse/frameio/{schema_name}.db/{table_name}".format(
                        schema_name=schema_name, table_name=table_name))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif schema_name == 'mdpd_target':
                spark.createDataFrame(dbutils.fs.ls(
                    "abfss://or1-prod-data@azr6665prddpaasmdpd.dfs.core.windows.net/user/hive/warehouse/ids_mdpd/{schema_name}.db/{table_name}".format(
                        schema_name=schema_name, table_name=table_name))).createOrReplaceTempView("max_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
        elif process.lower() == 'hive2' and workflow_name == 'b2b_source_tables':
            if schema_name == 'darwin_max':
                if table_name == 'ets_subsource_service_events':
                    spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                      schema_name=schema_name)).createOrReplaceTempView(
                        "max_date")
                    spark.createDataFrame(dbutils.fs.ls(
                        "abfs://or1-prod-data@azr6665prddpaasetsmax.dfs.core.windows.net/max/{schema_name}/{table_name}/event_code=SUBSOURCE_SERVICE/".format(
                            table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                    table_entry = spark.sql(
                        """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(event_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                            table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                            team=team, schema_name=schema_name))
                    final_df = final_df.union(table_entry)
                elif table_name == 'ets_painter_service_events':
                    spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                      schema_name=schema_name)).createOrReplaceTempView(
                        "max_date")
                    spark.createDataFrame(dbutils.fs.ls(
                        "abfs://or1-prod-data@azr6665prddpaasetsmax.dfs.core.windows.net/max/{schema_name}/{table_name}/event_code=PAINTER_SERVICE/".format(
                            table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                    table_entry = spark.sql(
                        """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(event_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                            table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                            team=team, schema_name=schema_name))
                    final_df = final_df.union(table_entry)
                elif table_name == 'ets_alchemist_service_events':
                    spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                      schema_name=schema_name)).createOrReplaceTempView(
                        "max_date")
                    spark.createDataFrame(dbutils.fs.ls(
                        "abfs://or1-prod-data@azr6665prddpaasetsmax.dfs.core.windows.net/max/{schema_name}/{table_name}/event_code=ALCHEMIST_SERVICE/".format(
                            table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                    table_entry = spark.sql(
                        """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(event_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                            table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                            team=team, schema_name=schema_name))
                    final_df = final_df.union(table_entry)
                elif table_name == 'ets_designer_service_events':
                    spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                      schema_name=schema_name)).createOrReplaceTempView(
                        "max_date")
                    spark.createDataFrame(dbutils.fs.ls(
                        "abfs://or1-prod-data@azr6665prddpaasetsmax.dfs.core.windows.net/max/{schema_name}/{table_name}/event_code=DESIGNER_SERVICE/".format(
                            table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                    table_entry = spark.sql(
                        """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(event_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                            table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                            team=team, schema_name=schema_name))
                    final_df = final_df.union(table_entry)
                elif table_name == 'ets_modeler_service_events':
                    spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                      schema_name=schema_name)).createOrReplaceTempView(
                        "max_date")
                    spark.createDataFrame(dbutils.fs.ls(
                        "abfs://or1-prod-data@azr6665prddpaasetsmax.dfs.core.windows.net/max/{schema_name}/{table_name}/event_code=MODELER_SERVICE/".format(
                            table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                    table_entry = spark.sql(
                        """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(event_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                            table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                            team=team, schema_name=schema_name))
                    final_df = final_df.union(table_entry)
            elif schema_name in ('spark', 'ccex'):
                if table_name in ('spark_user_guid_map', 'ccex_active_users_b'):
                    spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                      schema_name=schema_name)).createOrReplaceTempView(
                        "max_date")
                    spark.createDataFrame(dbutils.fs.ls(
                        "abfss://or1-prod-data@azr6665prddpaasaxds.dfs.core.windows.net/user/hive/warehouse/axds/{schema_name}.db/{table_name}/".format(
                            table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                    table_entry = spark.sql(
                        """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(event_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                            table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                            team=team, schema_name=schema_name))
                    final_df = final_df.union(table_entry)
                elif table_name == 'spark_active_users_b':
                    spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                      schema_name=schema_name)).createOrReplaceTempView(
                        "max_date")
                    spark.createDataFrame(dbutils.fs.ls(
                        "abfss://or1-prod-data@azr6665prddpaasaxds.dfs.core.windows.net/user/hive/warehouse/axds/{schema_name}.db/{table_name}/".format(
                            table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                    table_entry = spark.sql(
                        """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(split(partition,'/')[0],'=')[1])) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                            table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                            team=team, schema_name=schema_name))
                    final_df = final_df.union(table_entry)
            elif schema_name == 'genai':
                spark.sql(
                    """show partitions {schema_name}.{table_name} partition (event_stream='FIREFLY_WEB__USERS')""".format(
                        table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("max_date")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@abdalis.dfs.core.windows.net/user/hive/warehouse/xeds/{schema_name}.db/{table_name}/event_stream=FIREFLY_WEB__USERS/".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(split(partition,'/')[1],'=')[1])) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
            elif schema_name == 'ocf':
                spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                                  schema_name=schema_name)).createOrReplaceTempView(
                    "max_date")
                spark.createDataFrame(dbutils.fs.ls(
                    "abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ocf/{schema_name}.db/{table_name}/source=PROD_OFFERS_API/".format(
                        table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
                table_entry = spark.sql(
                    """select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date(max(load_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                        table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job,
                        team=team, schema_name=schema_name))
                final_df = final_df.union(table_entry)
        elif process.lower() == "cli" and table_name in ('b2b_cust_research_arr', 'b2b_cust_research_deployment'):
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("max_date")
            spark.sql("select *  from {schema_name}.{table_name}".format(table_name=table_name,
                                                                         schema_name=schema_name)).createOrReplaceTempView(
                "snapshot_d")
            table_entry = spark.sql(
                """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(max(as_of_date)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,snapshot_d""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == "cli" and table_name in ('b2b_connections'):
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("max_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
        elif process.lower() == "hive2" and table_name in (
        'l2_sa_sfdc_pipeline_core_snapshot', 'l2_sa_sfdc_pipeline_line_item_snapshot',
        'uda_dx_tap_prod_dbo_report_planning_cube_child_dme'):
            spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name,
                                                                              schema_name=schema_name)).createOrReplaceTempView(
                "max_date")
            spark.createDataFrame(dbutils.fs.ls(
                "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(
                    table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
            table_entry = spark.sql(
                """select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(as_of_date)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(
                    table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                    schema_name=schema_name))
            final_df = final_df.union(table_entry)
    except:
        table_entry = spark.sql(
            """select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date('0001-01-01') as snapshot_date, "{frequency}" as frequency,to_date('0001-01-01') as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name """.format(
                table_name=table_name, workflow_name=workflow_name, frequency=frequency, dbx_job=dbx_job, team=team,
                schema_name=schema_name))
        final_df = final_df.union(table_entry)

final_df.write.mode("overwrite").saveAsTable("b2b_stg.tabledetails_dbx")

# COMMAND ----------

table_metrics_df = spark.sql(
    ''' select * from b2b_stg.jobdetails_dbx a left join b2b_stg.tabledetails_dbx b on a.run_name = b.dbx_job union all select b.start_time,b.end_time,b.run_name,b.run_duration_minutes,a.table_name,a.workflow_name,a.snapshot_date,a.frequency,a.run_date,a.dbx_job,a.team,a.schema_name from b2b_stg.tabledetails_dbx a left join b2b_stg.jobdetails_dbx b on b.run_name = a.dbx_job where a.frequency in ('LOOKUPS','ENTERPRISE','ENTERPRISE_SUN_RUN_FRI_SNAP','ENTERPRISE_FRIDAY') union all select b.start_time,b.end_time,b.run_name,b.run_duration_minutes,a.table_name,a.workflow_name,a.snapshot_date,a.frequency,a.run_date,a.dbx_job,a.team,a.schema_name from b2b_stg.tabledetails_dbx a left join b2b_stg.jobdetails_dbx b on b.run_name = a.dbx_job where a.workflow_name in ('b2b_source_tables') ''')
table_metrics_df.write.mode("overwrite").saveAsTable("b2b_stg.table_stats")

# COMMAND ----------

from pyspark.sql.functions import *

table_vw = spark.sql("select * from b2b_stg.sqoop_table_entries")
table_det = table_vw.withColumn("execution_time_sec",
                                unix_timestamp(col('end_time')) - unix_timestamp(col('start_time'))) \
    .withColumn('execution_time_min', round(col('execution_time_sec') / 60))

cols = table_det.columns
cols = cols[0:3] + cols[5:7] + cols[3:5]
table_det = table_det[cols]

# COMMAND ----------

from random import randint
from time import sleep

table_det.createOrReplaceTempView("entries")
# sleep(randint(1,30))
spark.sql(''' MERGE INTO b2b_stg.sqoop_table_details details USING entries entries
ON details.workflow_name = entries.workflow_name
and details.table_name = entries.table_name
WHEN MATCHED THEN
  UPDATE SET
    start_time = entries.start_time,
    end_time = entries.end_time,
    workflow_name = details.workflow_name,
    execution_time_sec = entries.execution_time_sec,
    execution_time_min = entries.execution_time_min,
    table_name = details.table_name,
    frequency = details.frequency
WHEN  NOT MATCHED THEN
INSERT (start_time,end_time,workflow_name,execution_time_sec,execution_time_min,table_name,frequency) VALUES(
    entries.start_time,
    entries.end_time,
    entries.workflow_name,
    entries.execution_time_sec,
    entries.execution_time_min,
    entries.table_name,
    entries.frequency) ''')
spark.sql("select * from b2b_stg.sqoop_table_entries").show()
spark.sql("truncate table b2b_stg.sqoop_table_entries ")
