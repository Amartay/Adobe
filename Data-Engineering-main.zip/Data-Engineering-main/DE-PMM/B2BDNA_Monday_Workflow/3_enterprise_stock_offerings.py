# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.enterprise_stock_offerings partition(as_of_date)
select
org_id ,
org_name ,
cast(end_user_id as int) as end_user_id,
geo ,
market_area ,
market_segment ,
pro_provisioned ,
pro_w_w_provisioned ,
pro_assigned ,
pro_w_w_assigned ,
pro_activated_seats ,
pro_w_w_activated_seats ,
pro_qad ,
pro_w_w_qad_downloaders ,
pro_rqad ,
pro_w_w_rqad_downloaders ,
pro_content_downloads ,
pro_w_w_content_downloads ,
cast(pro_contract_start_date as date) as pro_contract_start_date ,
cast(pro_contract_end_date as date) as pro_contract_end_date ,
pro_billing_type ,
stock_billing_type ,
stock_assigned_count ,
stock_w_w_assigned_count ,
stock_consumption_count ,
stock_w_w_consumption_count ,
stock_provisioned_count ,
stock_w_w_provisioned_count ,
stock_users_assigned ,
stock_w_w_stock_users_assigned ,
stock_qad ,
stock_w_w_qad ,
stock_content_downloads ,
stock_w_w_content_downloads ,
stock_rqad ,
stock_w_w_rqad ,
cast(stock_contract_start_date as date) as stock_contract_start_date,
cast(stock_contract_end_date as date) as stock_contract_end_date,
cast(as_of_date as date) as as_of_date
from  
(
select 
org_id ,
org_name ,
end_user_id ,
geo ,
market_area ,
market_segment ,
pro_provisioned ,
pro_w_w_provisioned ,
pro_assigned ,
pro_w_w_assigned ,
pro_activated_seats ,
pro_w_w_activated_seats ,
pro_qad ,
pro_w_w_qad_downloaders ,
pro_rqad ,
pro_w_w_rqad_downloaders ,
pro_content_downloads ,
pro_w_w_content_downloads ,
pro_contract_start_date,
pro_contract_end_date,
pro_billing_type ,
stock_billing_type ,
stock_assigned_count ,
stock_w_w_assigned_count ,
stock_consumption_count ,
stock_w_w_consumption_count ,
stock_provisioned_count ,
stock_w_w_provisioned_count ,
stock_users_assigned ,
stock_w_w_stock_users_assigned ,
stock_qad ,
stock_w_w_qad ,
stock_content_downloads ,
stock_w_w_content_downloads ,
stock_rqad ,
stock_w_w_rqad ,
stock_contract_start_date ,
stock_contract_end_date,
as_of_date
from 
(
select a.* from
b2b_stg.ccepro_stock_qad a
left join
(select distinct org_id from 
b2b_stg.ccepro_stock_qad
where stock_billing_type is null and pro_billing_type ='' and as_of_date='{RUN_DATE}') b
on a.org_id=b.org_id
where b.org_id is null
and a.as_of_date='{RUN_DATE}'
) x
) cleanup_data
where as_of_date='{RUN_DATE}' """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()