# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.cce_pro partition(as_of_date)
SELECT 
cast(concat_ws(',',collect_list(cast(curr.end_user_id as string))) as bigint) as end_user_id,
SUM(nvl(curr.arr,0)) as arr,
SUM(nvl(curr.all_apps,0)) as all_apps,
SUM(nvl(curr.single_app,0)) as single_app,
SUM(nvl(curr.stock_arr,0)) as stock_arr,
SUM(nvl(curr.purchased_qty,0)) as purchased_qty,
curr.org_id,
curr.org_name,
curr.market_segment,
cntry.market_area_description as market_area,
cntry.region_description as region,
curr.geo,
curr.country,
curr.contract_offer_type,
cast(curr.contract_start_date as date),
b.fiscal_yr as start_fiscal_yr,
cast(b.fiscal_wk_in_yr as int) as start_fiscal_wk_in_yr,
cast(b.fiscal_wk_in_qtr as int) as start_fiscal_wk_in_qtr,
b.fiscal_qtr_name as start_fiscal_qtr_name,
cast(curr.contract_end_date as date),
c.fiscal_yr as end_fiscal_yr,
cast(c.fiscal_wk_in_yr as int) as end_fiscal_wk_in_yr,
cast(c.fiscal_wk_in_qtr as int) as end_fiscal_wk_in_qtr,
c.fiscal_qtr_name as end_fiscal_qtr_name,
nvl(curr.provisioned,0) as provisioned,
(nvl(curr.provisioned,0)-nvl(prev.provisioned,0)) as w_w_provisioned,
nvl(curr.assigned,0) as assigned,
(nvl(curr.assigned,0)-nvl(prev.assigned,0)) as w_w_assigned,
nvl(curr.activated_seats,0) as activated_seats,
(nvl(curr.activated_seats,0)-nvl(prev.activated_seats,0)) as w_w_activated_seats,
nvl(curr.content_downloads,0) as content_downloads,
(nvl(curr.content_downloads,0)-nvl(prev.content_downloads,0)) as w_w_content_downloads,
nvl(curr.qad_downloaders,0) as qad_downloaders,
(nvl(curr.qad_downloaders,0)-nvl(prev.qad_downloaders,0)) as w_w_qad_downloaders,
nvl(curr.rqad_downloaders,0) as rqad_downloaders,
(nvl(curr.rqad_downloaders,0)-nvl(prev.rqad_downloaders,0)) as w_w_rqad_downloaders,
calndr.fiscal_yr,
cast(calndr.fiscal_wk_in_yr as int),
cast(calndr.fiscal_wk_in_qtr as int),
calndr.fiscal_qtr_name,
cast(curr.as_of_date as date) from
	(select
	 c.end_user_id,
	 c.arr,
	 c1.all_apps,
	 c1.single_app,
	 c1.stock_arr,
	 c.purchased_qty,
	 a.org_id,
	 a.org_name,
     	 a.market_segment,
	 a.geo_description as geo,
	 a.country,
	 a.contract_offer_type,
	 a.contract_start_date,
	 a.contract_end_date,
	 sum(a.pro_membership_count) as provisioned,
	 sum(a.del_membership_count) as assigned,
         activ.activated_seats,
	 d.content_downloads,
	 qad.downloaders as qad_downloaders,
	 qad.rqad_downloaders as rqad_downloaders,
	 '{RUN_DATE}' as as_of_date
	 from enterprise.fact_snapshot_provision_deployment a 
	 left join
	 b2b.enduserid_orgid_mapping b 
	 on a.org_id=b.org_id
	 left join
        	(
        	SELECT
			cast(a.end_user as int) as end_user_id,
			a.end_user_name,
			a.olpg,
			round(SUM(a.ARR)) AS arr,
			sum(a.contract_quantity) AS purchased_qty,
			a.date_date
			FROM enterprise.ca_ent_arr_model_all a
			JOIN 
			(
			select 
			cast(end_user as int) as end_user_id,
			max(date_date) as date_date
			FROM enterprise.ca_ent_arr_model_all
			WHERE BUSINESS_TYPE = 'ETLA'
			AND ARR_TYPE IN ('BILLED','PRE_BILLED','LAB_ARR','MANUAL')
			AND ARR_EXCLUSION = 'N'
			AND snapshot_type ='W'
			AND date_date > DATE_SUB('{RUN_DATE}',90) AND date_date<='{RUN_DATE}'
			AND OLPG = 'CCE STOCK'
			GROUP BY cast(end_user as int)
			) b
			ON cast(a.end_user as int)=b.end_user_id
			AND a.date_date=b.date_date
			WHERE a.BUSINESS_TYPE = 'ETLA'
			AND a.ARR_TYPE IN ('BILLED','PRE_BILLED','LAB_ARR','MANUAL')
			AND a.ARR_EXCLUSION = 'N'
			AND a.snapshot_type ='W'
			AND a.date_date > DATE_SUB('{RUN_DATE}',90) AND a.date_date<='{RUN_DATE}'
			AND a.OLPG = 'CCE STOCK'
			GROUP BY
			a.OLPG,
			a.end_user,
			a.end_user_name,
			a.date_date
    		) c
on b.end_user_id=c.end_user_id
left join
			(
			select
			end_user_id,
			end_user_name,
			olpg,
			nvl(collect_set(ALL_APPS)[0],0) as ALL_APPS,
			nvl(collect_set(SINGLE_APP)[0],0) as SINGLE_APP,
			(nvl(collect_set(ALL_APPS)[0],0)*90+nvl(collect_set(SINGLE_APP)[0],0)*40) as stock_arr
			from
			(
				select 
				end_user_id,
				end_user_name,
				olpg,
				case when material_number_description='ALL APPS' then contract_quantity end as ALL_APPS,
				case when material_number_description='SINGLE APP' then contract_quantity end as SINGLE_APP
				from
				(
				 select 
				 int(a.end_user) as end_user_id,
				 a.end_user_name,
				 a.olpg,
				 case when ucase(a.material_number_description) like '%ALL APPS%' then 'ALL APPS' else 'SINGLE APP' end as material_number_description,
				 sum(a.contract_quantity) as contract_quantity,
				 a.date_date 
				 from enterprise.ca_ent_arr_model_all a 
				 JOIN 
				 (
				 select 
				 cast(end_user as int) as end_user_id,
				 max(date_date) as date_date
				 FROM enterprise.ca_ent_arr_model_all
				 WHERE BUSINESS_TYPE = 'ETLA'
				 AND ARR_TYPE IN ('BILLED','PRE_BILLED','LAB_ARR','MANUAL')
				 AND ARR_EXCLUSION = 'N'
				 AND snapshot_type ='W'
				 AND date_date > DATE_SUB('{RUN_DATE}',90) AND date_date<='{RUN_DATE}'
				 AND OLPG = 'CCE STOCK'
				 GROUP BY cast(end_user as int)
				 ) b
				 ON cast(a.end_user as int)=b.end_user_id
				 AND a.date_date=b.date_date
				 WHERE a.BUSINESS_TYPE = 'ETLA'
				 AND a.ARR_TYPE IN ('BILLED','PRE_BILLED','LAB_ARR','MANUAL')
				 AND a.ARR_EXCLUSION = 'N'
				 AND a.snapshot_type ='W'
				 AND a.date_date > DATE_SUB('{RUN_DATE}',90) AND a.date_date<='{RUN_DATE}'
				 AND a.OLPG = 'CCE STOCK'
				 GROUP BY 
				 int(a.end_user),
				 a.end_user_name,
				 case when ucase(a.material_number_description) like '%ALL APPS%' then 'ALL APPS' else 'SINGLE APP' end,
				 a.date_date,
				 a.olpg
				) a
			) b
group by 
end_user_id,
end_user_name,
olpg
		) c1
on c.end_user_id=c1.end_user_id		
left join
	(
	 SELECT
	 org_id,
	 sum(nvl(downloaders,0)) as downloaders,
         sum(nvl(rqad_downloaders,0)) as rqad_downloaders
	 FROM b2b.stock_qad
	 where as_of_date='{RUN_DATE}'
	 AND (ucase(offering_name) LIKE '%PRO%EDITION%' or ucase(offering_name) in ('SINGLE APP PRO GROUP B','SINGLE APP PRO - ENTERPRISE','SINGLE APP PRO','SINGLE APP PRO GROUP B - ENTERPRISE','ADOBE STOCK IMAGES - PRO'))
	 group by 
	 org_id
	) qad
	on a.org_id=qad.org_id
left join 
	(
	 SELECT  
	 d.org_id,
         nvl(count(distinct d.member_guid),0) AS activated_seats,
         '{RUN_DATE}' as as_of_date
	 FROM enterprise.fact_snapshot_recent_member_delegation d
	 INNER JOIN ocf_analytics.fact_user_activity a
	 ON a.member_guid = d.member_guid
	 WHERE a.category = 'STOCK'
         AND a.product NOT IN ('SEARCH', 'WATERMARKED')
         AND d.contract_offer_type = 'ETLA'
         AND d.cloud_type = 'CCE'
  	 AND d.is_valid='Y'
         AND (ucase(d.offering_name) like '%PRO%EDITION%' or ucase(d.offering_name) in ('SINGLE APP PRO GROUP B','SINGLE APP PRO - ENTERPRISE','SINGLE APP PRO','SINGLE APP PRO GROUP B - ENTERPRISE','ADOBE STOCK IMAGES - PRO'))
	 AND snapshot_date='{RUN_DATE}'
	 AND a.partition_date>='2019-03-01' 
	 group by d.org_id
         ) activ
	on a.org_id=activ.org_id
left join
	(
         select
         b.org_id,
         count(distinct a.content_download_id) as content_downloads
         from
         	(
          	select
          	distinct
          	d.member_guid,
          	d.org_id
          	from enterprise.fact_snapshot_recent_member_delegation d
          	WHERE d.snapshot_date='{RUN_DATE}'
          	AND d.contract_offer_type='ETLA'
          	AND d.cloud_type = 'CCE'
          	AND (ucase(d.offering_name) like '%PRO%EDITION%' or ucase(d.offering_name) in ('SINGLE APP PRO GROUP B','SINGLE APP PRO - ENTERPRISE','SINGLE APP PRO','SINGLE APP PRO GROUP B - ENTERPRISE','ADOBE STOCK IMAGES - PRO'))
         	) b
         	join
          	stock_enriched.downloads_enriched a
         	on a.split_member_guid=b.member_guid
         	where a.allotment_type IN ('CCE Pro','CCE Pro EDU','CCE Pro VIP') 
         	and a.download_date<='{RUN_DATE}'
         	group by
         	b.org_id
	) d
	on a.org_id=d.org_id
	where a.ddate='{RUN_DATE}'
	AND (ucase(a.offering_name) LIKE '%PRO%EDITION%' or ucase(a.offering_name) in ('SINGLE APP PRO GROUP B','SINGLE APP PRO - ENTERPRISE','SINGLE APP PRO','SINGLE APP PRO GROUP B - ENTERPRISE','ADOBE STOCK IMAGES - PRO'))
	AND a.contract_end_date >= '{RUN_DATE}'
	AND a.org_id<>'819D355B5D5DC21F0A495EDF' 
	group by
	c.end_user_id,
	c.arr,
	c1.all_apps,
	c1.single_app,
	c1.stock_arr,
    c.purchased_qty,
	a.org_id,
	a.org_name,
	a.market_segment,
	a.geo_description,
	a.country,
	a.contract_offer_type,
	a.contract_start_date,
	a.contract_end_date,
	activ.activated_seats,
	d.content_downloads,
	qad.downloaders,
	qad.rqad_downloaders
) curr
left join 
(
SELECT 
a.* 
FROM
b2b.cce_pro a
JOIN 
(SELECT org_id,max(as_of_date) AS max_as_of_date FROM b2b.cce_pro GROUP BY org_id) b
ON a.org_id=b.org_id AND a.as_of_date=b.max_as_of_date
) prev
ON curr.org_id=prev.org_id
left join ids_coredata.dim_country cntry
ON curr.country=cntry.country_code_iso2
left join ids_coredata.dim_date calndr
ON curr.as_of_date=calndr.date_date
left join ids_coredata.dim_date b
ON curr.contract_start_date=b.date_date
left join
ids_coredata.dim_date c
ON curr.contract_end_date=c.date_date
GROUP BY 
curr.org_id,
curr.org_name,
curr.market_segment,
cntry.market_area_description,
cntry.region_description,
curr.geo,
curr.country,
curr.contract_offer_type,
curr.contract_start_date,
b.fiscal_yr,
b.fiscal_wk_in_yr,
b.fiscal_wk_in_qtr,
b.fiscal_qtr_name,
curr.contract_end_date,
c.fiscal_yr,
c.fiscal_wk_in_yr,
c.fiscal_wk_in_qtr,
c.fiscal_qtr_name,
nvl(curr.provisioned,0),
(nvl(curr.provisioned,0)-nvl(prev.provisioned,0)),
nvl(curr.assigned,0),
(nvl(curr.assigned,0)-nvl(prev.assigned,0)),
nvl(curr.activated_seats,0),
(nvl(curr.activated_seats,0)-nvl(prev.activated_seats,0)),
nvl(curr.content_downloads,0),
(nvl(curr.content_downloads,0)-nvl(prev.content_downloads,0)),
nvl(curr.qad_downloaders,0),
(nvl(curr.qad_downloaders,0)-nvl(prev.qad_downloaders,0)),
nvl(curr.rqad_downloaders,0),
(nvl(curr.rqad_downloaders,0)-nvl(prev.rqad_downloaders,0)),
calndr.fiscal_yr,
calndr.fiscal_wk_in_yr,
calndr.fiscal_wk_in_qtr,
calndr.fiscal_qtr_name,
curr.as_of_date """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()