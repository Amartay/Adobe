from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.Compress.intermediate=true """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
             spark.sql(""" SET hive.auto.convert.join=true """)
             spark.sql(""" SET hive.merge.mapfiles=true """)
             spark.sql(""" SET hive.merge.mapredfiles=true """)
             spark.sql(""" SET hive.merge.size.per.task=512000000 """)
             spark.sql(""" SET hive.merge.smallfiles.avgsize=512000000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=false """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.cbo.enable=true """)
             spark.sql(""" set hive.compute.query.using.stats=true """)
             spark.sql(""" set hive.stats.fetch.column.stats=true """)
             spark.sql(""" set hive.stats.fetch.partition.stats=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.support.concurrency = false """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" insert overwrite table b2b.o365_integration  partition(as_of_date)
select * from 
(
SELECT org_id,
       org_name,
       market_segment,
       geo_code,
       'CREATE_PDF' AS post_pagename,
       contract_offer_type,
       CASE
           WHEN concat_ws('+',collect_list(DISTINCT a.cloud_type))='DCE+CCE' THEN 'CCE+DCE'
           ELSE concat_ws('+',collect_list(DISTINCT a.cloud_type))
       END AS cloud_type,
       calling_app,
       count(DISTINCT a.member_guid) AS mau,
       cast('{RUN_DATE}' as date) AS as_of_date
FROM
  (SELECT DISTINCT l.org_id,
                   l.org_name,
                   l.market_segment,
                   l.geo_code,
                   l.contract_offer_type,
                   l.cloud_type,
                   calling_app,
                   split(h.member_guid,'@')[0] AS member_guid,
                   cast('{RUN_DATE}' as date) AS as_of_date
   FROM
     (SELECT DISTINCT pguid,
                      'office' AS calling_app
      -- FROM b2b_stg.dc_acrobatstar_feature
      FROM dc_acrobatstar.feature
      WHERE FeatureName='Invoke sharing workflow PDFMaker Create and Share'
        AND substr(featuretime,1,10) BETWEEN DATE_SUB('{RUN_DATE}',27) AND '{RUN_DATE}'
      UNION ALL SELECT DISTINCT pguid,
                                category AS calling_app
      -- FROM b2b_stg.dc_acrotraystar_create_share_conversion_status
      FROM dc_acrotraystar.create_share_conversion_status
      WHERE subcategory='PDFMaker_Menu'
        AND substr(grouptime,1,10) BETWEEN DATE_SUB('{RUN_DATE}',27) AND '{RUN_DATE}'
      UNION ALL SELECT DISTINCT pguid,
                                category AS calling_app
      -- FROM b2b_stg.dc_acrotraystar_create_share_saveas_pdf
      FROM dc_acrotraystar.create_share_saveas_pdf
      WHERE subcategory='OK'
        AND substr(grouptime,1,10) BETWEEN DATE_SUB('{RUN_DATE}',27) AND '{RUN_DATE}'
      UNION ALL SELECT DISTINCT pguid,
                                category AS calling_app
      -- FROM b2b_stg.dc_acrotraystar_create_share_home_click
      FROM dc_acrotraystar.create_share_home_click
      WHERE subcategory='PDFMaker_Menu'
        AND substr(grouptime,1,10) BETWEEN DATE_SUB('{RUN_DATE}',27) AND '{RUN_DATE}' ) u
  --  JOIN b2b_stg.hb_monitor_user_mapping_snapshot h ON h.pguid=u.pguid
   JOIN hb_monitor.user_mapping_snapshot h ON h.pguid=u.pguid
   JOIN enterprise.fact_enterprise_member_license_delegation l ON split(h.member_guid,'@')[0]=l.member_guid
   WHERE l.is_valid = 'Y'
     AND l.delegation_status = 'ACCEPTED'
     AND l.contract_end_date >= '{RUN_DATE}'
     AND l.first_delegation_date <= '{RUN_DATE}' 
     AND l.offering_name NOT LIKE '%Trial%'
     AND l.offering_name NOT LIKE '%Support%'
     AND UPPER(l.offering_name) NOT LIKE '%SPARK%'
     AND UPPER(l.offering_name) NOT LIKE '%CREATIVE%CLOUD%SHARED%'
     AND upper(l.offering_name) NOT LIKE '%CREATIVE%CLOUD%EXPRESS%'  
     AND upper(l.offering_name) NOT LIKE '%ADOBE%EXPRESS%'  
) a
GROUP BY org_id,
         org_name,
         market_segment,
         geo_code,
         contract_offer_type,
         calling_app
UNION ALL
SELECT org_id,
       org_name,
       market_segment,
       geo_code,
       post_pagename,
       contract_offer_type,
       CASE
           WHEN concat_ws('+',collect_list(DISTINCT a.cloud_type))='DCE+CCE' THEN 'CCE+DCE'
           ELSE concat_ws('+',collect_list(DISTINCT a.cloud_type))
       END AS cloud_type,
       calling_app,
       count(DISTINCT member_guid) AS mau,
       cast('{RUN_DATE}' as date) AS as_of_date
FROM
  (SELECT DISTINCT l.org_id,
                   l.org_name,
                   l.market_segment,
                   l.geo_code,
                   l.contract_offer_type,
                   l.cloud_type,
                   'CONVERT_TO_PDF' AS post_pagename,
                   calling_app,
                   u.member_guid,
                   cast('{RUN_DATE}' as date) AS as_of_date
   FROM
     (SELECT DISTINCT post_evar47 AS calling_app,
                      split(post_evar12,'@')[0] AS member_guid
      FROM aa_ingest.adbdcwebprod_view
      WHERE post_pagename='Convert:Use:Click'
        AND click_date BETWEEN date_add('{RUN_DATE}',-27) AND '{RUN_DATE}'
        AND post_evar47 = 'dc-office-cpdf-app' ) u
   JOIN enterprise.fact_enterprise_member_license_delegation l ON u.member_guid=l.member_guid
   WHERE l.is_valid = 'Y'
     AND l.delegation_status = 'ACCEPTED'
     AND l.contract_end_date >= '{RUN_DATE}'
     AND l.first_delegation_date <= '{RUN_DATE}' 
     AND l.offering_name NOT LIKE '%Trial%'
     AND l.offering_name NOT LIKE '%Support%'
     AND UPPER(l.offering_name) NOT LIKE '%SPARK%'
     AND UPPER(l.offering_name) NOT LIKE '%CREATIVE%CLOUD%SHARED%'
     AND upper(l.offering_name) NOT LIKE '%CREATIVE%CLOUD%EXPRESS%'  
     AND upper(l.offering_name) NOT LIKE '%ADOBE%EXPRESS%'  
) a
GROUP BY org_id,
         org_name,
         market_segment,
         geo_code,
         contract_offer_type,
         post_pagename,
         calling_app
UNION ALL
SELECT org_id,
       org_name,
       market_segment,
       geo_code,
       'SEND_AGREEMENT' AS post_pagename,
       contract_offer_type,
       CASE
           WHEN concat_ws('+',collect_list(DISTINCT a.cloud_type))='DCE+CCE' THEN 'CCE+DCE'
           ELSE concat_ws('+',collect_list(DISTINCT a.cloud_type))
       END AS cloud_type,
       calling_app,
       count(DISTINCT a.member_guid) AS mau,
       cast('{RUN_DATE}' as date) AS as_of_date
FROM
  (SELECT DISTINCT l.org_id,
                   l.org_name,
                   l.market_segment,
                   l.geo_code,
                   l.contract_offer_type,
                   l.cloud_type,
                   calling_app,
                   u.member_guid,
                   cast('{RUN_DATE}' as date) AS as_of_date
   FROM
     (SELECT DISTINCT substr(originator_adobe_guid, 1, 24) AS member_guid,
                      integration_name AS calling_app
      FROM a_sign_pub.agreement
      WHERE substr(created,1,10) BETWEEN DATE_SUB('{RUN_DATE}',27) AND '{RUN_DATE}'
        AND (upper(integration_name) LIKE '%MS%'
             OR upper(integration_name) LIKE '%Microsoft%')) u
   JOIN enterprise.fact_enterprise_member_license_delegation l ON u.member_guid=l.member_guid
   WHERE l.is_valid = 'Y'
     AND l.delegation_status = 'ACCEPTED'
     AND l.contract_end_date >= '{RUN_DATE}'
     AND l.first_delegation_date <= '{RUN_DATE}' 
     AND l.offering_name NOT LIKE '%Trial%'
     AND l.offering_name NOT LIKE '%Support%'
     AND UPPER(l.offering_name) NOT LIKE '%SPARK%'
     AND UPPER(l.offering_name) NOT LIKE '%CREATIVE%CLOUD%SHARED%'
     AND upper(l.offering_name) NOT LIKE '%CREATIVE%CLOUD%EXPRESS%'  
     AND upper(l.offering_name) NOT LIKE '%ADOBE%EXPRESS%'  
) a
GROUP BY org_id,
         org_name,
         market_segment,
         geo_code,
         contract_offer_type,
         calling_app
UNION ALL
SELECT org_id,
       org_name,
       market_segment,
       geo_code,
       post_pagename,
       contract_offer_type,
       CASE
           WHEN concat_ws('+',collect_list(DISTINCT a.cloud_type))='DCE+CCE' THEN 'CCE+DCE'
           ELSE concat_ws('+',collect_list(DISTINCT a.cloud_type))
       END AS cloud_type,
       calling_app,
       count(DISTINCT member_guid) AS mau,
       cast('{RUN_DATE}' as date) AS as_of_date
FROM
  ( SELECT DISTINCT l.org_id,
                    l.org_name,
                    l.market_segment,
                    l.geo_code,
                    u.post_pagename,
                    l.contract_offer_type,
                    l.cloud_type,
                    u.calling_app,
                    u.member_guid,
                    l.user_auth_src_type,
                    cast('{RUN_DATE}' as date) AS as_of_date
   FROM
     ( SELECT DISTINCT 'SP+ONEDRIVE' AS calling_app,
                       post_evar42 AS tenant,
                       split(post_evar12,'@')[0] AS member_guid,
                       click_date,
                       post_pagename
      FROM aa_ingest.adbdcwebprod_view
      WHERE post_pagename = 'User actions:Document actions:Document opened'
        AND click_date<='{RUN_DATE}' 
        AND post_evar47 IN ('dc-onedrive-app',
                            'dc-sharepoint-app')
 ) u
   JOIN enterprise.fact_enterprise_member_license_delegation l ON u.member_guid=l.member_guid
   WHERE u.click_date BETWEEN date_add('{RUN_DATE}',-28) AND '{RUN_DATE}'
     AND u.post_pagename= 'User actions:Document actions:Document opened'
     AND l.is_valid = 'Y'
     AND l.delegation_status = 'ACCEPTED'
     AND l.contract_end_date >= '{RUN_DATE}'
     AND l.first_delegation_date <= '{RUN_DATE}' 
     AND l.offering_name NOT LIKE '%Trial%'
     AND l.offering_name NOT LIKE '%Support%'
     AND UPPER(l.offering_name) NOT LIKE '%SPARK%'
     AND UPPER(l.offering_name) NOT LIKE '%CREATIVE%CLOUD%SHARED%'
     AND upper(l.offering_name) NOT LIKE '%CREATIVE%CLOUD%EXPRESS%'  
     AND upper(l.offering_name) NOT LIKE '%ADOBE%EXPRESS%'  
     AND u.calling_app !='' ) a
WHERE contract_offer_type = 'ETLA'
  AND calling_app ='SP+ONEDRIVE'
  AND cloud_type IN ('CCE',
                     'DCE')
GROUP BY org_id,
         org_name,
         market_segment,
         geo_code,
         contract_offer_type,
         post_pagename,
         calling_app
) o365 """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()