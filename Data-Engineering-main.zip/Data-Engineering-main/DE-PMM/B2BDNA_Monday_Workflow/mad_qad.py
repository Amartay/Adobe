# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" drop table if exists b2b_stg.rqad_issue_msk """)
             spark.sql(""" create table b2b_stg.rqad_issue_msk as
select 
ent_fact.org_id,
ent_fact.org_name,
ent_fact.geo_description,
ent_fact.market_segment,
ent_fact.market_area_description,
ent_fact.offering_name,
ent_fact.member_guid,
ent_fact.is_valid,
ent_fact.contract_offer_type,
ent_fact.delegation_status,
ent_fact.contract_end_date,
ent_fact.cloud_type,
ent_fact.offer_id,
ent_fact.contract_id,
case
when snap.first_delegation_date is null then min(ent_fact.first_delegation_date) else min(snap.first_delegation_date)
end as first_delegation_date
from 
(select org_id,org_name,geo_description,market_segment,market_area_description,offering_name,member_guid,is_valid,contract_offer_type,delegation_status,contract_end_date,cloud_type,offer_id,contract_id,first_delegation_date from enterprise.fact_enterprise_member_license_delegation
) ent_fact
left join
(select first_delegation_date,org_id,offer_id,contract_id,member_guid from b2b.snapshot_fact_enterprise_member_license_delegation where asofdate = '2023-11-03') snap
on 
snap.org_id  = ent_fact.org_id
and snap.offer_id = ent_fact.offer_id
and snap.member_guid = ent_fact.member_guid
and snap.contract_id = ent_fact.contract_id 
group by 
ent_fact.org_id,
ent_fact.org_name,
ent_fact.geo_description,
ent_fact.market_segment,
ent_fact.market_area_description,
ent_fact.offering_name,
ent_fact.member_guid,
ent_fact.is_valid,
ent_fact.contract_offer_type,
ent_fact.delegation_status,
ent_fact.contract_end_date,
ent_fact.cloud_type,
ent_fact.offer_id,
ent_fact.contract_id,
snap.first_delegation_date """)
             spark.sql(""" insert overwrite table b2b.stock_mad partition (as_of_date)
SELECT
d.org_id,
b.end_user_id,
d.org_name,
d.geo_description as geo,
d.market_segment,
d.market_area_description as market_area,
d.offering_name,
count (distinct d.member_guid) AS downloaders,
'MAD' as type_of_dataset,
cast('{RUN_DATE}' as date) as as_of_date
FROM enterprise.fact_enterprise_member_license_delegation d
INNER JOIN enterprise.enterprise_fact_user_activity a
ON a.member_guid = d.member_guid
LEFT OUTER JOIN b2b.enduserid_orgid_mapping b
on d.org_id=b.org_id
WHERE category = 'STOCK'
AND product != 'SEARCH'
AND partition_date BETWEEN date_sub('{RUN_DATE}',27) AND '{RUN_DATE}' 
AND is_valid = 'Y'
AND contract_offer_type = 'ETLA'
AND delegation_status = 'ACCEPTED'
AND contract_end_date >= '{RUN_DATE}'
AND cloud_type = 'CCE'
AND offering_name NOT LIKE '%Trial%'
AND offering_name NOT LIKE '%Support%'
AND UPPER(offering_name) NOT LIKE '%SPARK%'
AND UPPER(offering_name) NOT LIKE '%CREATIVE%CLOUD%SHARED%'
AND upper(offering_name) NOT LIKE '%CREATIVE%CLOUD%EXPRESS%'  
AND upper(offering_name) NOT LIKE '%ADOBE%EXPRESS%'  
group by d.org_id,b.end_user_id,d.org_name,d.geo_description,d.market_segment,d.market_area_description,d.offering_name """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.stock_qad partition (as_of_date)
select 
org_id,
cast(concat_ws(',',collect_list(end_user_id)) as int) as end_user_id,
org_name,
geo,
market_segment,
market_area,
offering_name,
downloaders,
rqad_downloaders,
type_of_dataset,
cast(as_of_date as date) as as_of_date
from
(
select
a.org_id ,
a.end_user_id ,
a.org_name ,
a.geo ,
a.market_segment ,
a.market_area ,
a.offering_name ,
a.downloaders ,
b.rqad_downloaders ,
a.type_of_dataset,
a.as_of_date
from
(
SELECT
d.org_id,
b.end_user_id,
d.org_name,
d.geo_description as geo,
d.market_segment,
d.market_area_description as market_area,
d.offering_name,
count (distinct d.member_guid) AS downloaders,
'QAD' as type_of_dataset,
'{RUN_DATE}' as as_of_date
--FROM enterprise.fact_enterprise_member_license_delegation d
FROM b2b_stg.rqad_issue_msk d
INNER JOIN enterprise.enterprise_fact_user_activity a
ON a.member_guid = d.member_guid
LEFT OUTER JOIN b2b.enduserid_orgid_mapping b
on d.org_id=b.org_id
WHERE category = 'STOCK'
AND product != 'SEARCH'
AND partition_date BETWEEN date_sub('{RUN_DATE}',90) AND '{RUN_DATE}' 
AND is_valid = 'Y'
AND contract_offer_type = 'ETLA'
AND delegation_status = 'ACCEPTED'
AND contract_end_date >= '{RUN_DATE}'
AND cloud_type = 'CCE'
AND (upper(offering_name) LIKE 'ADOBE STOCK TRIAL' OR upper(offering_name) NOT LIKE '%TRIAL%')
AND upper(offering_name) NOT LIKE '%SUPPORT%'
AND upper(offering_name) NOT LIKE '%SPARK%'
AND UPPER(offering_name) NOT LIKE '%CREATIVE%CLOUD%SHARED%'
AND upper(offering_name) NOT LIKE '%CREATIVE%CLOUD%EXPRESS%'  
AND upper(offering_name) NOT LIKE '%ADOBE%EXPRESS%'  
AND a.activity_date >= d.first_delegation_date
group by d.org_id,b.end_user_id,d.org_name,d.geo_description,d.market_segment,d.market_area_description,d.offering_name
) a
left join
(
select
t1.org_id,
t1.org_name,
t1.geo,
t1.market_segment,
t1.market_area,
t1.offering_name,
count(distinct t1.member_guid) as rqad_downloaders,
'{RUN_DATE}' as as_of_date
FROM
    (SELECT distinct d.org_id,
         d.org_name,
         d.geo_description as geo,
         d.market_segment,
         d.market_area_description as market_area,
         d.offering_name,
         d.member_guid
--FROM enterprise.fact_enterprise_member_license_delegation d
FROM b2b_stg.rqad_issue_msk d
INNER JOIN enterprise.enterprise_fact_user_activity a
    ON a.member_guid = d.member_guid
WHERE category = 'STOCK'
        AND product != 'SEARCH'
        AND partition_date BETWEEN date_sub('{RUN_DATE}',90) AND '{RUN_DATE}' 
        AND is_valid = 'Y'
        AND contract_offer_type = 'ETLA'
        AND delegation_status = 'ACCEPTED'
        AND contract_end_date >= '{RUN_DATE}'
        AND cloud_type = 'CCE'
        AND (ucase(offering_name) like '%PRO%EDITION%' or ucase(offering_name) in ('SINGLE APP PRO GROUP B','SINGLE APP PRO - ENTERPRISE','SINGLE APP PRO','SINGLE APP PRO GROUP B - ENTERPRISE','ADOBE STOCK IMAGES - PRO'))
	AND a.activity_date >= d.first_delegation_date
        ) t1
INNER JOIN
     (SELECT distinct d.org_id,
         d.org_name,
         d.geo_description as geo,
         d.market_segment,
         d.market_area_description as market_area,
         d.offering_name,
         d.member_guid
--FROM enterprise.fact_enterprise_member_license_delegation d
FROM b2b_stg.rqad_issue_msk d
INNER JOIN enterprise.enterprise_fact_user_activity a
    ON a.member_guid = d.member_guid
WHERE category = 'STOCK'
        AND product != 'SEARCH'
        AND partition_date BETWEEN date_sub('{RUN_DATE}',181) AND date_sub('{RUN_DATE}',91) 
        AND is_valid = 'Y'
        AND contract_offer_type = 'ETLA'
        AND delegation_status = 'ACCEPTED'
        AND contract_end_date >= '{RUN_DATE}'
        AND cloud_type = 'CCE'
        AND (ucase(offering_name) like '%PRO%EDITION%' or ucase(offering_name) in ('SINGLE APP PRO GROUP B','SINGLE APP PRO - ENTERPRISE','SINGLE APP PRO','SINGLE APP PRO GROUP B - ENTERPRISE','ADOBE STOCK IMAGES - PRO'))
	AND a.activity_date >= d.first_delegation_date
        ) t2
on t1.member_guid=t2.member_guid
and t1.org_id=t2.org_id
and t1.org_name=t2.org_name
and t1.geo=t2.geo
and t1.market_segment=t2.market_segment
and t1.market_area=t2.market_area
and t1.offering_name=t2.offering_name
group by
t1.org_name,
t1.org_id,
t1.geo,
t1.market_segment,
t1.market_area,
t1.offering_name
) b
on a.org_id = b.org_id and
a.org_name = b.org_name and
a.geo = b.geo and
a.market_segment = b.market_segment and
a.market_area = b.market_area and
a.offering_name = b.offering_name 
) enduseridconcat
group by 
org_id,
org_name,
geo,
market_segment,
market_area,
offering_name,
downloaders,
rqad_downloaders,
type_of_dataset,
as_of_date """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()
