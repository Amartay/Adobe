# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b_stg """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" drop table if exists b2b_stg.entfactuat_dwnlds_enriched """)
             spark.sql(""" create table b2b_stg.entfactuat_dwnlds_enriched  as
		select 
		distinct
		l.org_id,
		l.org_name,
		l.member_guid,
		fuat_dwlds.content_download_id,
		fuat_dwlds.activity_date,
		fuat_dwlds.partition_date
		from
		(select
		distinct 
		org_id,
		org_name,
		member_guid 
		FROM enterprise.fact_enterprise_member_license_delegation 
		WHERE (ucase(offering_name) like '%STOCK%' AND ucase(offering_name) NOT LIKE 'ADOBE STOCK IMAGES - PRO') 
		AND is_valid = 'Y'
		AND contract_offer_type = 'ETLA'
		AND delegation_status = 'ACCEPTED'
		AND contract_end_date >= '{RUN_DATE}'
		AND cloud_type = 'CCE'
		AND first_delegation_date<='{RUN_DATE}' 
		) l
	    left join 	
		(
		select 
		distinct 
		member_guid,
		content_download_id,
		activity_date,
		partition_date
		from 
			(select
                        distinct
                        member_guid,
                        '' as content_download_id,
                        activity_date,
                        partition_date
                        from enterprise.enterprise_fact_user_activity
                        where partition_date<='{RUN_DATE}' and partition_date>=date_sub('{RUN_DATE}',181) and category='STOCK' and  product != 'SEARCH'
                        union all
                        select
                        distinct
                        split_member_guid as member_guid,
                        content_download_id,
                        download_date as activity_date,
                        download_date as partition_date
                        from stock_enriched.downloads_enriched
                        where allotment_type='CCE' and download_date<='{RUN_DATE}' and download_date>=date_sub('{RUN_DATE}',181)
                        ) a
		) fuat_dwlds	
		on l.member_guid=fuat_dwlds.member_guid """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" drop table if exists b2b_stg.stg_repeat_qad """)
             spark.sql(""" create table  b2b_stg.stg_repeat_qad  as
                select
                distinct
                r.member_guid
                from
                        (select
                         distinct
                         member_guid
                         from b2b_stg.entfactuat_dwnlds_enriched
                         where partition_date BETWEEN date_sub('{RUN_DATE}',90) AND '{RUN_DATE}'
                        ) r
                        join
                        (select
                         distinct
                         member_guid
                         from b2b_stg.entfactuat_dwnlds_enriched
                         where partition_date BETWEEN date_sub('{RUN_DATE}',181) AND date_sub('{RUN_DATE}',91)
                        ) r1
                         on r.member_guid=r1.member_guid """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" insert overwrite table b2b_stg.stg_qad partition (as_of_date)
select
org_id,
concat_ws(',',collect_list(end_user_id)) as end_user_id,
org_name,
geo,
market_segment,
market_area,
billing_type,
contract_start_date as stock_contract_start_date,
contract_end_date as stock_contract_end_date,
assigned_count,
consumption_count,
provisioned_count,
stock_users_assigned,
qad,
content_downloads,
rqad,
as_of_date
from 
	(
	SELECT
	d.org_id,
	b.end_user_id,
	d.org_name,
	d.geo,
	d.market_segment,
	d.market_area,
	d.contract_start_date,
	d.contract_end_date,
	stock.billing_type,
	stock.assigned_count,
	stock.consumption_count,
	stock.provisioned_count,
	count(distinct asgn_users.member_guid) AS stock_users_assigned,
	count (distinct a.member_guid) AS qad,
	count (distinct a.content_download_id) AS content_downloads,
	count (distinct rqad.member_guid) AS rqad,
	'{RUN_DATE}' AS as_of_date
	FROM 
		(SELECT 
		DISTINCt
		a1.org_id,
		a1.org_name,
		a1.market_Segment,
		a1.country,
		CASE when a1.country='<UNKNOWN>' THEN '<UNKNOWN>' ELSE cntry.market_area_description END AS market_area,
		CASE when a1.country='<UNKNOWN>' THEN '<UNKNOWN>' ELSE cntry.geo_description END AS geo,
		a1.contract_start_date,
		a1.contract_end_date
		FROM enterprise.fact_cce_membership_count a1 
		left join
		ids_coredata.dim_country cntry
     		ON a1.country=cntry.country_code_iso2
		WHERE a1.contract_offer_type='ETLA' and a1.contract_end_date>'{RUN_DATE}' and a1.is_valid='Y' and  ucase(a1.offering_name) like '%STOCK%'
		) d
left join
		(select distinct org_id,member_guid from b2b_stg.entfactuat_dwnlds_enriched) asgn_users
		ON asgn_users.org_id=d.org_id
left join 
		(select 
		org_id,
		billing_type,
		sum(assigned_count) as assigned_count,
		sum(consumption_count) as consumption_count,
		sum(provisioned_count) as provisioned_count 
		from enterprise.fact_snapshot_stock_purchased_allocated_consumed  
		where as_of_date='{RUN_DATE}'
		group by 
		org_id,
		billing_type
		) stock
		on d.org_id=stock.org_id
left join 
		(select distinct org_id,member_guid,content_download_id from b2b_stg.entfactuat_dwnlds_enriched where partition_date BETWEEN date_sub('{RUN_DATE}',90) AND '{RUN_DATE}') a
		ON d.org_id = a.org_id
left join
		b2b.enduserid_orgid_mapping b
		on d.org_id=b.org_id
left join
		b2b_stg.stg_repeat_qad rqad
		on asgn_users.member_guid=rqad.member_guid
group by 
d.org_id,
b.end_user_id,
d.org_name,
d.contract_start_date,
d.contract_end_date,
stock.billing_type,
d.geo,
d.market_segment,
d.market_area
,stock.assigned_count
,stock.consumption_count
,stock.provisioned_count
) x
group by 
org_id,
org_name,
geo,
market_segment,
market_area,
contract_start_date,
contract_end_date,
billing_type,
assigned_count,
consumption_count,
provisioned_count,
stock_users_assigned,
qad,
content_downloads,
rqad,
as_of_date """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" use b2b_stg """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b_stg.new_stg_qad partition (as_of_date)
select 
curr.org_id                  ,
curr.end_user_id             ,
curr.org_name                ,
curr.geo                     ,
curr.market_segment          ,
curr.market_area             ,
curr.billing_type            ,
curr.assigned_count    as stock_assigned_count      ,
(nvl(curr.assigned_count,0)-nvl(prev.assigned_count,0)) as stock_w_w_assigned_count,
curr.consumption_count  as stock_consumption_count     ,
(nvl(curr.consumption_count,0)-nvl(prev.consumption_count,0)) as stock_w_w_consumption_count,
curr.provisioned_count   as stock_provisioned_count    ,
(nvl(curr.provisioned_count,0)-nvl(prev.provisioned_count,0)) as stock_w_w_provisioned_count,
curr.stock_users_assigned   ,
(nvl(curr.stock_users_assigned,0)-nvl(prev.stock_users_assigned,0)) as stock_w_w_stock_users_assigned,
curr.qad               as stock_qad      ,
(nvl(curr.qad,0)-nvl(prev.qad,0)) as stock_w_w_qad,
curr.content_downloads  as stock_content_downloads     ,
(nvl(curr.content_downloads,0)-nvl(prev.content_downloads,0)) as stock_w_w_content_downloads,
curr.rqad            as stock_rqad        ,
(nvl(curr.rqad,0)-nvl(prev.rqad,0)) as stock_w_w_rqad,
curr.stock_contract_start_date,
curr.stock_contract_end_date,
curr.as_of_date
from b2b_stg.stg_qad curr
left join
(select * from b2b_stg.stg_qad where as_of_date=date_sub('{RUN_DATE}',7)) prev
on curr.org_id=prev.org_id
and curr.billing_type=prev.billing_type
where curr.as_of_date='{RUN_DATE}' """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()