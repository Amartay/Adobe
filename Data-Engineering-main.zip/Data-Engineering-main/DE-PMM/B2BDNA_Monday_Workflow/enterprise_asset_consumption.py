# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.enterprise_asset_consumption partition (as_of_date)
select * from 
(
select 
cast(end_user_id as bigint) as end_user_id,
organization_id,
name,
geo,
market_area,
market_segment,
billing_type,
media_type_drv,
media_type,
media_types_group,
is_editorial,
template_type,
allotment_type,
Downloads,
cast(Total_Credits as int) as Total_Credits,
cast(fiscal_year as int) as fiscal_year,
fiscal_quarter,
fiscal_month,
fiscal_week_f,
cast(as_of_date as date) as as_of_date
from (
select 
stock.end_user_id, 
stock.geo,
stock.market_area_description as market_area,
stock.market_segment,
o.guid as organization_id,
o.name,
stock.billing_type,
CASE
           WHEN dl.media_type ='Videos Others' AND dl.is_editorial = 'N' THEN 'Videos Loops'
           WHEN dl.media_type ='Videos HD' AND dl.is_editorial = 'N' THEN 'Videos HD'
           WHEN dl.media_type ='Videos 4K' AND dl.is_editorial = 'N' THEN 'Videos 4K'
           WHEN dl.media_type LIKE 'Videos%' AND dl.is_editorial = 'Y' THEN 'Editorial Videos'
           WHEN dl.media_type ='Pictures' AND dl.media_types_group ='Premium Images' AND dl.is_editorial = 'N' THEN 'Premium Images'
           WHEN dl.media_type ='Pictures' AND dl.media_types_group ='Premium Images' AND dl.is_editorial = 'Y' THEN 'Editorial Images'
           WHEN dl.media_type ='Template' AND dl.template_type IN ('PPRO MOGRT','AE MOGRT','OTHER MOGRT') THEN 'Motion Graphics Templates'
           WHEN dl.media_type ='Template' AND dl.template_type IN ('INDT','AIT','PSDT') THEN 'Design Templates'
           WHEN dl.media_type ='Instants' OR dl.media_type ='Pictures' THEN 'Photos'
           WHEN dl.media_type ='3D Euclid' THEN '3D'
           WHEN dl.media_type ='Unknown' THEN 'Unknown'
           WHEN dl.media_type ='Vectors' THEN 'Vectors'
           WHEN dl.media_type ='Illustrations' THEN 'Illustrations'
	   WHEN dl.media_type='Audio' THEN 'Audio' 
END AS media_type_drv,
dl.media_type,
dl.media_types_group,
dl.is_editorial,
dl.template_type,
dl.allotment_type,
nvl(count(distinct dl.content_download_id),0) as Downloads,
CASE
           WHEN dl.media_type ='Videos Others' AND dl.is_editorial = 'N' THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Videos HD' AND dl.is_editorial = 'N' THEN nvl(count(distinct dl.content_download_id),0)*8
           WHEN dl.media_type ='Videos 4K' AND dl.is_editorial = 'N' THEN nvl(count(distinct dl.content_download_id),0)*20
           WHEN dl.media_type LIKE 'Videos%' AND dl.is_editorial = 'Y' THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Pictures' AND dl.media_types_group ='Premium Images' AND dl.is_editorial = 'N' THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Pictures' AND dl.media_types_group ='Premium Images' AND dl.is_editorial = 'Y' THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Template' AND dl.template_type IN ('PPRO MOGRT','AE MOGRT','OTHER MOGRT') THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Template' AND dl.template_type IN ('INDT','AIT','PSDT') THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Instants' OR dl.media_type ='Pictures' THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='3D Euclid' THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Unknown' THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Vectors' THEN nvl(count(distinct dl.content_download_id),0)
           WHEN dl.media_type ='Illustrations' THEN nvl(count(distinct dl.content_download_id),0)
	   WHEN dl.media_type='Audio' THEN nvl(count(distinct dl.content_download_id),0) 
END AS Total_Credits,
dl.fiscal_year,
dl.fiscal_quarter,
dl.fiscal_month,
dl.fiscal_week_f, 
cast('{RUN_DATE}' as date) as as_of_date
from stock_import.organization o 
join
enterprise.fact_snapshot_stock_purchased_allocated_consumed stock
on 
o.guid=stock.org_id
join
stock_import.entitlement en
on o.organization_id=en.organization_id
join 
(select * from stock_enriched.downloads_enriched where download_date>date_sub('{RUN_DATE}',7) and download_date<='{RUN_DATE}' and allotment_type in ('CCE')) dl
on dl.delegate_guid = en.guid
where 
stock.as_of_date='{RUN_DATE}' 
group by 
stock.end_user_id,
o.guid, 
o.name,
stock.geo,
stock.market_area_description,
stock.market_segment,
stock.billing_type,
dl.media_type,
dl.media_types_group,
dl.is_editorial,
dl.template_type,
dl.allotment_type,
dl.fiscal_year,
dl.fiscal_quarter,
dl.fiscal_month,
dl.fiscal_week_f 
) a
union all
select 
end_user_id,
organization_id,
name,
geo,
market_area,
market_segment,
billing_type,
media_type_drv,
media_type,
media_types_group,
is_editorial,
template_type,
allotment_type,
Downloads,
cast(Total_Credits as int) as Total_Credits,
cast(fiscal_year as int) as fiscal_year,
fiscal_quarter,
fiscal_month,
fiscal_week_f,
as_of_date
from (
select 
ccepro.end_user_id, 
d.org_id as organization_id,
ccepro.org_name as name,
ccepro.geo,
ccepro.market_area,
ccepro.market_segment,
'CCE Pro' as billing_type,
CASE
           WHEN dl.media_type ='Videos Others' AND dl.is_editorial = 'N' THEN 'Videos Loops'
           WHEN dl.media_type ='Videos HD' AND dl.is_editorial = 'N' THEN 'Videos HD'
           WHEN dl.media_type ='Videos 4K' AND dl.is_editorial = 'N' THEN 'Videos 4K'
           WHEN dl.media_type LIKE 'Videos%' AND dl.is_editorial = 'Y' THEN 'Editorial Videos'
           WHEN dl.media_type ='Pictures' AND dl.media_types_group ='Premium Images' AND dl.is_editorial = 'N' THEN 'Premium Images'
           WHEN dl.media_type ='Pictures' AND dl.media_types_group ='Premium Images' AND dl.is_editorial = 'Y' THEN 'Editorial Images'
           WHEN dl.media_type ='Template' AND dl.template_type IN ('PPRO MOGRT','AE MOGRT','OTHER MOGRT') THEN 'Motion Graphics Templates'
           WHEN dl.media_type ='Template' AND dl.template_type IN ('INDT','AIT','PSDT') THEN 'Design Templates'
           WHEN dl.media_type ='Instants' OR dl.media_type ='Pictures' THEN 'Photos'
           WHEN dl.media_type ='3D Euclid' THEN '3D'
           WHEN dl.media_type ='Unknown' THEN 'Unknown'
           WHEN dl.media_type ='Vectors' THEN 'Vectors'
           WHEN dl.media_type ='Illustrations' THEN 'Illustrations'
	   WHEN dl.media_type='Audio' THEN 'Audio' 
END AS media_type_drv,
dl.media_type,
dl.media_types_group,
dl.is_editorial,
dl.template_type,
dl.allotment_type,
nvl(count(distinct dl.content_download_id),0) as Downloads,
'0' as Total_Credits,
dl.fiscal_year,
dl.fiscal_quarter,
dl.fiscal_month,
dl.fiscal_week_f, 
cast('{RUN_DATE}' as date) as as_of_date
from enterprise.fact_snapshot_recent_member_delegation d
join
b2b.cce_pro ccepro
on 
d.org_id=ccepro.org_id
join 
(select * from stock_enriched.downloads_enriched where download_date>date_sub('{RUN_DATE}',7) and download_date<='{RUN_DATE}' and allotment_type in ('CCE Pro','CCE Pro EDU','CCE Pro VIP')) dl
on dl.split_member_guid = d.member_guid
where 
ccepro.as_of_date='{RUN_DATE}' 
AND d.snapshot_date='{RUN_DATE}'
AND d.contract_offer_type='ETLA'
AND d.cloud_type = 'CCE'
AND (ucase(d.offering_name) like '%PRO%EDITION%' or ucase(d.offering_name) in ('SINGLE APP PRO GROUP B','SINGLE APP PRO - ENTERPRISE','SINGLE APP PRO','SINGLE APP PRO GROUP B - ENTERPRISE','ADOBE STOCK IMAGES - PRO'))
AND d.is_valid='Y'
group by 
ccepro.end_user_id,
d.org_id,
ccepro.org_name,
ccepro.geo,
ccepro.market_area,
ccepro.market_segment,
dl.media_type,
dl.media_types_group,
dl.is_editorial,
dl.template_type,
dl.allotment_type,
dl.fiscal_year,
dl.fiscal_quarter,
dl.fiscal_month,
dl.fiscal_week_f 
) b
) final """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()