# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b_stg """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b_stg.ccepro_stock_qad  partition(as_of_date)
select 
org_id ,
org_name ,
end_user_id ,
geo ,
market_area ,
market_segment ,
pro_provisioned ,
pro_w_w_provisioned ,
pro_assigned ,
pro_w_w_assigned ,
pro_activated_seats ,
pro_w_w_activated_seats ,
pro_qad ,
pro_w_w_qad_downloaders ,
pro_rqad ,
pro_w_w_rqad_downloaders ,
pro_content_downloads ,
pro_w_w_content_downloads ,
pro_contract_start_date ,
pro_contract_end_date ,
pro_billing_type ,
stock_billing_type ,
stock_assigned_count ,
stock_w_w_assigned_count ,
stock_consumption_count ,
stock_w_w_consumption_count ,
stock_provisioned_count ,
stock_w_w_provisioned_count ,
stock_users_assigned ,
stock_w_w_stock_users_assigned ,
stock_qad ,
stock_w_w_qad ,
stock_content_downloads ,
stock_w_w_content_downloads ,
stock_rqad ,
stock_w_w_rqad ,
stock_contract_start_date ,
stock_contract_end_date,
'{RUN_DATE}' as as_of_date
from 
(
select * from (
select 
a.org_id,
a.org_name,
a.end_user_id, 
a.geo,
a.market_area,
a.market_segment,
a.provisioned as pro_provisioned,
a.w_w_provisioned as pro_w_w_provisioned,
a.assigned as pro_assigned,
a.w_w_assigned as pro_w_w_assigned,
a.activated_seats as pro_activated_seats,
a.w_w_activated_seats as pro_w_w_activated_seats,
a.qad_downloaders as pro_qad,
a.w_w_qad_downloaders as pro_w_w_qad_downloaders,
a.rqad_downloaders as pro_rqad,
a.w_w_rqad_downloaders as pro_w_w_rqad_downloaders,
a.content_downloads as pro_content_downloads,
a.w_w_content_downloads as pro_w_w_content_downloads,
a.contract_start_date as pro_contract_start_date,
a.contract_end_date as pro_contract_end_date,
'CCE Pro' as pro_billing_type,
b.billing_type as stock_billing_type,
b.stock_assigned_count    ,
b.stock_w_w_assigned_count ,
b.stock_consumption_count ,
b.stock_w_w_consumption_count,
b.stock_provisioned_count ,
b.stock_w_w_provisioned_count,
b.stock_users_assigned,
b.stock_w_w_stock_users_assigned,
b.stock_qad,
b.stock_w_w_qad,
b.stock_content_downloads,
b.stock_w_w_content_downloads,
b.stock_rqad,
b.stock_w_w_rqad,
b.stock_contract_start_date,
b.stock_contract_end_date
from 
b2b.cce_pro a 
left join
(select * from b2b_stg.new_stg_qad where as_of_date='{RUN_DATE}') b
on a.org_id=b.org_id
where 
a.as_of_date='{RUN_DATE}'
and b.org_id is null) a
union all
select * from (
select 
a.org_id,
a.org_name,
a.end_user_id, 
a.geo,
a.market_area,
a.market_segment,
a.provisioned as pro_provisioned,
a.w_w_provisioned as pro_w_w_provisioned,
a.assigned as pro_assigned,
a.w_w_assigned as pro_w_w_assigned,
a.activated_seats as pro_activated_seats,
a.w_w_activated_seats as pro_w_w_activated_seats,
a.qad_downloaders as pro_qad,
a.w_w_qad_downloaders as pro_w_w_qad_downloaders,
a.rqad_downloaders as pro_rqad,
a.w_w_rqad_downloaders as pro_w_w_rqad_downloaders,
a.content_downloads as pro_content_downloads,
a.w_w_content_downloads as pro_w_w_content_downloads,
a.contract_start_date as pro_contract_start_date,
a.contract_end_date as pro_contract_end_date,
'CCE Pro' as pro_billing_type,
b.billing_type as stock_billing_type,
b.stock_assigned_count    ,
b.stock_w_w_assigned_count ,
b.stock_consumption_count ,
b.stock_w_w_consumption_count,
b.stock_provisioned_count ,
b.stock_w_w_provisioned_count,
b.stock_users_assigned,
b.stock_w_w_stock_users_assigned,
b.stock_qad,
b.stock_w_w_qad,
b.stock_content_downloads,
b.stock_w_w_content_downloads,
b.stock_rqad,
b.stock_w_w_rqad,
b.stock_contract_start_date,
b.stock_contract_end_date
from 
b2b.cce_pro a 
join
b2b_stg.new_stg_qad b
on a.org_id=b.org_id
where a.as_of_date='{RUN_DATE}' and b.as_of_date='{RUN_DATE}') b
union all
select * from (
select 
b.org_id,
b.org_name,
b.end_user_id,
b.geo,
b.market_area,
b.market_segment,
a.provisioned as pro_provisioned,
a.w_w_provisioned as pro_w_w_provisioned,
a.assigned as pro_assigned,
a.w_w_assigned as pro_w_w_assigned,
a.activated_seats as pro_activated_seats,
a.w_w_activated_seats as pro_w_w_activated_seats,
a.qad_downloaders as pro_qad,
a.w_w_qad_downloaders as pro_w_w_qad_downloaders,
a.rqad_downloaders as pro_rqad,
a.w_w_rqad_downloaders as pro_w_w_rqad_downloaders,
a.content_downloads as pro_content_downloads,
a.w_w_content_downloads as pro_w_w_content_downloads,
a.contract_start_date as pro_contract_start_date,
a.contract_end_date as pro_contract_end_date,
'' as pro_billing_type,
b.billing_type as stock_billing_type,
b.stock_assigned_count,
b.stock_w_w_assigned_count ,
b.stock_consumption_count ,
b.stock_w_w_consumption_count,
b.stock_provisioned_count ,
b.stock_w_w_provisioned_count,
b.stock_users_assigned,
b.stock_w_w_stock_users_assigned,
b.stock_qad,
b.stock_w_w_qad,
b.stock_content_downloads,
b.stock_w_w_content_downloads,
b.stock_rqad,
b.stock_w_w_rqad,
b.stock_contract_start_date,
b.stock_contract_end_date
from 
b2b_stg.new_stg_qad b  
left join
(select * from b2b.cce_pro where as_of_date='{RUN_DATE}') a
on b.org_id=a.org_id
where a.org_id is null
and b.as_of_date='{RUN_DATE}') c
) x """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()