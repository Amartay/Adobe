# Databricks notebook source
from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime, date, timedelta
import json
from pyspark.sql import functions
import sys


class main():
    def __init__(self):
        try:
            run_day = date.today().strftime("%A")
            spark = SparkSession.builder \
                    .enableHiveSupport() \
                    .config('hive.exec.dynamic.partition', 'true') \
                    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                    .config('hive.exec.max.dynamic.partitions', '10000') \
                    .getOrCreate()
            log4j = spark._jvm.org.apache.log4j
            log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
            spark.sql('SET hive.warehouse.data.skiptrash=true;')
            spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
            spark.conf.set('spark.sql.cbo.enabled', True)
            spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
            spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
            spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
            spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            spark.sql("set spark.sql.adaptive.enabled=false")

            dbutils.widgets.text("Custom_Settings", "")
            dbutils.widgets.text("RUN_DATE", "")
            dbutils.widgets.text("TODAY_DATE", "")

            Settings = dbutils.widgets.get("Custom_Settings")
            RUN_DATE = dbutils.widgets.get("RUN_DATE")
            TODAY_DATE = dbutils.widgets.get("TODAY_DATE")

            CUR_TUE = datetime.today().date()
            RUN_DATE = datetime.strptime(RUN_DATE, '%Y-%m-%d').date()
            NOW = datetime.today().date()
            CUR_TUE = RUN_DATE + timedelta(days=3)
            if NOW < CUR_TUE:
                RUN_DATE = RUN_DATE - timedelta(days=7)

            Set_list = Settings.split(',')
            if len(Set_list) > 0:
                for i in Set_list:
                    if i != "":
                        print("spark.sql(+i+)")
                        spark.sql("""{i}""".format(i=i))

            spark.sql(""" USE b2b_stg """)
            spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
            spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
            spark.sql(""" drop table if exists b2b_stg.stg_sign_billable_transactions """)
            spark.sql(""" create table b2b_stg.stg_sign_billable_transactions AS
    SELECT 
    arr.end_user_id,
    arr.end_user_name,
    arr.geo,
    trnspse.echosignid,
    trnspse.account_company_name,
    trnspse.transaction_date,
    nvl(trnspse.billable_agreements,0) AS billable_agreements,
    nvl(trnspse.non_billable_agreements,0) AS non_billable_agreements,
    nvl(trnspse.unknown_agreements,0) AS unknown_agreements,
    trnspse.shard,
    '{TODAY_DATE}' as as_of_date,
    year(trnspse.transaction_date) as transaction_year ,
    month(trnspse.transaction_date) as transaction_month 
    FROM
    (
    SELECT 
    regexp_replace(end_user,'^0+(?!$)','') AS end_user_id,
    concat_ws(',',collect_list(DISTINCT end_user_name)) AS end_user_name,
    concat_ws(',',collect_list(DISTINCT geo)) AS geo
    FROM enterprise.ca_ent_arr_model_all
    WHERE 
    ARR_TYPE IN ('BILLED','PRE_BILLED','LAB_ARR','MANUAL')
    AND ARR_EXCLUSION = 'N'
    AND snapshot_type ='W'
    AND date_date > DATE_SUB('{TODAY_DATE}',90) AND date_date<='{TODAY_DATE}'
    AND OLPG IN ('SIGN','DCE','DCE TRANSACTION')
    AND cast(material_number as INT) NOT IN (
    '38050220',     '38056335',     '65256905',     '65259870',     '65259875',     '65265015',     '65272760',     '65274430',     '65283020',     '65290670',     '65290895',     '65293095',     '65293100',     '65300225',     '65301350',     '65301355',     '65301360',     '65305585',     '65305645',     '65305850',     '65272759',     '65272762',     '65297906',     '65320930',     '38050226',     '38050256',     '65234496',     '65259871',     '65261341',     '65261366',     '65278641',     '65283021',     '65287021',     '65290671',     '65290771',     '65290891',     '65290896',     '65293091',     '65293121',     '65310016',     '65300226',     '65301356',     '65301361',     '65305556',     '65305561',     '65305661',     '65310017',     '65310018',     '65310019',     '38050222',     '38056337',     '65234497',     '65256862',     '65259872',     '65261342',     '65261347',     '65263132',     '65265017',     '65272752',     '65310020',     '65273072',     '65287022',     '65290672',     '65290767',     '65290772',     '65290892',     '65293092',     '65301357',     '65301362',     '65305537',     '65305577',     '65310021',     '65310022',     '65310023',     '65310025',     '65310027',     '65310028',     '65320722',     '38050238',     '38056333',     '65234498',     '65259868',     '65259873',     '65261468',     '65263133',     '65263188',     '65265018',     '65269913',     '65272728',     '65272753',     '65272763',     '65275613',     '65275773',     '65278638',     '65286533',     '65290673',     '65290768',     '65290773',     '65290893',     '65293088',     '65293138',     '65293158',     '65293238',     '65299443',     '65301358',     '65305588',     '65305593',     '65305608',     '65305628',     '65305848',     '65315946',     '65315947',     '65315950',     '65315952',     '38050224',     '38056334',     '65234499',     '65256904',     '65258084',     '65259869',     '65259874',     '65261339',     '65263134',     '65263189',     '65265014',     '65265019',     '65269914',     '65315954',     '65290669',     '65290769',     '65290774',     '65290894',     '65293104',     '65293129',     '65293239',     '65299444',     '65301349',     '65301354',     '65301359',     '65302619',     '65305559',     '65306419',     '65315957',     '65315269',     '65315958',     '65315959',     '65321124'
    )
    GROUP BY 
    regexp_replace(end_user,'^0+(?!$)','')
    ) arr
    LEFT JOIN
    (
    SELECT 
    accountid,
    echosignid,
    account_company_name,
    case when transaction_date is null then '' else transaction_date END AS transaction_date,
    nvl(COLLECT_SET(billable_agreements)[0],0) AS billable_agreements,
    nvl(COLLECT_SET(non_billable_agreements)[0],0) AS non_billable_agreements,
    nvl(COLLECT_SET(unknown_agreements)[0],0) AS unknown_agreements,
    shard
    FROM
    (
    SELECT
    DISTINCT 
    b.accountid,
    b.echosignid,
    c.account_company_name,
    c.transaction_date,
    CASE WHEN is_transaction='billable_agreements' THEN agreements END AS billable_agreements,
    CASE WHEN is_transaction='non_billable_agreements' THEN agreements END AS non_billable_agreements,
    CASE WHEN is_transaction='UNKNOWN' THEN agreements END AS unknown_agreements,
    c.shard
    FROM
        (
        SELECT 
        DISTINCT 
        cast(accountid AS int) AS accountid,
        echosignid 
        FROM b2b.sign_uda_accounts
        WHERE snapshotdate=regexp_replace('{RUN_DATE}','-','')
        ) b
        JOIN 
        (
        SELECT 
        account_id, 
        concat_ws(',',collect_list(DISTINCT account_company_name)) AS account_company_name,
        COUNT(DISTINCT agreement_id) as agreements,
        date(transaction_date) as transaction_date,
        CASE WHEN is_transaction='1' THEN 'billable_agreements' 
             WHEN is_transaction='0' THEN 'non_billable_agreements' ELSE 'UNKNOWN'
        END AS is_transaction,
        shard 
        FROM a_sign_pub.agreement
        WHERE  substr(created,1,10) >='2018-12-01' AND substr(created,1,10) <='{TODAY_DATE}' 
        AND account_id IS NOT NULL AND account_id!='' 
        GROUP BY 
        account_id,
        date(transaction_date),
        CASE WHEN is_transaction='1' THEN 'billable_agreements'
                 WHEN is_transaction='0' THEN 'non_billable_agreements' ELSE 'UNKNOWN'
            END,
        shard
        ) c
        ON b.echosignid=c.account_id
    ) agreements
    GROUP BY 
    accountid,
    echosignid,
    account_company_name,

    case when transaction_date is null then '' else transaction_date END,
    shard
    ) trnspse
    ON arr.end_user_id=trnspse.accountid """.format(RUN_DATE=RUN_DATE, TODAY_DATE = TODAY_DATE))
            spark.sql(""" INSERT OVERWRITE TABLE b2b.sign_billable_transactions partition (transaction_year,transaction_month)
    SELECT 
    DISTINCT
    cast(end_user_id as bigint) as end_user_id,
    end_user_name,
    geo,
    cast(echosignid as bigint) as echosignid,
    account_company_name,
    cast(transaction_date as date) as transaction_date,
    billable_agreements,
    non_billable_agreements,
    unknown_agreements,
    cast(as_of_date as date) as as_of_date,
    transaction_year,
    transaction_month
    FROM 
    (
    SELECT
    concat_ws(',',collect_list(DISTINCT end_user_id)) AS end_user_id,
    concat_ws(',',collect_list(DISTINCT end_user_name)) AS end_user_name,
    concat_ws(',',collect_list(DISTINCT geo)) AS geo,
    echosignid,
    account_company_name,
    transaction_date,
    billable_agreements,
    non_billable_agreements,
    unknown_agreements,
    shard,
    as_of_date,
    transaction_year,
    transaction_month
    FROM
    b2b_stg.stg_sign_billable_transactions
    WHERE echosignid is not null
    GROUP BY
    echosignid,
    account_company_name,
    transaction_date,
    billable_agreements,
    non_billable_agreements,
    unknown_agreements,
    shard,
    as_of_date,
    transaction_year,
    transaction_month
    UNION ALL
    SELECT 
    DISTINCT
    end_user_id,
    end_user_name,
    geo,
    echosignid,
    account_company_name,
    transaction_date,
    billable_agreements,
    non_billable_agreements,
    unknown_agreements,
    shard,
    as_of_date,
    transaction_year,
    transaction_month
    FROM
    b2b_stg.stg_sign_billable_transactions
    WHERE echosignid is null
    ) a 
    WHERE (a.transaction_date >= date_format(add_months('{TODAY_DATE}',-24),'yyyy-MM-dd') AND a.transaction_date <='{TODAY_DATE}') OR transaction_date='' """.format(RUN_DATE=RUN_DATE, TODAY_DATE = TODAY_DATE))
    
            try:
                dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                print("exception:", e)
        except Exception as e:
            dbutils.notebook.exit(e)
            
if __name__ == '__main__':
    main()