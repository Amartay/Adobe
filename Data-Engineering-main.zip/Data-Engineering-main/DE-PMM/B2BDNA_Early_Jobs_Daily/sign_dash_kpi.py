# Databricks notebook source
from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime, date, timedelta
import json
from pyspark.sql import functions
import sys


class main():
    def __init__(self):
        try:
            spark = SparkSession.builder \
                    .enableHiveSupport() \
                    .config('hive.exec.dynamic.partition', 'true') \
                    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                    .config('hive.exec.max.dynamic.partitions', '10000') \
                    .getOrCreate()
            log4j = spark._jvm.org.apache.log4j
            log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
            spark.sql('SET hive.warehouse.data.skiptrash=true;')
            spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
            spark.conf.set('spark.sql.cbo.enabled', True)
            spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
            spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
            spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
            spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            spark.sql("set spark.sql.adaptive.enabled=false")

            dbutils.widgets.text("Custom_Settings", "")
            dbutils.widgets.text("TODAY_DATE", "")

            Settings = dbutils.widgets.get("Custom_Settings")
            TODAY_DATE = dbutils.widgets.get("TODAY_DATE")

            Set_list = Settings.split(',')
            if len(Set_list) > 0:
                for i in Set_list:
                    if i != "":
                        print("spark.sql(+i+)")
                        spark.sql("""{i}""".format(i=i))

            spark.sql(""" use b2b """)
            spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
            spark.sql(""" SET hive.execution.engine = mr """)
            spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
            spark.sql(""" set hive.optimize.skewjoin=true """)
            spark.sql(""" drop table if exists b2b_stg.stg_sign_agreements_365_730 """)
            spark.sql(""" create table b2b_stg.stg_sign_agreements_365_730 AS
    SELECT
    DISTINCT
    originator_id,
    x.agreement_id,
    CASE WHEN x.agreement_id=ae.agreement_id THEN 'SIGNATURE_REQUESTED' END AS agmt_status,
    integration_name,
    CASE WHEN date>=x.curr_yr_fisc_start_date AND date<= '{TODAY_DATE}' THEN 'CURR_YTD' else '' END AS curr_ytd_flag, 
    CASE WHEN date>=x.prv_yr_fisc_start_date AND date<x.prv_yr_run_date THEN 'PRV_YTD' else '' END AS prv_ytd_flag, 
    CASE WHEN date BETWEEN DATE_SUB('{TODAY_DATE}',27) AND '{TODAY_DATE}' THEN 'M'  
         WHEN date BETWEEN DATE_SUB('{TODAY_DATE}',55) AND DATE_SUB('{TODAY_DATE}',28) THEN 'R' ELSE '' END AS mau_flag, 
    x.curr_yr_fisc_start_date,
    x.prv_yr_fisc_start_date,
    date,
    '{TODAY_DATE}' as as_of_date
    FROM
    (
        SELECT
            originator_id,
            agreement_id,
            CASE
                WHEN ucase(integration_name) LIKE '%ACROBAT%' OR ucase(integration_name) LIKE '%DC WEB%' OR ucase(integration_name) LIKE '%READER%' THEN 'ACRO_INTEGRATION'
                    WHEN ucase(integration_name) LIKE '%MS%' THEN 'MSFT_INTEGRATION'
            WHEN ucase(integration_name) LIKE 'MICROSOFT%' THEN 'MSFT_INTEGRATION'
                    ELSE 'OTHER'
            END AS integration_name,
            substr(created,1,10) as date,
        b.curr_yr_fisc_start_date,
        b.prv_yr_fisc_start_date,
        b.prv_yr_run_date
            FROM a_sign_pub.agreement a
        LEFT JOIN 
            (
        SELECT
        curr_yr_fisc_start_date,
        prv_yr_fisc_start_date,
        DATE_ADD(prv_yr_fisc_start_date,days_from_fisc_start_date) as prv_yr_run_date 
        FROM 
        (
            SELECT
                MAX(date_date) AS curr_yr_fisc_start_date,
                MIN(date_date) AS prv_yr_fisc_start_date,
                DATEDIFF('{TODAY_DATE}',MAX(date_date)) AS days_from_fisc_start_date
                FROM ids_coredata.dim_date a
                WHERE fiscal_day_in_yr='1.0000000'
                AND SUBSTR(a.fiscal_yr_and_qtr_desc,1,4) in
                    (
                    SELECT cast(SUBSTR(fiscal_yr_and_qtr_desc,1,4) as int) AS fisc_qtr_yr FROM ids_coredata.dim_date WHERE date_date='{TODAY_DATE}'
                    UNION ALL
                    SELECT cast(SUBSTR(fiscal_yr_and_qtr_desc,1,4)-1 as int) AS fisc_qtr_yr FROM ids_coredata.dim_date WHERE date_date='{TODAY_DATE}'
                    )
        ) dates_calc
        ) b
        WHERE a.agreement_should_be_ignored = 0
            AND substr(a.created,1,10) > DATE_SUB('{TODAY_DATE}',730) 
        AND substr(a.created,1,10)<='{TODAY_DATE}'
    ) x
    LEFT JOIN
    (
        SELECT
        DISTINCT
            agreement_id
            FROM a_sign.agreement_event
            WHERE date > DATE_SUB('{TODAY_DATE}',730)
        AND date<='{TODAY_DATE}'
            AND event = 'SIGNATURE_REQUESTED'
    ) ae
    ON x.agreement_id = ae.agreement_id """.format(TODAY_DATE = TODAY_DATE))
            spark.sql(""" use b2b_stg """)
            spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
            spark.sql(""" set hive.execution.engine = mr """)
            spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
            spark.sql(""" drop table if exists b2b_stg.stg_sign_agreements """)
            spark.sql(""" create table b2b_stg.stg_sign_agreements AS
    SELECT
    DISTINCT
    a.originator_id,
    a.agreement_id,
    a.agmt_status,
    a.integration_name,
    a.curr_ytd_flag,
    a.prv_ytd_flag,
    CASE WHEN a.mau_flag='R' THEN '' ELSE a.mau_flag END AS mau_flag, 
    CASE WHEN a.originator_id=b.originator_id THEN 'R' ELSE '' END AS rmau_flag, 
    a.curr_yr_fisc_start_date,
    a.prv_yr_fisc_start_date,
    a.date,
    a.as_of_date
    FROM
    b2b_stg.stg_sign_agreements_365_730 a
    LEFT JOIN
    (SELECT DISTINCT originator_id FROM b2b_stg.stg_sign_agreements_365_730 WHERE mau_flag='R') b
    ON a.originator_id=b.originator_id """)
            spark.sql(""" use b2b """)
            spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
            spark.sql(""" SET hive.execution.engine = mr """)
            spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
            spark.sql(""" set hive.optimize.skewjoin=true """)
            spark.sql(""" INSERT OVERWRITE TABLE b2b.sign_dash_kpi partition(as_of_date) 
    SELECT 
    integration_name        ,
    customer_segment        ,
    industry                ,
    market_segment          ,
    geo                     ,
    agmt_status             ,
    entitlement_type        ,
    csmb_new_other          ,
    cast(curr_ytd_agreements as int) as curr_ytd_agreements,
    cast(prv_ytd_agreements as int) as prv_ytd_agreements,
    cast(mau_overall as int) as mau_overall,
    cast(mau_csmb_new as int) as mau_csmb_new,
    cast(mau_acro_integration as int) as mau_acro_integration,
    cast(rmau_overall as int) as rmau_overall,
    type                    ,
    partition_flag          ,
    calndr.fiscal_yr_and_qtr_desc,
    calndr.fiscal_yr_and_qtr_flag as is_qtr_end,
    cast(as_of_date as date) as as_of_date
    FROM
    (
    SELECT
    a.integration_name,
    '' AS customer_segment,
    CASE WHEN industry IS NULL THEN 'UNKNOWN' ELSE industry END AS industry,
    CASE WHEN market_segment IN ('COMMERCIAL','EDUCATION','GOVERNMENT','NON-PROFIT') THEN market_segment ELSE 'UNKNOWN' END AS market_segment,
    CASE WHEN geo IN ('AMER','ASIA','EMEA','JPN') THEN geo ELSE 'UNKNOWN' END AS geo,
    CASE WHEN agmt_status IS NULL THEN 'OTHER' ELSE agmt_status END AS agmt_status,
    '' AS entitlement_type,
    CASE WHEN customer_segment = 'CSMB' AND entitlement_type = 'SIGN_FUNNEL' THEN 'CSMB_NEW' ELSE 'OTHER' END AS csmb_new_other,
    COUNT(DISTINCT CASE WHEN curr_ytd_flag='CURR_YTD' THEN a.agreement_id END) AS curr_YTD_Agreements,
    COUNT(DISTINCT CASE WHEN prv_ytd_flag='PRV_YTD' THEN a.agreement_id END) AS prv_YTD_Agreements,
    '' AS mau_overall,
    '' AS mau_csmb_new,
    '' AS mau_acro_integration,
    '' AS rmau_overall,
    'sign_kpi' AS TYPE,
    'AGREEMENTS' AS partition_flag,
    '{TODAY_DATE}' AS as_of_date
    FROM
    b2b.sign_all_users_de_duped u
    INNER JOIN
    b2b_stg.stg_sign_agreements a
    ON a.originator_id = u.originator_id
    GROUP BY
    CASE WHEN industry IS NULL THEN 'UNKNOWN'ELSE industry END,
    CASE  WHEN agmt_status IS NULL THEN 'OTHER' ELSE agmt_status END ,
    CASE WHEN customer_segment = 'CSMB' AND entitlement_type = 'SIGN_FUNNEL' THEN 'CSMB_NEW' ELSE 'OTHER' END,
    a.integration_name,
    CASE  WHEN market_segment IN ('COMMERCIAL','EDUCATION','GOVERNMENT','NON-PROFIT') THEN market_segment ELSE 'UNKNOWN' END,
    CASE  WHEN geo IN ('AMER','ASIA','EMEA','JPN') THEN geo ELSE 'UNKNOWN' END
    UNION ALL
    SELECT 
    '' AS integration_name,
    CASE WHEN customer_segment IS NULL OR customer_segment='' THEN 'UNKNOWN' ELSE customer_segment END AS customer_segment,
    CASE WHEN industry IS NULL THEN 'UNKNOWN'ELSE industry END AS industry,
    CASE WHEN market_segment IN ('COMMERCIAL','EDUCATION','GOVERNMENT','NON-PROFIT') THEN market_segment ELSE 'UNKNOWN' END AS market_segment,
    CASE WHEN geo IN ('AMER','ASIA','EMEA','JPN') THEN geo ELSE 'UNKNOWN' END AS geo,
    '' AS agmt_status,
    entitlement_type,
    CASE WHEN customer_segment = 'CSMB' AND entitlement_type = 'SIGN_FUNNEL' THEN 'CSMB_NEW' ELSE 'OTHER' END AS csmb_new_other,
    '' AS curr_YTD_Agreements,
    '' AS prv_YTD_Agreements,
    COUNT(DISTINCT CASE WHEN mau_flag='M' THEN a.originator_id END) AS mau_overall,
    COUNT(DISTINCT CASE WHEN mau_flag='M' AND customer_segment = 'CSMB' AND entitlement_type = 'SIGN_FUNNEL' THEN a.originator_id END) AS mau_csmb_new,
    COUNT(DISTINCT CASE WHEN mau_flag='M' AND integration_name = 'ACRO_INTEGRATION' THEN a.originator_id END) AS mau_acro_integration,
    COUNT(DISTINCT CASE WHEN mau_flag='M' AND rmau_flag='R' THEN a.originator_id END) AS rmau_overall,
    'sign_kpi' AS TYPE,
    'MAU' AS partition_flag,
    '{TODAY_DATE}' AS as_of_date
    FROM 
    b2b.sign_all_users_de_duped u
    INNER JOIN 
    b2b_stg.stg_sign_agreements a
    ON a.originator_id = u.originator_id
    GROUP BY
    CASE WHEN industry IS NULL THEN 'UNKNOWN' ELSE industry END,
    CASE WHEN customer_segment = 'CSMB' AND entitlement_type = 'SIGN_FUNNEL' THEN 'CSMB_NEW' ELSE 'OTHER' END,
    CASE  WHEN market_segment IN ('COMMERCIAL','EDUCATION','GOVERNMENT','NON-PROFIT') THEN market_segment ELSE 'UNKNOWN' END,
    CASE  WHEN geo IN ('AMER','ASIA','EMEA','JPN') THEN geo ELSE 'UNKNOWN' END,
    entitlement_type,
    CASE WHEN customer_segment IS NULL OR customer_segment='' THEN 'UNKNOWN' ELSE customer_segment END
    ) curr
    left join ids_coredata.dim_date calndr
    ON curr.as_of_date=calndr.date_date """.format(TODAY_DATE = TODAY_DATE))
            try:
                dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                print("exception:",e)

        except Exception as e:
            dbutils.notebook.exit(e)


if __name__ == '__main__':
    main()