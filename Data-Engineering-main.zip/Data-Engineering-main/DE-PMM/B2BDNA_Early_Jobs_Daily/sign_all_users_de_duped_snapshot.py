# Databricks notebook source
from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime, date, timedelta
import json
from pyspark.sql import functions
import sys


class main():
    def __init__(self):
        try:
            run_day = date.today().strftime("%A")
            if run_day == 'Saturday':
                spark = SparkSession.builder \
                    .enableHiveSupport() \
                    .config('hive.exec.dynamic.partition', 'true') \
                    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                    .config('hive.exec.max.dynamic.partitions', '10000') \
                    .getOrCreate()
                log4j = spark._jvm.org.apache.log4j
                log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
                spark.sql('SET hive.warehouse.data.skiptrash=true;')
                spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
                spark.conf.set('spark.sql.cbo.enabled', True)
                spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
                spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
                spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
                spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
                spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
                spark.sql("set spark.sql.adaptive.enabled=false")

                
                dbutils.widgets.text("Custom_Settings", "")
                dbutils.widgets.text("RUN_DATE", "")
    
                Settings = dbutils.widgets.get("Custom_Settings")
                RUN_DATE = dbutils.widgets.get("RUN_DATE")

                Set_list = Settings.split(',')
                if len(Set_list) > 0:
                    for i in Set_list:
                        if i != "":
                            print("spark.sql(+i+)")
                            spark.sql("""{i}""".format(i=i))

                spark.sql(""" SET hive.execution.engine = mr """)
                spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
                spark.sql(""" SET hive.auto.convert.join=FALSE """)
                spark.sql(""" INSERT overwrite TABLE b2b.sign_all_users_de_duped_snapshot partition (asofdate)
    SELECT distinct cast(originator_id as bigint) originator_id,
           member_guid,
           sign_account_name,
           cast(sign_account_id as bigint) sign_account_id,
           org_name,
           org_id,
           market_segment,
           geo,
           industry,
           customer_segment,
           contract_type,
           contract_id,
           product_name,
           entitlement_type,
           cast('{RUN_DATE}' as date) AS asofdate
    FROM b2b.sign_all_users_de_duped """.format(RUN_DATE = RUN_DATE))

            else:
                pass
            try:
                dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                print("exception:", e)
        except Exception as e:
            dbutils.notebook.exit(e)


if __name__ == '__main__':
    main()