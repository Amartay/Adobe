from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")
    
             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" use b2b """)
             spark.sql(""" drop table if exists b2b_stg.sign_agmt1 """)
             spark.sql(""" create table b2b_stg.sign_agmt1  AS
SELECT distinct originator_id,
       member_guid,
       sign_account_id,
       sign_account_name,
       channel_name,
       account_type,
       shard,
       CURRENT_DATE AS asofdate
FROM
  (SELECT  originator_id,
                   substr(originator_adobe_guid, 1, 24) AS member_guid,
                   account_id AS sign_account_id,
                   account_company_name AS sign_account_name,
                   channel_name,
                   account_type,
                   shard,
                   ROW_NUMBER() OVER(PARTITION BY originator_id
                                     ORDER BY substr(created, 1, 10) DESC) AS rownum
   FROM a_sign_pub.agreement
   WHERE substr(created, 1, 10) >= '2018-01-01') a
WHERE rownum = 1 """)
             spark.sql(""" drop table if exists b2b.sign_all_users_stg """)
             spark.sql(""" create table  b2b.sign_all_users_stg  AS
SELECT DISTINCT originator_id,
                member_guid,
                seat_status,
                sign_account_name,
                sign_account_id,
                org_name,
                org_id,
                market_segment,
                geo,
                industry,
                customer_segment,
                contract_type,
                product_name,
                contract_id,
                account_type,
                entitlement_type, 
CASE
    WHEN upper(account_type) LIKE '%NO%ACCOUNT%USER%'
         AND entitlement_type = 'SIGN_FUNNEL' THEN 560
    WHEN upper(account_type) LIKE '%NO%ACCOUNT%USER%'
         AND entitlement_type = 'PDF_FUNNEL' THEN 570
    WHEN upper(account_type) LIKE '%NO%ACCOUNT%USER%'
         AND entitlement_type = 'CC_OTHER' THEN 580
    WHEN upper(product_name) = 'APAS' THEN 10
    WHEN upper(product_name) = 'PDFF' THEN 10
    WHEN upper(product_name) LIKE '%ADOBE%SIGN%'
         AND contract_type = 'ETLA' THEN 20
    WHEN upper(product_name) LIKE '%ADOBE%SIGN%'
         AND contract_type = 'EVIP' THEN 30
    WHEN upper(contract_type) = 'ETLA'
         AND product_name = 'SIGN' THEN 50
    WHEN upper(contract_type) IN ('CSMB_ETLA',
                                  'STANDALONE') THEN 80
    WHEN upper(product_name) IN ('ECHP',
                                 'ECHG',
                                 'ECHE') THEN 120
    WHEN upper(contract_type) = 'ARIA_SMB' THEN 140
    WHEN contract_type = 'EMBEDDED_RESELLERS_CONTRACT' THEN 200
    WHEN upper(product_name) LIKE '%DOCUMENT%' THEN 220
    WHEN upper(product_name) RLIKE '(PDF|ACOM|APRO|ACR|APCC|ACROBAT|APAP)' THEN 250
    WHEN upper(product_name) LIKE '%ALL%APPS%' THEN 270
    WHEN upper(product_name) RLIKE '(CCLE|CCSN)' THEN 280
    WHEN upper(product_name) NOT LIKE '%ADOBE%SIGN%'
         AND contract_type = 'ETLA' THEN 300
    WHEN upper(product_name) NOT LIKE '%ADOBE%SIGN%'
         AND contract_type = 'EVIP' THEN 350
    WHEN contract_type = 'VIP' THEN 450
    WHEN contract_type = 'TEAM DIRECT' THEN 500
    WHEN contract_type = 'INDIVIDUAL' THEN 550
    WHEN customer_segment = 'UNKNOWN' THEN 600
    WHEN contract_type = 'TRIAL' THEN 800
    WHEN contract_type = 'FREE' THEN 850
    ELSE 1500
                                                                                                   END AS priority,
                                                                                                   shard,
                                                                                                   CASE
                                                                                                       WHEN upper(shard) IN ('NA2',
                                                                                                                             'JP1',
                                                                                                                             'IN1',
                                                                                                                             'NA1',
                                                                                                                             'AU1',
                                                                                                                             'NA4',
                                                                                                                             'EU1') THEN 'AWS'
                                                                                                       WHEN upper(shard) IN ('EU2',
                                                                                                                             'NA3') THEN 'AZURE'
                                                                                                       ELSE 'UNKNOWN'
                                                                                                   END AS sign_hosting,
                                                                                                   CURRENT_DATE AS asofdate
FROM
  (SELECT DISTINCT originator_id,
                   j.member_guid,
                   seat_status,
                   sign_account_name,
                   sign_account_id,
                   j.org_name,
                   j.org_id,
                   j.market_segment,
                   geo,
                   ech_parent_industry as industry,
                   CASE
                       WHEN j.contract_type = 'ETLA'
                            AND customer_segment IS NULL THEN 'ENTERPRISE'
                       WHEN upper(j.contract_type) = 'EVIP' THEN 'MidMarket'
                       WHEN j.contract_type IN ('DIRECT_INDIVIDUAL',
                                                'DIRECT_ORGANIZATION',
                                                'INDIRECT_ORGANIZATION') THEN 'CSMB'
                       ELSE customer_segment
                   END AS customer_segment,
                   CASE
                       WHEN upper(j.contract_type) IN ('ETLA',
                                                       'EVIP') THEN j.contract_type
                       WHEN j.contract_type = 'DIRECT_INDIVIDUAL' THEN 'INDIVIDUAL'
                       WHEN j.contract_type = 'DIRECT_ORGANIZATION' THEN 'TEAM DIRECT'
                       WHEN j.contract_type = 'INDIRECT_ORGANIZATION' THEN 'VIP'
                       ELSE contract_type
                   END AS contract_type,
                   product_name,
                   j.contract_id,
                   CASE
                       WHEN upper(j.product_name) LIKE '%ADOBE%SIGN%' THEN 'SIGN_FUNNEL'
                       WHEN upper(j.product_name) IN ('ECHP',
                                                      'ECHG',
                                                      'ASIG',
                                                      'ECHE',
                                                      'APAS',
                                                      'PDFF') THEN 'SIGN_FUNNEL'
                       WHEN contract_type IS NULL THEN 'UNKNOWN'
                       WHEN upper(j.product_name) RLIKE '(PDF|ACOM|APRO|ACR|APCC|ACROBAT|DOCUMENT|APAP)' THEN 'PDF_FUNNEL'
                       ELSE 'CC_OTHER'
                   END AS entitlement_type,
                   account_type,
                   shard
   FROM 
     (SELECT DISTINCT member_guid,
                      seat_status,
                      d.org_id,
                      org_name,
                      geo_code AS geo,
                      CASE
                          WHEN contract_offer_type = 'ETLA'
                               AND m.end_user_id IS NOT NULL THEN m.end_user_id
                          ELSE d.contract_id
                      END AS contract_id,
                      market_segment,
                      contract_offer_type AS contract_type,
                      offering_name AS product_name
      FROM
        (SELECT DISTINCT member_guid,
                         seat_status,
                         org_id,
                         org_name,
                         geo_code,
                         contract_id,
                         contract_offer_type,
                         market_segment,
                         offering_name
         FROM 
           (SELECT member_guid, 
                   delegation_status AS seat_status, 
                   org_name, 
                   org_id, 
                   geo_code, 
                   contract_id, 
                   contract_offer_type, 
                   market_segment, 
                   offering_name, 
                   ROW_NUMBER() OVER(PARTITION BY member_guid
                                     ORDER BY current_status_date DESC) AS rownum
            FROM enterprise.fact_enterprise_member_license_delegation)a 
         WHERE rownum = 1 )d
      LEFT  JOIN b2b.enduserid_orgid_mapping m ON d.org_id = m.org_id 
      UNION ALL SELECT DISTINCT s.member_guid,
                                seat_status,
                                e.org_id,
                                org_name,
                                geo,
                                s.contract_id,
                                market_segment,
                                s.contract_type,
                                product_name
      FROM
        (SELECT DISTINCT member_guid,
                         seat_status,
                         geo,
                         market_segment,
                         product_name,
                         contract_id,
                         contract_type
         FROM 
           /*
           (SELECT member_guid, 
                   seat_status, 
                   geo, 
                   market_segment, 
                   product_name, 
                   contract_id, 
                   contract_type, 
                   ROW_NUMBER() OVER(PARTITION BY member_guid 
                                     ORDER BY seat_last_modifieddate DESC) AS rownum 
            FROM ocf_analytics.dim_seat)a
            */
            --New SLS table
            (
            SELECT member_guid, 
                'null' as seat_status, 
                coun.geo_code as geo, 
                scd.market_segments as market_Segment, 
                scd.product_name, 
                scd.contract_id, 
                scd.contract_type, 
                ROW_NUMBER() OVER(PARTITION BY scd.member_guid 
                                    ORDER BY scd.end_ts DESC) AS rownum 
            FROM ocf_analytics.scd_delegate scd
            left outer join ids_coredata.dim_country coun
              on scd.country_code = coun.country_code_iso2
            where scd.contract_type in ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION')
            ) 
         WHERE rownum = 1) s 
      INNER  JOIN 
        (SELECT DISTINCT contract_id, 
                         contract_type,
                         owner_identity_id AS org_id 
         FROM ocf_analytics.dim_contract)e ON s.contract_id = e.contract_id 
      --LEFT JOIN b2b.cct_org_name o ON o.org_id = e.org_id)j 
      LEFT JOIN
      (SELECT 
     DISTINCT 
      org_id,
     org_name from 
     enterprise.dim_org dim ) o --Updated code for B2BDME-5832 on 27 FEB end
       ON o.org_id = e.org_id and e.contract_type != 'DIRECT_INDIVIDUAL')j
   LEFT JOIN 
     (SELECT DISTINCT cast(accountid AS int) AS contract_id, 
                      CASE 
                          WHEN signaccounttype = 'MID_MARKET' THEN 'MidMarket' 
                          ELSE signaccounttype 
                      END AS customer_segment
      FROM b2b.sign_uda_accounts a 
      WHERE signsourcetype = 'ETLA'
        AND CONCAT(SUBSTRING(snapshotdate, 1, 4), '-',SUBSTRING(snapshotdate, 5, 2), '-',SUBSTRING(snapshotdate, 7, 2)) BETWEEN date_sub(CURRENT_DATE,180) AND CURRENT_DATE ) u ON u.contract_id = j.contract_id 
   LEFT JOIN --b2b.org_industry_map i 
   (select distinct org_id,ech_parent_industry from b2b.ecp_ecc_org_map where as_of_date='{RUN_DATE}' and ech_parent_industry is not null and ech_parent_industry !=''  )  i ON j.org_id = i.org_id 
   --LEFT JOIN b2b_tmp.org_industry_map_final_temp  i ON j.org_id = i.org_id --used for validation july 26
   INNER JOIN b2b_stg.sign_agmt1 a ON ucase(a.member_guid) = ucase(j.member_guid) 
   WHERE ucase(a.member_guid) != '' 
     AND ucase(a.member_guid) IS NOT NULL 
     AND ucase(a.member_guid) != 'UNKNOWN' 
     --and as_of_date='{RUN_DATE}'
   UNION ALL SELECT DISTINCT originator_id, 
                             a.member_guid, 
                             'ACTIVE' AS seat_status, 
                             sign_account_name, 
                             sign_account_id, 
                             c.org_name, 
                             c.org_id, 
                             market_segment, 
                             geo, 
                             industry, 
                             CASE 
                                 WHEN upper(u.contract_type) IN ('CSMB_ETLA', 
                                                                 'ETLA', 
                                                                 'STANDALONE') THEN u.customer_segment 
                                 WHEN b.channel_name IS NOT  NULL 
                                      AND u.contract_id IS NULL THEN 'EMBEDDED_RESELLERS' 
                                 WHEN upper(u.contract_type) = 'ARIA_SMB' THEN 'MidMarket' 
                                 WHEN account_type LIKE '%TRIAL%' 
                                      AND u.contract_id IS NULL THEN 'FREE_TRIAL' 
                                 WHEN account_type LIKE '%FREE%' 
                                      AND u.contract_id IS NULL THEN 'FREE_TRIAL' 
                                 WHEN a.sign_account_id IN ('10', 
                                                            '1818') THEN 'FREE_TRIAL' 
                                 ELSE customer_segment 
                             END AS customer_segment, 
                             CASE 
                                 WHEN upper(u.contract_type) IN ('ETLA', 
                                                                 'STANDALONE', 
                                                                 'ARIA_SMB') THEN u.contract_type 
                                 WHEN upper(u.contract_type) = 'CSMB_ETLA' THEN 'ETLA' 
                                 WHEN b.channel_name IS NOT NULL 
                                      AND u.contract_id IS NULL THEN 'EMBEDDED_RESELLERS_CONTRACT' 
                                 WHEN a.account_type LIKE '%TRIAL%' 
                                      AND u.contract_id IS NULL THEN 'TRIAL' 
                                 WHEN a.account_type LIKE '%FREE%' 
                                      AND u.contract_id IS NULL THEN 'FREE' 
                                 WHEN a.sign_account_id IN ('10', 
                                                            '1818') THEN 'FREE' 
                             END AS contract_type, 
                             CASE 
                                 WHEN upper(u.contract_type) IN ('CSMB_ETLA', 
                                                                 'ETLA', 
                                                                 'STANDALONE', 
                                                                 'ARIA_SMB') THEN 'SIGN' 
                                 WHEN b.channel_name IS NOT NULL 
                                      AND u.contract_id IS NULL THEN 'SIGN_EMBEDDED' 
                                 WHEN a.account_type LIKE '%TRIAL%' 
                                      AND u.contract_id IS NULL THEN 'SIGN_FREE_TRIAL' 
                                 WHEN a.account_type LIKE '%FREE%' 
                                      AND u.contract_id IS NULL THEN 'SIGN_FREE_TRIAL' 
                                 WHEN a.sign_account_id IN ('10', 
                                                            '1818') THEN 'SIGN_FREE_TRIAL' 
                             END AS product_name, 
                             u.contract_id, 
                             CASE 
                                 WHEN upper(u.contract_type) IN ('CSMB_ETLA', 
                                                                 'ETLA', 
                                                                 'STANDALONE', 
                                                                 'ARIA_SMB') THEN 'SIGN_FUNNEL' 
                                 WHEN b.channel_name IS NOT  NULL 
                                      AND u.contract_id IS NULL THEN 'SIGN_FUNNEL' 
                                 WHEN a.account_type LIKE '%TRIAL%' 
                                      AND u.contract_id IS NULL THEN 'UNKNOWN' 
                                 WHEN a.account_type LIKE '%FREE%' 
                                      AND u.contract_id IS NULL THEN 'UNKNOWN' 
                                 WHEN a.sign_account_id IN ('10', 
                                                            '1818') THEN 'UNKNOWN' 
                                 ELSE 'UNKNOWN' 
                             END AS entitlement_type, 
                             account_type,
                             shard
   FROM b2b_stg.sign_agmt1 a 
   LEFT JOIN 
     (SELECT DISTINCT cast(accountid AS int) AS contract_id, 
                      signsourcetype AS contract_type, 
                      CASE 
                          WHEN signaccounttype = 'MID_MARKET' THEN 'MidMarket' 
                          ELSE signaccounttype 
                      END AS customer_segment, 
                      marketsegment AS market_segment, 
                      echosignid, 
                      b.ecp_industry AS industry, 
                      geo 
      FROM b2b.sign_uda_accounts a 
      LEFT JOIN b2b.sign_sfdc_industry_map_ecp b ON a.industry = b.sign_sfdc_industry 
      WHERE signsourcetype != 'VIP' 
        AND echosignid != '' 
        AND CONCAT(SUBSTRING(snapshotdate, 1, 4), '-',SUBSTRING(snapshotdate, 5, 2), '-',SUBSTRING(snapshotdate, 7, 2)) BETWEEN date_sub(CURRENT_DATE,180) AND CURRENT_DATE ) u ON u.echosignid = a.sign_account_id
   LEFT JOIN b2b.enduserid_orgid_mapping m ON u.contract_id = CAST (m.end_user_id AS int)
   LEFT JOIN
     (SELECT DISTINCT org_id,
                      org_name
      FROM enterprise.fact_cce_membership_count
      UNION ALL SELECT DISTINCT org_id,
                                org_name
      FROM enterprise.fact_dce_membership_count) c ON m. org_id = c.org_id
   LEFT JOIN
     (SELECT DISTINCT member_guid
      FROM enterprise.fact_enterprise_member_license_delegation
      UNION ALL 
      SELECT DISTINCT member_guid
      --FROM ocf_analytics.dim_seat s
      --New SLS table
      FROM ocf_analytics.scd_delegate scd
      where scd.contract_type in ('DIRECT_ORGANIZATION','INDIRECT_ORGANIZATION')
      ) k ON k.member_guid = a.member_guid 
   LEFT  JOIN b2b.sign_embedded_accts b ON UPPER (a.channel_name) = UPPER (b.channel_name)
   WHERE k.member_guid IS NULL )l """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" drop table if exists b2b.sign_all_users_de_duped_stg """)
             spark.sql(""" create table  b2b.sign_all_users_de_duped_stg  AS
SELECT originator_id,
       member_guid,
       seat_status,
       sign_account_name,
       sign_account_id,
       org_name,
       org_id,
       market_segment,
       geo,
       industry,
       CASE
           WHEN customer_segment IS NULL THEN 'UNKNOWN'
           ELSE customer_segment
       END AS customer_segment,
       contract_type,
       contract_id,
       product_name,
       entitlement_type,
       account_type,
       shard,
       sign_hosting,
       CURRENT_DATE AS asofdate
FROM
  (SELECT originator_id,
          member_guid,
          seat_status,
          sign_account_name,
          sign_account_id,
          org_name,
          org_id,
          market_segment,
          geo,
          industry,
          customer_segment,
          contract_type,
          contract_id,
          product_name,
          entitlement_type,
          account_type,
          shard,
          sign_hosting,
          ROW_NUMBER() OVER(PARTITION BY originator_id
                            ORDER BY priority ASC) AS rownum
   FROM
     (SELECT originator_id,
             member_guid,
             seat_status,
             sign_account_name,
             sign_account_id,
             org_name,
             org_id,
             market_segment,
             geo,
             industry,
             customer_segment,
             contract_type,
             contract_id,
             product_name,
             entitlement_type,
             account_type,
             priority,
             shard,
             sign_hosting
      FROM b2b.sign_all_users_stg
      WHERE priority IS NOT NULL
        AND originator_id IS NOT NULL
      GROUP BY originator_id,
               member_guid,
               seat_status,
               sign_account_name,
               sign_account_id,
               org_name,
               org_id,
               market_segment,
               geo,
               industry,
               customer_segment,
               contract_type,
               contract_id,
               product_name,
               entitlement_type,
               account_type,
               priority,
               shard,
               sign_hosting) a)b
WHERE rownum = 1 """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" drop table if exists b2b.sign_all_users """)
             spark.sql(""" ALTER TABLE b2b.sign_all_users_stg RENAME TO b2b.sign_all_users """)
             spark.sql(""" drop table if exists b2b.sign_all_users_de_duped """)
             spark.sql(""" ALTER TABLE b2b.sign_all_users_de_duped_stg RENAME TO b2b.sign_all_users_de_duped """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()