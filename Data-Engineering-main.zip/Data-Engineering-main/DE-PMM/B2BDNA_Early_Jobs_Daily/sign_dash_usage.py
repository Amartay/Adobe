# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime,date,timedelta
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                    .enableHiveSupport() \
                    .config('hive.exec.dynamic.partition', 'true') \
                    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                    .config('hive.exec.max.dynamic.partitions', '10000') \
                    .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")
             
             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("TODAY_DATE", "")
             
             Settings = dbutils.widgets.get("Custom_Settings")
             TODAY_DATE = dbutils.widgets.get("TODAY_DATE")
             
             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))
             
             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.sign_dash_usage 
    SELECT 
    CASE WHEN customer_segment IS NULL OR customer_segment='' THEN 'UNKNOWN' ELSE customer_segment END AS customer_segment,
    CASE WHEN contract_type IS NULL OR contract_type=''  THEN 'UNKNOWN' ELSE contract_type END AS contract_type,
    CASE WHEN industry IS NULL OR industry='' THEN 'UNKNOWN' ELSE industry END AS industry,
    CASE WHEN market_segment IN ('COMMERCIAL','EDUCATION','GOVERNMENT','NON-PROFIT') THEN market_segment ELSE 'UNKNOWN' END AS market_segment,
    CASE WHEN geo IN ('AMER','ASIA','EMEA','JPN') THEN geo ELSE 'UNKNOWN' END AS geo,
    CASE WHEN entitlement_type IS NULL OR entitlement_type='' THEN 'UNKNOWN' ELSE entitlement_type END AS entitlement_type,
    a.agmt_status,
    a.integration_name,
    COUNT(DISTINCT a.agreement_id) AS agreements,
    cast(a.date as date)
    FROM 
    b2b.sign_all_users_de_duped u
    INNER JOIN 
    (
    SELECT
    DISTINCT
    x.originator_id,
    x.agreement_id,
    CASE WHEN x.agreement_id=ae.agreement_id THEN 'SIGNATURE_REQUESTED' ELSE 'OTHER' END AS agmt_status,
    x.integration_name,
    x.date
    FROM
        (
        SELECT
        originator_id,
        agreement_id,
        CASE 
            WHEN ucase(integration_name) LIKE '%ACROBAT%' OR ucase(integration_name) LIKE '%DC WEB%' OR ucase(integration_name) LIKE '%READER%' THEN 'ACRO_INTEGRATION'
            WHEN ucase(integration_name) LIKE '%MS%' THEN 'MSFT_INTEGRATION'
            WHEN ucase(integration_name) LIKE 'MICROSOFT%' THEN 'MSFT_INTEGRATION' ELSE 'OTHER'
            END AS integration_name,
        SUBSTR(created,1,10) AS date
        FROM a_sign_pub.agreement a
        WHERE a.agreement_should_be_ignored = 0
        AND substr(a.created,1,10) > DATE_SUB('{TODAY_DATE}',730) 
        AND substr(a.created,1,10) <= '{TODAY_DATE}'
        ) x
    LEFT JOIN
        (
        SELECT
        DISTINCT
        agreement_id
        FROM a_sign.agreement_event
        WHERE date > DATE_SUB('{TODAY_DATE}',730) 
        AND event = 'SIGNATURE_REQUESTED'
    ) ae
    ON x.agreement_id = ae.agreement_id 
    ) a
    ON a.originator_id = u.originator_id
    GROUP BY
    CASE WHEN customer_segment IS NULL OR customer_segment='' THEN 'UNKNOWN' ELSE customer_segment END,
    CASE WHEN contract_type IS NULL OR contract_type=''  THEN 'UNKNOWN' ELSE contract_type END,
    CASE WHEN industry IS NULL OR industry='' THEN 'UNKNOWN' ELSE industry END,
    CASE WHEN entitlement_type IS NULL OR entitlement_type='' THEN 'UNKNOWN' ELSE entitlement_type END,
    a.agmt_status,
    integration_name,
    CASE  WHEN market_segment IN ('COMMERCIAL','EDUCATION','GOVERNMENT','NON-PROFIT') THEN market_segment ELSE 'UNKNOWN' END,
    CASE  WHEN geo IN ('AMER','ASIA','EMEA','JPN') THEN geo ELSE 'UNKNOWN' END,
    a.date """.format(TODAY_DATE = TODAY_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()