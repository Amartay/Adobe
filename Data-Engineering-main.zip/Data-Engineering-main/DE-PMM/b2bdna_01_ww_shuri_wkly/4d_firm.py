# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" SET mapred.job.priority=VERY_HIGH """)
             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=21333334 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=21333334 """)
             spark.sql(""" insert overwrite table b2b.shuri_final_20200915_d
SELECT A.*,
        CASE 
            WHEN gd.type = 'GENERIC' THEN 'Y' 
            WHEN gd.type IS NULL THEN 'N' 
            ELSE 'N' 
        END AS generic_domain_flag,
        coalesce(firm.smb_industry, 'UNKNOWN') AS smb_industry, 
        coalesce(firm.employee_range, 'UNKNOWN') AS employee_range, 
        coalesce(firm.revenue_range, 'UNKNOWN') AS revenue_range
    FROM b2b.shuri_final_20200915_c A
    LEFT OUTER JOIN (
    	SELECT distinct upper(trim(DOMAIN)) domain, 
    	    upper(trim(TYPE)) type 
    	FROM b2b.generic_domains 
    	WHERE upper(trim(TYPE)) = 'GENERIC') gd 
    ON gd.domain = A.domain
    LEFT OUTER JOIN b2b.dim_firm firm
    ON A.domain = firm.domain """)
             spark.sql(""" Insert into Table b2b.ww_shuri_job_logs 
Select 'Firm Update' step, current_timestamp() completion_datetime """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()