# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" SET mapred.job.priority=VERY_HIGH """)
             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=21333334 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=21333334 """)
             spark.sql(""" insert overwrite table b2b.shuri_final_20200915_f
SELECT A.*,
    if(bob.contract_id is not null, 
        'YES',
        if(crmbob.crm_customer_guid is not null,
            'YES',
            'NO')) as csam_bob_flag,
    coalesce(bob.csam_name, crmbob.csam_name) as csam_name,
    coalesce(bob.csam_team, crmbob.csam_team) as csam_team,
    coalesce(bob.csam_tsm, crmbob.csam_tsm) as csam_tsm,
    coalesce(bob.csam_ism, crmbob.csam_ism) as csam_ism
FROM b2b.shuri_final_20200915_e A
LEFT OUTER JOIN (
    Select a.*
    from b2b.dim_bob a
    cross join b2b.dim_date b
    where a.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc) bob
on coalesce(A.contract_id,A.subscription_account_guid) = bob.contract_id
LEFT OUTER JOIN (
    Select *
    from (Select A.crm_customer_guid,
                bob.csam_name,
                bob.csam_team,
                bob.csam_tsm,
                bob.csam_ism,
                ROW_NUMBER() OVER(PARTITION BY A.crm_customer_guid ORDER BY csam_name) as rownum
            from (
                Select a.*
                from b2b.dim_bob a
                cross join b2b.dim_date b
                where a.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc) bob
            inner join b2b.shuri_final_20200915_e A
            on coalesce(A.contract_id,A.subscription_account_guid) = bob.contract_id
            where A.crm_customer_guid != ''
            and A.crm_customer_guid is not null) temp
    where rownum = 1) crmbob
on A.crm_customer_guid = crmbob.crm_customer_guid """)
             spark.sql(""" Insert into Table b2b.ww_shuri_job_logs 
Select 'Bob Update' step, current_timestamp() completion_datetime """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()