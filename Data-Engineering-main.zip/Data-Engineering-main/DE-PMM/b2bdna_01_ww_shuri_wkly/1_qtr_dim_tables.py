# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")
             spark.sql("SET spark.databricks.delta.formatCheck.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" USE b2b """)
             spark.sql(""" SET mapred.job.priority=VERY_HIGH """)
             spark.sql(""" set mapred.job.queue.name=root.GRP-HADOOP-GTM """)
             spark.sql(""" SET hive.exec.max.created.files=900000 """)
             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=21333334 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=21333334 """)
             spark.sql(""" set hive.exec.dynamic.partition=true """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.support.quoted.identifiers = none """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.dim_cancel_reason PARTITION(fiscal_yr_and_qtr_desc)
Select A.fiscal_yr_and_wk_desc, A.sales_document, collect_list(V.cancel_reason)[0] cancel_reason, A.fiscal_yr_and_qtr_desc
from (
    Select distinct upper(A.fiscal_yr_and_wk_desc) fiscal_yr_and_wk_desc,
        upper(A.sales_document) sales_document,
        A.date_date,
        A.fiscal_yr_and_qtr_desc
    from csmb.vw_ccm_pivot4_all A
    cross join b2b.dim_date b
    where 1=1
    and A.date_key between b.start_date and b.end_date
    and upper(A.source_type) != 'F2P' 
    and upper(A.event_source) = 'EVENT'
    and (nvl(gross_cancellations,0)>0 OR nvl(migrated_from,0)>0) ) A
INNER JOIN (
    select distinct upper(lpad(order_number,10,'0')) as sales_document,
        inserteddate,
        cancel_reason
    from ocf.vw_csui_report
    where event_type in ('CANCEL_PLAN_NOW', 'CCT_CANCEL_CONTRACT', 'CCT_CANCEL_LICENSE', 'CCT_CANCEL_SEAT', 'CCT_DR_CANCEL_CONTRACT', 'CCT_DR_CANCEL_SEAT', 'STOCKS_RETURN')
    and inserteddate >= date_sub(current_date(),150)  
    and order_number is not null
    and cancel_reason is not null
    and cancel_reason not in ('')
    order by sales_document, inserteddate desc) V
on A.sales_document = V.sales_document
where V.inserteddate BETWEEN date_sub(A.date_date,30) AND A.date_date
GROUP BY A.fiscal_yr_and_wk_desc, A.sales_document, A.fiscal_yr_and_qtr_desc """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.dim_hx_sd_agent PARTITION(fiscal_yr_and_qtr_desc)
Select A.fiscal_yr_and_wk_desc, A.sales_document, collect_list(V.agent_ldapid)[0] agent, A.fiscal_yr_and_qtr_desc
from (
    Select distinct upper(A.sales_document) sales_document,
        upper(A.fiscal_yr_and_wk_desc) fiscal_yr_and_wk_desc,
        A.date_date,
        A.fiscal_yr_and_qtr_desc
    from csmb.vw_ccm_pivot4_all A
    cross join b2b.dim_date b
    where 1=1
    and A.date_key between b.start_date and b.end_date
    and upper(A.source_type) != 'F2P' 
    and upper(A.event_source) = 'EVENT'
    and (nvl(addl_purchase_diff,0)>0 OR nvl(addl_purchase_same,0)>0) ) A
INNER JOIN (
    select distinct upper(lpad(order_number,10,'0')) as sales_document,
        inserteddate,
        upper(agent_ldapid) agent_ldapid
    from ocf.vw_csui_report
    where upper(event_type) in ('CCT_ADD_LICENSES', 'CCT_ADD_PRODUCTS','CCT_ADD_SEATS', 'CCT_DR_ADD_PRODUCTS', 'CCT_DR_ADD_SEATS', 'CHANGE_PLAN', 'CREATE_APPROVAL_:_ADD_LICENSES', 'CREATE_APPROVAL_:_ADD_PRODUCTS', 'CREATE_APPROVAL_:_DR_ADD_PRODUCTS', 'CREATE_APPROVAL_:_DR_ADD_SEATS', 'STOCKS_ADD', 'STOCKS_ADD_LICENSE')
    and inserteddate >= date_sub(current_date(),150)   
    and order_number is not null
    and cast(order_number as double) is not null
    and agent_ldapid is not null
    and upper(agent_ldapid) not in ('','IN_PRODUCT_SUPPORT1')
    order by sales_document, inserteddate desc) V
on A.sales_document = V.sales_document
where V.inserteddate BETWEEN date_sub(A.date_date,30) AND A.date_date
GROUP BY A.fiscal_yr_and_wk_desc, A.sales_document, A.fiscal_yr_and_qtr_desc """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.dim_hx_dylan_agent PARTITION(fiscal_yr_and_qtr_desc)
Select A.fiscal_yr_and_wk_desc, A.dylan_order_number, collect_list(V.agent_ldapid)[0] agent, A.fiscal_yr_and_qtr_desc
from (
    Select distinct upper(A.dylan_order_number) dylan_order_number,
        upper(A.fiscal_yr_and_wk_desc) fiscal_yr_and_wk_desc,
        A.date_date,
        A.fiscal_yr_and_qtr_desc
    from csmb.vw_ccm_pivot4_all A
    cross join b2b.dim_date b
    where 1=1
    and A.date_key between b.start_date and b.end_date
    and upper(A.source_type) != 'F2P' 
    and upper(A.event_source) = 'EVENT'
    and (nvl(addl_purchase_diff,0)>0 OR nvl(addl_purchase_same,0)>0) ) A
INNER JOIN (
    select distinct upper(order_number) as dylan_number,
        inserteddate,
        upper(agent_ldapid) agent_ldapid
    from ocf.vw_csui_report
    where upper(event_type) in ('CCT_ADD_LICENSES', 'CCT_ADD_PRODUCTS','CCT_ADD_SEATS', 'CCT_DR_ADD_PRODUCTS', 'CCT_DR_ADD_SEATS', 'CHANGE_PLAN', 'CREATE_APPROVAL_:_ADD_LICENSES', 'CREATE_APPROVAL_:_ADD_PRODUCTS', 'CREATE_APPROVAL_:_DR_ADD_PRODUCTS', 'CREATE_APPROVAL_:_DR_ADD_SEATS', 'STOCKS_ADD', 'STOCKS_ADD_LICENSE')
    and inserteddate >= date_sub(current_date(),150)   
    and order_number is not null
    and cast(order_number as double) is null
    and agent_ldapid is not null
    and upper(agent_ldapid) not in ('','IN_PRODUCT_SUPPORT1')
    order by dylan_number, inserteddate desc) V
on A.dylan_order_number= V.dylan_number
where V.inserteddate BETWEEN date_sub(A.date_date,30) AND A.date_date
GROUP BY A.fiscal_yr_and_wk_desc, A.dylan_order_number, A.fiscal_yr_and_qtr_desc """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.dim_latam_apac PARTITION(fiscal_yr_and_qtr_desc)
Select sales_center,crm_customer_guid,ldap,fiscal_yr_and_qtr_desc
    FROM (
        Select upper(trim(sales_center)) sales_center,
            upper(trim(crm_guid)) as crm_customer_guid,
            upper(trim(ldap)) ldap,
            A.fiscal_yr_and_qtr_desc,
            ROW_NUMBER() OVER(PARTITION BY upper(trim(crm_guid)) ORDER BY date DESC) as rownum
        FROM b2b.latam_apac_raw A
        cross join b2b.dim_date b
        where A.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc) distinct_guid
    where rownum=1 """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.dim_cnx PARTITION(fiscal_yr_and_qtr_desc)
Select distinct upper(lpad(trim(order_number),10,'0')) order_number,
       A.fiscal_yr_and_qtr_desc
FROM b2b.cnx_raw A
cross join b2b.dim_date b
where A.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc """)
             spark.sql(""" Insert into Table b2b.ww_shuri_job_logs 
Select 'Qtr Dim Tables Update' step, current_timestamp() completion_datetime """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()