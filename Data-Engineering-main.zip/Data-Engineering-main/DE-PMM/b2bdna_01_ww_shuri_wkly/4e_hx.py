# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" SET mapred.job.priority=VERY_HIGH """)
             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=21333334 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=21333334 """)
             spark.sql(""" insert overwrite table b2b.shuri_final_20200915_e
Select A.*,
    CASE 
		WHEN nvl(A.init_purchase,0) <> 0 THEN 'Initial Purchase'
		WHEN A.hx_addon_by = 'CUSTOMER' THEN 'Customer Add On'
		WHEN A.hx_addon_by!='NA' THEN 'Rep Add On'
		ELSE 'Other' 
	END init_vs_addl
from 
    (SELECT A.*,
        IF(nvl(addl_purchase_diff,0)>0 OR nvl(addl_purchase_same,0)>0,
            coalesce(hxag.rep_name,'CUSTOMER'),
            'NA') AS hx_addon_by,
        IF(nvl(addl_purchase_diff,0)>0 OR nvl(addl_purchase_same,0)>0,
            coalesce(hxag.team,'CUSTOMER'),
            'NA') AS hx_addon_team,
        IF(nvl(addl_purchase_diff,0)>0 OR nvl(addl_purchase_same,0)>0,
            hxag.tsm,
            'NA') AS hx_addon_tsm,
        IF(nvl(addl_purchase_diff,0)>0 OR nvl(addl_purchase_same,0)>0,
            hxag.ism,
            'NA') AS hx_addon_ism,
        IF(nvl(gross_cancellations,0)>0 OR nvl(migrated_from,0)>0,
            coalesce(cxl.cancel_reason,'No Reason'),
            'NA') AS hx_cancel_reason
    FROM b2b.shuri_final_20200915_d A
    LEFT OUTER JOIN (
    Select a.*
    from b2b.dim_hx_sd_agent a
    cross join b2b.dim_date b
    where a.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc)  sd_agent
    on sd_agent.sales_document = A.sales_document
    and sd_agent.fiscal_yr_and_wk_desc = A.fiscal_yr_and_wk_desc
    LEFT OUTER JOIN (
    Select a.*
    from b2b.dim_hx_dylan_agent a
    cross join b2b.dim_date b
    where a.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc) dylan_agent
    on dylan_agent.dylan_order_number = A.dylan_order_number
    and dylan_agent.fiscal_yr_and_wk_desc = A.fiscal_yr_and_wk_desc
    LEFT OUTER JOIN (
    Select a.*
    from b2b.dim_agent a
    cross join b2b.dim_date b
    where a.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc) hxag
    on coalesce(sd_agent.agent,dylan_agent.agent) = hxag.ldap
    and A.geo = hxag.geo
    LEFT OUTER JOIN (
        Select a.*
        from b2b.dim_cancel_reason a
        cross join b2b.dim_date b
        where a.fiscal_yr_and_qtr_desc = b.fiscal_yr_and_qtr_desc) cxl 
    on cxl.sales_document = A.sales_document  
    and cxl.fiscal_yr_and_wk_desc = A.fiscal_yr_and_wk_desc ) A """)
             spark.sql(""" Insert into Table b2b.ww_shuri_job_logs 
Select 'Hx Update' step, current_timestamp() completion_datetime """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()