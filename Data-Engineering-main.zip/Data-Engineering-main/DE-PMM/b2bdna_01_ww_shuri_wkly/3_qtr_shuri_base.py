# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" SET mapred.job.priority=VERY_HIGH """)
             spark.sql(""" set mapred.job.queue.name=root.GRP-HADOOP-GTM """)
             spark.sql(""" SET hive.exec.max.created.files=900000 """)
             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=21333334 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=21333334 """)

             spark.sql(""" drop table if exists b2b.pivot_sample """)
             spark.sql(""" create table  b2b.pivot_sample as
Select p.fiscal_yr_and_wk_desc, sum(net_new_arr_cfx) as net_new_arr_cfx
from csmb.vw_ccm_pivot4_all  p
cross join b2b.dim_date d
where 1=1
and p.event_source = 'SNAPSHOT'
and p.source_type = 'TM'
and p.date_key = d.end_date
group by p.fiscal_yr_and_wk_desc """)
             
             df_shuri_base=spark.sql(""" SELECT  
nvl(p.stype,'UNKNOWN') AS stype,
upper(p.crm_customer_guid) AS crm_customer_guid,
upper(p.sales_document) AS sales_document,
p.fiscal_yr_desc AS fiscal_yr_desc, 
upper(p.fiscal_yr_and_wk_desc) AS fiscal_yr_and_wk_desc,
p.route_to_market AS route_to_market,
p.entitlement_type AS entitlement_type,
p.entitlement_period_desc AS entitlement_period_desc,
upper(if(p.market_segment is null or p.market_segment in ('?','#',''),'UNKNOWN',p.market_segment)) AS market_segment,
if(p.sales_district is null or p.sales_district in ('?','#',''),'UNKNOWN',p.sales_district) AS sales_district,
if(p.sales_district is null or p.sales_district in ('?','#',''),'UNKNOWN',p.sales_district_description) AS sales_district_description, 
if(p.market_area is null or p.market_area in ('?','#',''),'UNKNOWN',p.market_area) AS market_area, 
if(p.market_area is null or p.market_area in ('?','#',''),'UNKNOWN',p.market_area_description) AS market_area_description, 
upper(if(nvl(p.geo,'UNKNOWN') not in ('AMER','ASIA','EMEA','JPN'),'UNKNOWN',p.geo)) AS geo,
if(nvl(p.geo,'UNKNOWN') not in ('AMER','ASIA','EMEA','JPN'),'UNKNOWN',p.geo_description) AS geo_description,
nvl(p.region,'UNKNOWN') AS region,
nvl(p.region_description,'UNKNOWN') AS region_description, 
nvl(p.promotion,'UNKNOWN') AS promotion,
upper(nvl(p.promo_type,'UNKNOWN')) AS promo_type,
nvl(p.product_config,'UNKNOWN') AS product_config,
upper(nvl(p.product_config_description,'Unknown')) AS product_config_description,
upper(nvl(p.product_name,'UNKNOWN')) AS product_name,
nvl(p.product_name_description,'Unknown') AS product_name_description,
nvl(p.prod_group_hier,'UNKNOWN') as internal_segment,
nvl(p.prod_group_hier_description,'Unknown') AS internal_segment_description,
upper(p.manual_adjust_flag) AS manual_adjust_flag,
p.adjustment_reason AS adjustment_reason,
upper(p.cc_phone_vs_web) AS cc_phone_vs_web,
'' AS paid_type,
if(p.sub_product is null or p.sub_product in ('?','#',''),'UNKNOWN',p.sub_product) AS sub_product,
nvl(p.offer_type_desc,'Unknown') AS offer_type_desc,
p.cancellation_date AS cancellation_date,
p.material_number AS material_number,
p.document_currency AS document_currency, 
--IF(upper(p.cc_phone_vs_web)='VIP-PHONE', min(p.created_date_item), min(p.source_create_date)) AS created_date,
CASE WHEN (upper(p.cc_phone_vs_web))='VIP-PHONE' THEN p.created_date_item ELSE p.source_create_date END AS created_date,
upper(p.subscription_account_guid) AS subscription_account_guid,
p.contract_start_date_veda AS contract_start_date_veda,
p.contract_end_date_veda AS contract_end_date_veda,
upper(p.vip_contract) AS vip_contract,
upper(p.dylan_order_number) as dylan_order_number,
nvl(p.payment_method,'--')  AS payment_method,
CASE
WHEN upper(p.manual_adjust_flag) = 'YES' THEN 'Manual Adjustment'
WHEN p.payment_method = '00' THEN 'VIP Non-CC (00)'
WHEN p.payment_method = '02' THEN 'Credit Card (02)'
WHEN p.payment_method = '05' THEN 'Bank Transfer (05)'
WHEN p.payment_method = '06' THEN 'Direct Debit (06)'
WHEN p.payment_method = '08' THEN 'Paypal'
WHEN p.payment_method = '09' THEN 'Purchase Order'
WHEN p.payment_method = '99' THEN 'No Instrument'
ELSE 'UNKNOWN' end payment_method_desc,
p.ecc_customer_id AS ecc_customer_id,
upper(p.created_by) AS first_created_by,
upper(nvl(p.subs_offer,'UNKNOWN')) AS subs_offer,
nvl(p.cc_segment,'UNKNOWN') AS cc_segment,
nvl(p.cc_segment_offer,'UNKNOWN') AS cc_segment_offer,
p.posa_techghvendor_description AS posa_techghvendor_description, 
p.posa_type as posa_type,
p.stock_flag AS stock_flag,
p.cc_overage_type AS stock_overage_type,
p.stock_type AS stock_type,
nvl(p.current_exchange_rate,0) AS current_exchange_rate, 
p.created_date_item,
nvl(p.fqtr_begin_active,0) AS fqtr_begin_active, 
nvl(p.fqtr_begin_active,0) + nvl(p.net_new_subs,0) AS fqtr_end_active,
nvl(p.addl_purchase_diff,0) AS addl_purchase_diff,
nvl(p.addl_purchase_same,0) AS addl_purchase_same,
nvl(p.addl_purchase_same,0) + nvl(p.addl_purchase_diff,0) AS addl_purchase,
nvl(p.compl_cancel_cc_failure,0) AS compl_cancel_cc_failure,
nvl(p.compl_cancel_explicit,0) AS compl_cancel_explicit,
nvl(p.partial_cancel_cc_failure,0) AS partial_cancel_cc_failure,
nvl(p.partial_cancel_explicit,0) AS partial_cancel_explicit,
nvl(p.gross_cancellations,0) AS gross_cancellations,
nvl(p.gross_new_subs,0) AS gross_new_subs,
nvl(p.init_purchase,0) AS init_purchase,
nvl(p.migrated_from,0) AS migrated_from,
nvl(p.migrated_subs,0) AS migrated_subs,
nvl(p.migrated_to,0) AS migrated_to,
nvl(p.net_cancelled_subs,0) AS net_cancelled_subs,
nvl(p.net_purchases,0) AS net_purchases,
nvl(p.reactivated_subs,0) AS reactivated_subs,
nvl(p.renewal_from,0) AS renewal_from,
nvl(p.renewal_to,0) AS renewal_to, 
nvl(p.resubscription,0) AS resubscription,
nvl(p.returns_explicit,0) AS returns_explicit,
nvl(p.returns_never_paid,0) AS returns_never_paid,
nvl(p.returns,0) AS returns,
nvl(p.net_new_subs,0) AS net_new_subs,
nvl(p.target_quantity,0) AS overage_qty,
nvl(p.fqtr_begin_arr_cfx,0) AS fqtr_begin_arr_cfx, 
nvl(p.fqtr_begin_arr_cfx,0) + nvl(p.net_new_arr_cfx,0) AS fqtr_end_arr_cfx,
nvl(p.gross_new_arr_cfx,0) - nvl(p.init_purchase_arr_cfx,0) AS addl_purchases_arr_cfx, 
nvl(p.cc_failure_cancel_arr_cfx,0)  AS cc_failure_cancel_arr_cfx,
nvl(p.explicit_cancel_arr_cfx,0)  AS explicit_cancel_arr_cfx,
nvl(p.partial_cancel_cc_failure_arr_cfx,0)  AS partial_cancel_cc_failure_arr_cfx, 
nvl(p.partial_cancel_explicit_arr_cfx,0)  AS partial_cancel_explicit_arr_cfx,  
nvl(p.gross_cancel_arr_cfx,0)  AS gross_cancel_arr_cfx,
nvl(p.gross_new_arr_cfx,0) AS gross_new_arr_cfx,
nvl(p.init_purchase_arr_cfx,0) AS init_purchase_arr_cfx,
nvl(p.migrated_from_arr_cfx,0) AS migrated_from_arr_cfx,
nvl(p.migrated_to_arr_cfx,0) - nvl(p.migrated_from_arr_cfx,0) AS migration_arr_cfx,
nvl(p.migrated_to_arr_cfx,0) AS migrated_to_arr_cfx,
nvl(p.net_cancelled_arr_cfx,0) AS net_cancelled_arr_cfx,
nvl(p.net_purchases_arr_cfx,0) AS net_purchases_arr_cfx,
nvl(p.reactivated_arr_cfx,0) AS reactivated_arr_cfx,
nvl(p.renewal_from_arr_cfx,0) AS renewal_from_arr_cfx, 
nvl(p.renewal_to_arr_cfx,0) AS renewal_to_arr_cfx,  
nvl(p.resubscription_arr_cfx,0) AS resubscription_arr_cfx,
nvl(p.explicit_returns_arr_cfx,0) AS explicit_returns_arr_cfx,  
nvl(p.cc_failure_returns_arr_cfx,0) AS cc_failure_returns_arr_cfx,  
nvl(p.returns_arr_cfx,0) AS returns_arr_cfx, 
nvl(p.net_new_arr_cfx,0) AS net_new_arr_cfx,
nvl(p.net_value_usd,0) AS overage_net_value_usd
FROM csmb.vw_ccm_pivot4_all  p   
WHERE upper(p.source_type) != 'F2P'
AND p.date_key >= (SELECT MAX(start_date) FROM b2b.dim_date)
AND p.date_key <= (SELECT MAX(end_date) FROM b2b.dim_date)  """)
             
             df_shuri_base.createOrReplaceTempView("df_shuri_base")

             spark.sql(""" INSERT OVERWRITE TABLE b2b.shuri_base_20200915
SELECT  
A.stype,
A.crm_customer_guid,
A.sales_document,
A.fiscal_yr_desc,
A.fiscal_yr_and_wk_desc,
A.route_to_market,
A.entitlement_type,
A.entitlement_period_desc,
A.market_segment,
A.sales_district,
A.sales_district_description,
A.market_area,
A.market_area_description,
A.geo,
A.geo_description,
A.region,
A.region_description,
A.promotion,
A.promo_type,
A.product_config,
A.product_config_description,
A.product_name,
A.product_name_description,
A.internal_segment,
A.internal_segment_description,
A.manual_adjust_flag,
A.adjustment_reason,
A.cc_phone_vs_web,
A.paid_type,
A.sub_product,
A.offer_type_desc,
A.cancellation_date,
A.material_number,
A.document_currency,
--A.created_date,
min(A.created_date) AS created_date,
A.subscription_account_guid,
A.contract_start_date_veda,
A.contract_end_date_veda,
A.vip_contract,
A.dylan_order_number,
A.payment_method,
A.payment_method_desc,
A.ecc_customer_id,
A.first_created_by,
A.subs_offer,
A.cc_segment,
A.cc_segment_offer,
A.posa_techghvendor_description,
A.posa_type,
A.stock_flag,
A.stock_overage_type,
A.stock_type,
A.current_exchange_rate, 
sum(A.fqtr_begin_active) AS fqtr_begin_active,
sum(A.fqtr_end_active) AS fqtr_end_active,
sum(A.addl_purchase_diff) AS addl_purchase_diff,
sum(A.addl_purchase_same) AS addl_purchase_same, 
sum(A.addl_purchase) AS addl_purchase,
sum(A.compl_cancel_cc_failure) AS compl_cancel_cc_failure,
sum(A.compl_cancel_explicit) AS compl_cancel_explicit,
sum(A.partial_cancel_cc_failure) AS partial_cancel_cc_failure,
sum(A.partial_cancel_explicit) AS partial_cancel_explicit,
sum(A.gross_cancellations) AS gross_cancellations,
sum(A.gross_new_subs) AS gross_new_subs,
sum(A.init_purchase) AS init_purchase,
sum(A.migrated_from) AS migrated_from,
sum(A.migrated_subs) AS migrated_subs,
sum(A.migrated_to) AS migrated_to,
sum(A.net_cancelled_subs) AS net_cancelled_subs,
sum(A.net_purchases) AS net_purchases,
sum(A.reactivated_subs) AS reactivated_subs,
sum(A.renewal_from) AS renewal_from,
sum(A.renewal_to) AS renewal_to,
sum(A.resubscription) AS resubscription,
sum(A.returns_explicit) AS returns_explicit,
sum(A.returns_never_paid) AS returns_never_paid,
sum(A.returns) AS returns,
sum(A.net_new_subs) AS net_new_subs,
sum(A.overage_qty) AS overage_qty,
sum(A.fqtr_begin_arr_cfx) AS fqtr_begin_arr_cfx,
sum(A.fqtr_end_arr_cfx) AS fqtr_end_arr_cfx,
sum(A.addl_purchases_arr_cfx) AS addl_purchases_arr_cfx,
sum(A.cc_failure_cancel_arr_cfx) AS cc_failure_cancel_arr_cfx,
sum(A.explicit_cancel_arr_cfx) AS explicit_cancel_arr_cfx,
sum(A.partial_cancel_cc_failure_arr_cfx) AS partial_cancel_cc_failure_arr_cfx,
sum(A.partial_cancel_explicit_arr_cfx) AS partial_cancel_explicit_arr_cfx,
sum(A.gross_cancel_arr_cfx) AS gross_cancel_arr_cfx,
sum(A.gross_new_arr_cfx) AS gross_new_arr_cfx,
sum(A.init_purchase_arr_cfx) AS init_purchase_arr_cfx,
sum(A.migrated_from_arr_cfx) AS migrated_from_arr_cfx,
sum(A.migration_arr_cfx) AS migration_arr_cfx,
sum(A.migrated_to_arr_cfx) AS migrated_to_arr_cfx,
sum(A.net_cancelled_arr_cfx) AS net_cancelled_arr_cfx,
sum(A.net_purchases_arr_cfx) AS net_purchases_arr_cfx,
sum(A.reactivated_arr_cfx) AS reactivated_arr_cfx,
sum(A.renewal_from_arr_cfx) AS renewal_from_arr_cfx,
sum(A.renewal_to_arr_cfx) AS renewal_to_arr_cfx,
sum(A.resubscription_arr_cfx) AS resubscription_arr_cfx,
sum(A.explicit_returns_arr_cfx) AS explicit_returns_arr_cfx,
sum(A.cc_failure_returns_arr_cfx) AS cc_failure_returns_arr_cfx,
sum(A.returns_arr_cfx) AS returns_arr_cfx,
sum(A.net_new_arr_cfx) AS net_new_arr_cfx,
sum(A.overage_net_value_usd) AS overage_net_value_usd,
current_date() as etl_date
FROM df_shuri_base A
GROUP BY stype,
crm_customer_guid,
sales_document,
fiscal_yr_desc,
fiscal_yr_and_wk_desc,
route_to_market,
entitlement_type,
entitlement_period_desc,
market_segment,
sales_district,
sales_district_description,
market_area,
market_area_description,
geo,
geo_description,
region,
region_description,
promotion,
promo_type,
product_config,
product_config_description,
product_name,
product_name_description,
internal_segment,
internal_segment_description,
manual_adjust_flag,
adjustment_reason,
cc_phone_vs_web,
paid_type,
sub_product,
offer_type_desc,
cancellation_date,
material_number,
document_currency,
created_date,
subscription_account_guid,
contract_start_date_veda,
contract_end_date_veda,
vip_contract,
dylan_order_number,
payment_method,
payment_method_desc,
ecc_customer_id,
first_created_by,
subs_offer,
cc_segment,
cc_segment_offer,
posa_techghvendor_description,
posa_type,
stock_flag,
stock_overage_type,
stock_type,
current_exchange_rate
HAVING round(sum(nvl(A.fqtr_begin_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.gross_new_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.returns_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.gross_cancel_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.reactivated_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.migrated_to_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.migrated_from_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.renewal_to_arr_cfx,0)),2)!=0.00 
OR round(sum(nvl(A.renewal_from_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.net_new_arr_cfx,0)),2)!=0.00
OR round(sum(nvl(A.overage_net_value_usd,0)),2)!=0.00
OR sum(nvl(A.fqtr_begin_active,0))!=0 
OR sum(nvl(A.gross_new_subs,0))!=0 
OR sum(nvl(A.returns,0))!=0 
OR sum(nvl(A.gross_cancellations,0))!=0 
OR sum(nvl(A.reactivated_subs,0))!=0
OR sum(nvl(A.migrated_to,0))!=0
OR sum(nvl(A.migrated_from,0))!=0
OR sum(nvl(A.renewal_to,0))!=0
OR sum(nvl(A.renewal_from,0))!=0
OR sum(nvl(A.net_new_subs,0))!=0
OR sum(nvl(A.overage_qty,0))!=0
 """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()