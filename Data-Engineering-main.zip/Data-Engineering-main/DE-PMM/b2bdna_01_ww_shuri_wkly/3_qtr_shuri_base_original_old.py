# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" SET mapred.job.priority=VERY_HIGH """)
             spark.sql(""" set mapred.job.queue.name=root.GRP-HADOOP-GTM """)
             spark.sql(""" SET hive.exec.max.created.files=900000 """)
             spark.sql(""" SET hive.exec.parallel = true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=21333334 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=21333334 """)
             spark.sql(""" drop table if exists b2b.pivot_sample """)
             spark.sql(""" create table  b2b.pivot_sample as
Select p.fiscal_yr_and_wk_desc, sum(net_new_arr_cfx) as net_new_arr_cfx
from csmb.vw_ccm_pivot4_all  p
cross join b2b.dim_date d
where 1=1
and p.event_source = 'SNAPSHOT'
and p.source_type = 'TM'
and p.date_key = d.end_date
group by p.fiscal_yr_and_wk_desc """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.shuri_base_20200915
Select
    nvl(A.stype,'UNKNOWN') AS stype,
    upper(A.crm_customer_guid) AS crm_customer_guid,
    upper(A.sales_document) AS sales_document,
    A.fiscal_yr_desc AS fiscal_yr_desc, 
    upper(A.fiscal_yr_and_wk_desc) AS fiscal_yr_and_wk_desc,
    A.route_to_market AS route_to_market,
    A.entitlement_type AS entitlement_type,
    A.entitlement_period_desc AS entitlement_period_desc,
    upper(if(A.market_segment is null or A.market_segment in ('?','#',''),'UNKNOWN',A.market_segment)) AS market_segment,
    if(A.sales_district is null or A.sales_district in ('?','#',''),'UNKNOWN',A.sales_district) AS sales_district,
    if(A.sales_district is null or A.sales_district in ('?','#',''),'UNKNOWN',A.sales_district_description) AS sales_district_description, 
    if(A.market_area is null or A.market_area in ('?','#',''),'UNKNOWN',A.market_area) AS market_area, 
    if(A.market_area is null or A.market_area in ('?','#',''),'UNKNOWN',A.market_area_description) AS market_area_description, 
    upper(if(nvl(A.geo,'UNKNOWN') not in ('AMER','ASIA','EMEA','JPN'),'UNKNOWN',A.geo)) AS geo,
    if(nvl(A.geo,'UNKNOWN') not in ('AMER','ASIA','EMEA','JPN'),'UNKNOWN',A.geo_description) AS geo_description,
    nvl(A.region,'UNKNOWN') AS region,
    nvl(A.region_description,'UNKNOWN') AS region_description, 
    nvl(A.promotion,'UNKNOWN') AS promotion,
    upper(nvl(A.promo_type,'UNKNOWN')) AS promo_type,
    nvl(A.product_config,'UNKNOWN') AS product_config,
    upper(nvl(A.product_config_description,'Unknown')) AS product_config_description,
    upper(nvl(A.product_name,'UNKNOWN')) AS product_name,
    nvl(A.product_name_description,'Unknown') AS product_name_description,
    nvl(A.prod_group_hier,'UNKNOWN') as internal_segment,
    nvl(A.prod_group_hier_description,'Unknown') as internal_segment_description,
    upper(A.manual_adjust_flag) AS manual_adjust_flag,
    A.adjustment_reason AS adjustment_reason,
    upper(A.cc_phone_vs_web) AS cc_phone_vs_web,
    '' AS paid_type,
    if(A.sub_product is null or A.sub_product in ('?','#',''),'UNKNOWN',A.sub_product) AS sub_product,
    nvl(A.offer_type_desc,'Unknown') AS offer_type_desc,
    A.cancellation_date AS cancellation_date,
    A.material_number AS material_number,
    A.document_currency AS document_currency, 
    IF(upper(A.cc_phone_vs_web)='VIP-PHONE',
        min(A.created_date_item),
        min(A.source_create_date)) AS created_date,
    upper(A.subscription_account_guid) AS subscription_account_guid,
    A.contract_start_date_veda AS contract_start_date_veda,
    A.contract_end_date_veda AS contract_end_date_veda,
    upper(A.vip_contract) AS vip_contract,
    upper(A.dylan_order_number) as dylan_order_number,
    nvl(A.payment_method,'--')  AS payment_method,
    CASE
    	WHEN upper(A.manual_adjust_flag) = 'YES' THEN 'Manual Adjustment'
    	WHEN A.payment_method = '00' THEN 'VIP Non-CC (00)'
    	WHEN A.payment_method = '02' THEN 'Credit Card (02)'
    	WHEN A.payment_method = '05' THEN 'Bank Transfer (05)'
    	WHEN A.payment_method = '06' THEN 'Direct Debit (06)'
    	WHEN A.payment_method = '08' THEN 'Paypal'
    	WHEN A.payment_method = '09' THEN 'Purchase Order'
    	WHEN A.payment_method = '99' THEN 'No Instrument'
    	ELSE 'UNKNOWN' end payment_method_desc,
    A.ecc_customer_id AS ecc_customer_id,
    upper(A.created_by) AS first_created_by,
    upper(nvl(A.subs_offer,'UNKNOWN')) AS subs_offer,
    nvl(A.cc_segment,'UNKNOWN') AS cc_segment,
    nvl(A.cc_segment_offer,'UNKNOWN') AS cc_segment_offer,
    A.posa_techghvendor_description AS posa_techghvendor_description, 
    A.posa_type as posa_type,
    A.stock_flag AS stock_flag,
    A.cc_overage_type AS stock_overage_type,
    A.stock_type AS stock_type,
    nvl(A.current_exchange_rate,0) AS current_exchange_rate, 
    sum(nvl(A.fqtr_begin_active,0)) AS fqtr_begin_active, 
    sum(nvl(A.fqtr_begin_active,0)) + sum(nvl(A.net_new_subs,0)) AS fqtr_end_active,
    sum(nvl(A.addl_purchase_diff,0)) AS addl_purchase_diff,
    sum(nvl(A.addl_purchase_same,0)) AS addl_purchase_same,
    sum(nvl(A.addl_purchase_same,0)) + sum(nvl(A.addl_purchase_diff,0)) AS addl_purchase,
    sum(nvl(A.compl_cancel_cc_failure,0)) AS compl_cancel_cc_failure,
    sum(nvl(A.compl_cancel_explicit,0)) AS compl_cancel_explicit,
    sum(nvl(A.partial_cancel_cc_failure,0)) AS partial_cancel_cc_failure,
    sum(nvl(A.partial_cancel_explicit,0)) AS partial_cancel_explicit,
    sum(nvl(A.gross_cancellations,0)) AS gross_cancellations,
    sum(nvl(A.gross_new_subs,0)) AS gross_new_subs,
    sum(nvl(A.init_purchase,0)) AS init_purchase,
    sum(nvl(A.migrated_from,0)) AS migrated_from,
    sum(nvl(A.migrated_subs,0)) AS migrated_subs,
    sum(nvl(A.migrated_to,0)) AS migrated_to,
    sum(nvl(A.net_cancelled_subs,0)) AS net_cancelled_subs,
    sum(nvl(A.net_purchases,0)) AS net_purchases,
    sum(nvl(A.reactivated_subs,0)) AS reactivated_subs,
    sum(nvl(A.renewal_from,0)) AS renewal_from,
    sum(nvl(A.renewal_to,0)) AS renewal_to, 
    sum(nvl(A.resubscription,0)) AS resubscription,
    sum(nvl(A.returns_explicit,0)) AS returns_explicit,
    sum(nvl(A.returns_never_paid,0)) AS returns_never_paid,
    sum(nvl(A.returns,0)) AS returns,
    sum(nvl(A.net_new_subs,0)) AS net_new_subs,
    sum(nvl(A.target_quantity,0)) AS overage_qty,
    sum(nvl(A.fqtr_begin_arr_cfx,0)) AS fqtr_begin_arr_cfx, 
    sum(nvl(A.fqtr_begin_arr_cfx,0)) + sum(nvl(A.net_new_arr_cfx,0)) AS fqtr_end_arr_cfx,
    sum(nvl(A.gross_new_arr_cfx,0)) - sum(nvl(A.init_purchase_arr_cfx,0)) AS addl_purchases_arr_cfx, 
    sum(nvl(A.cc_failure_cancel_arr_cfx,0))  AS cc_failure_cancel_arr_cfx,
    sum(nvl(A.explicit_cancel_arr_cfx,0))  AS explicit_cancel_arr_cfx,
    sum(nvl(A.partial_cancel_cc_failure_arr_cfx,0))  AS partial_cancel_cc_failure_arr_cfx, 
    sum(nvl(A.partial_cancel_explicit_arr_cfx,0))  AS partial_cancel_explicit_arr_cfx,  
    sum(nvl(A.gross_cancel_arr_cfx,0))  AS gross_cancel_arr_cfx,
    sum(nvl(A.gross_new_arr_cfx,0)) AS gross_new_arr_cfx,
    sum(nvl(A.init_purchase_arr_cfx,0)) AS init_purchase_arr_cfx,
    sum(nvl(A.migrated_from_arr_cfx,0)) AS migrated_from_arr_cfx,
    sum(nvl(A.migrated_to_arr_cfx,0)) - sum(nvl(A.migrated_from_arr_cfx,0)) AS migration_arr_cfx,
    sum(nvl(A.migrated_to_arr_cfx,0)) AS migrated_to_arr_cfx,
    sum(nvl(A.net_cancelled_arr_cfx,0)) AS net_cancelled_arr_cfx,
    sum(nvl(A.net_purchases_arr_cfx,0)) AS net_purchases_arr_cfx,
    sum(nvl(A.reactivated_arr_cfx,0)) AS reactivated_arr_cfx,
    sum(nvl(A.renewal_from_arr_cfx,0)) AS renewal_from_arr_cfx, 
    sum(nvl(A.renewal_to_arr_cfx,0)) AS renewal_to_arr_cfx,  
    sum(nvl(A.resubscription_arr_cfx,0)) AS resubscription_arr_cfx,
    sum(nvl(A.explicit_returns_arr_cfx,0)) AS explicit_returns_arr_cfx,  
    sum(nvl(A.cc_failure_returns_arr_cfx,0)) AS cc_failure_returns_arr_cfx,  
    sum(nvl(A.returns_arr_cfx,0)) AS returns_arr_cfx, 
    sum(nvl(A.net_new_arr_cfx,0)) AS net_new_arr_cfx,
    sum(nvl(A.net_value_usd,0)) AS overage_net_value_usd,
    current_date() as etl_date
from
( Select p.* 
from csmb.vw_ccm_pivot4_all  p   
where upper(p.source_type) != 'F2P') A
cross join b2b.dim_date b
where 1=1
and A.date_key >= b.start_date and A.date_key <= b.end_date   
GROUP BY 
    nvl(A.stype,'UNKNOWN'),
    upper(A.crm_customer_guid),
    upper(A.sales_document),
    A.fiscal_yr_desc,
    upper(A.fiscal_yr_and_wk_desc),
    A.route_to_market,
    A.entitlement_type,
    A.entitlement_period_desc,
    upper(if(A.market_segment is null or A.market_segment in ('?','#',''),'UNKNOWN',A.market_segment)),
    if(A.sales_district is null or A.sales_district in ('?','#',''),'UNKNOWN',A.sales_district),
    if(A.sales_district is null or A.sales_district in ('?','#',''),'UNKNOWN',A.sales_district_description),
    if(A.market_area is null or A.market_area in ('?','#',''),'UNKNOWN',A.market_area),
    if(A.market_area is null or A.market_area in ('?','#',''),'UNKNOWN',A.market_area_description),
    upper(if(nvl(A.geo,'UNKNOWN') not in ('AMER','ASIA','EMEA','JPN'),'UNKNOWN',A.geo)),
    if(nvl(A.geo,'UNKNOWN') not in ('AMER','ASIA','EMEA','JPN'),'UNKNOWN',A.geo_description),
    nvl(A.region,'UNKNOWN'),
    nvl(A.region_description,'UNKNOWN'),
    nvl(A.promotion,'UNKNOWN'),
    upper(nvl(A.promo_type,'UNKNOWN')),
    nvl(A.product_config,'UNKNOWN'),
    upper(nvl(A.product_config_description,'Unknown')),
    upper(nvl(A.product_name,'UNKNOWN')),
    nvl(A.product_name_description,'Unknown'),
    nvl(A.prod_group_hier,'UNKNOWN'),
    nvl(A.prod_group_hier_description,'Unknown'),
    upper(A.manual_adjust_flag),
    A.adjustment_reason,
    upper(A.cc_phone_vs_web),
    if(A.sub_product is null or A.sub_product in ('?','#',''),'UNKNOWN',A.sub_product),
    nvl(A.offer_type_desc,'Unknown'),
    A.cancellation_date,
    A.material_number,
    A.document_currency,
    upper(A.subscription_account_guid),
    A.contract_start_date_veda,
    A.contract_end_date_veda,
    upper(A.vip_contract),
    upper(A.dylan_order_number),
    nvl(A.payment_method,'--'),
    CASE
    	WHEN upper(A.manual_adjust_flag) = 'YES' THEN 'Manual Adjustment'
    	WHEN A.payment_method = '00' THEN 'VIP Non-CC (00)'
    	WHEN A.payment_method = '02' THEN 'Credit Card (02)'
    	WHEN A.payment_method = '05' THEN 'Bank Transfer (05)'
    	WHEN A.payment_method = '06' THEN 'Direct Debit (06)'
    	WHEN A.payment_method = '08' THEN 'Paypal'
    	WHEN A.payment_method = '09' THEN 'Purchase Order'
    	WHEN A.payment_method = '99' THEN 'No Instrument'
    	ELSE 'UNKNOWN' end,
    A.ecc_customer_id,
    upper(A.created_by),
    upper(nvl(A.subs_offer,'UNKNOWN')),
    nvl(A.cc_segment,'UNKNOWN'),
    nvl(A.cc_segment_offer,'UNKNOWN'),
    A.posa_techghvendor_description,
    A.posa_type,
    A.stock_flag,
    A.cc_overage_type,
    A.stock_type,
    nvl(A.current_exchange_rate,0)
having round(sum(nvl(A.fqtr_begin_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.gross_new_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.returns_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.gross_cancel_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.reactivated_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.migrated_to_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.migrated_from_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.renewal_to_arr_cfx,0)),2)!=0.00 
    or round(sum(nvl(A.renewal_from_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.net_new_arr_cfx,0)),2)!=0.00
    or round(sum(nvl(A.net_value_usd,0)),2)!=0.00
    or sum(nvl(A.fqtr_begin_active,0))!=0 
    or sum(nvl(A.gross_new_subs,0))!=0 
    or sum(nvl(A.returns,0))!=0 
    or sum(nvl(A.gross_cancellations,0))!=0 
    or sum(nvl(A.reactivated_subs,0))!=0
    or sum(nvl(A.migrated_to,0))!=0
    or sum(nvl(A.migrated_from,0))!=0
    or sum(nvl(A.renewal_to,0))!=0
    or sum(nvl(A.renewal_from,0))!=0
    or sum(nvl(A.net_new_subs,0))!=0
    or sum(nvl(A.target_quantity,0))!=0 """)
             spark.sql(""" Insert into Table b2b.ww_shuri_job_logs 
Select 'Shuri Base Update' step, current_timestamp() completion_datetime """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()