# Databricks notebook source
from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys


class main:
    def __init__(self):
        try:
            spark = (
                SparkSession.builder.enableHiveSupport()
                .config("hive.exec.dynamic.partition", "true")
                .config("hive.exec.dynamic.partition.mode", "nonstrict")
                .config("hive.exec.max.dynamic.partitions", "10000")
                .getOrCreate()
            )
            log4j = spark._jvm.org.apache.log4j
            log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
            spark.sql("SET hive.warehouse.data.skiptrash=true;")
            spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
            spark.conf.set("spark.sql.cbo.enabled", True)
            spark.conf.set("spark.sql.cbo.join reorder.enabled", True)
            spark.sql("set spark.sql.parquet.enableVectorizedReader=false")
            spark.sql("set spark.sql.sources.partitionOverwriteMode=dynamic")
            spark.sql(
                "set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false"
            )
            spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            spark.sql("set spark.sql.adaptive.enabled=false")

            dbutils.widgets.text("Custom_Settings", "")

            Settings = dbutils.widgets.get("Custom_Settings")

            Set_list = Settings.split(",")
            if len(Set_list) > 0:
                for i in Set_list:
                    if i != "":
                        print("spark.sql(+i+)")
                        spark.sql("""{i}""".format(i=i))

            spark.sql(""" Use b2b """)
            spark.sql(""" SET mapred.job.priority=VERY_HIGH """)
            spark.sql(""" set mapred.job.queue.name=root.GRP-HADOOP-GTM """)
            spark.sql(""" SET hive.exec.max.created.files=900000 """)
            spark.sql(""" SET hive.exec.parallel = true """)
            spark.sql(
                """ SET mapreduce.input.fileinputformat.split.minsize=21333334 """
            )
            spark.sql(
                """ SET mapreduce.input.fileinputformat.split.maxsize=21333334 """
            )
            spark.sql(""" set hive.exec.dynamic.partition=true """)
            spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
            spark.sql(""" set hive.support.quoted.identifiers = none """)
            spark.sql(
                """ insert overwrite table b2b.dim_seat
Select upper(subscription_account_guid) subs_guid, 
        upper(contract_id) contract_id,
	    count(distinct seat_id) as total_seats,
	    count(distinct case when seat_status='ACTIVE SEAT' then seat_id end) as total_active_seats,
	    count(distinct case when seat_status='ACTIVE SEAT' and seat_delegation_status = 'ASSIGNED' then seat_id end) as total_deployed_seats
    from ocf_analytics.dim_seat
    where contract_id is not null
    and contract_id != ''
    and subscription_account_guid is not null
    and subscription_account_guid != ''
    group by upper(subscription_account_guid), upper(contract_id) """
            )
            spark.sql(
                """ insert overwrite table b2b.dim_contract
Select contract_id,contract_created_date,enrollee_id
from (
    Select upper(trim(contract_id)) contract_id,
        trim(contract_created_date) contract_created_date,
        upper(trim(enrollee_id)) enrollee_id,
        ROW_NUMBER() OVER(PARTITION BY upper(trim(contract_id)) ORDER BY trim(contract_modified_date) DESC) as recent
    from ocf_analytics.dim_contract_jem 
    where country_code is not null) ep_row
where recent=1 """
            )
            spark.sql(
                """ insert overwrite table b2b.dim_pcd
Select  upper(lpad(vbeln,10,'0')) sales_document, 
        max(cretdate) as payment_create_date
    from replicn_ecc.zcc04
    where vbeln!=''
    and vbeln is not null
    and cretdate >= '20180601'
    group by upper(lpad(vbeln,10,'0')) """
            )
            spark.sql(
                """ insert overwrite table b2b.dim_domain1
Select user_guid,domain,recent
    from (
        Select upper(user_guid) user_guid, 
            upper(case when pers_email IS NULL then 'UNKNOWN' else split(pers_email, "@")[1] end) as domain,
            ROW_NUMBER() OVER(PARTITION BY upper(user_guid) ORDER BY row_update_dttm DESC) as recent 
        from ocf_analytics.dim_user_lvt_profile
        where pers_email like '%@%' and upper(split(pers_email, '[\@]')[1]) <> 'ADOBE.COM') ep_row
    where recent=1 """
            )
            spark.sql(
                """ insert overwrite table b2b.dim_domain2
Select user_guid,domain,recent
    from (
        Select upper(user_guid) user_guid, 
            upper(case when email IS NULL then 'UNKNOWN' else split(email, "@")[1] end) as domain,
            ROW_NUMBER() OVER(PARTITION BY upper(user_guid) ORDER BY hana_update_datetime DESC) as recent 
        from cahcsmb.userprofile_hana_hadoop 
        where email like '%@%' and upper(split(email, '[\@]')[1]) <> 'ADOBE.COM') ep_row
    where recent=1 """
            )
            spark.sql(
                """ insert overwrite table b2b.dim_partner
Select upper(lpad(sales_document,10,'0')) sales_document, 
        upper(max(reseller_purchase_order)) reseller_purchase_order
    from csmb.vw_dim_contract_partner
    where upper(reseller_purchase_order) not in ('UNKNOWN','','APPROVED','DECLINED')
    group by upper(lpad(sales_document,10,'0')) """
            )
            spark.sql(
                """ insert overwrite table b2b.dim_firm
select domain,smb_industry,employee_range,revenue_range,rownum
    FROM (
        Select upper(domain) domain,
            domestic_ultimate_core_industry as smb_industry,
            domestic_employees_range_for_msft_excel as employee_range,
            domestic_revenue_range as revenue_range,
            ROW_NUMBER() OVER(PARTITION BY upper(domain) ORDER BY domestic_revenue_range DESC) as rownum
        FROM b2b.gtm_firmographics
        where domain is not NULL
        and domain != '') distinct_guid
    where rownum=1 """
            )
            spark.sql(
                """ Insert into Table b2b.ww_shuri_job_logs 
Select 'Dim Tables Update' step, current_timestamp() completion_datetime """
            )

            try:
                dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                print("exception:", e)
        except Exception as e:
            dbutils.notebook.exit(e)


if __name__ == "__main__":
    main()