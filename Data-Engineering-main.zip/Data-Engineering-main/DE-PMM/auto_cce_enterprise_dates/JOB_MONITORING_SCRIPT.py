# Databricks notebook source
# DBTITLE 1,Table Monitoring Script
# MAGIC %python
# MAGIC from pyspark.sql.types import StringType, DateType, StructType, StructField
# MAGIC from datetime import date
# MAGIC from datetime import datetime, timedelta
# MAGIC from dateutil.relativedelta import relativedelta
# MAGIC
# MAGIC run_month=datetime.now().month
# MAGIC #run_month = date.today().strftime("%m")
# MAGIC run_year = date.today().strftime("%Y")
# MAGIC monthkey = date.today().strftime("%Y-%m")
# MAGIC month = date.today().strftime("%m")
# MAGIC
# MAGIC current_date = date.today()
# MAGIC now = date.today().strftime("%Y-%m-%d")
# MAGIC first_monday_of_month = datetime(int(run_year), int(month), 7) + timedelta(-(datetime(int(run_year), int(month), 7).weekday()))
# MAGIC if current_date == first_monday_of_month.date():
# MAGIC     run_month = run_month - 1
# MAGIC     monthkey = (current_date - relativedelta(months=1)).strftime('%Y-%m')
# MAGIC else:
# MAGIC     run_month = run_month
# MAGIC     monthkey = monthkey
# MAGIC
# MAGIC
# MAGIC monitoring_tables_df = spark.sql(
# MAGIC     """select schema_name,table_name,frequency,process,workflow_name,dbx_job,team from b2b.monitoring_tables where end_date is NULL"""
# MAGIC ).collect()
# MAGIC
# MAGIC schema = StructType(
# MAGIC     [
# MAGIC         StructField("table_name", StringType(), True),
# MAGIC         StructField("workflow_name", StringType(), True),
# MAGIC         StructField("snapshot_date", DateType(), True),
# MAGIC         StructField("frequency", StringType(), True),
# MAGIC         StructField("run_date", DateType(), True),
# MAGIC         StructField("dbx_job", StringType(), True),
# MAGIC         StructField("team", StringType(), True),
# MAGIC         StructField("schema_name", StringType(), True)
# MAGIC     ]
# MAGIC )
# MAGIC final_df = spark.createDataFrame([], schema)
# MAGIC
# MAGIC for row in monitoring_tables_df:
# MAGIC     schema_name = row["schema_name"]
# MAGIC     table_name = row["table_name"]
# MAGIC     process = row["process"]
# MAGIC     frequency = row["frequency"]
# MAGIC     workflow_name = row["workflow_name"]
# MAGIC     dbx_job = row["dbx_job"]
# MAGIC     team = row["team"]
# MAGIC     
# MAGIC     if process.lower() == "hive2" and frequency.lower() == "b2b_daily":
# MAGIC         spark.sql("""show partitions {schema_name}.{table_name}""".format(schema_name=schema_name,table_name=table_name)).createOrReplaceTempView("tmp1")
# MAGIC         spark.sql(""" select split(split(partition,"/")[0],"=")[1] as flag, split(split(partition,"/")[1],"=")[1] as as_of_date from tmp1 """).createOrReplaceTempView("tmp2")
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/flag=D/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(as_of_date) as date) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team, "{schema_name}" as schema_name from tmp2,run_date""".format(table_name=table_name, workflow_name=workflow_name,frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == "hive2" and frequency.lower() in ("b2b_saturday","b2b_sunday","friday"):
# MAGIC         spark.sql("""show partitions {schema_name}.{table_name} """.format(schema_name=schema_name,table_name=table_name)).createOrReplaceTempView("tmp1")
# MAGIC         spark.sql(""" select split(split(partition,"/")[0],"=")[1] as flag, split(split(partition,"/")[1],"=")[1] as as_of_date from tmp1 """).createOrReplaceTempView("tmp2")
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/flag=W/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(as_of_date) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from tmp2,run_date where flag ='W' """.format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == "uda_uda_finance_arr_vw_entarr":
# MAGIC         if frequency.lower() == "b2b_daily":
# MAGIC             spark.sql("""show partitions {schema_name}.{table_name} """.format(schema_name=schema_name,table_name=table_name)).createOrReplaceTempView("tmp1")
# MAGIC             spark.sql("""select split(split(partition,"/")[0],"=")[1] as snapshottype ,split(split(partition,"/")[1],"=")[1] as datedate from tmp1""").createOrReplaceTempView("tmp2")
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/SnapshotType=D/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(datedate) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team, "{schema_name}" as schema_name from tmp2,run_date where snapshottype = 'D'""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC         elif frequency.lower() == "b2b_saturday":
# MAGIC             spark.sql("""show partitions {schema_name}.{table_name} """.format(schema_name=schema_name,table_name=table_name)).createOrReplaceTempView("tmp1")
# MAGIC             spark.sql("""select split(split(partition,"/")[0],"=")[1] as snapshottype ,split(split(partition,"/")[1],"=")[1] as datedate from tmp1""").createOrReplaceTempView("tmp2")
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/SnapshotType=W/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(datedate) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from tmp2,run_date where snapshottype = 'W' """.format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC         else:
# MAGIC             spark.sql("""show partitions {schema_name}.{table_name} """.format(schema_name=schema_name,table_name=table_name)).createOrReplaceTempView("tmp1")
# MAGIC             spark.sql("""select split(split(partition,"/")[0],"=")[1] as snapshottype ,split(split(partition,"/")[1],"=")[1] as datedate from tmp1""").createOrReplaceTempView("tmp2")
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/SnapshotType=Q/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name, "{workflow_name}" as workflow_name,cast(max(datedate) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from tmp2,run_date where snapshottype = 'Q' """.format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC     if process.lower() == "cli" and workflow_name != 'DREMIO_LOAD':
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("max_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == "cli" and workflow_name == 'DREMIO_LOAD':
# MAGIC         if table_name in ('dc_acrobatstar_feature','dc_acrotraystar_create_share_conversion_status','dc_acrotraystar_create_share_home_click','dc_acrotraystar_create_share_saveas_pdf'):
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/year={run_year}/month={run_month}/monthkey={monthkey}".format(table_name=table_name, schema_name=schema_name, run_year = run_year, run_month = run_month, monthkey = monthkey))).createOrReplaceTempView("max_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC         elif table_name in ('hb_monitor_user_mapping_snapshot','a_sign_pub_agreement','a_sign_setting','a_sign_account','a_sign_pod','a_sign_agreement_event','a_sign_user'):
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("max_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name, "{workflow_name}" as workflow_name,to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date, "{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC     # # elif process.lower() == "applaunch_all":
# MAGIC     # #     license_type = ['FRL','NGL','trial','GRACE_LICENSE','subscription','perpetual']
# MAGIC     # #     for i in license_type:
# MAGIC     # #         spark.createDataFrame(
# MAGIC     # #             dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/month={run_month}/year={run_year}/license_type={i}/".format(schema_name=schema_name,table_name=table_name,run_month=run_month,run_year=run_year,i=i))).createOrReplaceTempView("max_date")
# MAGIC     # #         table_entry = spark.sql("""select "{table_name}_{i}" as table_name, to_date(to_timestamp(max(modificationTime)/1000)) as latest_rundate, "{frequency}" as frequency from max_date""".format(table_name=table_name,i=i,frequency=frequency))
# MAGIC     # #         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == "fact_user_activity":
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/month={run_month}/year={run_year}/monthkey={monthkey}".format(schema_name=schema_name,table_name=table_name,run_month=run_month,run_year=run_year,monthkey=monthkey))).createOrReplaceTempView("max_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(table_name=table_name,workflow_name=workflow_name,frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == "enterprise":
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}".format(schema_name=schema_name , table_name=table_name ))).createOrReplaceTempView("max_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date(to_timestamp(max(modificationTime)/1000)) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == 'hive' and table_name in ('ca_ent_arr_model_all','enterprise_fact_user_activity', 'serial_mau_wau_fisc_wk_end'):
# MAGIC         if table_name == "ca_ent_arr_model_all":
# MAGIC             spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("max_date")
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}/snapshot_type=W/".format(schema_name=schema_name , table_name=table_name ))).createOrReplaceTempView("run_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(split(partition,"/")[1],"=")[1])) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC         elif table_name == "enterprise_fact_user_activity":
# MAGIC             spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("max_date")
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}".format(schema_name=schema_name , table_name=table_name ))).createOrReplaceTempView("run_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(split(partition,"/")[1],"=")[1])) as snapshot_date, "{frequency}" as frequency,to_date(max(split(split(partition,"/")[1],"=")[1])) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC         elif table_name == "serial_mau_wau_fisc_wk_end":
# MAGIC             spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("max_date")
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(split(partition,"/")[0],"=")[1])) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == 'hive' and table_name in ('service_enabled','fact_snapshot_stock_purchased_allocated_consumed','fact_product_versions','stg_qad','sign_all_users_de_duped_snapshot'):
# MAGIC         if table_name in ('service_enabled','fact_product_versions','stg_qad','sign_all_users_de_duped_snapshot'):
# MAGIC             spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("max_date")
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date((select max(split(partition,"=")[1]) as as_of_date from max_date where split(partition,"=")[1]  NOT IN  (select max(split(partition,"=")[1]) from max_date))) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC         elif table_name == 'fact_snapshot_stock_purchased_allocated_consumed':
# MAGIC             spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("max_date")
# MAGIC             spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC             table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date((select max(split(partition,"=")[1]) as as_of_date from max_date where split(partition,"=")[1]  NOT IN  (select max(split(partition,"=")[1]) from max_date))) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC             final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == 'hive' and table_name in ('sign_uda_accounts','vw_td_ddomeaccountmastereccsnapshot','uda_vw_tf_adobesignconsolidatedarr'):
# MAGIC         spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("tmp1")
# MAGIC         spark.sql(""" select concat(substr(split(partition,'=')[1],1,4),'-',substr(split(partition,'=')[1],5,2),'-',substr(split(partition,'=')[1],7,2)) as as_of_date from tmp1 """).createOrReplaceTempView("tmp2")
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name,cast(max(as_of_date) as date) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from tmp2,run_date """.format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == 'hive' and table_name in ('uda_vw_tf_adobesignmigrationconsolidated'):
# MAGIC         spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("tmp1")
# MAGIC         spark.sql(""" select concat(substr(split(partition,'=')[1],1,4),'-',substr(split(partition,'=')[1],5,2),'-',substr(split(partition,'=')[1],7,2)) as as_of_date from tmp1 """).createOrReplaceTempView("tmp2")
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date((select max(as_of_date) from tmp2 where as_of_date not in (select max(as_of_date) from tmp2))) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from run_date """.format(table_name=table_name, workflow_name=workflow_name,frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == 'hive' and frequency.lower() == "b2b_daily" and table_name in ('uda_replicn_sf_corp_uda_vw_apttusproposalproposallineitem','uda_uda_sales_dbo_vw_td_sellableproduct'):
# MAGIC         spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("tmp1")
# MAGIC         spark.sql(""" select split(split(partition,"/")[0],"=")[1] as flag, split(split(partition,"/")[1],"=")[1] as as_of_date from tmp1 """).createOrReplaceTempView("tmp2")
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name, to_date((select max(as_of_date) from tmp2 where as_of_date not in (select max(as_of_date) from tmp2))) as snapshot_date, "{frequency}" as frequency,to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from run_date """.format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == 'hive' and frequency.lower() == 'enterprise':
# MAGIC         spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("max_date")
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@ariaprime.dfs.core.windows.net/user/hive/warehouse/ddome/{schema_name}.db/{table_name}/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(partition,"=")[1])) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC     elif process.lower() == 'hive':
# MAGIC         spark.sql("""show partitions {schema_name}.{table_name}""".format(table_name=table_name, schema_name=schema_name)).createOrReplaceTempView("max_date")
# MAGIC         spark.createDataFrame(dbutils.fs.ls("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/{schema_name}.db/{table_name}/".format(table_name=table_name, schema_name=schema_name))).createOrReplaceTempView("run_date")
# MAGIC         table_entry = spark.sql("""select "{table_name}" as table_name,"{workflow_name}" as workflow_name,to_date(max(split(partition,"=")[1])) as snapshot_date, "{frequency}" as frequency, to_date(to_timestamp(max(modificationTime)/1000)) as run_date,"{dbx_job}" as dbx_job,"{team}" as team,"{schema_name}" as schema_name from max_date,run_date group by 1""".format(table_name=table_name,workflow_name=workflow_name, frequency=frequency,dbx_job=dbx_job,team=team,schema_name=schema_name))
# MAGIC         final_df = final_df.union(table_entry)
# MAGIC         
# MAGIC         
# MAGIC final_df.write.mode("overwrite").saveAsTable("b2b.tabledetails_dbx")

# COMMAND ----------

table_metrics_df = spark.sql(" select * from b2b.jobdetails_dbx a left join b2b.tabledetails_dbx b on a.run_name = b.dbx_job union all select b.start_time,b.end_time,b.run_name,b.run_duration_minutes,a.table_name,a.workflow_name,a.snapshot_date,a.frequency,a.run_date,a.dbx_job,a.team,a.schema_name from b2b.tabledetails_dbx a left join b2b.jobdetails_dbx b on b.run_name = a.dbx_job where a.frequency in ('LOOKUPS','ENTERPRISE') ")
table_metrics_df.write.mode("overwrite").saveAsTable("b2b.table_stats")
