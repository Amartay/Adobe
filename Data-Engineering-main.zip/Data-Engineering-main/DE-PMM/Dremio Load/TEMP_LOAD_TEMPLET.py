# Databricks notebook source
import pyarrow
from pyarrow import flight
import pandas
from pyspark.sql.functions import col

host = '10.51.7.145'
port = '32010'
uid = 'cceuser'
pat = 'PMbbl0+/S2qigDQ388IcfE0FMT5Pu9RRsywLJdAMBxbkFhdx6TXFejyvvYORUA=='

print("uid")
#Connect
client = flight.FlightClient('grpc+tcp://' + host + ':' + port)
print("client")
#Authenticate
bearer_token = client.authenticate_basic_token(uid, pat)
print("bearer_token")
options = flight.FlightCallOptions(headers=[bearer_token])
print("options")

sql1="""DROP TABLE IF EXISTS azr6665prddpaasb2bdna."user".hive.warehouse.b2bdna."b2b_stg.db".a_sign_pod_stg_test"""
info = client.get_flight_info(flight.FlightDescriptor.for_command(sql1),options)
reader = client.do_get(info.endpoints[0].ticket, options)
print("Table is deleted")
#Query
sql= """
CREATE table azr6665prddpaasb2bdna."user".hive.warehouse.b2bdna."b2b_stg.db".a_sign_pod_stg_test AS SELECT * FROM sign."a_sign.pod" """
info = client.get_flight_info(flight.FlightDescriptor.for_command(sql),options)

reader = client.do_get(info.endpoints[0].ticket, options)

df = reader.read_all()#added on July 03
print("Table is created")


# COMMAND ----------

client.close()

# COMMAND ----------

from pyspark.sql.functions import col
import time
import os

#time.sleep(360) #Commented on July 3


df = spark.read.parquet("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/a_sign_pod_stg_test")
print("Record count - ",df.count())

df.write.format('parquet').mode('overwrite').saveAsTable("b2b_stg.a_sign_pod_stg_test2")

#df = spark.read.parquet(dir)
print("Record count - ",df.count())
#spark.sql("refresh table b2b_stg.fact_serial_sku_txt_stg")
#dbutils.notebook.exit("SUCCESS")

# COMMAND ----------

print (df)

# COMMAND ----------

from pyspark.sql import functions as F

sorted_df = df.orderBy(F.desc("pod_id")).limit(10)
sorted_df.show()


# COMMAND ----------

# MAGIC %sql
# MAGIC refresh table b2b_stg.a_sign_pod_stg2;
# MAGIC select count(*) from b2b_stg.a_sign_pod_stg2;

# COMMAND ----------

# MAGIC %sql
# MAGIC show create table b2b_stg.fact_serial_sku_txt_stg2

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from  b2b_stg.fact_serial_sku_txt_stg2
# MAGIC union all
# MAGIC select count(*) from  b2b.fact_serial_sku_txt 
# MAGIC  

# COMMAND ----------

-CREATE TABLE b2b_stg.a_sign_pod (
  pod_id STRING,
  name STRING,
  cobrand_id STRING,
  modified STRING,
  account_id STRING,
  created STRING,
  status STRING,
  extract_dts STRING,
  load_dts STRING,
  shard STRING)
USING parquet
LOCATION 'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/a_sign_pod'
TBLPROPERTIES (
  'bucketing_version' = '2')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from b2b_stg.a_sign_pod where pod_id='70000000053673415'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select count(*),'a_sign_agreement_event' as SRC from b2b_stg.a_sign_agreement_event