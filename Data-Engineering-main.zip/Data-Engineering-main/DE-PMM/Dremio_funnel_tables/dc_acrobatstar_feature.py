# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

# MAGIC %python
# MAGIC import datetime
# MAGIC from dateutil.relativedelta import relativedelta
# MAGIC
# MAGIC mon_date_1 = RUN_DATE.replace(day=1)
# MAGIC mon_date_2 = mon_date_1 - relativedelta(months=1)
# MAGIC mon_date_3 = mon_date_1 - relativedelta(months=2)
# MAGIC mon_date_4 = mon_date_1 - relativedelta(months=3)
# MAGIC mon_date_5 = mon_date_1 - relativedelta(months=4)
# MAGIC
# MAGIC lst=[mon_date_1,mon_date_2,mon_date_3,mon_date_4,mon_date_5]
# MAGIC y_val=set()
# MAGIC m_val=set()
# MAGIC ym_val=set()
# MAGIC
# MAGIC for i in lst:
# MAGIC     year_val=str(i.year)
# MAGIC     y_val.add(year_val)
# MAGIC
# MAGIC     month_val=str(i.month)
# MAGIC     m_val.add(month_val)
# MAGIC
# MAGIC     yearmonth_val=str(i)[:7]
# MAGIC     ym_val.add(yearmonth_val)
# MAGIC
# MAGIC if len(y_val) == 1:
# MAGIC     y_val = "('"+ str(tuple(y_val)[0])+ "')"
# MAGIC else:
# MAGIC     y_val = tuple(y_val)  
# MAGIC m_val = tuple(m_val)
# MAGIC ym_val = tuple(ym_val)
# MAGIC
# MAGIC print(y_val)
# MAGIC print(m_val)
# MAGIC print(ym_val)

# COMMAND ----------

import datetime,time
from dateutil.relativedelta import relativedelta

FROM_DATE = RUN_DATE - relativedelta(days=27)
TO_DATE = RUN_DATE
print(FROM_DATE)
print(TO_DATE)

# COMMAND ----------

import pyarrow
from pyarrow import flight
import pandas
from pyspark.sql.functions import col

host = '10.51.7.145'
port = '32010'
# uid = 'cceuser'
#pat = 'PMbbl0+/S2qigDQ388IcfE0FMT5Pu9RRsywLJdAMBxbkFhdx6TXFejyvvYORUA=='
# pat = 'ybzZsSfrSUuMbcOuegdCfYc6kt33ucPXNP31aKY4hVNTa3Ae33g7kEjaC3wCBw=='

uid = 'lat57607'
pat = 'wcWsuQisS9ykYxNvDT7ID0Y2v4akI9gBpLg5E4FBGybO7erS7iHPTg5/Qo/0DA=='

print("uid")
#Connect
client = flight.FlightClient('grpc+tcp://' + host + ':' + port)
print("client")
#Authenticate
bearer_token = client.authenticate_basic_token(uid, pat)
print("bearer_token")
options = flight.FlightCallOptions(headers=[bearer_token])
print("options")

sql1="""DROP TABLE IF EXISTS azr6665prddpaasb2bdna."user".hive.warehouse.b2bdna."b2b_stg.db"."dc_acrobatstar_feature_stg" """
info = client.get_flight_info(flight.FlightDescriptor.for_command(sql1),options)
reader = client.do_get(info.endpoints[0].ticket, options)
print("Deleted the stg table")
#Query
sql = """create table azr6665prddpaasb2bdna."user".hive.warehouse.b2bdna."b2b_stg.db"."dc_acrobatstar_feature_stg" as select distinct pguid,featuretime,category,subcategory,featurename,"year","month",monthkey from "hive-prod"."dc_acrobatstar"."feature" WHERE substr(featuretime,1,10) BETWEEN '{FROM_DATE}' AND '{TO_DATE}' and "year" IN {y_val} and "month" in {m_val} and monthkey in {ym_val} """.format(FROM_DATE = FROM_DATE, TO_DATE = TO_DATE, y_val = y_val, m_val = m_val, ym_val = ym_val)

info = client.get_flight_info(flight.FlightDescriptor.for_command(sql),options)

reader = client.do_get(info.endpoints[0].ticket, options)
df = reader.read_all()
print("Created the stg table")
client.close()

# COMMAND ----------

from pyspark.sql.functions import col
import time
from datetime import date
from datetime import datetime, timedelta

spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.shuffle.partitions","auto")
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.parquet.enableVectorizedReader", True)
spark.conf.set("spark.databricks.sql.files.prorateMaxPartitionBytes.enabled",False)


spark.sql("refresh table b2b_stg.dc_acrobatstar_feature_stg")
spark.sql("MERGE INTO b2b_stg.dc_acrobatstar_feature a  USING b2b_stg.dc_acrobatstar_feature_stg b ON a.pguid = b.pguid and a.featuretime = b.featuretime and a.category = b.category and a.subcategory = b.subcategory and a.featurename = b.featurename and a.`year` = b.`year` and a.`month` = b.`month` and a.monthkey = b.monthkey WHEN NOT MATCHED THEN INSERT * ")
print("Loaded the final table")
dbutils.notebook.exit("SUCCESS")