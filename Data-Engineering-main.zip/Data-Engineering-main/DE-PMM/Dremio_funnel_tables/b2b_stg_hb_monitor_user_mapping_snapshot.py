# Databricks notebook source
import pyarrow
from pyarrow import flight
import pandas
from pyspark.sql.functions import col

host = '10.51.7.145'
port = '32010'
uid = 'cceuser'
pat = 'ybzZsSfrSUuMbcOuegdCfYc6kt33ucPXNP31aKY4hVNTa3Ae33g7kEjaC3wCBw=='

print("uid")
#Connect
client = flight.FlightClient('grpc+tcp://' + host + ':' + port)
print("client")
#Authenticate
bearer_token = client.authenticate_basic_token(uid, pat)
print("bearer_token")
options = flight.FlightCallOptions(headers=[bearer_token])
print("options")

sql1="""DROP TABLE IF EXISTS azr6665prddpaasb2bdna."user".hive.warehouse.b2bdna."b2b_stg.db"."hb_monitor_user_mapping_snapshot_stg" """
info = client.get_flight_info(flight.FlightDescriptor.for_command(sql1),options)
reader = client.do_get(info.endpoints[0].ticket, options)
print("Stg table is deleted")
#Query
sql= """
create table azr6665prddpaasb2bdna."user".hive.warehouse.b2bdna."b2b_stg.db"."hb_monitor_user_mapping_snapshot_stg" as
select DISTINCT
member_guid,
pguid 
from "hive-prod"."hb_monitor"."user_mapping_snapshot"
"""
info = client.get_flight_info(flight.FlightDescriptor.for_command(sql),options)

reader = client.do_get(info.endpoints[0].ticket, options)
df = reader.read_all()
print("Stg table is created")
client.close()

# COMMAND ----------

import time
time.sleep(360)
spark.sql("refresh table b2b_stg.hb_monitor_user_mapping_snapshot_stg")
table_df = spark.sql("""insert overwrite table b2b_stg.hb_monitor_user_mapping_snapshot select * from b2b_stg.hb_monitor_user_mapping_snapshot_stg""")
print("Final table load completed")
dbutils.notebook.exit("SUCCESS")

# COMMAND ----------

# from pyspark.sql.functions import col
# import time
# dir = "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/hb_monitor_user_mapping_snapshot_stg"
# try:
#     dbutils.fs.ls(dir)
#     time.sleep(360)
#     df = spark.read.parquet("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/hb_monitor_user_mapping_snapshot_stg")
#     print("Record count - ",df.count())
#     df.write.format('parquet').mode('overwrite').insertInto("b2b_stg.hb_monitor_user_mapping_snapshot")
#     print("Final table load completed")
#     dbutils.notebook.exit("SUCCESS")
# except Exception as e:
#     if 'java.io.FileNotFoundException' in str(e):
#         print("Source path does not exist")
#         dbutils.notebook.exit("Source table Path doesnt exist")
#     else:
#         raise