# Databricks notebook source
# MAGIC %fs
# MAGIC ls 'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched'

# COMMAND ----------

# MAGIC %fs
# MAGIC rm 'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv'

# COMMAND ----------

# Assuming the file is uploaded to the path /FileStore/your_file_name.csv.gz
file_path = "file:/enriched_accounts_qfm_june_06082023.csv.gz"

# Read the CSV.gz file into a DataFrame
df = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(file_path)


# COMMAND ----------

import gzip

spark.read.format('CSV').load('abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_june_06082023.csv.gz')
with gzip.open('abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_june_06082023.csv.gz','r') as fin:
    for line in fin:
        print(line)

# COMMAND ----------

# MAGIC %sql
# MAGIC LOAD DATA LOCAL INPATH 'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv.gz' OVERWRITE INTO TABLE b2b_tmp.lattice_export_qfm_enriched;

# COMMAND ----------

# MAGIC %sql
# MAGIC refresh table b2b_stg.lattice_export_qfm_enriched;
# MAGIC select * from b2b_stg.lattice_export_qfm_enriched;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists b2b_stg.lattice_export_qfm_enriched;
# MAGIC CREATE EXTERNAL TABLE b2b_stg.lattice_export_qfm_enriched(	
# MAGIC   address_1 string COMMENT 'from deserializer', 	
# MAGIC   address_2 string COMMENT 'from deserializer', 	
# MAGIC   firmographics_city string COMMENT 'from deserializer', 	
# MAGIC   company_description string COMMENT 'from deserializer', 	
# MAGIC   company_name string COMMENT 'from deserializer', 	
# MAGIC   country_region string COMMENT 'from deserializer', 	
# MAGIC   d_u_n_s_number string COMMENT 'from deserializer', 	
# MAGIC   domain string COMMENT 'from deserializer', 	
# MAGIC   domestic_employees_range string COMMENT 'from deserializer', 	
# MAGIC   domestic_employees_range_for_msft_excel string COMMENT 'from deserializer', 	
# MAGIC   domestic_sales_usd string COMMENT 'from deserializer', 	
# MAGIC   domestic_ultimate_city string COMMENT 'from deserializer', 	
# MAGIC   domestic_ultimate_core_industry string COMMENT 'from deserializer', 	
# MAGIC   domestic_ultimate_uk_sic_description string COMMENT 'from deserializer', 	
# MAGIC   global_employees_range string COMMENT 'from deserializer', 	
# MAGIC   global_sales_usd string COMMENT 'from deserializer', 	
# MAGIC   global_ultimate_address_1 string COMMENT 'from deserializer', 	
# MAGIC   global_ultimate_city string COMMENT 'from deserializer', 	
# MAGIC   global_ultimate_company_name string COMMENT 'from deserializer', 	
# MAGIC   global_ultimate_d_u_n_s_number string COMMENT 'from deserializer', 	
# MAGIC   is_primary_domain string COMMENT 'from deserializer', 	
# MAGIC   is_public_domain string COMMENT 'from deserializer', 	
# MAGIC   is_subsidiary string COMMENT 'from deserializer', 	
# MAGIC   naics_code string COMMENT 'from deserializer', 	
# MAGIC   naics_description string COMMENT 'from deserializer', 	
# MAGIC   postal_code string COMMENT 'from deserializer', 	
# MAGIC   state_province string COMMENT 'from deserializer', 	
# MAGIC   state_province_abbreviation string COMMENT 'from deserializer', 	
# MAGIC   telephone_number string COMMENT 'from deserializer', 	
# MAGIC   uk_sic_description string COMMENT 'from deserializer', 	
# MAGIC   account_id string COMMENT 'from deserializer', 	
# MAGIC   country_code string COMMENT 'from deserializer', 	
# MAGIC   website string COMMENT 'from deserializer', 	
# MAGIC   3d_animation string COMMENT 'from deserializer', 	
# MAGIC   3d_animation_software string COMMENT 'from deserializer', 	
# MAGIC   3d_cad string COMMENT 'from deserializer', 	
# MAGIC   3d_design_engineering string COMMENT 'from deserializer', 	
# MAGIC   3d_printing string COMMENT 'from deserializer', 	
# MAGIC   3dcart string COMMENT 'from deserializer', 	
# MAGIC   3ds_max string COMMENT 'from deserializer', 	
# MAGIC   autocad string COMMENT 'from deserializer', 	
# MAGIC   chaos_group_vray string COMMENT 'from deserializer', 	
# MAGIC   digital_signature_technology string COMMENT 'from deserializer', 	
# MAGIC   document_control string COMMENT 'from deserializer', 	
# MAGIC   e_signature_software string COMMENT 'from deserializer', 	
# MAGIC   unreal_engine string COMMENT 'from deserializer', 	
# MAGIC   video_editing_software string COMMENT 'from deserializer', 	
# MAGIC   website_design string COMMENT 'from deserializer')	
# MAGIC ROW FORMAT SERDE 	
# MAGIC   'org.apache.hadoop.hive.serde2.OpenCSVSerde' 	
# MAGIC WITH SERDEPROPERTIES ( 	
# MAGIC   'escapeChar'='\\', 	
# MAGIC   'quoteChar'='\"', 	
# MAGIC   'separatorChar'=',') 	
# MAGIC STORED AS INPUTFORMAT 	
# MAGIC   'org.apache.hadoop.mapred.TextInputFormat' 	
# MAGIC OUTPUTFORMAT 	
# MAGIC   'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'	
# MAGIC LOCATION	
# MAGIC   'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched'	
# MAGIC TBLPROPERTIES (	
# MAGIC   'skip.header.line.count'='1');

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists b2b_tmp.lattice_export_qfm_enriched;
# MAGIC CREATE EXTERNAL TABLE b2b_tmp.lattice_export_qfm_enriched(	
# MAGIC   address_1 string COMMENT 'from deserializer', 	
# MAGIC   address_2 string COMMENT 'from deserializer', 	
# MAGIC   firmographics_city string COMMENT 'from deserializer', 	
# MAGIC   company_description string COMMENT 'from deserializer', 	
# MAGIC   company_name string COMMENT 'from deserializer', 	
# MAGIC   country_region string COMMENT 'from deserializer', 	
# MAGIC   d_u_n_s_number string COMMENT 'from deserializer', 	
# MAGIC   domain string COMMENT 'from deserializer', 	
# MAGIC   domestic_employees_range string COMMENT 'from deserializer', 	
# MAGIC   domestic_employees_range_for_msft_excel string COMMENT 'from deserializer', 	
# MAGIC   domestic_sales_usd string COMMENT 'from deserializer', 	
# MAGIC   domestic_ultimate_city string COMMENT 'from deserializer', 	
# MAGIC   domestic_ultimate_core_industry string COMMENT 'from deserializer', 	
# MAGIC   domestic_ultimate_uk_sic_description string COMMENT 'from deserializer', 	
# MAGIC   global_employees_range string COMMENT 'from deserializer', 	
# MAGIC   global_sales_usd string COMMENT 'from deserializer', 	
# MAGIC   global_ultimate_address_1 string COMMENT 'from deserializer', 	
# MAGIC   global_ultimate_city string COMMENT 'from deserializer', 	
# MAGIC   global_ultimate_company_name string COMMENT 'from deserializer', 	
# MAGIC   global_ultimate_d_u_n_s_number string COMMENT 'from deserializer', 	
# MAGIC   is_primary_domain string COMMENT 'from deserializer', 	
# MAGIC   is_public_domain string COMMENT 'from deserializer', 	
# MAGIC   is_subsidiary string COMMENT 'from deserializer', 	
# MAGIC   naics_code string COMMENT 'from deserializer', 	
# MAGIC   naics_description string COMMENT 'from deserializer', 	
# MAGIC   postal_code string COMMENT 'from deserializer', 	
# MAGIC   state_province string COMMENT 'from deserializer', 	
# MAGIC   state_province_abbreviation string COMMENT 'from deserializer', 	
# MAGIC   telephone_number string COMMENT 'from deserializer', 	
# MAGIC   uk_sic_description string COMMENT 'from deserializer', 	
# MAGIC   account_id string COMMENT 'from deserializer', 	
# MAGIC   country_code string COMMENT 'from deserializer', 	
# MAGIC   website string COMMENT 'from deserializer', 	
# MAGIC   3d_animation string COMMENT 'from deserializer', 	
# MAGIC   3d_animation_software string COMMENT 'from deserializer', 	
# MAGIC   3d_cad string COMMENT 'from deserializer', 	
# MAGIC   3d_design_engineering string COMMENT 'from deserializer', 	
# MAGIC   3d_printing string COMMENT 'from deserializer', 	
# MAGIC   3dcart string COMMENT 'from deserializer', 	
# MAGIC   3ds_max string COMMENT 'from deserializer', 	
# MAGIC   autocad string COMMENT 'from deserializer', 	
# MAGIC   chaos_group_vray string COMMENT 'from deserializer', 	
# MAGIC   digital_signature_technology string COMMENT 'from deserializer', 	
# MAGIC   document_control string COMMENT 'from deserializer', 	
# MAGIC   e_signature_software string COMMENT 'from deserializer', 	
# MAGIC   unreal_engine string COMMENT 'from deserializer', 	
# MAGIC   video_editing_software string COMMENT 'from deserializer', 	
# MAGIC   website_design string COMMENT 'from deserializer')	
# MAGIC ROW FORMAT SERDE 	
# MAGIC   'org.apache.hadoop.hive.serde2.OpenCSVSerde' 	
# MAGIC WITH SERDEPROPERTIES ( 	
# MAGIC   'escapeChar'='\\', 	
# MAGIC   'quoteChar'='\"', 	
# MAGIC   'separatorChar'=',') 	
# MAGIC STORED AS INPUTFORMAT 	
# MAGIC   'org.apache.hadoop.mapred.TextInputFormat' 	
# MAGIC OUTPUTFORMAT 	
# MAGIC   'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'	
# MAGIC LOCATION	
# MAGIC   'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_tmp.db/lattice_export_qfm_enriched'	
# MAGIC TBLPROPERTIES (	
# MAGIC   'skip.header.line.count'='1');

# COMMAND ----------

df = spark.read.csv("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv",header=False)

df.show(5)

# COMMAND ----------

filename_end = 'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv'
schema = 'address_1 string, address_2 string, firmographics_city string, company_description string, company_name string, country_region string, d_u_n_s_number string, domain string, domestic_employees_range string, domestic_employees_range_for_msft_excel string, domestic_sales_usd string, domestic_ultimate_city string, domestic_ultimate_core_industry string, domestic_ultimate_uk_sic_description string, global_employees_range string, global_sales_usd string, global_ultimate_address_1 string, global_ultimate_city string, global_ultimate_company_name string, global_ultimate_d_u_n_s_number string, is_primary_domain string, is_public_domain string, is_subsidiary string, naics_code string, naics_description string, postal_code string, state_province string, state_province_abbreviation string, telephone_number string, uk_sic_description string, account_id string, country_code string, website string, 3d_animation string, 3d_animation_software string, 3d_cad string, 3d_design_engineering string, 3d_printing string, 3dcart string, 3ds_max string, autocad string, chaos_group_vray string, digital_signature_technology string, document_control string, e_signature_software string, unreal_engine string, video_editing_software string, website_design string'

df_end = spark.read.csv(path=filename_end, schema=schema, header=True)
df_end.show()

# COMMAND ----------

import os

os.system("gunzip file:/enriched_accounts_qfm_june_06082023.csv.gz")

# COMMAND ----------

dbutils.fs.ls("file:/")

# COMMAND ----------

dbutils.fs.ls("dbfs:/FileStore/shared_uploads/lat17440@adobe.com/")

# COMMAND ----------

dbutils.fs.ls("dbfs:/FileStore/shared_uploads/lat17440@adobe.com/enriched_accounts_qfm_june_06082023.csv")

# COMMAND ----------

dbutils.fs.cp("dbfs:/FileStore/shared_uploads/lat17440@adobe.com/enriched_accounts_qfm_june_06082023.csv",'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv')

# COMMAND ----------

# MAGIC %fs
# MAGIC ls 'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv'

# COMMAND ----------

df = spark.read.csv("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv")

df.display(5)

# COMMAND ----------

from subprocess import check_output
print(check_output(["ls", "file:/"]).decode("utf8"))

# COMMAND ----------

import pandas as pd

df = pd.read_csv("abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv.gz", compression='gzip', header=None, sep=' ', quotechar='"')
df.head()

# COMMAND ----------

import io
import gzip

def zip_extract(x):
    """Extract *.gz file in memory for Spark"""
    file_obj = gzip.GzipFile(fileobj=io.BytesIO(x[1]), mode="r")
    return file_obj.read()

zip_data = sc.binaryFiles('abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv.gz')
results = zip_data.map(zip_extract) \
                  .flatMap(lambda zip_file: zip_file.split("\n")) \
                  .map(lambda line: parse_line(line)) \
                  .collect()

# COMMAND ----------

dbutils.fs.cp('abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_july_07282023.csv.gz', "file:/enriched_accounts_qfm_june_06082023.csv.gz")

# COMMAND ----------

dbutils.fs.ls("file:/enriched_accounts_qfm_june_06082023.csv.gz")

# COMMAND ----------



df = spark.read.csv('abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/lattice_export_qfm_enriched/enriched_accounts_qfm_june_06082023.csv.gz')
df.show(5)

# COMMAND ----------

from pyspark.sql import SparkSession

# Set AWS access key and secret access key
access_key = 'AKIAYR65XI26LSGNTF5I'
secret_key = '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'

# Set S3 bucket and file path
bucket_name = 'latticeengines-prod-customers'
s3_path = 's3://' + bucket_name + '/dropfolder/mdljlgsw/Export/Account/Latest Account Enrichment/enriched_accounts.csv.gz'

# Configure Spark session with AWS credentials
spark = SparkSession.builder \
    .appName("S3 to databricks Transfer") \
    .config("spark.hadoop.fs.s3a.access.key", access_key) \
    .config("spark.hadoop.fs.s3a.secret.key", secret_key) \
    .getOrCreate()

print("sc created")

# Read data from Databricks
df = spark.read.csv(s3_path, header=True)
print("df created")
df.show(5)

# Write data to S3
#df.write.csv(s3_path, header=True, mode='overwrite')

# COMMAND ----------

import boto3

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("S3 to databricks Transfer") \
    .getOrCreate()

#df = spark.read.csv("dbfs:/path/to/databricks/file.csv")


access_key = 'AKIAYR65XI26LSGNTF5I'
secret_key = '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'
bucket_name = 'latticeengines-prod-customers'
s3_path = 's3://' + bucket_name + '/dropfolder/mdljlgsw/Export/Account/Latest Account Enrichment/enriched_accounts.csv.gz'

# Configure Boto3 with AWS credentials
session = boto3.Session(aws_access_key_id=access_key, aws_secret_access_key=secret_key)
s3_client = session.client('s3')
print("sc created")
# Convert DataFrame to Pandas DataFrame and write to S3
#df.toPandas().to_csv('/tmp/temp_file.csv', index=False)
s3_client.download_file(bucket_name, 'enriched_accounts.csv.gz' , 'mdljlgsw/Export/Account/Latest Account Enrichment/enriched_accounts.csv.gz')
print("df created")

# COMMAND ----------

AWS_SECRET_ACCESS_KEY=dbutils.secrets.get(scope="DBX-B2BDNA-APPLICATION", key="awssecret")
AWS_ACCESS_KEY_ID=dbutils.secrets.get(scope="DBX-B2BDNA-APPLICATION", key="awsaccess")

aws_bucket_name = "latticeengines-prod-customers"

df = spark.read.load(f"s3a://{aws_bucket_name}/")
display(df)
#dbutils.fs.ls(f"s3a://{aws_bucket_name}/")

# COMMAND ----------

import urllib

ACCESS_KEY = 'AKIAYR65XI26LSGNTF5I'
SECRET_KEY = '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'
# MOUNT_NAME = '/mnt/
AWS_S3_BUCKET = 'latticeengines-prod-customers'
MOUNT_NAME = '/mnt/mount_workfront_test_s3'
ENCODED_SECRET_KEY = urllib.parse.quote(string = SECRET_KEY, safe="")

SOURCE_URL = "s3a://%s:%s@%s" %(ACCESS_KEY, ENCODED_SECRET_KEY, AWS_S3_BUCKET)

dbutils.fs.mount(SOURCE_URL, MOUNT_NAME)

# COMMAND ----------

file_path = "/mnt/mount_workfront_test_s3/dropfolder/mdljlgsw/Export/Account/Latest Account Enrichment/enriched_accounts.csv.gz"

df = spark.read.format("csv").option("header", "true").option("inferSchema", "true").option("compression", "gzip").load(file_path)

df.show()

#df.write.mode("overwrite").saveAsTable("test.workfront_campaign_3107")


# COMMAND ----------

import boto3
from io import BytesIO

aws_access_key_id = 'AKIAYR65XI26LSGNTF5I'
aws_secret_access_key = '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'

s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)
bucket_name = 'latticeengines-prod-customers'
file_key = 'dropfolder/mdljlgsw/Export/Account/Latest Account Enrichment/enriched_accounts.csv.gz'

response = s3.get_object(Bucket=bucket_name, Key=file_key)
file_content = response['Body'].read()

df = spark.read.format("csv").option("header", "true").option("inferSchema", "true").option("compression", "gzip").load(file_path)
df.show(5)

# COMMAND ----------

# MAGIC %python
# MAGIC
# MAGIC import boto3
# MAGIC import os
# MAGIC
# MAGIC session = boto3.Session(
# MAGIC          aws_access_key_id='AKIAYR65XI26LSGNTF5I',
# MAGIC          aws_secret_access_key='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')
# MAGIC
# MAGIC os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
# MAGIC
# MAGIC #Then use the session to get the resource
# MAGIC s3 = session.resource('s3')
# MAGIC my_bucket = s3.Bucket('latticeengines-prod-customers')
# MAGIC for my_bucket_object in my_bucket.objects.all():
# MAGIC     print(my_bucket_object.key)

# COMMAND ----------

value = dbutils.secrets.get(scope="DBX-B2BDNA-READWRITE", key="BrKo0QwOcVqS3kxv/RHa01E3lnpOU1D+x8DnvRoM")

for char in value:
    print(char, end=" ")