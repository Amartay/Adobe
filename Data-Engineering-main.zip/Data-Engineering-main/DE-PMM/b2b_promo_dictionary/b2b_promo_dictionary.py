from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")

             spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
             spark.conf.set("spark.sql.shuffle.partitions","auto")
             spark.conf.set("spark.sql.adaptive.enabled",True)
             spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=true')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')

             spark.conf.set("spark.sql.statistics.histogram.enabled",True)
             spark.conf.set("spark.sql.adaptive.skewedJoin.enabled",True)

             
             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))
             spark.sql(""" SET spark.sql.legacy.timeParserPolicy=LEGACY """)
             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" set hive.exec.reducers.max=50 """)
             spark.sql(""" set hive.exec.reducers.bytes.per.reducer=1000000 """)
             spark.sql(""" set hive.optimize.distinct.rewrite=true """)
             spark.sql(""" set hive.map.aggr=true """)
             spark.sql(""" SET hive.exec.Compress.intermediate=true """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
             spark.sql(""" SET hive.auto.convert.join=true """)
             spark.sql(""" SET hive.merge.mapfiles=true """)
             spark.sql(""" SET hive.merge.mapredfiles=true """)
             spark.sql(""" SET hive.merge.size.per.task=512000000 """)
             spark.sql(""" SET hive.merge.smallfiles.avgsize=512000000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=false """)
             spark.sql(""" SET hive.exec.compress.output=true """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.cbo.enable=true """)
             spark.sql(""" set hive.compute.query.using.stats=true """)
             spark.sql(""" set hive.stats.fetch.column.stats=true """)
             spark.sql(""" set hive.stats.fetch.partition.stats=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.exec.dynamic.partition=true """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.support.concurrency = false """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" drop table if exists b2b.promo_dictionary""")
             spark.sql(""" Create table  b2b.promo_dictionary as
select S_No
,Time_Period
,Offer_Description
,JDI_Test
,Promo_name
,Promo_Start_Date
,Promo_End_Date
,promo_start_fiscal_qtr_name
,promo_start_fiscal_yr_and_qtr_desc
,promo_start_fiscal_wk_in_qtr
,promo_start_fiscal_wk_in_yr
,promo_start_fiscal_yr_and_wk_desc
,promo_end_fiscal_qtr_name
,promo_end_fiscal_yr_and_qtr_desc
,promo_end_fiscal_wk_in_qtr
,promo_end_fiscal_wk_in_yr
,promo_end_fiscal_yr_and_wk_desc
,Promo_price
,Full_Price
,pd.Material_Number
,Product_Segment
,pd.Product_name_description
,product_category
,Open_vs_Closed
,Promo_use_case
,Promo_RTM
,PROMO_RTM_MAPPED
,pd.MARKET_SEGMENT
,MAPPED_MARKET_SEGMENT
,Promo_Region
,region_code

,pd.Promo_type
,Promo_SKU_type
,PROJECT_ID
,pd.OFFER_ID
,pd.MATERIAL_ID
,CUSTOMER_SEGMENT
,COMMITMENT
,TERM
,PRODUCT_CODE
,PRODUCT_ARRANGEMENT_CODE
,LANGUAGE
,COUNTRY
,pd.GEO 
,pd.MARKET_AREA
,SUBS_OFFER
,CURRENCY
,UNIT_PRICE
,UNIT_PRICE_WITH_TAX
,UNIT_PRICE_WITHOUT_TAX
,TAX
,TAX_RATE 
from  (
        select distinct 
S_No
,Time_Period
,Offer_Description
,JDI_Test
,Promo_name
,Promo_Start_Date
,Promo_End_Date
,promo_start_fiscal_qtr_name
,promo_start_fiscal_yr_and_qtr_desc
,promo_start_fiscal_wk_in_qtr
,promo_start_fiscal_wk_in_yr
,promo_start_fiscal_yr_and_wk_desc
,promo_end_fiscal_qtr_name
,promo_end_fiscal_yr_and_qtr_desc
,promo_end_fiscal_wk_in_qtr
,promo_end_fiscal_wk_in_yr
,promo_end_fiscal_yr_and_wk_desc
,Promo_price
,Full_Price
,pd.Material_Number
,Product_Segment
,pd.Product_name_description
--,product_category
,trim(' ' from Open_vs_Closed_value)  Open_vs_Closed
,trim(' ' from Promo_use_case_value) Promo_use_case
,trim(' ' from Promo_RTM_value) Promo_RTM
,
CASE
        WHEN Promo_RTM_value IN ('WEB', 'PHONE',' WEB', ' PHONE') THEN 'ADOBE.COM/CC.COM'
        WHEN Promo_RTM_value in ('RESELLER',' RESELLER') THEN 'RESELLER'
        ELSE trim(' ' from Promo_RTM_value)  
    END AS PROMO_RTM_MAPPED
,MARKET_SEGMENT_value MARKET_SEGMENT
,CASE
        WHEN MARKET_SEGMENT_value in ('COM',' COM') THEN 'COMMERCIAL'
        WHEN MARKET_SEGMENT_value in ('GOV',' GOV') THEN 'GOVERNMENT'
        WHEN MARKET_SEGMENT_value in ('EDU',' EDU') THEN 'EDUCATION'
        ELSE trim(' ' from MARKET_SEGMENT_value)  
    END AS MAPPED_MARKET_SEGMENT
,Promo_Region
,region_code
-- ,pa.market_area as pivot_market_area
-- ,pa.region as pivot_region
-- ,pa.geo as pivot_geo
-- ,pa.sales_district as sales_district
,pd.Promo_type
,Promo_SKU_type
,PROJECT_ID
,pd.OFFER_ID
,pd.MATERIAL_ID
,CUSTOMER_SEGMENT
,COMMITMENT
,TERM
,PRODUCT_CODE
,PRODUCT_ARRANGEMENT_CODE
,LANGUAGE
,COUNTRY
,pd.GEO 
,pd.MARKET_AREA
--,SUBS_OFFER
,CURRENCY
,UNIT_PRICE
,UNIT_PRICE_WITH_TAX
,UNIT_PRICE_WITHOUT_TAX
,TAX
,TAX_RATE 

    from 
(
select 
`S.No` AS S_No
,Time_Period
,Offer_Description
,JDI_Test
,Promo_name
,Promo_Start_Date
,Promo_End_Date
,Promo_price
,Full_Price
,pd.Material_Number,
CASE
        WHEN Promo_RTM = 'All' THEN 'WEB|PHONE|RESELLER'
        ELSE upper(trim(' ' from Promo_RTM))
    END AS Promo_RTM,
    
    CASE
        WHEN pd.MARKET_SEGMENT = 'All' THEN 'COM|GOV|EDU'
        ELSE upper(trim(' ' from pd.MARKET_SEGMENT))
    END AS MARKET_SEGMENT,
    
    CASE
        WHEN Open_vs_Closed = 'All' THEN 'OPEN|CLOSED'
        ELSE upper(trim(' ' from Open_vs_Closed))
    END AS Open_vs_Closed,
    
    CASE
        WHEN Promo_use_case = 'All' THEN 'ACQUISITION|EXPANSION'
        ELSE upper(trim(' ' from Promo_use_case))
    END AS Promo_use_case,
    Product_Segment
,pd.Product_name_description
--,product_category
,region_code 
,Promo_Region
,pd.Promo_type
,Promo_SKU_type
,PROJECT_ID
,pd.OFFER_ID
,pd.MATERIAL_ID
,CUSTOMER_SEGMENT
,COMMITMENT
,TERM
,PRODUCT_CODE
,PRODUCT_ARRANGEMENT_CODE
,LANGUAGE
,COUNTRY
, geo_code as GEO 
, market_area_code MARKET_AREA
--,SUBS_OFFER
,CURRENCY
,UNIT_PRICE
,UNIT_PRICE_WITH_TAX
,UNIT_PRICE_WITHOUT_TAX
,TAX
,TAX_RATE
,p_start.fiscal_qtr_name promo_start_fiscal_qtr_name,
p_start.fiscal_yr_and_qtr_desc promo_start_fiscal_yr_and_qtr_desc,
p_start.fiscal_wk_in_qtr promo_start_fiscal_wk_in_qtr,
p_start.fiscal_wk_in_yr promo_start_fiscal_wk_in_yr,
p_start.fiscal_yr_and_wk_desc promo_start_fiscal_yr_and_wk_desc,
p_end.fiscal_qtr_name promo_end_fiscal_qtr_name,
p_end.fiscal_yr_and_qtr_desc promo_end_fiscal_yr_and_qtr_desc,
p_end.fiscal_wk_in_qtr promo_end_fiscal_wk_in_qtr,
p_end.fiscal_wk_in_yr promo_end_fiscal_wk_in_yr,
p_end.fiscal_yr_and_wk_desc promo_end_fiscal_yr_and_wk_desc
 from  b2b_tmp.promo_dictionary_tmp pd
 left join 
  Ids_coredata.dim_country country
  on pd.COUNTRY = country.country_code_iso2
   
   left join ids_coredata.dim_date p_start
on p_start.date_date=date(date_format(to_date(pd.Promo_Start_Date, 'MM/dd/yyyy'), 'yyyy-MM-dd'))
left join ids_coredata.dim_date p_end
on p_end.date_date=date(date_format(to_date(pd.Promo_End_Date, 'MM/dd/yyyy'), 'yyyy-MM-dd'))
)pd


LATERAL VIEW explode(split(pd.Promo_RTM, '[|/]')) Promo_RTM_split AS Promo_RTM_value 
LATERAL VIEW explode(split(pd.Promo_use_case, '[|/]')) Promo_use_case_rtm_split AS Promo_use_case_value 
LATERAL VIEW explode(split(pd.Open_vs_Closed, '[|/]')) Open_vs_Closed_split AS Open_vs_Closed_value 
LATERAL VIEW explode(split(pd.MARKET_SEGMENT, '[|/]')) MARKET_SEGMENT_split AS MARKET_SEGMENT_value 
)pd

left join (select distinct subs_offer,product_category,TRIM(LEADING '0' FROM material_number) material_numbers from csmb.vw_Ccm_pivot4_All 
where source_type = 'TM'  and   event_source = 'EVENT' and fiscal_yr_and_qtr_desc >= '2020-Q1') pa
  on material_numbers= pd.material_id 
        

        
 """)

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()