# Databricks notebook source
from datetime import date
from datetime import datetime, timedelta

run_day = date.today().strftime("%A")
print(run_day)
#if run_day == 'Friday':
#    run_date = date.today()
#else:
#    today = datetime.today()
#    days_since_friday = (today.weekday() + 3) % 7
#    last_friday = today - timedelta(days=days_since_friday)
#    run_date = last_friday.date()
run_date = date.today()
print(run_date)
query = "select * from frameio.users where as_of_date = '{}' ".format(run_date)
count = spark.sql(query).count()
print(count)
if (count==0):
    raise Exception("Table is not updated")
else:
    pass

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.frameio_users_weekly_snapshot partition(as_of_date)
select
      a.user_id    
     ,regexp_replace(a.user_email, '\n','') as user_email    
     ,regexp_replace(a.user_name, '\n','') as user_name    
     ,cast(a.fio_signup_date as timestamp)   
     ,cast(a.fio_first_login_date as timestamp)   
     ,cast(a.fio_last_login_date as timestamp)   
     ,a.has_logged_into_premiere   
     ,cast(a.last_premiere_login_date as timestamp) 
     ,a.personal_account_id   
     ,a.personal_plan_tier_consolidated   
     ,cast(a.personal_plan_arr AS INT) AS personal_plan_arr  
     ,a.highest_associated_account_id   
     ,a.highest_associated_plan_tier_consolidated   
     ,cast(a.highest_associated_plan_arr AS INT) AS highest_associated_plan_arr   
     ,regexp_replace(job_title, '\n|\r','') as job_title   
     ,a.fio_joined_via   
     ,a.from_adobe   
     ,a.adobe_auth_id   
     ,cast(a.total_upload_count AS INT) AS total_upload_count   
     ,cast(a.total_comment_count AS INT) AS total_comment_count   
     ,cast(a.total_media_view_count AS INT) AS total_media_view_count   
     ,cast(a.total_share_count AS INT) AS total_share_count   
     ,cast(a.total_core_platform_action_count AS INT) AS total_core_platform_action_count   
     ,cast(a.upload_count_last_30_days AS INT) AS upload_count_last_30_days   
     ,cast(a.comment_count_last_30_days AS INT) AS comment_count_last_30_days   
     ,cast(a.media_view_count_last_30_days AS INT) AS media_view_count_last_30_days   
     ,cast(a.share_count_last_30_days AS INT) AS share_count_last_30_days   
     ,cast(a.core_platform_action_count_last_30_days AS INT) AS core_platform_action_count_last_30_days   
     ,a.fio_last_activity_date   
     ,cast(a.as_of_date as date)
    from frameio.users a
    where a.as_of_date = '{RUN_DATE}' """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()
