# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.frameio_accounts_weekly_snapshot partition(as_of_date) 
select 
     distinct account_id 
    ,owner_user_id 
    ,regexp_replace(owner_user_email, '\n','') as owner_user_email 
    ,regexp_replace(account_domain, '\n|\r','') as account_domain 
    ,salesforce_account_id 
    ,stripe_customer_id 
    ,plan_tier_consolidated 
    ,cast(etla_deals as string) as etla_deals
    ,etla_customer 
    ,cast(pricing_version as INT) as pricing_version
    ,cast(arr as INT) as arr
    ,cast(storage_gb as INT) as storage_gb
    ,cast(storage_limit_gb as INT) as storage_limit_gb
    ,cast(project_count as INT) as project_count
    ,cast(project_limit as INT) as project_limit
    ,cast(user_count as INT) as user_count
    ,cast(user_limit as INT) as user_limit
    ,cast(seat_count as INT) as seat_count
    ,cast(seat_limit as INT) as seat_limit
    ,cast(team_member_count as INT) as team_member_count
    ,cast(team_member_limit as INT) as team_member_limit
    ,cast(collaborator_count as INT) as collaborator_count
    ,cast(collaborator_limit  as INT) as collaborator_limit
    ,cast(created_at as timestamp)
    ,cast(last_activity_date as date)
    ,cast(active_users_last_30_days as INT) as active_users_last_30_days
    ,cast(active_users_last_90_days as INT) AS active_users_last_90_days
    ,cast(as_of_date as date)
 from frameio.accounts
 where as_of_date = '{RUN_DATE}' """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()
