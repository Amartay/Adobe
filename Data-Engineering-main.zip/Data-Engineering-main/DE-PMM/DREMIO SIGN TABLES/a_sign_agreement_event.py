# Databricks notebook source
import pyarrow
from pyarrow import flight
import pandas
from pyspark.sql.functions import col

host = '10.51.7.145'
port = '32010'
uid = 'cceuser'
pat = 'ybzZsSfrSUuMbcOuegdCfYc6kt33ucPXNP31aKY4hVNTa3Ae33g7kEjaC3wCBw=='

print("uid")
#Connect
client = flight.FlightClient('grpc+tcp://' + host + ':' + port)
print("client")
#Authenticate
bearer_token = client.authenticate_basic_token(uid, pat)
print("bearer_token")
options = flight.FlightCallOptions(headers=[bearer_token])
print("options")

sql1="""DROP TABLE IF EXISTS azr6665prddpaasb2bdna."user".hive.warehouse.b2bdna."b2b_stg.db".a_sign_agreement_event """
info = client.get_flight_info(flight.FlightDescriptor.for_command(sql1),options)
reader = client.do_get(info.endpoints[0].ticket, options)
print("Table is deleted")
#Query
sql= """
CREATE table azr6665prddpaasb2bdna."user".hive.warehouse.b2bdna."b2b_stg.db".a_sign_agreement_event AS SELECT * FROM sign."a_sign.agreement_event"
"""
info = client.get_flight_info(flight.FlightDescriptor.for_command(sql),options)

reader = client.do_get(info.endpoints[0].ticket, options)

df = reader.read_all()#added on July 03
print("Table is created")


# COMMAND ----------

client.close()

# COMMAND ----------

from pyspark.sql.functions import col
import time
import os

#time.sleep(360) #Commented on July 3

dir = "abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b_stg.db/a_sign_agreement_event"

# if not os.path.join(os.getcwd(), f"{dir}"):
#     print('The path does not exist')
#     dbutils.notebook.exit("Source table Path doesn't exist")
# else:
df = spark.read.parquet(dir)
spark.sql("refresh table b2b_stg.a_sign_agreement_event")
print("Record count - ",df.count())
dbutils.notebook.exit("SUCCESS")

# COMMAND ----------

from pyspark.sql.functions import col
spark.sql("refresh table b2b_stg.a_sign_agreement_event")
spark.sql("select count(*) from b2b_stg.a_sign_agreement_event").show()
