# Databricks notebook source
from datetime import date
from datetime import datetime, timedelta

run_day = date.today().strftime("%A")
print(run_day)
run_date = date.today()
print(run_date)
query = "select * from frameio.users where as_of_date = '{}' ".format(run_date)
count = spark.sql(query).count()
print(count)
if (count==0):
    raise Exception("Table is not updated")
else:
    pass

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("TODAY_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             TODAY_DATE = dbutils.widgets.get("TODAY_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" use b2b """)
             spark.sql(""" drop table if exists b2b.frameio_users_enriched """)
             spark.sql(""" create table b2b.frameio_users_enriched  as 
select
a.user_id   
,regexp_replace(a.user_email, '\n','') as user_email   
,regexp_replace(a.user_name, '\n','') as user_name   
,a.fio_signup_date   
,a.fio_first_login_date   
,a.fio_last_login_date   
,a.has_logged_into_premiere   
,a.last_premiere_login_date   
,a.personal_account_id   
,a.personal_plan_tier_consolidated   
,a.personal_plan_arr   
,a.highest_associated_account_id   
,a.highest_associated_plan_tier_consolidated   
,a.highest_associated_plan_arr   
,regexp_replace(a.job_title, '\n|\r','') job_title   
,a.fio_joined_via   
,a.from_adobe   
,a.adobe_auth_id   
,a.total_upload_count   
,a.total_comment_count   
,a.total_media_view_count   
,a.total_share_count   
,a.total_core_platform_action_count   
,a.upload_count_last_30_days   
,a.comment_count_last_30_days   
,a.media_view_count_last_30_days   
,a.share_count_last_30_days   
,a.core_platform_action_count_last_30_days   
,a.fio_last_activity_date
,c.optinvalue
,a.as_of_date
from 
    frameio.users as a  
left join
     mps.emailpermission_view as c
     on lower(trim(regexp_replace(a.user_email, '\n',''))) = lower(trim(c.email))
where a.as_of_date = '{TODAY_DATE}'
group by 
a.user_id   
,regexp_replace(a.user_email, '\n','') 
,regexp_replace(a.user_name, '\n','')    
,a.fio_signup_date   
,a.fio_first_login_date   
,a.fio_last_login_date   
,a.has_logged_into_premiere   
,a.last_premiere_login_date   
,a.personal_account_id   
,a.personal_plan_tier_consolidated   
,a.personal_plan_arr   
,a.highest_associated_account_id   
,a.highest_associated_plan_tier_consolidated   
,a.highest_associated_plan_arr   
,regexp_replace(a.job_title, '\n|\r','')    
,a.fio_joined_via   
,a.from_adobe   
,a.adobe_auth_id   
,a.total_upload_count   
,a.total_comment_count   
,a.total_media_view_count   
,a.total_share_count   
,a.total_core_platform_action_count   
,a.upload_count_last_30_days   
,a.comment_count_last_30_days   
,a.media_view_count_last_30_days   
,a.share_count_last_30_days   
,a.core_platform_action_count_last_30_days   
,a.fio_last_activity_date
,c.optinvalue
,a.as_of_date """.format(TODAY_DATE = TODAY_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()