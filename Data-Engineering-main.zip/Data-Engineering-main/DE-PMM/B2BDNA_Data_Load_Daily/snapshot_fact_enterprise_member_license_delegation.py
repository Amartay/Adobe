# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime, date
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             run_day = date.today().strftime("%A")
             if run_day == 'Friday':
                 spark = SparkSession.builder \
                     .enableHiveSupport() \
                     .config('hive.exec.dynamic.partition', 'true') \
                     .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                     .config('hive.exec.max.dynamic.partitions', '10000') \
                     .getOrCreate()
                 log4j = spark._jvm.org.apache.log4j
                 log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
                 spark.sql('SET hive.warehouse.data.skiptrash=true;')
                 spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
                 spark.conf.set('spark.sql.cbo.enabled', True)
                 spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
                 spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
                 spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
                 spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
                 spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
                 spark.sql("set spark.sql.adaptive.enabled=false")
    
                 dbutils.widgets.text("Custom_Settings", "")
                 dbutils.widgets.text("RUN_DATE", "")
    
                 Settings = dbutils.widgets.get("Custom_Settings")
                 RUN_DATE = dbutils.widgets.get("RUN_DATE")
    
                 Set_list = Settings.split(',')
                 if len(Set_list)>0:
                     for i in Set_list:
                         if i != "":
                             print("spark.sql(+i+)")
                             spark.sql("""{i}""".format(i=i))
    
                 spark.sql(""" set hive.execution.engine = mr """)
                 spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
                 spark.sql(""" insert overwrite table b2b.snapshot_fact_enterprise_member_license_delegation  partition (asofdate)
    SELECT 
    org_id , 
      cast(group_id as bigint) as group_id, 
      cast(current_status_date as date) as current_status_date , 
      owner_type , 
      member_guid , 
      delegation_status , 
      payment_status , 
      product_id , 
      product_context_id , 
      cast(first_delegation_date as date) as first_delegation_date, 
      cast(first_revoked_date as date) as first_revoked_date , 
      contract_id , 
      contract_offer_type , 
      license_type , 
      cast(contract_start_date as date) as contract_start_date, 
      cast(contract_end_date as date) as contract_end_date , 
      cast(etla_id as string) as etla_id , 
      fulfillable_entitlement_id , 
      purchasable_entitlement_id , 
      offer_id , 
      fulfill_ent_status , 
      user_type , 
      user_auth_src_type , 
      cast(storage_amount as int) as storage_amount , 
      cast(esm_user_storage as int) as esm_user_storage , 
      offering_name , 
      delegatable_type , 
      service_type , 
      offering_type , 
      cloud_type , 
      org_name , 
      country , 
      market_segment , 
      is_valid , 
      cast(current_status_fiscal_yr_and_wk as STRING) as current_status_fiscal_yr_and_wk , 
      cast(current_status_fiscal_yr_and_per as STRING) as current_status_fiscal_yr_and_per , 
      cast(current_status_fiscal_yr_and_qtr as STRING) as current_status_fiscal_yr_and_qtr , 
      cast(current_status_fiscal_yr as int) as current_status_fiscal_yr , 
      cast(current_status_fiscal_wk_seq as int) as current_status_fiscal_wk_seq , 
      cast(current_status_fiscal_per_seq as int) as current_status_fiscal_per_seq , 
      cast(current_status_fiscal_qtr_seq as int) as current_status_fiscal_qtr_seq , 
      country_name , 
      market_area_code , 
      market_area_description , 
      region , 
      region_description , 
      geo_code , 
      geo_description , 
      offering_type_join , 
      cont_st_dt_fiscal_yr_and_wk , 
      cont_st_dt_fiscal_yr_and_per , 
      cont_st_dt_fiscal_yr_and_qtr , 
      cast(cont_st_dt_fiscal_yr as int) as cont_st_dt_fiscal_yr , 
      cast(fiscal_wk_seq as int) as fiscal_wk_seq, 
      cast(fiscal_per_seq as int) as fiscal_per_seq , 
      cast(fiscal_qtr_seq as int) as fiscal_qtr_seq , 
      active_member_count , 
      row_insertion_dttm, 
      license_pool , 
      provisioning_status , 
      id_type , 
      pers_first_name , 
      pers_last_name , 
      pers_email , 
      pers_country_code, 
      cast('{RUN_DATE}' as date) AS asofdate
    FROM b2b.fact_enterprise_member_license_delegation """.format(RUN_DATE = RUN_DATE))

             else:
                 pass
             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()


