# Databricks notebook source
 from pyspark import SparkContext, SparkConf , StorageLevel
 from pyspark.sql import SparkSession, HiveContext
 from pyspark.sql.functions import *
 from pyspark.sql.types import *
 import logging
 from dateutil.rrule import rrule, MONTHLY
 from datetime import datetime
 import json
 from pyspark.sql import functions
 import sys
 class main() :
     def __init__(self):
          try :
              spark = SparkSession.builder \
                  .enableHiveSupport() \
                  .config('hive.exec.dynamic.partition', 'true') \
                  .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                  .config('hive.exec.max.dynamic.partitions', '10000') \
                  .getOrCreate()
              log4j = spark._jvm.org.apache.log4j
              log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
              spark.sql('SET hive.warehouse.data.skiptrash=true;')
              spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
              spark.conf.set('spark.sql.cbo.enabled', True)
              spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
              spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
              spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
              spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
              spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
              spark.sql("set spark.sql.adaptive.enabled=false")

              dbutils.widgets.text("Custom_Settings", "")

              Settings = dbutils.widgets.get("Custom_Settings")

              Set_list = Settings.split(',')
              if len(Set_list)>0:
                  for i in Set_list:
                      if i != "":
                          print("spark.sql(+i+)")
                          spark.sql("""{i}""".format(i=i))

              spark.sql(""" use b2b """)
              spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
              spark.sql(""" set hive.execution.engine = mr """)
              spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
              spark.sql(""" insert overwrite table b2b.fact_serial_sku_txt
 select  cast(end_user_id as bigint) as end_user_id,
         org_name,
         program_type,
        cast(salesorder as bigint) as salesorder,
        cast(certificate as bigint) as certificate,
         cast(material_num as bigint) as material_num,
         material_number_desc as material_text,
         product_name_desc as long_text,
         serial_number,
         addl_text, 
         cast(created_date as date) as created_date
 from
 (select end_user_id,
         org_name,
         program_type,
        salesorder,
        certificate,  
         material_num,
         material_number_desc,
         product_name_desc,
         serial_number,
         addl_text,
 ROW_NUMBER()
     OVER (partition by serial_number
 ORDER BY  date ASC) AS rownum,
         date as created_date 
 from
 (SELECT DISTINCT 
 regexp_replace(ZLICCERTHDR.ENDUSER,
          '^0+(?!$)','') AS end_user_id,program_type,
           salesorder,zliccerthdr.certificate,
          KNA1.NAME1 AS org_name, 
          regexp_replace(MARA.material_number,
          '^0+(?!$)','') AS material_num,
          MARA.material_number_desc,
          MARA.product_name_desc,
          regexp_replace(ZLICCERTSN.SERIAL_NUMBER,'-','') AS serial_number,
          MARA.additional_text AS addl_text,
          from_unixtime(unix_timestamp(ZLICCERTHDR.created_date ,'yyyyMMdd'), 'yyyy-MM-dd') AS date
 FROM replicn_ecc.stg_zliccerthdr ZLICCERTHDR
 LEFT  JOIN replicn_ecc.stg_zliccertsn ZLICCERTSN
     ON ZLICCERTSN.CERTIFICATE = ZLICCERTHDR.CERTIFICATE
 LEFT JOIN ids_coredata.dim_product MARA
     ON MARA.material_number = ZLICCERTSN.COMPONENT_SKU
 LEFT JOIN replicn_ecc.kna1 KNA1
     ON KNA1.KUNNR = ZLICCERTHDR.ENDUSER )n
 where serial_number is not NULL
 group by
         end_user_id,
         org_name,
         program_type,
         salesorder,
         certificate,
         material_num,
         material_number_desc,
         product_name_desc,
         serial_number,
         addl_text,
          date)m
 where created_date >='2005-01-01'
         and rownum = 1 """)

              try:
                  dbutils.notebook.exit("SUCCESS")
              except Exception as e:
                  print("exception:",e)
          except Exception as e:
              dbutils.notebook.exit(e)

 if __name__ == '__main__':
         main()
