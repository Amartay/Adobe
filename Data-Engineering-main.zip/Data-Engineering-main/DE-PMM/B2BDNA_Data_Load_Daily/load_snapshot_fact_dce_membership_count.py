# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("TODAY_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             TODAY_DATE = dbutils.widgets.get("TODAY_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.snapshot_fact_dce_membership_count partition (as_of_date)
select
contract_id,
cloud_type,
offering_type,
offering_name,
service_type,
etla_id,
cast(org_create_date as date) as org_create_date,
cast(contract_start_date as date) as contract_start_date,
org_id,
license_type,
model, 
org_name,
country,
market_segment,
cast(contract_end_date as date) as contract_end_date,
is_valid,
contract_offer_type,
offer_id,
consumption_start_date,
consumption_cycle_duration,
sign_service_level,
sign_overages,
total_sign_transactions,
sign_lic_type, 
pro_membership_count,
local_licensed_qty, 
pro_desktop_services_membership_count,
pro_desktop_membership_count,
pro_services_membership_count,
del_membership_count,
del_desktop_services_membership_count,
del_desktop_membership_count,
del_services_membership_count,
cast(row_insertion_dttm as timestamp) as row_insertion_dttm,
cast('{TODAY_DATE}' as date) AS as_of_date
from 
enterprise.fact_dce_membership_count """.format(TODAY_DATE = TODAY_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()


