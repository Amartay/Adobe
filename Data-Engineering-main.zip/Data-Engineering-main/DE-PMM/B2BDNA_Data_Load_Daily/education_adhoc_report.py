from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
import pytz
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime,date
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             #run_day = date.today().strftime("%A")
             dbutils.widgets.text("RUN_DAY_PST", "")
             RUN_DAY_PST = dbutils.widgets.get("RUN_DAY_PST")
             run_day = RUN_DAY_PST
             if run_day == 'Monday':
                 spark = SparkSession.builder \
                     .enableHiveSupport() \
                     .config('hive.exec.dynamic.partition', 'true') \
                     .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                     .config('hive.exec.max.dynamic.partitions', '10000') \
                     .getOrCreate()
                 log4j = spark._jvm.org.apache.log4j
                 log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
                 spark.sql('SET hive.warehouse.data.skiptrash=true;')
                 spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
                 spark.conf.set('spark.sql.cbo.enabled', True)
                 spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
                 spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
                 spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
                 spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
                 spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
                 spark.sql("set spark.sql.adaptive.enabled=false")
    
                 dbutils.widgets.text("Custom_Settings", "")
                 dbutils.widgets.text("RUN_DATE", "")
    
                 Settings = dbutils.widgets.get("Custom_Settings")
                 RUN_DATE = dbutils.widgets.get("RUN_DATE")
    
                 Set_list = Settings.split(',')
                 if len(Set_list)>0:
                     for i in Set_list:
                         if i != "":
                             print("spark.sql(+i+)")
                             spark.sql("""{i}""".format(i=i))
    
                 spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
                 spark.sql(""" set hive.execution.engine = mr """)
                 spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
                 spark.sql(""" drop table if exists b2b_stg.edu_report_base """)
                 spark.sql(""" create table  b2b_stg.edu_report_base as 
    select 
    org_id, 
    org_name, 
    case when geo = 'Americas' then 'AMER'
    when geo = 'Asia' then 'ASIA'
    when geo = 'Japan' then 'JPN' else geo 
    end as geo, 
    market_segment, 
    country, 
    cloud_type, 
    contract_offer_type,
    case when offering_name = 'ADOBE STOCK CREDITS' then 'Adobe Stock Credits'
    when offering_name = 'ADOBE STOCK IMAGES' then 'Adobe Stock Images'
    else offering_name end as offering_name, 
    provisioned_count,
    assigned_count,
    activated_count, 
    mau, 
    cast(as_of_date as date) as as_of_date
    from 
    (
    select 
    org_id, 
    org_name, 
    geo, 
    market_segment, 
    null as country, 
    'STOCK' as cloud_type, 
    contract_offer_type, 
    concat('ADOBE STOCK ', product_type) as offering_name, 
    cast(provisioned_count as bigint) as provisioned_count, 
    cast(assigned_count as bigint) as assigned_count, 
    cast(consumption_count as bigint) as activated_count,
    0 as mau, 
    as_of_date
    from enterprise.fact_snapshot_stock_purchased_allocated_consumed 
    where as_of_date = '{RUN_DATE}'
    and market_segment = 'EDUCATION'
    group by 
    org_id, 
    org_name, 
    geo, 
    market_segment, 
    contract_offer_type, 
    concat('ADOBE STOCK ', product_type), 
    provisioned_count, 
    assigned_count, 
    consumption_count, 
    as_of_date
    UNION ALL 
    select 
    org_id, 
    org_name, 
    org_geo_description as geo, 
    market_segment, 
    org_country as country, 
    cloud_type, 
    contract_type as contract_offer_type , 
    offering_name, 
    cast(provisioned as bigint) as provisioned_count,  
    cast(delegated as bigint) as assigned_count, 
    cast(activated as bigint) as activated_count, 
    cast(mau as bigint) as mau,
    as_of_date
    from b2b.b2b_deployment_usage as a 
    where as_of_date = '{RUN_DATE}'
    AND UPPER(offering_name) NOT LIKE '%STOCK%'
    AND market_segment = 'EDUCATION' and contract_type IN ('ETLA','EVIP')
    group by org_id, org_name, org_geo_description, market_segment, org_country, cloud_type, jem_contract_id, contract_type, offering_name
    , provisioned, delegated, activated, mau, as_of_date
    ) as a """.format(RUN_DATE = RUN_DATE))
                 spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
                 spark.sql(""" set hive.execution.engine = mr """)
                 spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
                 spark.sql(""" insert overwrite table b2b.edu_reports_base_ecp partition(as_of_date)
    select 
    a.org_id,
    a.org_name,
    a.geo,
    a.market_segment,
    a.country AS org_country,
    case when a.cloud_type = 'CCE' then 'CC'
    when a.cloud_type = 'DCE' then 'DC' else a.cloud_type end as cloud_type,
    a.contract_offer_type,
    a.offering_name,
    a.provisioned_count,
    a.assigned_count,
    a.activated_count,
    a.mau,
    cast(end_user_id as bigint) as end_user_id,
    end_user_name,
    end_user_id_market_segment,
    dme_acct_segment,
    cast(ech_parent_id as bigint) as ech_parent_id,
    ech_parent_name,
    ech_parent_country_code,
    ech_parent_country_name,
    ech_parent_market_area_code,
    ech_parent_market_area_description,
    ech_parent_region_code,
    ech_parent_region_description,
    ech_parent_geo_code,
    ech_parent_geo_description,
    cast(ech_sub_id as bigint) as ech_sub_id,
    ech_sub_name,
    ech_sub_country_code,
    ech_parent_annual_sales_usd,
    ech_parent_tot_emp_cont,
    ech_parent_industry,
    ech_sub_annual_sales_usd,
    ech_sub_tot_emp_cont,
    ech_sub_industry,
    concat('https://agent.adminconsole.adobe.com/organizations/',a.org_id, '@AdobeOrg/contracts') as AAUI_link, 
    sfdc_account_id,
    dme_csm_id, 
    dme_csm_name, 
    dme_csm_mgr_id, 
    dme_csm_mgr_name,
    dx_csm_id, 
    dx_csm_name, 
    dx_csm_mgr_id, 
    dx_csm_mgr_name,
    sign_csm_id, 
    sign_csm_name, 
    sign_csm_mgr_id, 
    sign_csm_mgr_name,
    a.as_of_date
    from b2b_stg.edu_report_base as a 
    LEFT JOIN 
    (
    select
    org_id,
    org_country,
    CONCAT_WS(' / ',collect_list(DISTINCT end_user_id)) AS end_user_id,
    CONCAT_WS(' / ',collect_list(DISTINCT end_user_name)) AS end_user_name,
    CONCAT_WS(' / ',collect_list(DISTINCT end_user_id_market_segment)) AS end_user_id_market_segment,
    CONCAT_WS(' / ',collect_list(DISTINCT dme_acct_segment)) AS dme_acct_segment,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_id)) AS ech_parent_id,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_name)) AS ech_parent_name,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_country_code)) AS ech_parent_country_code,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_country_name)) AS ech_parent_country_name,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_market_area_code)) AS ech_parent_market_area_code,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_market_area_description)) AS ech_parent_market_area_description,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_region_code)) AS ech_parent_region_code,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_region_description)) AS ech_parent_region_description,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_geo_code)) AS ech_parent_geo_code,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_geo_description)) AS ech_parent_geo_description,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_sub_id)) AS ech_sub_id,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_sub_name)) AS ech_sub_name,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_sub_country_code)) AS ech_sub_country_code,
    SUM(ech_parent_annual_sales_usd) AS ech_parent_annual_sales_usd,
    SUM(ech_parent_tot_emp_cont) AS ech_parent_tot_emp_cont,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_parent_industry)) AS ech_parent_industry,
    SUM(ech_sub_annual_sales_usd) AS ech_sub_annual_sales_usd,
    SUM(ech_sub_tot_emp_cont) AS ech_sub_tot_emp_cont,
    CONCAT_WS(' / ',collect_list(DISTINCT ech_sub_industry)) AS ech_sub_industry,
    CONCAT_WS(' / ',collect_list(DISTINCT dme_csm_id)) AS dme_csm_id,
    CONCAT_WS(' / ',collect_list(DISTINCT dme_csm_name)) AS dme_csm_name,
    CONCAT_WS(' / ',collect_list(DISTINCT dme_csm_mgr_id)) AS dme_csm_mgr_id,
    CONCAT_WS(' / ',collect_list(DISTINCT dme_csm_mgr_name)) AS dme_csm_mgr_name,
    CONCAT_WS(' / ',collect_list(DISTINCT dx_csm_id)) AS dx_csm_id,
    CONCAT_WS(' / ',collect_list(DISTINCT dx_csm_name)) AS dx_csm_name,
    CONCAT_WS(' / ',collect_list(DISTINCT dx_csm_mgr_id)) AS dx_csm_mgr_id,
    CONCAT_WS(' / ',collect_list(DISTINCT dx_csm_mgr_name)) AS dx_csm_mgr_name,
    CONCAT_WS(' / ',collect_list(DISTINCT sign_csm_id)) AS sign_csm_id,
    CONCAT_WS(' / ',collect_list(DISTINCT sign_csm_name)) AS sign_csm_name,
    CONCAT_WS(' / ',collect_list(DISTINCT sign_csm_mgr_id)) AS sign_csm_mgr_id,
    CONCAT_WS(' / ',collect_list(DISTINCT sign_csm_mgr_name)) AS sign_csm_mgr_name,
    CONCAT_WS(' , ',collect_list(DISTINCT sfdc_account_id)) AS sfdc_account_id
    FROM 
    (
    select
    b.org_id,
    b.org_country,
    b.end_user_id,
    b.end_user_name,
    b.end_user_id_market_segment,
    b.dme_acct_segment,
    b.ech_parent_id,
    b.ech_parent_name,
    b.ech_parent_country_code,
    b.ech_parent_country_name,
    b.ech_parent_market_area_code,
    b.ech_parent_market_area_description,
    b.ech_parent_region_code,
    b.ech_parent_region_description,
    b.ech_parent_geo_code,
    b.ech_parent_geo_description,
    b.ech_sub_id,
    b.ech_sub_name,
    b.ech_sub_country_code,
    b.ech_parent_annual_sales_usd,
    b.ech_parent_tot_emp_cont,
    b.ech_parent_industry,
    b.ech_sub_annual_sales_usd,
    b.ech_sub_tot_emp_cont,
    b.ech_sub_industry, 
    c.dme_csm_id,
    c.dme_csm_name,
    c.dme_csm_mgr_id,
    c.dme_csm_mgr_name,
    c.dx_csm_id,
    c.dx_csm_name,
    c.dx_csm_mgr_id,
    c.dx_csm_mgr_name,
    c.sign_csm_id,
    c.sign_csm_name,
    c.sign_csm_mgr_id,
    c.sign_csm_mgr_name,
    concat('https://adobe.my.salesforce.com/', d.sfdcaccounts) as sfdc_account_id
    from 
    (
    select  
    org_id,
    org_country,
    end_user_id,
    end_user_name,
    end_user_id_market_segment,
    dme_acct_segment,
    ech_parent_id,
    ech_parent_name,
    ech_parent_country_code,
    ech_parent_country_name,
    ech_parent_market_area_code,
    ech_parent_market_area_description,
    ech_parent_region_code,
    ech_parent_region_description,
    ech_parent_geo_code,
    ech_parent_geo_description,
    ech_sub_id,
    ech_sub_name,
    ech_sub_country_code,
    ech_parent_annual_sales_usd,
    ech_parent_tot_emp_cont,
    ech_parent_industry,
    ech_sub_annual_sales_usd,
    ech_sub_tot_emp_cont,
    ech_sub_industry
    from b2b.ecp_ecc_org_map 
    where as_of_date='{RUN_DATE}' 
    ) b 
    LEFT JOIN 
    (select
    sub_std_name_key,
    child_country,
    MAX(case when UPPER(cvg_bu)= 'DME' and emp_id is not null  then emp_ldap else null end ) as dme_csm_id,
    MAX(case when UPPER(cvg_bu)= 'DX' and emp_id is not null  then emp_ldap else null end ) as dx_csm_id,
    MAX(case when UPPER(cvg_bu)= 'SIGN' and emp_id is not null  then emp_ldap else null end) as sign_csm_id,
    MAX(case when UPPER(cvg_bu)= 'DME' and emp_id is not null  then emp_name else null end  ) as dme_csm_name,
    MAX(case when UPPER(cvg_bu)= 'DX' and emp_id is not null  then emp_name else null end ) as dx_csm_name,
    MAX(case when UPPER(cvg_bu)= 'SIGN' and emp_id is not null  then emp_name else null end ) as sign_csm_name,
    MAX(case when UPPER(cvg_bu)= 'DME' and emp_id is not null  then flm_ldap else null end  ) as dme_csm_mgr_id,
    MAX(case when UPPER(cvg_bu)= 'DX' and emp_id is not null  then flm_ldap else null end ) as dx_csm_mgr_id,
    MAX(case when UPPER(cvg_bu)= 'SIGN' and emp_id is not null  then flm_ldap else null end ) as sign_csm_mgr_id,
    MAX(case when UPPER(cvg_bu)= 'DME' and emp_id is not null  then flm_name else null end ) as dme_csm_mgr_name,
    MAX(case when UPPER(cvg_bu)= 'DX' and emp_id is not null  then flm_name else null end ) as dx_csm_mgr_name,
    MAX(case when UPPER(cvg_bu)= 'SIGN' and emp_id is not null  then flm_name else null end ) as sign_csm_mgr_name
    From b2b.tbl_anaplanhierarchymapping a where emp_id is not null --and emp_id <> 'NULL'
    AND a.as_of_date IN (SELECT MAX(as_of_date) FROM b2b.tbl_anaplanhierarchymapping)
    group by
    sub_std_name_key,
    child_country
    ) c
    on b.ech_sub_id = c.sub_std_name_key
    and upper(b.org_country) = upper(c.child_country)
    left join
    (
    select
    cast(eccid as bigint) as eccid,
    sfdcaccounts
    from b2b.vw_td_ddomeaccountmastereccsnapshot a
    where a.sfdcaccounts is not null and a.sfdcaccounts <> ''
    and a.snapshotdate IN (SELECT max(snapshotdate) FROM b2b.vw_td_ddomeaccountmastereccsnapshot)
    group by
    cast(eccid as bigint) ,
    sfdcaccounts
    ) as d
    on cast(b.end_user_id as bigint) = d.eccid
    ) fnl
    GROUP BY 
    org_id,
    org_country
    ) mp
    on a.org_id = mp.org_id """.format(RUN_DATE = RUN_DATE))

             else:
                 pass
             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()