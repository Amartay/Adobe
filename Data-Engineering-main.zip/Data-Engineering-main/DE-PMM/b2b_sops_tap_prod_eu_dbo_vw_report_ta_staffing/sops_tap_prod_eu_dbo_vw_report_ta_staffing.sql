-- Databricks notebook source
CREATE EXTERNAL TABLE IF NOT EXISTS b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing_on_prem (
  `position_id` string, 
  `fiscal_year` string, 
  `employee_id` string, 
  `employee_name` string, 
  `employee_ldap` string, 
  `mgr_position_id` string, 
  `mgr_employee_id` string, 
  `mgr_employee_name` string, 
  `mgr_employee_ldap` string, 
  `position_type` string, 
  `anaplan_rh_id` string, 
  `reg_hierarchy_id` string, 
  `global_region` string, 
  `region` string, 
  `sub_region` string, 
  `major_territory` string, 
  `territory` string, 
  `sub_territory` string, 
  `area` string, 
  `role_type` string, 
  `product_group_id` string, 
  `product_group` string, 
  `geo_group_id` string, 
  `geo_group` string, 
  `rep_segment` string, 
  `has_coverage_flag` string, 
  `position_creation_date` string, 
  `pos_fy_key` string)
PARTITIONED BY ( 
  `as_of_date` string)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe' 
WITH SERDEPROPERTIES ( 
  'field.delim'='\u0001', 
  'serialization.format'='\u0001') 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b.db/sops_tap_prod_eu_dbo_vw_report_ta_staffing_on_prem';





CREATE EXTERNAL TABLE IF NOT EXISTS b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing (
  `position_id` BIGINT, 
  `fiscal_year` INT, 
  `employee_id` BIGINT, 
  `employee_name` string, 
  `employee_ldap` string, 
  `mgr_position_id` BIGINT, 
  `mgr_employee_id` BIGINT, 
  `mgr_employee_name` string, 
  `mgr_employee_ldap` string, 
  `position_type` string, 
  `anaplan_rh_id` BIGINT, 
  `reg_hierarchy_id` string, 
  `global_region` string, 
  `region` string, 
  `sub_region` string, 
  `major_territory` string, 
  `territory` string, 
  `sub_territory` string, 
  `area` string, 
  `role_type` string, 
  `product_group_id` BIGINT, 
  `product_group` string, 
  `geo_group_id` BIGINT, 
  `geo_group` string, 
  `rep_segment` string, 
  `has_coverage_flag` string, 
  `position_creation_date` DATE, 
  `pos_fy_key` string)
PARTITIONED BY ( 
  `as_of_date` DATE)
STORED as parquet
LOCATION
  'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b.db/sops_tap_prod_eu_dbo_vw_report_ta_staffing';
