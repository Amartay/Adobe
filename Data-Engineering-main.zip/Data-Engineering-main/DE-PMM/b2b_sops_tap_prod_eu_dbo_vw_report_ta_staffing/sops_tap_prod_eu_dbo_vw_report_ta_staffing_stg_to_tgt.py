# Databricks notebook source
from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys


class main:
    def __init__(self):
        try:
            spark = (
                SparkSession.builder.enableHiveSupport()
                .config("hive.exec.dynamic.partition", "true")
                .config("hive.exec.dynamic.partition.mode", "nonstrict")
                .config("hive.exec.max.dynamic.partitions", "10000")
                .getOrCreate()
            )
            log4j = spark._jvm.org.apache.log4j
            log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
            spark.sql("SET hive.warehouse.data.skiptrash=true;")
            spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
            spark.conf.set("spark.sql.cbo.enabled", True)
            spark.conf.set("spark.sql.cbo.join reorder.enabled", True)
            spark.sql("set spark.sql.parquet.enableVectorizedReader=false")
            spark.sql("set spark.sql.sources.partitionOverwriteMode=dynamic")
            spark.sql(
                "set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false"
            )
            # spark.sql("SET spark.databricks.delta.formatCheck.enabled=false")
            spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            spark.sql("set spark.sql.adaptive.enabled=false")

            dbutils.widgets.text("TGT_TBL", "")
            dbutils.widgets.text("STG_TBL", "")
            dbutils.widgets.text("Custom_Settings", "")

            TGT_TBL = dbutils.widgets.get("TGT_TBL")
            STG_TBL = dbutils.widgets.get("STG_TBL")

            Settings = dbutils.widgets.get("Custom_Settings")
            Set_list = Settings.split(",")
            if len(Set_list) > 0:
                for i in Set_list:
                    if i != "":
                        print("spark.sql(+i+)")
                        spark.sql("""{i}""".format(i=i))
            spark.sql("""MSCK REPAIR TABLE b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing_on_prem""")
            spark.sql(
                """ insert overwrite {TGT_TBL} PARTITION (as_of_date)
             SELECT CAST(position_id AS BIGINT) AS position_id , CAST(fiscal_year AS INT) AS fiscal_year , CAST(employee_id AS BIGINT) AS employee_id , CAST(employee_name AS STRING) AS employee_name , CAST(employee_ldap AS STRING) AS employee_ldap , CAST(mgr_position_id AS BIGINT) AS mgr_position_id , CAST(mgr_employee_id AS BIGINT) AS mgr_employee_id , CAST(mgr_employee_name AS STRING) AS mgr_employee_name , CAST(mgr_employee_ldap AS STRING) AS mgr_employee_ldap , CAST(position_type AS STRING) AS position_type , CAST(anaplan_rh_id AS BIGINT) AS anaplan_rh_id , CAST(reg_hierarchy_id AS STRING) AS reg_hierarchy_id , CAST(global_region AS STRING) AS global_region , CAST(region AS STRING) AS region , CAST(sub_region AS STRING) AS sub_region , CAST(major_territory AS STRING) AS major_territory , CAST(territory AS STRING) AS territory , CAST(sub_territory AS STRING) AS sub_territory , CAST(area AS STRING) AS area , CAST(role_type AS STRING) AS role_type , CAST(product_group_id AS BIGINT) AS product_group_id , CAST(product_group AS STRING) AS product_group , CAST(geo_group_id AS BIGINT) AS geo_group_id , CAST(geo_group AS STRING) AS geo_group , CAST(rep_segment AS STRING) AS rep_segment , CAST(has_coverage_flag AS STRING) AS has_coverage_flag , CAST(position_creation_date AS DATE) AS position_creation_date , CAST(pos_fy_key AS STRING) AS pos_fy_key , CAST(as_of_date AS DATE) AS as_of_date from {STG_TBL} """.format(
                    TGT_TBL=TGT_TBL, STG_TBL=STG_TBL
                )
            )

            try:
                dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                print("exception:", e)
        except Exception as e:
            raise e  # dbutils.notebook.exit(e)


if __name__ == "__main__":
    main()