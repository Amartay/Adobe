# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             #dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             #RUN_DATE = dbutils.widgets.get("RUN_DATE")
             #B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
             #RUN_DATE = B2B_RUN_DATE

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)

             spark.sql(""" CREATE OR REPLACE TEMP FUNCTION ORIGINAL as 'acom.adobe.com.hiveUdfs.LKP_ORIGINAL_ID' USING JAR 'abfs://artifacts@ariaprime.dfs.core.windows.net/common_artifacts/hiveUdfs-0.0.1-SNAPSHOT-jar-with-dependencies.jar'; """)

             spark.sql(""" INSERT OVERWRITE TABLE b2b.b2b_ax_app_usage partition(as_of_date)
select 
del.org_id ,
del.org_name,
del.org_geo_description ,
del.org_market_area_description,
del.org_country ,
del.org_region_description,
del.cloud_type,
del.offering_type, 
del.market_segment, 
del.offer_id,
del.jem_contract_id,
del.offering_name, 
del.end_user_id ,
orgmap.end_user_name,
del.ech_sub_name ,
del.ech_sub_industry ,
del.ech_sub_id ,
del.ech_parent_name ,
del.ech_parent_id ,
del.dme_acct_segment ,
del.contract_type ,
del.product_segment,
del.entitlement,
sum(del.provisioned) as provisioned,
sum(del.delegated) as delegated,
CAST(SUM(CAST(del.delegated AS DOUBLE))*1.0/CASE WHEN SUM(CAST(del.provisioned AS DOUBLE)) = 0 THEN 1 ELSE SUM(CAST(del.provisioned AS DOUBLE)) END * 100.0 AS DECIMAL(16,2)) AS deployment_rate,


-- ADOBE EXPRESS
sum(express_delegated) as express_delegated,
sum(express_activated) as express_activated,
sum(express_provisioned) as express_provisioned,
sum(express_rmalu) as express_rmalu,
sum(express_qalu) as express_qalu,
sum(express_malu) as express_malu,

--FIREFLY_AX_WEB
sum(ff_ax_activated) as ff_ax_activated,
sum(ff_ax_rmalu) as ff_ax_rmalu,
sum(ff_ax_qalu) as ff_ax_qalu,
sum(ff_ax_malu) as ff_ax_malu,

--usg.offer_id, -- To be removed
del.contract_end_date,
aem.has_aem_product,
del.directory_sync_services, --B2BDME-2527
--MAX(num_directory_sync_enabled) AS num_directory_sync_enabled, -- Removing this field
CASE WHEN del.directory_sync_services is not null THEN 'Y' ELSE 'N' END AS directory_sync_enabled, --B2BDME-2527
spark_service_enabled,
--MAX(num_spark_service_enabled) AS num_spark_service_enabled,
sum(num_spark_service_enabled) as num_spark_service_enabled,
YEAR(CAST(del.contract_end_date AS DATE)) AS renewal_fy,
qtr.fiscal_yr_and_qtr_desc AS renewal_fq,
CASE 
    WHEN (arr_info.net_arr='' OR arr_info.net_arr IS NULL) THEN 0 
    WHEN entitlement IN ('Express Trial','Express Free') THEN 0  
ELSE arr_info.net_arr END AS ending_arr,
CASE WHEN entitlement='Express Premium' THEN NVL(arr_info.net_arr,0) ELSE 0 END AS express_arr,
'' as domain,
CAST(del.as_of_date AS DATE) AS as_of_date
from
-- org_pro_del table
(
select 
org_id,
org_name,
org_geo_description,
org_country,
org_region_description,
org_market_area_description,
market_segment,
offer_id, -- to remove the field
jem_contract_id,
offering_type,
offering_name,
--cc_pro,
directory_sync_services, --B2BDME-2527
cloud_type,
product_segment,
end_user_id,
ech_sub_industry,
ech_sub_id,
ech_sub_name,
ech_parent_name,
ech_parent_id,
CASE
	WHEN mm_flag = 'Y' THEN 'MM'
	ELSE dme_acct_segment
END AS dme_acct_segment,
contract_type,
CASE WHEN offering_type IN ('SINGLE_APP', 'ALL_APPS','SUBST') THEN 'CC License'
     WHEN lower(offering_name) like  '%express%trial%' THEN 'Express Trial'
     WHEN lower(offering_name) like  '%express%firefly%' THEN 'Express Premium'
     WHEN lower(offering_name) like  '%free%membership%'
	 or lower(offering_name) like '%express%' or lower(offering_type) = 'ax' THEN 'Express Free' -- Modified to include offering_type AX 2023-09-18
     ELSE 'No Entitlement'
END AS entitlement,

max(contract_end_date) as contract_end_date,
sum(local_licensed_qty) as provisioned,
sum(delegated) as delegated,
as_of_date
from b2b.b2b_org_pro_del
--b2b_tmp.b2b_org_pro_del_test_B2BDME_2527_4557_20230922
where 
--org_id='728DBC61583632060A495DE7' and 
as_of_Date='{B2B_RUN_DATE}' and (contract_end_date >= date_sub(as_of_date,90) or contract_end_date='<UNKNOWN>' or contract_end_date is null)
group by 
org_id,
org_name,
org_geo_description,
org_market_area_description,
org_country,
org_region_description,
market_segment,
offer_id, -- To remove the field
jem_contract_id,
offering_type,
offering_name,
--cc_pro,
directory_sync_services, --B2BDME-2527
cloud_type,
product_segment,
end_user_id,
ech_sub_industry,
ech_sub_id,
ech_sub_name,
ech_parent_name,
ech_parent_id,
CASE
	WHEN mm_flag = 'Y' THEN 'MM'
	ELSE dme_acct_segment
END,
contract_type,
CASE WHEN offering_type IN ('SINGLE_APP', 'ALL_APPS','SUBST') THEN 'CC License'
     WHEN lower(offering_name) like  '%express%trial%' THEN 'Express Trial'
     WHEN lower(offering_name) like  '%express%firefly%' THEN 'Express Premium'
     WHEN lower(offering_name) like  '%free%membership%'
	 or lower(offering_name) like '%express%' or lower(offering_type) = 'ax' THEN 'Express Free' -- Modified to include offering_type AX 2023-09-18
     ELSE 'No Entitlement'
END,
as_of_date
) del

left join 
-- b2b_app_usage table data
(
select 
org_id ,
offering_type, 
jem_contract_id,
contract_type,
product_segment, -- NEED TO CHECK ON THIS FIELD
offer_id,
COLLECT_SET(express_delegated)[0] AS express_delegated,
COLLECT_SET(express_activated)[0] AS express_activated,
COLLECT_SET(express_provisioned)[0] AS express_provisioned,
COLLECT_SET(express_rmalu)[0] AS express_rmalu,
COLLECT_SET(express_qalu)[0] AS express_qalu,
COLLECT_SET(express_malu)[0] AS express_malu,

COLLECT_SET(ff_ax_activated)[0] AS ff_ax_activated,
COLLECT_SET(ff_ax_rmalu)[0] AS ff_ax_rmalu,
COLLECT_SET(ff_ax_qalu)[0] AS ff_ax_qalu,
COLLECT_SET(ff_ax_malu)[0] AS ff_ax_malu,

as_of_date
from 
(
select 
DISTINCT 
org_id ,
offering_type,  
jem_contract_id, 
contract_type ,
CASE
		WHEN UPPER(offering_name) LIKE '%SUBSTANCE%' THEN 'SUBSTANCE'
		WHEN UPPER(offering_name) LIKE '%PDF%SERVICES%' THEN 'ACROBAT'
		WHEN UPPER(offering_name) LIKE '%DOCUMENT%CLOUD%' THEN 'ACROBAT'
		WHEN (UPPER(offering_name) LIKE '%ACROBAT%' AND UPPER(offering_name) NOT LIKE '%ACROBAT%SIGN%') OR UPPER(offering_name) LIKE '%ACROBAT%E-SIGN%' THEN 'ACROBAT'
		WHEN UPPER(offering_name) LIKE '%ADOBE%SIGN%' OR (UPPER(offering_name) LIKE '%ACROBAT%SIGN%' AND UPPER(offering_name) NOT LIKE '%ACROBAT%E-SIGN%') THEN 'SIGN'
		WHEN (UPPER(offering_name) LIKE '%STOCK%' --OR product_name = 'CTSK' --NEED TO CHECK ON THIS CONDITION
              ) THEN 'STOCK'
        WHEN regexp_like(UPPER(offering_name),'ADOBE EXPRESS|SPARK|CREATIVE CLOUD SHARED DEVICE ACCESS|CREATIVE CLOUD EXPRESS') THEN 'AX' --B2BDME-4557
		ELSE 'CC'
END AS product_segment,
offer_id,

-- ADOBE EXPRESS

CASE WHEN app_name='ADOBE EXPRESS' THEN  app_users_delegated END AS express_delegated,
CASE WHEN app_name='ADOBE EXPRESS' THEN  app_users_activated END AS express_activated,
CASE WHEN app_name='ADOBE EXPRESS' THEN  app_seats_provisioned END AS express_provisioned,
CASE WHEN app_name='ADOBE EXPRESS' THEN  app_rmalu END AS express_rmalu,
CASE WHEN app_name='ADOBE EXPRESS' THEN  app_qalu END AS express_qalu,
CASE WHEN app_name='ADOBE EXPRESS' THEN  app_malu END AS express_malu,

CASE WHEN app_name='FIREFLY_AX' THEN  app_users_activated END AS ff_ax_activated,
CASE WHEN app_name='FIREFLY_AX' THEN  app_rmalu END AS ff_ax_rmalu,
CASE WHEN app_name='FIREFLY_AX' THEN  app_qalu END AS ff_ax_qalu,
CASE WHEN app_name='FIREFLY_AX' THEN  app_malu END AS ff_ax_malu,

as_of_date
from 
b2b.b2b_app_usage
where 
as_of_Date='{B2B_RUN_DATE}' 
) a  
group by 
org_id ,
offering_type, 
jem_contract_id, 
contract_type,
product_segment, --NEED TO CHECK ON THIS CONDITION
offer_id,
as_of_date
) usg
on del.org_id=usg.org_id 
-- and del.offering_type=usg.offering_type
-- and del.product_segment=usg.product_segment
and del.jem_contract_id=usg.jem_contract_id
and del.offer_id=usg.offer_id
and del.as_of_date=usg.as_of_date

-- aem_product 
left join 
(

	SELECT 
	org_id,
    CASE WHEN MAX(COALESCE(has_aem_product, '0')) = '1' THEN 'Y' ELSE 'N' END AS has_aem_product	
	FROM enterprise.t2e_cct_cce_unified_orgs_with_domain
	WHERE snapshot_date = (SELECT MAX(snapshot_date) FROM enterprise.t2e_cct_cce_unified_orgs_with_domain) -- This table has only one single date
   GROUP BY org_id
) aem
on del.org_id=aem.org_id

left join 
(	
       select org_id,offer_id,'Y' AS spark_service_enabled,	sum(num_users_services_enabled) as num_spark_service_enabled from b2b.service_enabled where asofdate='{B2B_RUN_DATE}' and lower(service_name) like '%spark%'
       group by org_id,offer_id

) sprk_serv
on del.org_id=sprk_serv.org_id
and del.offer_id=sprk_serv.offer_id

-- fiscal quarter fields

LEFT JOIN ids_coredata.dim_date qtr 
ON CAST(SUBSTR(qtr.calendar_date, 1, 10) AS DATE) = CAST(CASE WHEN del.contract_end_date LIKE '%UNKNOWN%' THEN '2099-12-31' ELSE del.contract_end_date END AS DATE) 

-- arr_info 

left join
(
    SELECT orgenduser.org_id,
           arr.as_of_date,
           arr.product_segment,
           arr.offering_type,
           SUM(CAST(fwk_end_arr AS BIGINT)) AS net_arr
   FROM 
   (
				SELECT  orgs.org_id, 
                orgs.product_segment, 
                orgs.offering_type,
                orgmap.end_user_id AS end_user_id, 
                --UPPER(orgmap.end_user_name) AS end_user_name,
                MAX(end_user_name) AS end_user_name,
                orgmap.ech_sub_id AS ech_sub_id,
                orgmap.ech_sub_name AS ech_sub_name,
                orgs.as_of_date
				FROM b2b.b2b_org_pro_del orgs 
				LEFT JOIN 
				(SELECT DISTINCT org_id, as_of_date, end_user_id, end_user_name, ech_sub_id, ech_sub_name FROM b2b.ecp_ecc_org_map 
				WHERE as_of_date = ('{B2B_RUN_DATE}')) orgmap 
				ON orgmap.org_id = orgs.org_id AND orgs.as_of_date = orgmap.as_of_date
				where orgs.as_of_Date='{B2B_RUN_DATE}' and (orgs.contract_end_date >= date_sub(orgs.as_of_date,90) or orgs.contract_end_date='<UNKNOWN>' or orgs.contract_end_date is null)
				GROUP BY 
				orgs.org_id, 
                orgs.product_segment, 
                orgs.offering_type, 
                orgmap.end_user_id, 
                orgmap.ech_sub_id,
                orgmap.ech_sub_name,
                orgs.as_of_date

   ) orgenduser 
   INNER JOIN b2b.b2b_arr arr
   ON orgenduser.end_user_id = arr.end_user_id 
   AND orgenduser.as_of_date = arr.as_of_date 
   AND orgenduser.product_segment = arr.product_segment 
   AND orgenduser.offering_type = arr.offering_type 
   WHERE arr.as_of_date='{B2B_RUN_DATE}'
   GROUP BY 
   orgenduser.org_id,
           arr.as_of_date,
           arr.product_segment,
           arr.offering_type
) arr_info
on del.org_id=arr_info.org_id and
del.product_segment=arr_info.product_segment and 
del.offering_type=arr_info.offering_type

left join 
(SELECT org_id,max(end_user_name) as end_user_name FROM b2b.ecp_ecc_org_map WHERE as_of_date ='{B2B_RUN_DATE}' group by org_id) orgmap 
on del.org_id=orgmap.org_id 
group by 
del.org_id ,
del.org_name,
del.org_geo_description ,
del.org_country ,
del.org_region_description,
del.org_market_area_description,
del.cloud_type,
del.offering_type, 
del.market_segment,
del.offer_id,
del.jem_contract_id, 
del.offering_name,
del.end_user_id ,
orgmap.end_user_name,
del.ech_sub_name ,
del.ech_sub_industry ,
del.ech_sub_id ,
del.ech_parent_name ,
del.ech_parent_id ,
del.dme_acct_segment ,
del.contract_type ,
del.product_segment,
del.entitlement,
del.contract_end_date,
aem.has_aem_product,
del.directory_sync_services, --B2BDME-2527
spark_service_enabled,
YEAR(CAST(del.contract_end_date AS DATE)),
qtr.fiscal_yr_and_qtr_desc,
CASE 
    WHEN (arr_info.net_arr='' OR arr_info.net_arr IS NULL) THEN 0 
    WHEN entitlement IN ('Express Trial','Express Free') THEN 0  
ELSE arr_info.net_arr END,
CASE WHEN entitlement='Express Premium' THEN NVL(arr_info.net_arr,0) ELSE 0 END,
CAST(del.as_of_date AS DATE) 

UNION ALL

-- FOR CCI PAID AND CCI FREE RECORDS HAVING SAME B2B Domains matched
select 
org_id, 
org_name ,
org_geo_description ,
org_market_area_description ,
org_country ,
org_region_description ,
cloud_type ,
offering_type, 
market_segment, 
offer_id,
jem_contract_id,
offering_name, 
end_user_id ,
end_user_name, 
ech_sub_name ,
ech_sub_industry ,
ech_sub_id ,
ech_parent_name ,
ech_parent_id ,
dme_acct_segment ,
contract_type ,
product_segment, 
entitlement ,
CAST(IF(provisioned='',null,provisioned) as BIGINT) as provisioned,
CAST(IF(delegated='',null,delegated)  AS BIGINT) as delegated,
CAST(IF(deployment_rate='',null,deployment_rate)  AS DECIMAl(16,2)) as deployment_rate,
CAST(IF(express_delegated='',null,express_delegated)  AS BIGINT) as express_delegated,
express_activated ,
CAST(IF(express_provisioned='',null,express_provisioned)  AS BIGINT) as express_provisioned,
express_rmalu ,
express_qalu ,
express_malu ,
CAST(IF(ff_ax_activated='',null,ff_ax_activated) AS BIGINT) as ff_ax_activated,
CAST(IF(ff_ax_rmalu='',null,ff_ax_rmalu) AS BIGINT) as ff_ax_rmalu, 
CAST(IF(ff_ax_qalu='',null,ff_ax_qalu) AS BIGINT) as ff_ax_qalu, 
CAST(IF(ff_ax_malu='',null,ff_ax_malu) AS BIGINT) as ff_ax_malu,
contract_end_date,
has_aem_product ,
CAST(IF(directory_sync_services='',null,directory_sync_services)  AS BIGINT) as directory_sync_services,
--CAST(IF(num_directory_sync_enabled='',null,num_directory_sync_enabled)  AS BIGINT) as num_directory_sync_enabled, -- Removing the field
directory_sync_enabled ,
spark_service_enabled ,
CAST(IF(num_spark_service_enabled='',null,num_spark_service_enabled)  AS BIGINT) as num_spark_service_enabled,
renewal_fy ,
renewal_fq ,
CAST(IF(ending_arr='',null,ending_arr)  AS BIGINT) as ending_arr,
CAST(IF(express_arr='',null,express_arr)  AS BIGINT) as express_arr,
domain,
CAST(as_of_date AS DATE) AS as_of_date
from 
(
select 
d.org_id,
del.org_name,
del.org_geo_description,
del.org_country,
del.org_region_description,
del.org_market_area_description,
del.market_segment,
del.end_user_id,
del.end_user_name,
del.ech_sub_industry,
del.ech_sub_id,
del.ech_sub_name,
del.ech_parent_name,
del.ech_parent_id,
del.dme_acct_segment,
del.contract_type,
del.contract_end_date,
'' AS offer_id,
'' AS jem_contract_id,
'' AS offering_name,
'OTHERS' AS offering_type,
'OTHERS' AS cloud_type,
'OTHERS' AS product_Segment,
'' AS has_aem_product,
'' AS ending_arr,
'' AS provisioned,
'' AS delegated,
'' AS deployment_rate,
'' AS express_assigned,
'' AS express_provisioned,
'' AS ff_ax_activated,
'' AS ff_ax_rmalu, 
'' AS ff_ax_qalu, 
'' AS ff_ax_malu,
'' AS directory_sync_services,
--'' AS num_directory_sync_enabled,
'' AS directory_sync_enabled ,
'' AS spark_service_enabled,
'' AS num_spark_service_enabled,
'' AS express_arr,
--CASE WHEN express.sku_contract_type_primary='PAID' THEN 'CCI Paid' 
--     WHEN express.sku_contract_type_primary='FREE' THEN 'CCI Free' 
--ELSE express.sku_contract_type_primary END AS entitlement,
express.entitlement,
del.renewal_fq,
YEAR(CAST(del.contract_end_date AS DATE)) AS renewal_fy,
'' AS express_delegated,
SUM(CASE WHEN express.logged_in_once = 'Y' THEN 1 ELSE 0 END) express_activated,
SUM(CASE WHEN express.ax_user_rmau = 'Y' THEN 1 ELSE 0 END) express_rmalu,
SUM(CASE WHEN express.ax_user_qau = 'Y' THEN 1 ELSE 0 END) express_qalu,
SUM(CASE WHEN express.ax_user_mau = 'Y' THEN 1 ELSE 0 END) express_malu,
concat_ws('|',collect_list(DISTINCT express.domain)) AS domain,
'{B2B_RUN_DATE}' AS as_of_date
FROM 
(
SELECT 
  entitlement,
  email_id,
  domain,
  CASE WHEN MAX(ax_user_28_days_login) = 'Y' THEN 'Y' ELSE 'N' END AS ax_user_mau,
  CASE WHEN MAX(ax_user_28_days_login) = 'Y' AND MAX(ax_user_28_56_days_login) = 'Y' THEN 'Y' ELSE 'N' END AS ax_user_rmau,
  CASE WHEN MAX(ax_user_90_days_login) = 'Y' THEN 'Y' ELSE 'N' END AS ax_user_qau,
  CASE WHEN MAX(logged_in_once_login) = 'Y' THEN 'Y' ELSE 'N' END AS logged_in_once
FROM 

(
select
distinct 
  CASE WHEN sprk.member_guid=ocf.member_guid THEN ocf.entitlement ELSE 'CCI Free' END AS entitlement,
  sprk.member_guid,
  LOWER(profile.pers_email) AS email_id,
  LOWER(SPLIT(profile.pers_email, '@')[1]) AS domain,
CASE WHEN CAST(sprk.event_date AS DATE) >= DATE_ADD(cast('{B2B_RUN_DATE}' as date),-27) AND CAST(sprk.event_date as date) <= CAST('{B2B_RUN_DATE}' AS DATE) THEN 'Y' ELSE 'N' END AS ax_user_28_days_login,
CASE WHEN CAST(sprk.event_date AS DATE) BETWEEN DATE_ADD(cast('{B2B_RUN_DATE}' as date),-56) AND DATE_ADD(cast('{B2B_RUN_DATE}' as date),-28) THEN 'Y' ELSE 'N' END AS ax_user_28_56_days_login,
CASE WHEN CAST(sprk.event_date AS DATE) >= DATE_ADD(cast('{B2B_RUN_DATE}' as date),-90) AND CAST(sprk.event_date AS DATE) <= CAST('{B2B_RUN_DATE}' AS DATE) THEN 'Y' ELSE 'N' END AS ax_user_90_days_login,
CASE WHEN CAST(sprk.event_date AS DATE) < CAST('{B2B_RUN_DATE}' AS DATE) THEN 'Y' ELSE 'N' END AS logged_in_once_login
--row_number() over (partition by profile.user_guid order by sprk.event_date desc) as row_num
from

(

SELECT DISTINCT c.member_guid,b.event_date FROM spark.spark_active_users_b b 
inner join
(SELECT DISTINCT user_guid,original_guid AS member_guid FROM spark.spark_user_guid_map) c 
ON b.user_guid=c.user_guid
WHERE b.event_date >= date_add('{B2B_RUN_DATE}',-1094) and b.event_date<='{B2B_RUN_DATE}'
   
-- Added on 08/24 for B2BDME-4283 -- START
UNION ALL

SELECT DISTINCT UPPER(ORIGINAL(event_user_guid,'guid')) as member_guid, event_date
FROM  ccex.ccex_active_users_b
WHERE --event_user_guid NOT LIKE '%-%' and 
event_date >= date_add('{B2B_RUN_DATE}',-1094) and event_date<='{B2B_RUN_DATE}'
) sprk

left JOIN ocf_analytics.dim_user_lvt_profile profile ON LOWER(TRIM(sprk.member_guid)) = LOWER(TRIM(profile.user_guid))
 
left join 
(
Select member_guid,
CASE 
    WHEN product_name = 'CCEX' THEN 'CCI Paid - Express'
    WHEN lower(subs_offer)<>'acrobat cc' THEN 'CCI Paid - AA/SA'
    ELSE 'CCI Free'
END AS entitlement 
FROM ocf_analytics.scd_member_cc where --(product_name = 'CCEX' or lower(subs_offer) = 'cci complete') -- cci complete, CCE ALL APPS -- ADD single app aswell AND
paid_or_free = 'PAID'
and subscription_type = 'IN' and effective_till_date >= '{B2B_RUN_DATE}'
group by member_guid,
CASE 
    WHEN product_name = 'CCEX' THEN 'CCI Paid - Express'
    WHEN lower(subs_offer)<>'acrobat cc' THEN 'CCI Paid - AA/SA'
    ELSE 'CCI Free'
END
) ocf
on sprk.member_guid=ocf.member_guid

-- Removing the b2b users list using the latest snapshot data
  LEFT JOIN 
  b2b.b2b_users users
  on sprk.member_guid=users.member_guid
  and users.as_of_date='{B2B_RUN_DATE}'
  where users.member_guid is null
) app

GROUP BY 
entitlement,
email_id,
domain
) express 
join 
  (select max(dom.org_id) as org_id,lower(dom.domain) as domain from b2b.b2b_domains dom  
   inner join 
  (select org_id from b2b.b2b_org_pro_del 
  where as_of_date='{B2B_RUN_DATE}' and (contract_end_date >= date_sub(as_of_date,90) or contract_end_date='<UNKNOWN>' or contract_end_date is null)
   group by org_id
) org
  on dom.org_id=org.org_id
  where dom.domain is not null and dom.domain <> '' and domain_category <> '1.GENERIC'
group by lower(dom.domain) 
) d 
  on lower(trim(express.domain))=trim(d.domain)

-- To get all the b2b dimensional specific fields
left join 

(
select d.*,qtr.fiscal_yr_and_qtr_desc AS renewal_fq,orgmap.end_user_name from 
(
select * from 
( 
-- 2023-09-06 Logic is modified for CCI FREE and PAID to pick only one record at org_level for org_geo_description,org_region_description,org_market_area_description,contract_type
select 
org_id,
org_name,
org_geo_description,
org_country,
org_region_description,
org_market_area_description,
market_segment,
end_user_id,
ech_sub_industry,
ech_sub_id,
ech_sub_name,
ech_parent_name,
ech_parent_id,
CASE
	WHEN mm_flag = 'Y' THEN 'MM'
	ELSE dme_acct_segment
END AS 
dme_acct_segment,
contract_type,
min(contract_end_date) as contract_end_date,
ROW_NUMBER() OVER(PARTITION BY org_id ORDER BY min(contract_end_date) ) as rownum,
as_of_date
from b2b.b2b_org_pro_del del 
where 
as_of_Date='{B2B_RUN_DATE}' and (contract_end_date >= date_sub(as_of_date,90) or contract_end_date='<UNKNOWN>' or contract_end_date is null)
group by org_id,org_name,org_country,org_geo_description,org_market_area_description,org_region_description,market_segment,end_user_id,ech_sub_industry,ech_sub_id,ech_sub_name,ech_parent_name,ech_parent_id,
CASE
	WHEN mm_flag = 'Y' THEN 'MM'
	ELSE dme_acct_segment
END,
contract_type,as_of_date
)b 
where b.rownum=1
) d

 LEFT JOIN ids_coredata.dim_date qtr 
 ON CAST(SUBSTR(qtr.calendar_date, 1, 10) AS DATE) = CAST(CASE WHEN d.contract_end_date LIKE '%UNKNOWN%' THEN '2099-12-31' ELSE d.contract_end_date END AS DATE) 
 left join 
 (SELECT org_id,max(end_user_name) as end_user_name FROM b2b.ecp_ecc_org_map WHERE as_of_date ='{B2B_RUN_DATE}' group by org_id) orgmap 
 on d.org_id=orgmap.org_id 
) del
on d.org_id=del.org_id
group by d.org_id,
del.org_name,
del.org_geo_description,
del.org_country,
del.org_region_description,
del.org_market_area_description,
del.market_segment,
del.end_user_id,
del.end_user_name,
del.ech_sub_industry,
del.ech_sub_id,
del.ech_sub_name,
del.ech_parent_name,
del.ech_parent_id,
del.dme_acct_segment,
del.contract_type,
del.contract_end_date,
--CASE WHEN express.sku_contract_type_primary='PAID' THEN 'CCI Paid' 
--     WHEN express.sku_contract_type_primary='FREE' THEN 'CCI Free' 
--ELSE express.sku_contract_type_primary END,
express.entitlement,
del.renewal_fq,
YEAR(CAST(del.contract_end_date AS DATE)),
del.as_of_date
)a """.format(B2B_RUN_DATE = B2B_RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()