# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" use b2b """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.execution.engine = mr """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" drop table if exists b2b_stg.frl_data """)
             spark.sql(""" create table b2b_stg.frl_data as
select 
b.org_id,
b.org_name,
b.market_segment,
b.contract_offer_type,
case when b.cloud_type='DCE+CCE' then 'CCE+DCE' else b.cloud_type end as cloud_type,
b.country,
case when b.country='<UNKNOWN>' then '<UNKNOWN>' else cntry.geo_description end as geo,
a.operating_mode,
cast(a.number_of_devices as int),
b.pro_membership_count,
'{RUN_DATE}' as as_of_date
from 
	(
	 select
         org_id,
         org_name,
         market_segment,
         contract_offer_type,
         country,
         concat_ws('+',collect_list(cloud_type)) as cloud_type,
	 sum(pro_membership_count) as pro_membership_count
         from
                     (
			select
                	cce.org_id,
                	cce.org_name,
                	cce.market_segment,
                	cce.contract_offer_type,
			cce.cloud_type,
                	cce.country,
			sum(cce.pro_membership_count) as pro_membership_count
                	from enterprise.fact_cce_membership_count cce
                	where ucase(cce.offering_name) like '%RESTRICTED%' and cce.is_valid='Y' and cce.contract_end_date>current_date
			group by
			cce.org_id,
                        cce.org_name,
                        cce.market_segment,
                        cce.contract_offer_type,
                        cce.cloud_type,
                        cce.country
                	union all
                	select
                	dce.org_id,
                	dce.org_name,
                	dce.market_segment,
                	dce.contract_offer_type,
			dce.cloud_type,
                	dce.country,
			sum(dce.pro_membership_count) as pro_membership_count
                	from enterprise.fact_dce_membership_count dce
                	where ucase(dce.offering_name) like '%RESTRICTED%' and dce.is_valid='Y' and dce.contract_end_date>current_date
			group by 
			dce.org_id,
                        dce.org_name,
                        dce.market_segment,
                        dce.contract_offer_type,
                        dce.cloud_type,
                        dce.country
	 	     ) x 
            	group by 
            	org_id,
           	org_name,
            	market_segment,
            	contract_offer_type,
            	country		
	) b
left join
	(
	SELECT 
	org_id,
       	operating_mode,
       	COUNT(DISTINCT machine_id) as number_of_devices
	FROM b2b.applaunch_all a
	WHERE license_type = 'FRL'
	GROUP BY 
	org_id,
        operating_mode
	) a
on a.org_id=b.org_id
left join
ids_coredata.dim_country cntry
ON b.country=cntry.country_code_iso2
where b.org_name is not null """.format(RUN_DATE = RUN_DATE))
             spark.sql(""" insert overwrite table b2b.frl_data partition (as_of_date)
select
org_id,
org_name,
market_segment,
contract_offer_type,
cloud_type,
country,
geo,
nvl(pro_membership_count,0) as frl_provisioned_licenses,
nvl(COLLECT_SET(frl_isolated_devices_deployed)[0],0) AS frl_isolated_devices_deployed,
nvl(COLLECT_SET(frl_connected_devices_deployed)[0],0) AS frl_connected_devices_deployed,
as_of_date
from
(select
org_id,
org_name,
market_segment,
contract_offer_type,
cloud_type,
country,
geo,
case when operating_mode='FRL_ISOLATED' then number_of_devices end as frl_isolated_devices_deployed,
case when operating_mode='FRL_CONNECTED' then number_of_devices end as frl_connected_devices_deployed,
pro_membership_count,
cast(as_of_date as date) as as_of_date
from b2b_stg.frl_data 
) a
group by
org_id,
org_name,
market_segment,
contract_offer_type,
cloud_type,
country,
geo,
pro_membership_count,
as_of_date """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()