# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET mapreduce.job.maps=5 """)
             spark.sql(""" set hive.exec.reducers.max=50 """)
             spark.sql(""" set hive.exec.reducers.bytes.per.reducer=1000000 """)
             spark.sql(""" set hive.optimize.distinct.rewrite=true """)
             spark.sql(""" SET hive.map.aggr=true """)
             spark.sql(""" SET hive.merge.mapfiles=flase """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
             spark.sql(""" SET hive.exec.Compress.intermediate=true """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
             spark.sql(""" SET hive.auto.convert.join=true """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.cbo.enable=true """)
             spark.sql(""" set hive.compute.query.using.stats=true """)
             spark.sql(""" set hive.stats.fetch.column.stats=true """)
             spark.sql(""" set hive.stats.fetch.partition.stats=true """)
             spark.sql(""" set hive.exec.dynamic.partition=true """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.support.concurrency = false """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" INSERT OVERWRITE TABLE b2b.b2b_acro_deployment_adoption_funnel PARTITION(as_of_date) 
SELECT  distinct b2b_base.market_segment,
		b2b_base.org_geo_description AS geo,
		b2b_base.ech_sub_industry AS industry,
		b2b_base.org_id,
		b2b_base.org_name,
		b2b_base.ech_parent_id,
		b2b_base.ech_parent_name,
		b2b_base.lic_type,
		b2b_base.org_market_area_description AS market_area,
		b2b_base.offer_id,
                b2b_base.offering_name,
		b2b_base.contract_type AS contract_offer_type,
                b2b_base.contract_id,
		b2b_base.mm_flag,
		b2b_base.dme_acct_segment,
		b2b_base.org_id AS total_organizations_provisioned,
		cast(b2b_base.pro_membership_count as int) AS total_seats_provisioned,		
		CASE WHEN UPPER(b2b_base.service_type) = 'SHARED' THEN cast(b2b_base.pro_membership_count as int) END AS service_seats_provisioned,
		CASE WHEN UPPER(b2b_base.service_type) = 'DESKTOP' AND UPPER(b2b_base.offering_name) not like '%FEATURE%RESTRICTED%' THEN cast(b2b_base.pro_membership_count as int) END AS non_service_seats_provisioned,
		cast(b2b_base.del_membership_count as int) AS total_seats_delegated,
		CASE WHEN UPPER(b2b_base.service_type) = 'SHARED' THEN cast(b2b_base.del_membership_count as int) END AS service_seats_delegated,
		CASE WHEN UPPER(b2b_base.service_type) = 'DESKTOP' AND UPPER(b2b_base.offering_name) not like '%FEATURE%RESTRICTED%' THEN cast(b2b_base.del_membership_count as int) END AS non_service_seats_delegated,
		CASE WHEN UPPER(b2b_base.service_type) = 'DESKTOP' THEN cast(b2b_base.act_membership_count as int) END AS non_service_seats_activated,
		CASE WHEN UPPER(b2b_base.service_type) = 'SHARED' THEN cast(b2b_base.act_membership_count as int) END AS service_seats_activated,
		frl_data.org_id AS total_organizations_deployed,
		cast(frl_data_base.numerator_delegated as int) AS frl_machines_deployed,
		CASE WHEN UPPER(b2b_base.service_type) = 'DESKTOP' AND UPPER(b2b_base.offering_name) LIKE '%FEATURE%RESTRICTED%' THEN cast(b2b_base.pro_membership_count as int) END AS frl_seats_provisioned,
		CASE WHEN o365_usg.usage_rate >= 0.05 THEN o365_usg.org_id ELSE NULL END AS o365_usage_organizations,
		cast(o365_usg.o365_usage as int) as o365_usage,
		acrobat.acrobat_desktop_usage_organizations,
		acrobat.acrobat_mobile_usage_organizations,
		cast(acrobat.acrobat_desktop_usage as int) as acrobat_desktop_usage,
		cast(acrobat.acrobat_mobile_usage as int) as acrobat_mobile_usage,
		CASE 
		WHEN b2b_base.contract_type in ('TEAM_DIRECT', 'VIP') THEN b2b_base.org_id
		WHEN (b2b_base.contract_type not in ('TEAM_DIRECT', 'VIP') and serv_enabld.pdf_services_ratio >= 0.7) THEN serv_enabld.org_id 
		END AS pdf_services_available_organizations,
		CASE 
		WHEN b2b_base.contract_type in ('TEAM_DIRECT', 'VIP') THEN '100% users'
		WHEN (b2b_base.contract_type not in ('TEAM_DIRECT', 'VIP') and serv_enabld.pdf_services_ratio >= 0.7) THEN 'More Than 70% Users'
		ELSE 'Less Than 70% Users'
		END AS pdf_services_available_organizations_filter,
		CASE 
		WHEN b2b_base.contract_type in ('TEAM_DIRECT', 'VIP') THEN cast(b2b_base.del_membership_count as int)
		WHEN b2b_base.contract_type not in ('TEAM_DIRECT', 'VIP') THEN cast(serv_enabld.num_users_pdf_services_enabled as int) 
		END AS num_users_pdf_services_enabled,
		CASE WHEN pdf_serv_usage.mau_percent >= 0.05 THEN pdf_serv_usage.org_id ELSE NULL END AS pdf_services_usage_organizations,
		cast(pdf_serv_usage.services_mau as int) AS pdf_services_usage,
        b2b_base.fiscal_yr_and_qtr_desc AS fiscal_qt,
       cast('{RUN_DATE}' as date) AS as_of_date
FROM
        ( 
            SELECT distinct dep_usage.org_id,
                            dep_usage.org_name,
                            dep_usage.ech_parent_id,
                            dep_usage.ech_parent_name,
                            dep_usage.lic_type,
                            dep_usage.org_market_area_description,
                            dep_usage.market_segment,
                            dep_usage.contract_type,
                            dep_usage.jem_contract_id as contract_id,
                            dep_usage.offering_name,
                            dep_usage.offer_id,
                            dep_usage.org_geo_description,
                            dep_usage.ech_sub_industry,
                            CASE WHEN UPPER(dep_usage.offering_name) LIKE '%DESKTOP%' or UPPER(dep_usage.offering_name) like '%CHINA%' or UPPER(dep_usage.offering_name) like '%FEATURE%RESTRICTED%'
                                THEN 'DESKTOP' ELSE 'SHARED' END AS service_type,
                            dep_usage.local_licensed_qty AS pro_membership_count,
                            dep_usage.delegated AS del_membership_count,
                            dep_usage.activated AS act_membership_count,
                            ROW_NUMBER() OVER (PARTITION BY dep_usage.org_id ORDER BY CAST(UPPER(dep_usage.offering_name) NOT LIKE '%FEATURE RESTRICTED%' AS int)) AS row_num,
                            dep_usage.dme_acct_segment,
                            dep_usage.mm_flag,
                            dte.fiscal_yr_and_qtr_desc
            FROM b2b.b2b_deployment_usage dep_usage
            LEFT JOIN
            (
			    SELECT DISTINCT date_date,fiscal_yr_and_qtr_desc FROM ids_coredata.dim_date
			) dte
            ON dte.date_date=dep_usage.as_of_date
            WHERE dep_usage.as_of_date = '{RUN_DATE}'
            AND dep_usage.cloud_type = 'DC'
            AND UPPER(dep_usage.offering_name) NOT LIKE ('%TRIAL%')     
            AND UPPER(dep_usage.offering_name) NOT LIKE ('%SIGN%')
            AND UPPER(dep_usage.offering_name) NOT LIKE ('%SUPPORT%')
            AND UPPER(dep_usage.offering_name) NOT LIKE ('%STOCK%')
            AND UPPER(dep_usage.offering_name) NOT LIKE ('%SHARED%')
            AND dep_usage.offering_name != 'Enterprise PDF Services Developer'
        )b2b_base
		LEFT JOIN 
        (
			SELECT org_id
                    ,offering_name
                    ,num_users_pdf_services_enabled
                    ,(cast(enabled_org_lvl as decimal(22,2))/cast(services_total_org_lvl as decimal(22,2))) as pdf_services_ratio
            FROM
            (   
                SELECT serv_enabld_org_offr.org_id
                        ,serv_enabld_org_offr.offering_name
                        ,SUM(serv_enabld_org_offr.num_users_services_enabled) AS num_users_pdf_services_enabled
                        ,SUM(serv_enabld_org_offr.num_users_services_enabled + serv_enabld_org_offr.num_users_services_disabled) AS num_users_services_disabled
                        ,SUM(SUM(serv_enabld_org_offr.num_users_services_enabled)) OVER (PARTITION BY org_id order by NULL) AS enabled_org_lvl
                        ,SUM(SUM(serv_enabld_org_offr.num_users_services_enabled + serv_enabld_org_offr.num_users_services_disabled)) OVER (PARTITION BY org_id order by NULL) AS services_total_org_lvl
                FROM b2b.service_enabled serv_enabld_org_offr
                WHERE serv_enabld_org_offr.service_name = 'PDF_SERVICES'
                      AND serv_enabld_org_offr.asofdate = cast('{RUN_DATE}' as date)
                GROUP BY org_id, offering_name
            )enabld_org_offr
        )serv_enabld
        ON b2b_base.org_id = serv_enabld.org_id
        AND b2b_base.offering_name = serv_enabld.offering_name
        LEFT JOIN
		(
			SELECT org_id
			FROM
				(
					SELECT e.org_id
						   ,SUM(cast(e.delegated as int)) AS numerator_delegated
						   ,SUM(cast(e.local_licensed_qty as int)) AS denominator_provisioned
					FROM b2b.b2b_deployment_usage e
					WHERE as_of_date = '{RUN_DATE}'
					        AND cast(e.delegated as int)> 0
							AND UPPER(e.offering_name) NOT LIKE ('%TRIAL%')     
                            AND UPPER(e.offering_name) NOT LIKE ('%SIGN%')
                            AND UPPER(e.offering_name) NOT LIKE ('%SUPPORT%')
                            AND UPPER(e.offering_name) NOT LIKE ('%STOCK%')
                            AND UPPER(e.offering_name) NOT LIKE ('%SHARED%')
                            AND UPPER(e.offering_name) NOT LIKE ('%FEATURE RESTRICTED%')
                    GROUP BY org_id
					UNION ALL
					SELECT org_id
						   ,(frl_connected_devices_deployed + frl_isolated_devices_deployed) AS numerator_delegated
						   ,frl_provisioned_licenses AS denominator_provisioned
				    FROM b2b.frl_data
					WHERE cloud_type IN ('DCE','CCE+DCE')
							AND as_of_date = '{RUN_DATE}'
							AND frl_provisioned_licenses > 0
				)frl
				GROUP BY org_id
				HAVING sum(cast(numerator_delegated AS DOUBLE))/sum(cast(denominator_provisioned AS DOUBLE)) >= 0.8
		)frl_data
		ON b2b_base.org_id = frl_data.org_id
		LEFT JOIN
		(
			SELECT distinct org_id
					,(frl_connected_devices_deployed + frl_isolated_devices_deployed) AS numerator_delegated
					,frl_provisioned_licenses AS denominator_provisioned
			FROM b2b.frl_data
			WHERE cloud_type IN ('DCE','CCE+DCE')
				AND as_of_date = '{RUN_DATE}'
				AND frl_provisioned_licenses > 0
                AND org_id is not null
		)frl_data_base
		ON b2b_base.org_id = frl_data_base.org_id
		AND b2b_base.row_num = 1
		LEFT JOIN 
		(
			SELECT o365_base.org_id
					,o365_base.offering_name
			        ,o365_base.offer_id
					,o365_base.o365_usage
					,CASE WHEN org_del_denominator = 0 THEN 0 ELSE (cast(o365_base.members_numerator as decimal(22,2))/cast(denom.org_del_denominator as decimal(22,2))) END AS usage_rate 
			FROM
			(	
				SELECT m.org_id
						,m.offering_name
				        ,m.offer_id
						,COUNT(DISTINCT o.member_guid) AS o365_usage
						,SUM(COUNT(DISTINCT o.member_guid)) OVER (PARTITION BY org_id order by NULL) AS members_numerator
					FROM b2b.o365_integration_raw o
					JOIN b2b.b2b_users m
					ON o.member_guid = m.member_guid
					WHERE cast(o.event_date AS date) BETWEEN date_sub(cast('{RUN_DATE}' as date),27)  AND cast('{RUN_DATE}' AS date)
					AND m.as_of_date = '{RUN_DATE}'
					GROUP BY org_id, offering_name, offer_id
			)o365_base
			JOIN 
			(
				SELECT org_id, offer_id
						,SUM(cast (delegated as int)) as org_del_denominator, offering_name
					FROM b2b.b2b_deployment_usage dep_usage
					WHERE cloud_type = 'DC'
				    AND as_of_date = '{RUN_DATE}'
					GROUP BY org_id, offering_name, offer_id
			)denom
			ON o365_base.org_id = denom.org_id
			AND o365_base.offer_id = denom.offer_id
		)o365_usg
		ON b2b_base.org_id = o365_usg.org_id
		AND b2b_base.offer_id = o365_usg.offer_id
		LEFT JOIN
		(	
           select 
	   org_id,
           offer_id, 
           sum(cast(acrobat_desktop_usage as int)) as acrobat_desktop_usage,
           sum(cast(acrobat_mobile_usage as int)) as acrobat_mobile_usage,
           min(acrobat_desktop_usage_organizations) as acrobat_desktop_usage_organizations,
           min(acrobat_mobile_usage_organizations) as acrobat_mobile_usage_organizations
           FROM
            (SELECT 
                 org_id,
	             offer_id,
                 CASE
                      WHEN app_name = 'ACROBAT' THEN app_malu 
					  END AS acrobat_desktop_usage,
                 CASE
                      WHEN app_name = 'ACROBAT READER MOBILE' THEN app_malu 
                      END AS acrobat_mobile_usage,
                 CASE
                      WHEN app_name = 'ACROBAT' AND app_malu IS NOT NULL
                      AND percent >= 0.05 THEN org_id
                      END AS acrobat_desktop_usage_organizations,
                 CASE
                      WHEN app_name = 'ACROBAT READER MOBILE' AND app_malu IS NOT NULL
                      AND percent >= 0.05 THEN org_id
                      END AS acrobat_mobile_usage_organizations
             FROM
             (
               SELECT
                     org_id,
		     offer_id,
                     app_name,
                     app_malu, 
                     cast(acrobat_numerator as DOUBLE)/cast(acrobat_denominator as DOUBLE) as percent FROM
                 (SELECT
                     org_id,
		     offer_id,
                     app_name,
                     SUM(cast(app_malu as DOUBLE)) as app_malu,
                     SUM(cast(app_users_delegated as DOUBLE)) as app_users_delegated,
                     SUM(SUM(cast(app_malu as DOUBLE))) OVER (PARTITION BY org_id, app_name order by NULL) as acrobat_numerator,
                     SUM(SUM(cast(app_users_delegated as DOUBLE))) OVER (PARTITION BY org_id, app_name order by NULL) as acrobat_denominator
                  FROM b2b.b2b_app_usage
                  WHERE
                    as_of_date = '{RUN_DATE}'
                    AND app_name LIKE '%ACROBAT%'
		    AND offering_type LIKE '%ACRO%' 
                    AND app_users_delegated > '0'
                    AND app_malu > '0'
                  GROUP BY 
                     org_id,
		     offer_id,
                     app_name
	           ) app_use
	      GROUP BY org_id,
		       offer_id,
                       app_name,
                       app_malu,
                       cast(acrobat_numerator as DOUBLE)/cast(acrobat_denominator as DOUBLE)
	      ) app
             GROUP BY org_id, offer_id, app_name, app_malu, percent
	     ) acrobat_app
             GROUP BY org_id, offer_id
	     )acrobat
		ON b2b_base.org_id = acrobat.org_id
		AND b2b_base.offer_id = acrobat.offer_id
		LEFT JOIN 
		(
			SELECT distinct org_id
					,offering_name
			                ,offer_id
					,services_mau
					,usage_discovery_all
					,cast(pdf_numerator AS DOUBLE)/cast(pdf_denominator AS DOUBLE) AS mau_percent
			FROM
				(SELECT  e.org_id
                                         ,e.offering_name
					 ,e.offer_id
					 ,pdf.usage_all AS services_mau
					 ,pdf.usage_discovery_all AS usage_discovery_all
					 ,SUM(cast(pdf.usage_all as DOUBLE)) as usage_all
					 ,SUM(cast(e.delegated as DOUBLE)) as delegated
					 ,SUM(SUM(cast(pdf.usage_all as DOUBLE))) OVER (PARTITION BY e.org_id, e.offer_id order by NULL) AS pdf_numerator
					 ,SUM(SUM(cast(e.delegated as DOUBLE))) OVER (PARTITION BY e.org_id,e.offer_id order by NULL) AS pdf_denominator
				FROM b2b.b2b_deployment_usage e
				LEFT JOIN b2b.pdf_service_usage_metrics pdf		
					ON e.org_id = pdf.org_id
					AND e.offer_id = pdf.offer_id
				WHERE pdf.asofdate = cast('{RUN_DATE}' as date)
				AND e.cloud_type='DC'
				GROUP BY e.org_id
                                         ,e.offering_name
					 ,e.offer_id
				         ,pdf.usage_all
					 ,pdf.usage_discovery_all)pdf_use
		)pdf_serv_usage
		ON b2b_base.org_id = pdf_serv_usage.org_id
		AND b2b_base.offer_id = pdf_serv_usage.offer_id """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__': 
        main()