from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("FROM_DATE", "")
             dbutils.widgets.text("TO_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             FROM_DATE = dbutils.widgets.get("FROM_DATE")
             TO_DATE = dbutils.widgets.get("TO_DATE")
             y_val = dbutils.widgets.get("y_val")
             m_val = dbutils.widgets.get("m_val")
             ym_val = dbutils.widgets.get("ym_val")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET mapreduce.job.maps=5 """)
             spark.sql(""" set hive.exec.reducers.max=50 """)
             spark.sql(""" set hive.exec.reducers.bytes.per.reducer=1000000 """)
             spark.sql(""" set hive.optimize.distinct.rewrite=true """)
             spark.sql(""" SET hive.map.aggr=true """)
             spark.sql(""" SET hive.merge.mapfiles=flase """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
             spark.sql(""" SET hive.exec.Compress.intermediate=true """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
             spark.sql(""" SET hive.auto.convert.join=true """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.cbo.enable=true """)
             spark.sql(""" set hive.compute.query.using.stats=true """)
             spark.sql(""" set hive.stats.fetch.column.stats=true """)
             spark.sql(""" set hive.stats.fetch.partition.stats=true """)
             spark.sql(""" set hive.exec.dynamic.partition=true """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.support.concurrency = false """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             spark.sql(""" insert overwrite table b2b.pdf_service_usage_raw partition(event_date)
SELECT DISTINCT post_evar47 AS calling_app,
                post_pagename,
                split(post_evar12,'@')[0] AS member_guid,
                cast(click_date as date) as event_date
--FROM aa_ingest.sc_visitor_click_history_parquet_apr2022 updated on 02/13 B2BDME-6218
FROM aa_ingest.sc_visitor_click_history
WHERE click_date BETWEEN '{FROM_DATE}' AND '{TO_DATE}'
  AND report_suite='adbdcwebprod'
  AND post_evar47 IN ('dc-office-cpdf-app',
                      'dc-web-app',
                      'dc-gsuite-app',
                      'dc-shared-gdrive-app',
                      'dc-box-app',
                      'dc-sharepoint-app',
                      'dc-spod-app',
                      'dc-onedrive-app',
                      'dc-msteams-integration-app')
UNION ALL
SELECT DISTINCT (params['clientID']) AS calling_app,
                (params['converter']) AS post_pagename,
                split((params['userID']),'@')[0] AS member_guid,
                cast(event_date as date) as event_date
FROM darwin.dca_ets_ingest
WHERE event_code='DEX_PROCESS'
  AND subcode = 'DEX_PROCESS_SUCCESS' 
  AND event_date BETWEEN '{FROM_DATE}' AND '{TO_DATE}' 
  AND (params['clientID']) RLIKE 'Scan|Reader|Acrobat|dc-prod-spod|dc-office-addin|dc-prod-gsuite|dc-prod-boxintegration|sc_worker_createpdf|Reader|Mobile|dc-prod-spod|dc-prod-gsuite|dc-prod-boxintegration|sc_worker_exportpdf|Scan|ReaderMobile|AcrobatMobile|Acrobat|dc-prod-spod|dc-prod-gsuite|dc-prod-boxintegration|dc-office-addin' 
UNION ALL
SELECT DISTINCT calling_app,
                'Create' AS post_pagename,
                split(h.member_guid,'@')[0] AS member_guid,
                cast(event_date as date) as event_date
FROM
  (SELECT DISTINCT pguid,
                   'Office' AS calling_app,
                   substr(featuretime,1,10) AS event_date
  --  FROM b2b_stg.dc_acrobatstar_feature
   FROM dc_acrobatstar.feature
   WHERE FeatureName='Invoke sharing workflow PDFMaker Create and Share'
     AND substr(featuretime,1,10) BETWEEN '{FROM_DATE}' AND '{TO_DATE}' AND `year` IN {y_val} and `month` in {m_val} and `monthkey` in {ym_val}
   UNION ALL SELECT DISTINCT pguid,
                             category AS calling_app,
                             substr(grouptime,1,10) AS event_date
  --  FROM b2b_stg.dc_acrotraystar_create_share_conversion_status
   FROM dc_acrotraystar.create_share_conversion_status
   WHERE subcategory='PDFMaker_Menu'
     AND substr(grouptime,1,10) BETWEEN '{FROM_DATE}' AND '{TO_DATE}'
   UNION ALL SELECT DISTINCT pguid,
                             category AS calling_app,
                             substr(grouptime,1,10) AS event_date
  --  FROM b2b_stg.dc_acrotraystar_create_share_saveas_pdf
   FROM dc_acrotraystar.create_share_saveas_pdf
   WHERE subcategory='OK'
     AND substr(grouptime,1,10) BETWEEN '{FROM_DATE}' AND '{TO_DATE}'
   UNION ALL SELECT DISTINCT pguid,
                             category AS calling_app,
                             substr(grouptime,1,10) AS event_date
  --  FROM b2b_stg.dc_acrotraystar_create_share_home_click
   FROM dc_acrotraystar.create_share_home_click
   WHERE subcategory='PDFMaker_Menu'
     AND substr(grouptime,1,10) BETWEEN '{FROM_DATE}' AND '{TO_DATE}' ) u
-- JOIN b2b_stg.hb_monitor_user_mapping_snapshot h
JOIN hb_monitor.user_mapping_snapshot h 
ON h.pguid=u.pguid """.format(FROM_DATE = FROM_DATE, TO_DATE = TO_DATE, y_val = y_val, m_val = m_val, ym_val = ym_val))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()