from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")
             dbutils.widgets.text("RUN_DATE", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             RUN_DATE = dbutils.widgets.get("RUN_DATE")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET mapreduce.job.maps=5 """)
             spark.sql(""" set hive.exec.reducers.max=50 """)
             spark.sql(""" set hive.exec.reducers.bytes.per.reducer=1000000 """)
             spark.sql(""" set hive.optimize.distinct.rewrite=true """)
             spark.sql(""" SET hive.map.aggr=true """)
             spark.sql(""" SET hive.merge.mapfiles=flase """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.minsize=512000000 """)
             spark.sql(""" SET mapreduce.input.fileinputformat.split.maxsize=5120000000 """)
             spark.sql(""" SET hive.exec.Compress.intermediate=true """)
             spark.sql(""" SET hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec """)
             spark.sql(""" SET hive.intermediate.compression.type=BLOCK """)
             spark.sql(""" SET hive.vectorized.execution.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled = true """)
             spark.sql(""" SET hive.vectorized.execution.reduce.groupby.enabled = true """)
             spark.sql(""" SET hive.auto.convert.join=true """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.cbo.enable=true """)
             spark.sql(""" set hive.compute.query.using.stats=true """)
             spark.sql(""" set hive.stats.fetch.column.stats=true """)
             spark.sql(""" set hive.stats.fetch.partition.stats=true """)
             spark.sql(""" set hive.exec.dynamic.partition=true """)
             spark.sql(""" set hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" set hive.support.concurrency = false """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" set mapred.job.queue.name=root.adhoc.standard """)
             deployment_usage_count = spark.sql(''' select * from b2b.b2b_deployment_usage where as_of_date = '{RUN_DATE}' '''.format(RUN_DATE=RUN_DATE)).count()
             b2b_users_count = spark.sql(''' select * from b2b.b2b_users where as_of_date = '{RUN_DATE}' '''.format(RUN_DATE=RUN_DATE)).count()
             if deployment_usage_count != 0 and b2b_users_count != 0:
               pass
             else:
               dbutils.notebook.exit("b2b_deployment_usage/b2b_users is not updated for latest snapshot")
             spark.sql(""" INSERT OVERWRITE TABLE b2b.pdf_service_usage_metrics PARTITION(asofdate) 
SELECT dep_usage_mau.org_id,
       dep_usage_mau.org_name,
       dep_usage_mau.offering_name,
       dep_usage_mau.market_segment,
       dep_usage_mau.geo_code,
       dep_usage_mau.industry,
       dep_usage_mau.contract_offer_type,
       CONVERT,
       Create_,
       Export_,
       Combine,
       COMPRESS,
       Edit,
       Organize,
       SHARE,
       Scan,
       Comment_,
       Star,
       Sign_In,
       usage_all,
       0 as discovery_all,
       discovery_all_mau AS usage_discovery_all,
       dep_usage_mau.ech_parent_id,
       dep_usage_mau.ech_parent_name,
       dep_usage_mau.lic_type,
       dep_usage_mau.org_market_area_description as market_area,
       dep_usage_mau.offer_id,
       dep_usage_mau.dme_acct_segment,
       dep_usage_mau.mm_flag,
       dep_usage_mau.offering_type,
       dep_usage_mau.end_user_id,
       cast('{RUN_DATE}' as date) AS asofdate
   FROM
  (
SELECT    org_id,
          offering_name,
	        offer_id,
          COUNT(DISTINCT IF(action='Convert', member_guid,NULL)) AS CONVERT,
          COUNT(DISTINCT IF(action='Create', member_guid,NULL)) AS Create_,
          COUNT(DISTINCT IF(action='Export', member_guid,NULL)) AS Export_,
          COUNT(DISTINCT IF(action='Combine', member_guid,NULL)) AS Combine,
          COUNT(DISTINCT IF(action='Compress', member_guid,NULL)) AS COMPRESS,
          COUNT(DISTINCT IF(action='Edit', member_guid,NULL)) AS Edit,
          COUNT(DISTINCT IF(action='Organize', member_guid,NULL)) AS Organize,
          COUNT(DISTINCT IF(action='Share', member_guid,NULL)) AS SHARE,
          COUNT(DISTINCT IF(action='Scan', member_guid,NULL)) AS Scan,
          COUNT(DISTINCT IF(action='Comment', member_guid,NULL)) AS Comment_,
          COUNT(DISTINCT IF(action='Star', member_guid,NULL)) AS Star,
          COUNT(DISTINCT IF(action='Sign In', member_guid,NULL)) AS Sign_In,
          COUNT(DISTINCT IF(action IN ('Convert','Create','Export','Combine','Compress','Edit','Organize','Share','Scan','Comment','Star'), member_guid,NULL)) AS usage_all
   FROM
     (SELECT dep_usage.org_id,
             dep_usage.offering_name,
             dep_usage.offer_id,
             users.member_guid,
             CASE
                 WHEN upper(p.calling_app) LIKE '%ACROBAT%MOBILE%'
                      OR upper(p.calling_app) LIKE '%READER%MOBILE%' THEN 'Acrobat Mobile'
                 WHEN upper(p.calling_app) LIKE '%ADOBE%ACROBAT%' THEN 'Acrobat Desktop'
                 WHEN upper(p.calling_app) LIKE '%ADOBE%READER%' THEN 'Reader Desktop'
                 WHEN p.calling_app IN ('dc-box-app',
                                        'dc-prod-boxintegration') THEN 'Box'
                 WHEN p.calling_app IN ('dc-gsuite-app',
                                        'dc-prod-gsuite',
                                        'dc-shared-gdrive-app') THEN 'GDrive/GSuite'
                 WHEN upper(p.calling_app) LIKE '%POWERPOINT%'
                      OR upper(p.calling_app) LIKE '%EXCEL%'
                      OR upper(p.calling_app) LIKE '%WORD%'
                      OR upper(p.calling_app) LIKE '%OFFICE%' THEN 'MS Office'
                 WHEN p.calling_app IN ('dc-onedrive-app',
                                        'dc-prod-spod',
                                        'dc-sharepoint-app') THEN 'MS SharePoint/OneDrive'
                 WHEN p.calling_app='dc-web-app' THEN 'Acrobat Web'
                 WHEN upper(p.calling_app) LIKE '%SCAN%' THEN 'Scan'
                 WHEN p.calling_app='dc-msteams-integration-app' THEN 'MS Teams'
             END AS calling_app,
             CASE
                 WHEN UPPER(p.post_pagename) LIKE '%GROUP-CONVERT:%'
                      AND p.calling_app IN ('dc-office-cpdf-app',
                                            'dc-web-app') THEN 'Convert'
                 WHEN (p.post_pagename='Create'
                       OR UPPER(p.post_pagename) LIKE '%CREATEPDF%'
                       OR UPPER(p.post_pagename) LIKE '%CREATE PDF%')
                      AND (p.calling_app IN ('dc-gsuite-app',
                                             'dc-shared-gdrive-app',
                                             'dc-prod-gsuite',
                                             'dc-box-app',
                                             'dc-prod-boxintegration',
                                             'dc-sharepoint-app',
                                             'dc-spod-app',
                                             'dc-onedrive-app',
                                             'dc-web-app',
                                             'Office',
                                             'Word',
                                             'Powerpoint')
                           OR upper(p.calling_app) LIKE '%ACROBAT%MOBILE%'
                           OR upper(p.calling_app) LIKE '%READER%MOBILE%'
                           OR upper(p.calling_app) LIKE '%SCAN%'
                           OR upper(p.calling_app) LIKE '%ADOBE%ARCOBAT%'
                           OR upper(p.calling_app) LIKE '%ADOBE%READER%') THEN 'Create'
                 WHEN (UPPER(p.post_pagename) LIKE '%EXPORTPDF%'
                       OR UPPER(p.post_pagename) LIKE '%EXPORT PDF%'
                       OR UPPER(p.post_pagename) LIKE '%EXPORT-PDF%')
                      AND (p.calling_app IN ('dc-web-app',
                                             'dc-sharepoint-app',
                                             'dc-spod-app',
                                             'dc-shared-gdrive-app',
                                             'dc-prod-gsuite',
                                             'dc-onedrive-app',
                                             'dc-gsuite-app',
                                             'dc-box-app',
                                             'dc-prod-boxintegration')
                           OR upper(p.calling_app) LIKE '%ACROBAT%MOBILE%'
                           OR upper(p.calling_app) LIKE '%READER%MOBILE%'
                           OR upper(p.calling_app) LIKE '%ADOBE%READER%'
                           OR upper(p.calling_app) LIKE '%SCAN%') THEN 'Export'
                 WHEN (UPPER(p.post_pagename) LIKE '%COMBINEPDF%'
                       OR UPPER(p.post_pagename) LIKE '%COMBINE PDF%'
                       OR UPPER(p.post_pagename) LIKE '%COMBINE-PDF%')
                      AND (p.calling_app IN ('dc-web-app',
                                             'dc-sharepoint-app',
                                             'dc-spod-app',
                                             'dc-shared-gdrive-app',
                                             'dc-prod-gsuite',
                                             'dc-onedrive-app',
                                             'dc-gsuite-app',
                                             'dc-box-app',
                                             'dc-prod-boxintegration')
                           OR upper(p.calling_app) LIKE '%ACROBAT%MOBILE%'
                           OR upper(p.calling_app) LIKE '%READER%MOBILE%'
                           OR upper(p.calling_app) LIKE '%ADOBE%READER%'
                           OR upper(p.calling_app) LIKE '%SCAN%') THEN 'Combine'
                 WHEN (UPPER(p.post_pagename) LIKE '%COMPRESSPDF%'
                       OR UPPER(p.post_pagename) LIKE '%COMPRESS PDF%'
                       OR UPPER(p.post_pagename) LIKE '%COMPRESS-PDF%')
                      AND (p.calling_app='dc-web-app'
                           OR upper(p.calling_app) LIKE '%ACROBAT%MOBILE%'
                           OR upper(p.calling_app) LIKE '%READER%MOBILE%') THEN 'Compress'
                 WHEN (UPPER(p.post_pagename) LIKE '%EDIT-PDF%'
                       OR UPPER(p.post_pagename) LIKE '%EDITPDF%'
                       OR UPPER(p.post_pagename) LIKE '%GROUP-EDIT%') THEN 'Edit'
                 WHEN (UPPER(p.post_pagename) LIKE '%ORGANIZE%'
                       OR UPPER(p.post_pagename) LIKE '%ORGANIZE PDF%'
                       OR UPPER(p.post_pagename) LIKE '%ORGANIZE-PDF%') THEN 'Organize'
                 WHEN (UPPER(p.post_pagename) LIKE '%UNIFIEDSHARE%'
                       OR UPPER(p.post_pagename) LIKE '%GROUP-SHARE%')
                      AND p.calling_app='dc-web-app' THEN 'Share'
                 WHEN UPPER(p.post_pagename) LIKE '%PROTECT-PDF%' THEN 'Protect'
                 WHEN upper(p.calling_app) LIKE '%SCAN%'
                      AND p.post_pagename='sc_worker_ocrpdf' THEN 'Scan'
                 WHEN UPPER(p.post_pagename) LIKE '%COMMENT%'
                      AND p.calling_app='dc-msteams-integration-app' THEN 'Comment'
                 WHEN p.post_pagename IN ('Navigation:Use:StarredClicked',
                                          'actions:star:clicked',
                                          'acrobat:star-action:entry:clicked',
                                          'actions:star-action:clicked',
                                          'actions:goto-dc-starred-action:clicked',
                                          'Document profile:Document properties:Add to Starred',
                                          'documentcloud.adobe.com:link:documents:starred') THEN 'Star'
                 WHEN p.post_pagename IN ('Initial Startup:DCWebApp:UserSignedIn',
                                          'Upsell:DropDownView:upsellSignInClicked',
                                          'SignIn:Use:Clicked') THEN 'Sign In'
                 WHEN upper(p.post_pagename) LIKE '%DOCUMENT OPEN%' THEN 'Open Documents'
                 ELSE 'Discovery'
             END AS action
      from b2b.b2b_deployment_usage dep_usage
		  left join b2b.b2b_users users
		    on dep_usage.org_id = users.org_id
		    and dep_usage.offer_id = users.offer_id
		    and dep_usage.as_of_date = users.as_of_date
		  left join b2b.pdf_service_usage_raw p
		    on users.member_guid = p.member_guid
      WHERE p.event_date between date_sub(cast('{RUN_DATE}' as date),27) and cast('{RUN_DATE}' as date)
        AND p.post_pagename!=''
	      AND UPPER(dep_usage.offering_name) NOT LIKE '%DESKTOP%'
        AND upper(dep_usage.offering_name) NOT LIKE '%RESTRICTED%'
        AND upper(dep_usage.offering_name) NOT LIKE '%MULTI%'
        AND upper(dep_usage.offering_name) NOT LIKE '%CHINA%'
        AND upper(dep_usage.offering_name) NOT LIKE '%ADOBE SIGN%'
        AND ((        cloud_type = 'DC'
              AND (   UPPER(dep_usage.offering_name) LIKE '%ACROBAT%'
                   OR UPPER(dep_usage.offering_name) LIKE '%DOCUMENT%'))
          OR (        cloud_type = 'CC'
              AND     UPPER(dep_usage.offering_name) LIKE '%ALL%APPS%'))
        AND dep_usage.as_of_date='{RUN_DATE}')a
    WHERE calling_app IS NOT NULL
    AND action IS NOT NULL
    GROUP BY org_id,
             offering_name,
	           offer_id
)dep_usage_action
RIGHT JOIN
(
SELECT  dep_usage.org_id,
        dep_usage.org_name,
        dep_usage.ech_parent_id,
        dep_usage.ech_parent_name,
        dep_usage.lic_type,
        dep_usage.org_market_area_description,
        dep_usage.offering_name,
       dep_usage.offer_id,
        dep_usage.contract_type as contract_offer_type,
        dep_usage.market_segment,
        dep_usage.org_geo_description as geo_code,
        dep_usage.ech_sub_industry as industry,
        COUNT(DISTINCT users.member_guid) AS discovery_all_mau,
        dme_acct_segment,
        offering_type,
        end_user_id,
        mm_flag
		  from b2b.b2b_deployment_usage dep_usage
		  join b2b.b2b_users users
		    on dep_usage.org_id = users.org_id
		    and dep_usage.offer_id = users.offer_id
		    and dep_usage.as_of_date = users.as_of_date
		  join b2b.pdf_service_usage_raw one_year_pdf
		    on users.member_guid = one_year_pdf.member_guid
		  WHERE cast(event_date AS date) BETWEEN date_sub(cast('{RUN_DATE}' AS date),364) AND cast('{RUN_DATE}' AS date)
		  AND post_pagename!=''
	        AND UPPER(dep_usage.offering_name) NOT LIKE '%DESKTOP%'
          AND upper(dep_usage.offering_name) NOT LIKE '%RESTRICTED%'
          AND upper(dep_usage.offering_name) NOT LIKE '%MULTI%'
          AND upper(dep_usage.offering_name) NOT LIKE '%CHINA%'
          AND upper(dep_usage.offering_name) NOT LIKE '%ADOBE SIGN%'
        AND ((        cloud_type = 'DC'
              AND (   UPPER(dep_usage.offering_name) LIKE '%ACROBAT%'
                   OR UPPER(dep_usage.offering_name) LIKE '%DOCUMENT%'))
          OR (        cloud_type = 'CC'
              AND     UPPER(dep_usage.offering_name) LIKE '%ALL%APPS%'))
            AND dep_usage.as_of_date='{RUN_DATE}'
         GROUP BY dep_usage.org_id,
          dep_usage.org_name,
          dep_usage.ech_parent_id,
          dep_usage.ech_parent_name,
          dep_usage.lic_type,
          dep_usage.org_market_area_description,
          dep_usage.offering_name,
          dep_usage.offer_id,
          dep_usage.contract_type,
          dep_usage.market_segment,
          dep_usage.org_geo_description,
          dep_usage.ech_sub_industry,
		      dme_acct_segment,
          offering_type,
          end_user_id,
		      mm_flag
	) dep_usage_mau
on 	dep_usage_action.org_id = dep_usage_mau.org_id
AND dep_usage_action.offer_id=dep_usage_mau.offer_id """.format(RUN_DATE = RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()
