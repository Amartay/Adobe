# Databricks notebook source
from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys


class main():
    def __init__(self):
        try:
            spark = SparkSession.builder \
                .enableHiveSupport() \
                .config('hive.exec.dynamic.partition', 'true') \
                .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                .config('hive.exec.max.dynamic.partitions', '10000') \
                .getOrCreate()
            log4j = spark._jvm.org.apache.log4j
            log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
            spark.sql('SET hive.warehouse.data.skiptrash=true;')
            spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
            spark.conf.set('spark.sql.cbo.enabled', True)
            spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
            spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
            spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
            spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
            spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            spark.sql("set spark.sql.adaptive.enabled=false")

            dbutils.widgets.text("Custom_Settings", "")
            dbutils.widgets.text("RUN_DATE", "")

            Settings = dbutils.widgets.get("Custom_Settings")
            RUN_DATE = dbutils.widgets.get("RUN_DATE")
            B2B_RUN_DATE = dbutils.widgets.get("B2B_RUN_DATE")
            RUN_DATE = B2B_RUN_DATE

            Set_list = Settings.split(',')
            if len(Set_list) > 0:
                for i in Set_list:
                    if i != "":
                        print("spark.sql(+i+)")
                        spark.sql("""{i}""".format(i=i))

            spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_user_events_by_guid ''')
            spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_user_events_bulk_esig ''')

            spark.sql(''' CREATE TABLE IF NOT EXISTS b2b_stg.hva_acro_user_events_by_guid AS
WITH
orgs AS (
    SELECT
            b2b_base.org_id AS org_id,
            b2b_base.offer_id AS offer_id,
            b2b_base.contract_type AS contract_offer_type,
            b2b_base.jem_contract_id AS contract_id,
            b2b_base.as_of_date AS as_of_date,
            sum (local_licensed_qty) AS app_seats_provisioned,
            max (b2b_base.market_segment) AS market_segment,
            max (b2b_base.org_geo_description) AS geo,
            max (b2b_base.ech_sub_industry) AS industry,
            max (b2b_base.org_name) AS org_name,
            max (b2b_base.ech_parent_id) AS ech_parent_id,
            max (b2b_base.ech_parent_name) AS ech_parent_name,
            max (b2b_base.lic_type) AS lic_type,
            max (b2b_base.org_market_area_description) AS market_area,
            max (b2b_base.offering_name) AS offering_name,
            max (b2b_base.offering_type) offering_type,
            max (b2b_base.mm_flag) AS mm_flag,
            CASE WHEN max (b2b_base.mm_flag) = 'Y' THEN 'MM' ELSE max (b2b_base.dme_acct_segment) END dme_acct_segment,
            max (b2b_base.end_user_id) AS end_user_id
        FROM
            b2b.b2b_org_pro_del b2b_base
        WHERE b2b_base.as_of_date = '{B2B_RUN_DATE}'
            AND (     b2b_base.cloud_type = 'DC'
              OR (    b2b_base.cloud_type = 'CC'
                  AND UPPER(b2b_base.offering_name) LIKE '%ALL%APPS%'))
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%TRIAL%')     
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%SIGN%')
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%SUPPORT%')
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%STOCK%')
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%SHARED%')
            AND b2b_base.offering_name != 'Enterprise PDF Services Developer'
        GROUP BY
            b2b_base.org_id,
            b2b_base.offer_id,
            b2b_base.contract_type,
            b2b_base.jem_contract_id,
            b2b_base.as_of_date
),
members AS (
    SELECT DISTINCT
            usrs.org_id,
            usrs.offer_id,
            usrs.contract_offer_type,
            usrs.contract_id,
            usrs.member_guid,
            usrs.auth_id
        FROM
            b2b.b2b_users AS usrs
        WHERE
            usrs.as_of_date = '{B2B_RUN_DATE}'
        AND (coalesce (usrs.member_guid, '') <> '') 
        AND usrs.contract_offer_type in ('TEAM_DIRECT','VIP','VIPMP')
        AND (
		        UPPER (usrs.offering_name) LIKE '%ACROBAT%PRO%'
		    OR  UPPER (usrs.offering_name) LIKE '%ACROBAT%STANDARD%'
		    OR  UPPER (usrs.offering_name) LIKE '%DOCUMENT%CLOUD%'
		    OR  UPPER (usrs.offering_name) LIKE '%ALL%APPS%'
		    OR (UPPER (usrs.offering_name) LIKE '%ACRO%'
			    AND UPPER (usrs.offering_name) NOT LIKE '%ACROBAT%SIGN%')
			OR  UPPER (usrs.offering_name) LIKE '%ACROBAT%E-SIGN%')
),
org_members AS (
    SELECT
            pr.*,
            usrs.member_guid,
            usrs.auth_id
    FROM orgs pr
        LEFT JOIN members usrs
             ON usrs.org_id = pr.org_id
            AND usrs.offer_id = pr.offer_id
            AND usrs.contract_offer_type = pr.contract_offer_type
            AND usrs.contract_id = pr.contract_id
),
usage_base AS 
(
    SELECT
            u.member_guid AS activation_guid,
            u.hv_tool,
            u.hv_category,
            MAX(CASE
                    WHEN u.event_date >= CAST (DATE_SUB('{B2B_RUN_DATE}', 90) AS STRING)
                     AND u.event_date <= '{B2B_RUN_DATE}'
                        THEN member_guid
                    ELSE NULL
                END) AS qau_member_guid,
            MAX(CASE
                    WHEN u.event_date >= CAST (DATE_SUB('{B2B_RUN_DATE}', 27) AS STRING)
                     AND u.event_date <= '{B2B_RUN_DATE}'
                        THEN member_guid
                    ELSE NULL
                END) AS mau_member_guid,
            MAX(CASE
                    WHEN u.event_date >= CAST (DATE_SUB('{B2B_RUN_DATE}', 55) AS STRING)
                     AND u.event_date <= CAST (DATE_SUB('{B2B_RUN_DATE}', 28) AS STRING)
                        THEN member_guid
                    ELSE NULL
                END) AS rmau_member_guid
        FROM
            b2b.hva_acro_raw_events u
        WHERE
            hv_tool IS NOT NULL
        AND u.event_date
                BETWEEN CAST (DATE_SUB('{B2B_RUN_DATE}', 1094) AS STRING)
                    AND '{B2B_RUN_DATE}'
        GROUP BY
            u.member_guid,
            u.hv_tool,
            u.hv_category
)
-- How many users used tools
    SELECT
            m.*,
            u.activation_guid,
            u.hv_tool,
            u.hv_category,
            u.qau_member_guid,
            u.mau_member_guid,
            IF (u.mau_member_guid = u.rmau_member_guid, u.rmau_member_guid, NULL) AS rmau_member_guid
        FROM
            org_members m
        LEFT JOIN usage_base u
            ON m.member_guid = u.activation_guid;
             '''.format(B2B_RUN_DATE=B2B_RUN_DATE))

            #Bulk and E - Signature

            spark.sql(''' CREATE TABLE IF NOT EXISTS b2b_stg.hva_acro_user_events_bulk_esig AS
WITH
orgs AS (
    SELECT DISTINCT
            b2b_base.org_id,
            b2b_base.offer_id,
            b2b_base.contract_type AS contract_offer_type,
            b2b_base.jem_contract_id AS contract_id,
            b2b_base.as_of_date
        FROM
            b2b.b2b_org_pro_del b2b_base
        WHERE as_of_date = '{B2B_RUN_DATE}'
            AND (     b2b_base.cloud_type = 'DC'
              OR (    b2b_base.cloud_type = 'CC'
                  AND UPPER(b2b_base.offering_name) LIKE '%ALL%APPS%'))
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%TRIAL%')     
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%SIGN%')
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%SUPPORT%')
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%STOCK%')
            AND UPPER(b2b_base.offering_name) NOT LIKE ('%SHARED%')
            AND b2b_base.offering_name != 'Enterprise PDF Services Developer'
),
members AS (
    SELECT DISTINCT
            usrs.org_id,
            usrs.offer_id,
            usrs.contract_offer_type,
            usrs.contract_id,
            usrs.member_guid,
            usrs.auth_id
        FROM
            b2b.b2b_users AS usrs
        LEFT JOIN b2b.b2b_users AS usrs2
             ON usrs2.as_of_date = usrs.as_of_date
            AND usrs2.org_id = usrs.org_id
            AND usrs2.member_guid = usrs.member_guid
            AND (UPPER(usrs2.offering_name) LIKE '%ADOBE%SIGN%'
                      OR (
                              UPPER(usrs2.offering_name) LIKE '%ACROBAT%SIGN%'
                          AND UPPER(usrs2.offering_name) NOT LIKE '%ACROBAT%E-SIGN%'
                        ))
        WHERE
            usrs.as_of_date = '{B2B_RUN_DATE}'
        AND usrs2.org_id IS NULL
        AND (coalesce (usrs.member_guid, '') <> '')
        AND (
		        UPPER (usrs.offering_name) LIKE '%ACROBAT%PRO%'
		    OR  UPPER (usrs.offering_name) LIKE '%ACROBAT%STANDARD%'
		    OR  UPPER (usrs.offering_name) LIKE '%DOCUMENT%CLOUD%'
		    OR  UPPER (usrs.offering_name) LIKE '%ALL%APPS%'
		    OR (UPPER (usrs.offering_name) LIKE '%ACRO%'
			    AND UPPER (usrs.offering_name) NOT LIKE '%ACROBAT%SIGN%')
			OR  UPPER (usrs.offering_name) LIKE '%ACROBAT%E-SIGN%')
),
org_members AS (
    SELECT
            pr.*,
            usrs.member_guid,
            usrs.auth_id
    FROM orgs pr
        LEFT JOIN members usrs
             ON usrs.org_id = pr.org_id
            AND usrs.offer_id = pr.offer_id
            AND usrs.contract_offer_type = pr.contract_offer_type
            AND usrs.contract_id = pr.contract_id
),
agreements AS (
    SELECT DISTINCT
        agr.agreement_id,
        substr (agr.originator_adobe_guid, 1, 24) AS member_guid,
        agr.originator_id AS created_by_user_id,
        agr.participation_num_other_account_ids + 1 AS participation_users,
        agr.parent_id AS megasign_agreement_id,
        agr.integration_name,
        -- created - The timestamp of when the agreement was created.
        --- (Note, this is not necessarily when it was sent for signature, but we usually treat it that way.)
        substr (agr.created, 1, 10) AS created_date,
        -- latest_time_signed - When was this agreement most recently signed? 
        -- (Note that the document may still be waiting for additional signatures.)
        agr.latest_time_signed AS most_recently_signed_date,
        -- The date and time (in UTC) when this agreement became billable.
        agr.transaction_date AS billable_start_date,
        agr.agreement_sent_for_signature,
        agr.agreement_sent_for_esignature,
        agr.agreement_sent_for_written_signature,
        agr.agreement_is_megasign_child,
        CASE 
            WHEN agr.status IN (
                'WAITING_FOR_SIGNATURES',
                'SIGNED',
                'EXPIRED',
                'WAITING_FOR_REVIEW',
                'ABANDONED')
                THEN 1 ELSE 0 END AS status_send_for_signature,
        CASE WHEN substr (agr.created, 1, 10) >= CAST (DATE_SUB(CAST ('{B2B_RUN_DATE}' AS DATE),27) AS STRING)
              AND substr (agr.created, 1, 10) <= '{B2B_RUN_DATE}'
                THEN 1 ELSE 0 END AS last_28_days
        FROM
            a_sign_pub.agreement AS agr
        WHERE substr (agr.created, 1, 10) <= '{B2B_RUN_DATE}'
        AND substr (agr.created, 1, 10) >= cast (add_months('{B2B_RUN_DATE}', -12) as string)
        AND agr.origination_type <> 'WELCOME'
        AND agr.agreement_should_be_ignored = 0
        AND originator_adobe_guid <> ''
)
SELECT
        org_members.org_id,
        org_members.offer_id,
        org_members.contract_id,
        org_members.contract_offer_type,
        max (agreements.integration_name) AS integration_name,
        count (DISTINCT agreements.agreement_id) AS number_of_agreements_created_last_one_year,
        count (DISTINCT
                CASE
                    WHEN last_28_days = 1
                        THEN agreements.agreement_id
                    ELSE NULL
                END) AS number_of_agreements_created_last_28_days,
        COUNT (DISTINCT
                CASE
                    WHEN status_send_for_signature = 1
                     AND agreement_sent_for_esignature = 1
                        THEN agreements.agreement_id
                    ELSE NULL
                END) AS number_of_agreements_send_for_signature_last_one_year,
        COUNT (DISTINCT
                CASE
                    WHEN last_28_days = 1
                     AND status_send_for_signature = 1
                     AND agreement_sent_for_esignature = 1
                        THEN agreements.agreement_id
                    ELSE NULL
                END) AS number_of_agreements_send_for_signature_last_28_days,
        count (DISTINCT
                CASE
                    WHEN last_28_days = 1
                        THEN agreements.created_by_user_id
                    ELSE NULL
                END) AS number_of_users_created_last_28_days,
        '{B2B_RUN_DATE}' AS as_of_date
    FROM
        org_members
    JOIN agreements 
        ON agreements.member_guid = org_members.member_guid 
    GROUP BY
        org_members.org_id,
        org_members.offer_id,
        org_members.contract_id,
        org_members.contract_offer_type '''.format(B2B_RUN_DATE=B2B_RUN_DATE))

            # Results for dashboard

            spark.sql(''' INSERT OVERWRITE b2b.hva_acro_org_events_overall partition (as_of_date)
WITH hva AS (
    SELECT
            market_segment,
            geo,
            industry,
            org_id,
            org_name,
            ech_parent_id,
            ech_parent_name,
            lic_type,
            market_area,
            offer_id,
            offering_name,
            contract_offer_type,
            offering_type,
            contract_id,
            mm_flag,
            dme_acct_segment,
            end_user_id,
            app_seats_provisioned,
            COUNT(DISTINCT member_guid) AS hva_delegated,
            COUNT(DISTINCT activation_guid) AS hva_activated,
            COUNT(DISTINCT qau_member_guid) AS hva_qalu,
            COUNT(DISTINCT mau_member_guid) AS hva_malu,
            COUNT(DISTINCT rmau_member_guid) AS hva_rmalu,
            as_of_date
    FROM b2b_stg.hva_acro_user_events_by_guid
    GROUP BY
            market_segment,
            geo,
            industry,
            org_id,
            org_name,
            ech_parent_id,
            ech_parent_name,
            lic_type,
            market_area,
            offer_id,
            offering_name,
            contract_offer_type,
            offering_type,
            contract_id,
            mm_flag,
            dme_acct_segment,
            end_user_id,
            app_seats_provisioned,
            as_of_date
),
funnel AS (
    SELECT
            market_segment,
            geo,
            industry,
            f.org_id,
            org_name,
            ech_parent_id,
            ech_parent_name,
            lic_type,
            market_area,
            f.offer_id,
            offering_name,
            f.contract_offer_type,
            f.contract_id,
            mm_flag,
            dme_acct_segment,
            f.as_of_date,
            total_organizations_provisioned,
            total_seats_provisioned,
            service_seats_provisioned,
            non_service_seats_provisioned,
            total_seats_delegated,
            service_seats_delegated,
            non_service_seats_delegated,
            non_service_seats_activated,
            service_seats_activated,
            total_organizations_deployed,
            frl_machines_deployed,
            frl_seats_provisioned,
            o365_usage_organizations,
            o365_usage,
            acrobat_desktop_usage_organizations,
            acrobat_mobile_usage_organizations,
            acrobat_desktop_usage,
            acrobat_mobile_usage,
            pdf_services_available_organizations,
            pdf_services_available_organizations_filter,
            num_users_pdf_services_enabled,
            pdf_services_usage_organizations,
            pdf_services_usage,
            fiscal_qt,
            f.offering_type,
            f.end_user_id
    FROM b2b.b2b_acro_deployment_adoption_funnel f
    WHERE f.as_of_date = '{B2B_RUN_DATE}'
),
usage AS (
    SELECT
            org_id,
            offer_id,
            contract_type AS contract_offer_type,
            jem_contract_id AS contract_id,
            as_of_date,
            sum (usage.app_seats_provisioned) AS app_seats_provisioned,
            sum (usage.app_users_delegated) AS usage_delegated,
            sum (usage.app_users_activated) AS usage_activated,
            sum (usage.app_malu) AS usage_mau,
            sum (usage.app_qalu) AS usage_qau,
            sum (usage.app_rmalu) AS usage_rmau
        FROM b2b.b2b_app_usage usage
        WHERE usage.as_of_date = '{B2B_RUN_DATE}'
        AND lower(usage.app_name) = 'acrobat'
        GROUP BY
            org_id,
            offer_id,
            contract_type,
            jem_contract_id,
            as_of_date
),

combined_base AS (
    SELECT
            market_segment,
            geo,
            industry,
            org_id,
            org_name,
            ech_parent_id,
            ech_parent_name,
            lic_type,
            market_area,
            offer_id,
            offering_name,
            contract_offer_type,
            offering_type,
            end_user_id,
            contract_id,
            mm_flag,
            dme_acct_segment,
            as_of_date
    FROM hva
    UNION DISTINCT
    SELECT
            market_segment,
            geo,
            industry,
            org_id,
            org_name,
            ech_parent_id,
            ech_parent_name,
            lic_type,
            market_area,
            offer_id,
            offering_name,
            contract_offer_type,
            offering_type,
            end_user_id,
            contract_id,
            mm_flag,
            dme_acct_segment,
            as_of_date
    FROM funnel
),
combined AS (
    SELECT
            org_id,
            offer_id,
            contract_id,
            contract_offer_type,
            as_of_date,
            max (market_segment) AS market_segment,
            max (geo) AS geo,
            max (industry) AS industry,
            max (org_name) AS org_name,
            max (ech_parent_id) AS ech_parent_id,
            max (ech_parent_name) AS ech_parent_name,
            max (lic_type) AS lic_type,
            max (offering_type) AS offering_type,
            max (end_user_id) AS end_user_id,
            max (market_area) AS market_area,
            max (offering_name) AS offering_name,
            max (mm_flag) AS mm_flag,
            max (dme_acct_segment) AS dme_acct_segment
    FROM combined_base
    GROUP BY
            org_id,
            offer_id,
            contract_id,
            contract_offer_type,
            as_of_date
)
SELECT
    combined.org_id,
combined.offer_id,
combined.contract_id,
combined.contract_offer_type,
combined.market_segment,
combined.geo,
combined.industry,
combined.org_name,
combined.ech_parent_id,
combined.ech_parent_name,
combined.lic_type,
combined.offering_type,
combined.end_user_id,
combined.market_area,
combined.offering_name,
combined.mm_flag,
combined.dme_acct_segment,
    -- HVA/Usage
    hva.app_seats_provisioned as provisioned,
    -- HVA
    hva.hva_delegated,
    hva.hva_activated,
    hva.hva_qalu,
    hva.hva_malu,
    hva.hva_rmalu,
    -- Usage
    usage.usage_delegated,
    usage.usage_activated,
    usage.usage_mau,
    usage.usage_qau,
    usage.usage_rmau,
    -- Funnel
    funnel.total_organizations_provisioned,
    funnel.total_seats_provisioned,
    funnel.service_seats_provisioned,
    funnel.non_service_seats_provisioned,
    funnel.total_seats_delegated,
    funnel.service_seats_delegated,
    funnel.non_service_seats_delegated,
    funnel.non_service_seats_activated,
    funnel.service_seats_activated,
    funnel.total_organizations_deployed,
    funnel.frl_machines_deployed,
    funnel.frl_seats_provisioned,
    funnel.o365_usage_organizations,
    funnel.o365_usage,
    funnel.acrobat_desktop_usage_organizations,
    funnel.acrobat_mobile_usage_organizations,
    funnel.acrobat_desktop_usage,
    funnel.acrobat_mobile_usage,
    funnel.pdf_services_available_organizations,
    funnel.pdf_services_available_organizations_filter,
    funnel.num_users_pdf_services_enabled,
    funnel.pdf_services_usage_organizations,
    funnel.pdf_services_usage,
    funnel.fiscal_qt,
    -- Bulk
    bulk.integration_name,
    bulk.number_of_agreements_created_last_one_year,
    bulk.number_of_agreements_created_last_28_days,
    bulk.number_of_agreements_send_for_signature_last_one_year,
    bulk.number_of_agreements_send_for_signature_last_28_days,
    bulk.number_of_users_created_last_28_days,
    combined.as_of_date
FROM
    combined
LEFT JOIN hva
     ON hva.org_id = combined.org_id
    AND hva.offer_id = combined.offer_id
    AND hva.contract_offer_type = combined.contract_offer_type
    AND hva.contract_id = combined.contract_id
    AND hva.as_of_date = combined.as_of_date
LEFT JOIN funnel
     ON funnel.org_id = combined.org_id
    AND funnel.offer_id = combined.offer_id
    AND funnel.contract_offer_type = combined.contract_offer_type
    AND funnel.contract_id = combined.contract_id
    AND funnel.as_of_date = combined.as_of_date
LEFT JOIN usage
     ON usage.org_id = combined.org_id
    AND usage.offer_id = combined.offer_id
    AND usage.contract_offer_type = combined.contract_offer_type
    AND usage.contract_id = combined.contract_id
    AND usage.as_of_date = combined.as_of_date
LEFT JOIN b2b_stg.hva_acro_user_events_bulk_esig bulk
     ON bulk.org_id = combined.org_id
    AND bulk.offer_id = combined.offer_id
    AND bulk.contract_offer_type = combined.contract_offer_type
    AND bulk.contract_id = combined.contract_id
    AND bulk.as_of_date = combined.as_of_date
WHERE combined.org_id IS NOT NULL
AND combined.offer_id IS NOT NULL
AND combined.contract_offer_type IS NOT NULL
AND combined.contract_id IS NOT NULL '''.format(B2B_RUN_DATE=B2B_RUN_DATE))

            spark.sql(''' INSERT OVERWRITE b2b.hva_acro_org_events_hva_combined_nonzero partition (as_of_date)
    SELECT
            'HVA' AS level_type,
            org_id,
            org_name,
            offer_id,
            contract_id,
            contract_offer_type,
            offering_type,
            ech_parent_id,
            end_user_id,
            app_seats_provisioned as provisioned,
            hv_category AS category,
            hv_tool AS hva,
            COUNT(DISTINCT member_guid) AS hva_delegated,
            COUNT(DISTINCT activation_guid) AS hva_activated,
            COUNT(DISTINCT qau_member_guid) AS hva_qalu,
            COUNT(DISTINCT mau_member_guid) AS hva_malu,
            COUNT(DISTINCT rmau_member_guid) AS hva_rmalu,
            as_of_date
    FROM b2b_stg.hva_acro_user_events_by_guid
    WHERE hv_tool IS NOT NULL
    AND contract_offer_type in ('TEAM_DIRECT','VIP','VIPMP')
    GROUP BY
            org_id,
            org_name,
            offer_id,
            contract_id,
            contract_offer_type,
            offering_type,
            ech_parent_id,
            end_user_id,
            app_seats_provisioned,
            hv_category,
            hv_tool,
            as_of_date
    UNION ALL
    SELECT
            'Category' AS level_type,
            org_id,
            org_name,
            offer_id,
            contract_id,
            contract_offer_type,
            offering_type,
            ech_parent_id,
            end_user_id,
            app_seats_provisioned,
            hv_category AS category,
            hv_category AS hva,
            COUNT(DISTINCT member_guid) AS hva_delegated,
            COUNT(DISTINCT activation_guid) AS hva_activated,
            COUNT(DISTINCT qau_member_guid) AS hva_qalu,
            COUNT(DISTINCT mau_member_guid) AS hva_malu,
            COUNT(DISTINCT rmau_member_guid) AS hva_rmalu,
            as_of_date
    FROM b2b_stg.hva_acro_user_events_by_guid
    WHERE hv_category IS NOT NULL
    AND contract_offer_type in ('TEAM_DIRECT','VIP','VIPMP')
    GROUP BY
            org_id,
            org_name,
            offer_id,
            contract_id,
            contract_offer_type,
            offering_type,
            ech_parent_id,
            end_user_id,
            app_seats_provisioned,
            hv_category,
            as_of_date
    UNION ALL
    SELECT
            'Overall' AS level_type,
            org_id,
            org_name,
            offer_id,
            contract_id,
            contract_offer_type,
            offering_type,
            ech_parent_id,
            end_user_id,
            provisioned,
            'Overall' AS category,
            'Overall' AS hva,
            hva_delegated,
            hva_activated,
            hva_qalu,
            hva_malu,
            hva_rmalu,
            as_of_date
    FROM b2b.hva_acro_org_events_overall
    WHERE hva_delegated IS NOT NULL
    AND contract_offer_type in ('TEAM_DIRECT','VIP','VIPMP')
    AND as_of_date = '{B2B_RUN_DATE}' '''.format(B2B_RUN_DATE=B2B_RUN_DATE))

            spark.sql(''' DROP TABLE IF EXISTS b2b_stg.hva_acro_org_events_hva_combined_zero ''')
            spark.sql(''' CREATE TABLE b2b_stg.hva_acro_org_events_hva_combined_zero AS
WITH
latest_snap AS (
    SELECT max(as_of_date) AS as_of_date
    FROM b2b.hva_acro_org_events_hva_combined_nonzero
),
all_orgs AS (
    SELECT DISTINCT
            org_id,
            org_name,
            offer_id,
            contract_id,
            contract_offer_type,
            offering_type,
            ech_parent_id,
            end_user_id,
            provisioned,
            hva.as_of_date
	FROM b2b.hva_acro_org_events_hva_combined_nonzero hva
    JOIN latest_snap s ON s.as_of_date = hva.as_of_date
),
all_combs AS (
    SELECT DISTINCT
            level_type,
            category,
            hva,
            hva.as_of_date
	FROM b2b.hva_acro_org_events_hva_combined_nonzero hva
    JOIN latest_snap s ON s.as_of_date = hva.as_of_date
)
SELECT
            c.level_type,
            o.org_id,
            o.org_name,
            o.offer_id,
            o.contract_id,
            o.contract_offer_type,
            o.offering_type,
            o.ech_parent_id,
            o.end_user_id,
            o.provisioned,
            c.category,
            c.hva,
            0 AS hva_delegated,
            0 AS hva_activated,
            0 AS hva_qalu,
            0 AS hva_malu,
            0 AS hva_rmalu,
            c.as_of_date
FROM all_orgs o
JOIN all_combs c ON o.as_of_date = c.as_of_date
WHERE NOT EXISTS
	(SELECT TRUE
	 FROM b2b.hva_acro_org_events_hva_combined_nonzero b
    JOIN latest_snap s ON s.as_of_date = b.as_of_date
	 WHERE b.level_type = c.level_type
	   AND b.org_id = o.org_id
	   AND b.offer_id = o.offer_id
	   AND b.contract_id = o.contract_id
	   AND b.contract_offer_type = o.contract_offer_type
       AND b.offering_type = o.offering_type
       AND b.ech_parent_id = o.ech_parent_id
       AND b.end_user_id = o.end_user_id
	   AND b.category = c.category
	   AND b.hva = c.hva
	   AND b.as_of_date = c.as_of_date) ''')

            spark.sql(''' CREATE VIEW IF NOT EXISTS b2b.hva_acro_org_events_hva_combined AS
    SELECT
            level_type,
            org_id,
            org_name,
            offer_id,
            contract_id,
            contract_offer_type,
            offering_type,
            ech_parent_id,
            end_user_id,
            provisioned,
            category,
            hva,
            hva_delegated,
            hva_activated,
            hva_qalu,
            hva_malu,
            hva_rmalu,
            as_of_date
    FROM b2b.hva_acro_org_events_hva_combined_nonzero
    UNION ALL
    SELECT
            level_type,
            org_id,
            org_name,
            offer_id,
            contract_id,
            contract_offer_type,
            offering_type,
            ech_parent_id,
            end_user_id,
            provisioned,
            category,
            hva,
            hva_delegated,
            hva_activated,
            hva_qalu,
            hva_malu,
            hva_rmalu,
            as_of_date
    FROM b2b_stg.hva_acro_org_events_hva_combined_zero ''')

            try:
                 dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                 print("exception:",e)
        except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()

