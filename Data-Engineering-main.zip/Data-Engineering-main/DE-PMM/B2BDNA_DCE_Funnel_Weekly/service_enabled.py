from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys


class main:
    def __init__(self):
        try:
            spark = (
                SparkSession.builder.enableHiveSupport()
                .config("hive.exec.dynamic.partition", "true")
                .config("hive.exec.dynamic.partition.mode", "nonstrict")
                .config("hive.exec.max.dynamic.partitions", "10000")
                .getOrCreate()
            )
            log4j = spark._jvm.org.apache.log4j
            log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
            spark.sql("SET hive.warehouse.data.skiptrash=true;")
            spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
            spark.conf.set("spark.sql.cbo.enabled", True)
            spark.conf.set("spark.sql.cbo.join reorder.enabled", True)
            spark.sql("set spark.sql.parquet.enableVectorizedReader=false")
            spark.sql("set spark.sql.sources.partitionOverwriteMode=dynamic")
            spark.sql(
                "set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false"
            )
            spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            spark.sql("set spark.sql.adaptive.enabled=false")

            dbutils.widgets.text("Custom_Settings", "")
            dbutils.widgets.text("RUN_DATE", "")

            Settings = dbutils.widgets.get("Custom_Settings")
            RUN_DATE = dbutils.widgets.get("RUN_DATE")

            Set_list = Settings.split(",")
            if len(Set_list) > 0:
                for i in Set_list:
                    if i != "":
                        print("spark.sql(+i+)")
                        spark.sql("""{i}""".format(i=i))

            spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
            spark.sql(""" SET hive.execution.engine = mr """)
            spark.sql(""" SET mapred.job.queue.name=root.adhoc.standard """)
            spark.sql(""" SET hive.exec.dynamic.partition = TRUE """)
            org_pro_del_count = spark.sql(
                ''' select * from b2b.b2b_org_pro_del where as_of_date = '{RUN_DATE}' '''.format(
                    RUN_DATE=RUN_DATE)).count()
            snapshot_fact_count = spark.sql(
                ''' select * from b2b.snapshot_fact_enterprise_member_license_delegation where asofdate = '{RUN_DATE}' '''.format(
                    RUN_DATE=RUN_DATE)).count()
            if org_pro_del_count != 0 and snapshot_fact_count != 0:
                pass
            else:
                dbutils.notebook.exit(
                    "b2b_org_pro_del/snapshot_fact_enterprise_member_license_delegation is not updated for latest snapshot")
            spark.sql(
                """ INSERT OVERWRITE TABLE b2b.service_enabled PARTITION (asofdate)
SELECT p.org_id,
       p.org_name,
       --cast(g.group_id as int), -- B2BDME-2566 Commented as these fields are not used in the downstream tables 2023-09-06
       --p.cloud_type,
       --p.market_segment,
       --dim_geo.geo_code, -- B2BDME-2566 Commented as these fields are not used in the downstream tables 2023-09-06 
       --p.country,
       --ech_parent_industry as industry,
       p.offer_id, -- B2BDME-2566 NEW Field 
       p.offering_name,
       p.contract_offer_type,
       UPPER(service_name) as service_name,
       sum(num_users_services_enabled) num_users_services_enabled,
       SUM(num_users_services_disabled) num_users_services_disabled,
       cast('{RUN_DATE}' as date) AS asofdate
FROM 
  (

-- OLD CODE 
/*
SELECT org_id,
          org_name,
          cloud_type,
          market_segment,
          country,
          offering_name,
          contract_offer_type
   FROM enterprise.fact_dce_membership_count
   WHERE upper(offering_name) LIKE '%ACROBAT%'
     AND upper(offering_name) NOT LIKE '%RESTRICTED%'
     AND upper(offering_name) NOT LIKE '%MULTI%'
     AND upper(offering_name) NOT LIKE '%CHINA%'
     AND upper(offering_name) NOT LIKE '%ADOBE SIGN%'
     AND service_type != 'DESKTOP'
     AND is_valid = 'Y'
     AND contract_end_date >= '{RUN_DATE}'
*/

--NEW CODE START
    SELECT  
    DISTINCT  
    org_id,
    org_name,
    cloud_type,
    market_segment,
    org_country as country,
    offering_name,
    contract_type as contract_offer_type,
    offer_id -- B2BDME-2566 NEW Field 
    FROM b2b.b2b_org_pro_del
    WHERE 
    contract_type IN ('ETLA','EVIP') AND 
    --upper(offering_name) LIKE '%ACROBAT%' AND  -- B2BDME-2566 Removed the condition 
    upper(offering_name) NOT LIKE '%RESTRICTED%'
    AND upper(offering_name) NOT LIKE '%MULTI%'
    AND upper(offering_name) NOT LIKE '%CHINA%'
    AND upper(offering_name) NOT LIKE '%ADOBE SIGN%'
    --AND service_type != 'DESKTOP'   -- B2BDME-2566 Removed the condition adn applied on the offering_name as the service_type field is not availabel in the org_pro_del table
    AND upper(offering_name) NOT LIKE '%DESKTOP%'
    AND as_of_date='{RUN_DATE}'

-- NEW CODE END    
  ) p
LEFT JOIN
  (
    SELECT 
    d.org_id,
    d.group_id,
    d.offer_id,
    s.service_name,
    COUNT (DISTINCT if(upper(service_enabled)='TRUE',d.member_guid,NULL)) AS num_users_services_enabled,
    COUNT (DISTINCT if(upper(service_enabled)='FALSE',d.member_guid,NULL)) AS num_users_services_disabled,
    offering_name
    FROM b2b.snapshot_fact_enterprise_member_license_delegation d
    INNER JOIN
    (
      SELECT 
      DISTINCT 
      member_guid,
      org_id,
      group_id,
      service_name,
      service_enabled
      FROM enterprise.fact_fulfilled_enabled_services s
    ) s 
    ON (d.member_guid = s.member_guid
    AND d.org_id = s.org_id
    AND d.group_id = s.group_id)
    WHERE is_valid = 'Y'
    AND license_type = 'CONTRACTED'
    AND delegation_status = 'ACCEPTED'
    AND d.asofdate='{RUN_DATE}'
    GROUP BY 
    d.org_id,
    offering_name,
    s.service_name,
    d.group_id,
    d.offer_id
  ) d 
  ON p.org_id = d.org_id
  --AND p.offering_name = d.offering_name --Commented the code because of data duplication on offering_name mapping 2023-09-06
  AND p.offer_id = d.offer_id

--LEFT JOIN ids_coredata.dim_country dim_geo ON dim_geo.country_code_iso2 = p.country
--LEFT JOIN enterprise.dim_group g ON g.group_id=d.group_id
--LEFT JOIN (select org_id,max(ech_parent_industry) as ech_parent_industry from b2b.ecp_ecc_org_map where as_of_date = '{RUN_DATE}' group by org_id) i ON p.org_id=i.org_id
--AND g.org_id=d.org_id
GROUP BY p.org_id,
         p.org_name,
        -- g.group_id, -- B2BDME-2566 Commented as these fields are not used in the downstream tables 2023-09-06
         --p.cloud_type,
         --p.market_segment,
        -- dim_geo.geo_code, -- B2BDME-2566 Commented as these fields are not used in the downstream tables 2023-09-06
         --p.country,
         --ech_parent_industry,
         p.offering_name,
         p.offer_id,  -- B2BDME-2566 NEW Field
         p.contract_offer_type,
         d.service_name """.format(
                    RUN_DATE=RUN_DATE
                )
            )

            try:
                dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                print("exception:", e)
        except Exception as e:
            dbutils.notebook.exit(e)


if __name__ == "__main__":
    main()
