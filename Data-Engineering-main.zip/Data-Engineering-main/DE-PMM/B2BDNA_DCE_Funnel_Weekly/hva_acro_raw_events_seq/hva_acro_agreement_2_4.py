# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
import pandas as pd
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             df = spark.sql(""" select monthkey1,monthkey2,month1,month2,year1,year2,cast(first_day_prev_month as string) first_day_prev_month,from_date_string,to_date_string from b2b_tmp.hva_acro_partition_dates_tmp  """).toPandas()
             
             year_list = tuple(set(df.loc[0,['year1', 'year2']].values.flatten().tolist()))
             if len(year_list) == 1:
                 year_list = "('"+ str(tuple(year_list)[0])+ "')"
             else:
                 year_list = tuple(year_list)
             print(year_list)
             
             month_list = tuple(set(df.loc[0,['month1', 'month2']].values.flatten().tolist()))
             print(month_list)
             
             monthkey_list = tuple(set(df.loc[0,['monthkey1', 'monthkey2']].values.flatten().tolist()))
             print(monthkey_list)
             
             first_day_prev_month = tuple(set(df.loc[0,['first_day_prev_month']].values.flatten().tolist()))[0]
             print(first_day_prev_month)
             
             from_date_string = tuple(set(df.loc[0,['from_date_string']].values.flatten().tolist()))[0]
             print(from_date_string)

             to_date_string = tuple(set(df.loc[0,['to_date_string']].values.flatten().tolist()))[0]
             print(to_date_string)

             spark.sql(''' INSERT OVERWRITE TABLE b2b_tmp.hva_acro_agreement
WITH agreements AS (
    SELECT DISTINCT 
            substr (u.originator_adobe_guid, 1, 24) as member_guid,
            u.agreement_sent_for_esignature,
            u.agreement_is_megasign_child,
            date (substr (u.created, 1, 10)) AS event_date
        FROM
            (select distinct originator_adobe_guid,agreement_sent_for_esignature,agreement_is_megasign_child,created from a_sign_pub.agreement
            WHERE substr (created, 1, 10) >= '{from_date_string}'
        AND   substr (created, 1, 10) <= '{to_date_string}'
        AND status IN (
                'WAITING_FOR_SIGNATURES',
                'SIGNED',
                'EXPIRED',
                'WAITING_FOR_REVIEW',
                'ABANDONED')
        AND origination_type <> 'WELCOME'
        AND agreement_should_be_ignored = 0
        AND (   agreement_sent_for_esignature = 1
            OR  agreement_is_megasign_child = 1)) u
        JOIN b2b.b2b_users AS m
             ON m.member_guid = substr (u.originator_adobe_guid, 1, 24)
            AND m.as_of_date = '{B2B_RUN_DATE}'
            AND m.contract_offer_type in ('TEAM_DIRECT','VIP','VIPMP')
)
SELECT
        member_guid,
        'REQUEST_E_SIGNATURE' AS hv_tool,
        'FORMS_AND_SIGNATURES' AS hv_category,
        event_date
FROM    agreements
WHERE   agreement_sent_for_esignature = 1
UNION ALL
SELECT
        member_guid,
        'BULK_SEND' AS hv_tool,
        'FORMS_AND_SIGNATURES' AS hv_category,
        event_date
FROM    agreements
WHERE   agreement_is_megasign_child = 1 '''.format(B2B_RUN_DATE = B2B_RUN_DATE,from_date_string = from_date_string,to_date_string = to_date_string))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             raise Exception(e)

if __name__ == '__main__': 
        main()
