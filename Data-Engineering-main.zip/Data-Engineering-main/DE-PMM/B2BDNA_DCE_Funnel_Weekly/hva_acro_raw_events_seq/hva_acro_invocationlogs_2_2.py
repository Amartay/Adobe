# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
import pandas as pd
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             df = spark.sql(""" select monthkey1,monthkey2,month1,month2,year1,year2,cast(first_day_prev_month as string) first_day_prev_month,from_date_string,to_date_string from b2b_tmp.hva_acro_partition_dates_tmp  """).toPandas()
             
             year_list = tuple(set(df.loc[0,['year1', 'year2']].values.flatten().tolist()))
             if len(year_list) == 1:
                 year_list = "('"+ str(tuple(year_list)[0])+ "')"
             else:
                 year_list = tuple(year_list)
             print(year_list)
             
             month_list = tuple(set(df.loc[0,['month1', 'month2']].values.flatten().tolist()))
             print(month_list)
             
             monthkey_list = tuple(set(df.loc[0,['monthkey1', 'monthkey2']].values.flatten().tolist()))
             print(monthkey_list)
             
             first_day_prev_month = tuple(set(df.loc[0,['first_day_prev_month']].values.flatten().tolist()))[0]
             print(first_day_prev_month)
             
             from_date_string = tuple(set(df.loc[0,['from_date_string']].values.flatten().tolist()))[0]
             print(from_date_string)

             to_date_string = tuple(set(df.loc[0,['to_date_string']].values.flatten().tolist()))[0]
             print(to_date_string)

             #Extract data from alternative sources of events
             #As we only looking for limited number of events, the logic is simpler

             spark.sql(''' INSERT OVERWRITE TABLE b2b_tmp.hva_acro_invocationlogs
    SELECT DISTINCT 
            split(h.member_guid,'@')[0] as member_guid,
            CASE
                WHEN u.featurename IN 
                    ( 'SendInBulkApp', 'OpenInWebApp_SendInBulkApp')
                THEN 'BULK_SEND'
                WHEN u.featurename IN 
                    ('CollectPaymentsApp', 'OpenInWebApp_CollectPaymentsApp')
                THEN 'COLLECT_PAYMENTS'
                WHEN u.featurename IN 
                    ('AddSignBrandingApp', 'OpenInWebApp_AddSignBrandingApp')
                THEN 'CUSTOM_BRANDING'
                WHEN u.featurename IN 
                    ('CreateWebFormApp', 'OpenInWebApp_CreateWebFormApp')
                THEN 'PREPARE_WEB_FORMS'
            END AS hv_tool,
            'FORMS_AND_SIGNATURES' AS hv_category,
            date (substr (u.grouptime, 1, 10)) AS event_date
        FROM
            (SELECT distinct pguid,featurename,grouptime FROM dc_acrobatstar.invocationlogs
            WHERE monthkey  IN {monthkey_list}
        AND year        IN {year_list}
        AND month       IN {month_list}
        AND date (substr (grouptime, 1, 10)) >= date('{first_day_prev_month}')
        AND category    = 'ToolCenter'
        AND subcategory = 'Invoked'
        AND featurename IN (
            'CollectPaymentsApp',
            'AddSignBrandingApp',
            'SendInBulkApp',
            'CreateWebFormApp',
            'OpenInWebApp_CollectPaymentsApp',
            'OpenInWebApp_AddSignBrandingApp',
            'OpenInWebApp_SendInBulkApp',
            'OpenInWebApp_CreateWebFormApp')) u
        JOIN hb_monitor.user_mapping_snapshot h ON h.pguid = u.pguid
         '''.format(monthkey_list = monthkey_list,year_list = year_list,month_list = month_list,first_day_prev_month = first_day_prev_month))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             raise Exception(e)

if __name__ == '__main__': 
        main()
