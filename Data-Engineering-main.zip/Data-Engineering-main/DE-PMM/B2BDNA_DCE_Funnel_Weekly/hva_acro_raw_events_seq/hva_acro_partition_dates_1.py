# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
import pandas as pd
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             #Variables to be used to extract data by partition

             spark.sql(''' INSERT OVERWRITE TABLE b2b_tmp.hva_acro_partition_dates_tmp
WITH
    dates AS (
        SELECT
            to_date('{B2B_RUN_DATE}') d1, 
            trunc (add_months('{B2B_RUN_DATE}', -1), 'MM') d2)
SELECT
        substr (d1, 1, 4) AS year1,
        substr (d2, 1, 4) AS year2,
        substr (d1, 1, 7) AS monthkey1,
        substr (d2, 1, 7) AS monthkey2,
        cast (cast (substr (d1, 6, 2) AS INT) AS STRING) AS month1,
        cast (cast (substr (d2, 6, 2) AS INT) AS STRING) AS month2,
        date (d2) AS first_day_prev_month,
        cast (d2 AS STRING) AS from_date_string,
        cast (d1 AS STRING) AS to_date_string
FROM    dates 
             '''.format(B2B_RUN_DATE = B2B_RUN_DATE))


             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             raise Exception(e)

if __name__ == '__main__': 
        main()
