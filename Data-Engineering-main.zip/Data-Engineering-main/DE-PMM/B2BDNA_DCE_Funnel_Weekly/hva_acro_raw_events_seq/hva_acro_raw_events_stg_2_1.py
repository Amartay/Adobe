# Databricks notebook source
# MAGIC %run "/b2bdme/dates"

# COMMAND ----------

from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
import pandas as pd
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")

             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")
             

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             #Extract all usage data we will need for High Value Tool reporting
             #It allows us to look at only relevant usage in subsequent queries

             df = spark.sql(""" select monthkey1,monthkey2,month1,month2,year1,year2,cast(first_day_prev_month as string) first_day_prev_month,from_date_string,to_date_string from b2b_tmp.hva_acro_partition_dates_tmp  """).toPandas()
             
             year_list = tuple(set(df.loc[0,['year1', 'year2']].values.flatten().tolist()))
             if len(year_list) == 1:
                 year_list = "('"+ str(tuple(year_list)[0])+ "')"
             else:
                 year_list = tuple(year_list)
             print(year_list)
             
             month_list = tuple(set(df.loc[0,['month1', 'month2']].values.flatten().tolist()))
             print(month_list)
             
             monthkey_list = tuple(set(df.loc[0,['monthkey1', 'monthkey2']].values.flatten().tolist()))
             print(monthkey_list)
             
             first_day_prev_month = tuple(set(df.loc[0,['first_day_prev_month']].values.flatten().tolist()))[0]
             print(first_day_prev_month)
             
             from_date_string = tuple(set(df.loc[0,['from_date_string']].values.flatten().tolist()))[0]
             print(from_date_string)

             to_date_string = tuple(set(df.loc[0,['to_date_string']].values.flatten().tolist()))[0]
             print(to_date_string)

             spark.sql("""
          INSERT OVERWRITE TABLE b2b_tmp.hva_acro_raw_events_stg3
    SELECT DISTINCT
            u.pguid,
            m.hv_tool,
            m.hv_category,
            date (substr (u.featuretime, 1, 10)) AS event_date
        FROM
            (select distinct pguid,featuretime,category,subcategory,featurename,year,month,monthkey 
            from dc_acrobatstar.feature
            where year in {year_list}
            and month in {month_list} 
            and monthkey in {monthkey_list}
            and date (substr (featuretime, 1, 10)) >= date('{first_day_prev_month}')
            ) AS u
        JOIN b2b_stg.hva_acro_raw_events_mapping AS m
             ON u.category    = m.category
            AND u.subcategory = m.subcategory
            AND u.featurename = m.featurename
          """.format(year_list = year_list, month_list = month_list, monthkey_list = monthkey_list, first_day_prev_month = first_day_prev_month))

             #Extract corresponding member_guid

             spark.sql('''INSERT OVERWRITE TABLE b2b_tmp.hva_acro_raw_events_stg4
    SELECT DISTINCT 
            split(h.member_guid,'@')[0] as member_guid,
            u.hv_tool,
            u.hv_category,
            u.event_date
        FROM
            b2b_tmp.hva_acro_raw_events_stg3 u
        JOIN hb_monitor.user_mapping_snapshot h ON h.pguid = u.pguid
        JOIN b2b.b2b_users AS m
             ON m.member_guid = split(h.member_guid,'@')[0]
            AND m.as_of_date = '{B2B_RUN_DATE}'
            AND m.contract_offer_type in ('TEAM_DIRECT','VIP','VIPMP') '''.format(B2B_RUN_DATE = B2B_RUN_DATE))

             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             raise Exception(e)

if __name__ == '__main__': 
        main()
