# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
import pandas as pd
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")             

             #Populate permanent table
             spark.sql(''' 
             INSERT OVERWRITE table b2b_tmp.hva_acro_raw_events_tmp
    SELECT DISTINCT * FROM
    (SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'feature' as data_source
    FROM b2b_tmp.hva_acro_raw_events_stg4
    UNION ALL
    SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'web' as data_source
    FROM b2b_tmp.hva_acro_web
    UNION ALL
    SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'rhpfavtools' as data_source
    FROM b2b_tmp.hva_acro_rhpfavtools
    UNION ALL
    SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'invocationlogs' as data_source
    FROM b2b_tmp.hva_acro_invocationlogs
    UNION ALL
    SELECT
        member_guid,
        hv_tool,
        hv_category,
        CAST (event_date AS STRING) as event_date,
        CAST (CAST (SUBSTR (CAST (event_date AS STRING), 6, 2) AS INT) AS STRING) as month,
        SUBSTR (CAST (event_date AS STRING), 1, 4) as year,
        SUBSTR (CAST (event_date AS STRING), 1, 7) as monthkey,
        'agreements' as data_source
    FROM b2b_tmp.hva_acro_agreement) ''')


             try:
                 dbutils.notebook.exit("SUCCESS")   
             except Exception as e:                 
                 print("exception:",e)
         except Exception as e:
             raise Exception(e)

if __name__ == '__main__': 
        main()
