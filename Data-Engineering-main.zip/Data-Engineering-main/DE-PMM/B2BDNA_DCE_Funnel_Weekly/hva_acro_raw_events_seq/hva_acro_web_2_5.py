from pyspark import SparkContext, SparkConf, StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
import pandas as pd
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys


class main:
    def __init__(self):
        try:
            spark = (
                SparkSession.builder.enableHiveSupport()
                .config("hive.exec.dynamic.partition", "true")
                .config("hive.exec.dynamic.partition.mode", "nonstrict")
                .config("hive.exec.max.dynamic.partitions", "10000")
                .getOrCreate()
            )
            log4j = spark._jvm.org.apache.log4j
            log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
            spark.sql("SET hive.warehouse.data.skiptrash=true;")
            spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
            spark.conf.set("spark.sql.cbo.enabled", True)
            spark.conf.set("spark.sql.cbo.join reorder.enabled", True)
            spark.sql("set spark.sql.parquet.enableVectorizedReader=false")
            spark.sql("set spark.sql.sources.partitionOverwriteMode=dynamic")
            spark.sql(
                "set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false"
            )
            spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
            spark.sql("set spark.sql.adaptive.enabled=false")

            df = spark.sql(
                """ select monthkey1,monthkey2,month1,month2,year1,year2,cast(first_day_prev_month as string) first_day_prev_month,from_date_string,to_date_string from b2b_stg.hva_acro_partition_dates  """
            ).toPandas()

            year_list = tuple(
                set(df.loc[0, ["year1", "year2"]].values.flatten().tolist())
            )
            if len(year_list) == 1:
                year_list = "('" + str(tuple(year_list)[0]) + "')"
            else:
                year_list = tuple(year_list)
            print(year_list)

            month_list = tuple(
                set(df.loc[0, ["month1", "month2"]].values.flatten().tolist())
            )
            print(month_list)

            monthkey_list = tuple(
                set(df.loc[0, ["monthkey1", "monthkey2"]].values.flatten().tolist())
            )
            print(monthkey_list)

            first_day_prev_month = tuple(
                set(df.loc[0, ["first_day_prev_month"]].values.flatten().tolist())
            )[0]
            print(first_day_prev_month)

            from_date_string = tuple(
                set(df.loc[0, ["from_date_string"]].values.flatten().tolist())
            )[0]
            print(from_date_string)

            to_date_string = tuple(
                set(df.loc[0, ["to_date_string"]].values.flatten().tolist())
            )[0]
            print(to_date_string)

            spark.sql(
                """ CREATE OR REPLACE TABLE b2b_stg.hva_acro_web AS
    SELECT
            UPPER (SUBSTR (p.post_evar12, 1, 24)) as member_guid,
            CASE
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/public/compose%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Email Added%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Subject Updated%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:Message Updated%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Native Send:Use:File Uploaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/sendProgress%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/documentEdit%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/authoringv4%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%/account/postSend%'
                THEN 'REQUEST_E_SIGNATURE'
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:compose:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:authoring:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:review:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-sendinbulk:confirmation:loaded%'
                THEN 'BULK_SEND'
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_mrchId:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_pbcKey:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_prvKey:chg%'
                THEN 'COLLECT_PAYMENTS'
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_lgUpld:done%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_hostName:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_cmpName:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%adm_acSetup_cnAllUsrs:chg%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%adm_acSetup_cnAllUsrs:uchk%'
                THEN 'CUSTOM_BRANDING'
                WHEN   CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:compose:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:authoring:loaded%'
                    OR CONCAT (p.post_pagename, '|', p.post_evar83, '|', p.post_evar80, '|', p.post_evar59) LIKE '%sign:verb-createwebform:confirmation:loaded%'
                THEN 'PREPARE_WEB_FORMS'
            END AS hv_tool,
            'FORMS_AND_SIGNATURES' AS hv_category,
            date (p.click_date) AS event_date
        FROM
            --aa_ingest.sc_visitor_click_history_parquet_apr2022 p updated on 02/13 B2BDME-6218
            aa_ingest.sc_visitor_click_history p
        where report_suite = 'adbdcwebprod'
        AND post_evar7 = 'authenticated'
        AND click_date >= '{from_date_string}'
        AND click_date <= '{to_date_string}'
        AND (  CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%/public/compose%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Native Send:Use:Email Added%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Native Send:Use:Subject Updated%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Native Send:Use:Message Updated%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Native Send:Use:File Uploaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%/account/sendProgress%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%/account/documentEdit%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%/account/authoringv4%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%/account/postSend%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%sign:verb-sendinbulk:compose:loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%sign:verb-sendinbulk:authoring:loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%sign:verb-sendinbulk:review:loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%sign:verb-sendinbulk:confirmation:loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_lgUpld:done%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_hostName:chg%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Sign:SignIFramePage:adm_acSetup_cmpName:chg%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%adm_acSetup_cnAllUsrs:chg%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%adm_acSetup_cnAllUsrs:uchk%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%sign:verb-createwebform:compose:loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%sign:verb-createwebform:authoring:loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%sign:verb-createwebform:confirmation:loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_loaded%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_mrchId:chg%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_pbcKey:chg%'
            OR CONCAT (post_pagename, '|', post_evar83, '|', post_evar80, '|', post_evar59) LIKE '%Sign:SignIFramePage:adm_payInt_prvKey:chg%')
         """.format(
                    from_date_string=from_date_string, to_date_string=to_date_string
                )
            )

            try:
                dbutils.notebook.exit("SUCCESS")
            except Exception as e:
                print("exception:", e)
        except Exception as e:
            raise Exception(e)


if __name__ == "__main__":
    main()