-- Databricks notebook source
CREATE EXTERNAL TABLE IF NOT EXISTS b2b.finsys_dme_b2b_fpa_dbo_productmappings_on_prem (
  `materialnumber` string, 
  `materialnumberdescription` string, 
  `internalsegment` string, 
  `internalsegmentdescription` string, 
  `productname` string, 
  `productnamedescription` string, 
  `productconfig` string, 
  `productconfigdescription` string, 
  `subsegment` string, 
  `profitcenter` string, 
  `profitcenterdescription` string, 
  `olpg` string, 
  `numberofusers` string, 
  `entitlementtype` string, 
  `multiuserflag` string, 
  `svcsflag` string, 
  `svcstype` string, 
  `productdetail` string, 
  `productsummary` string, 
  `updateddatetime` string)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe' 
WITH SERDEPROPERTIES ( 
  'field.delim'='\u0001', 
  'serialization.format'='\u0001') 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b.db/finsys_dme_b2b_fpa_dbo_productmappings_on_prem';





CREATE EXTERNAL TABLE IF NOT EXISTS b2b.finsys_dme_b2b_fpa_dbo_productmappings (
  `materialnumber` string, 
  `materialnumberdescription` string, 
  `internalsegment` string, 
  `internalsegmentdescription` string, 
  `productname` string, 
  `productnamedescription` string, 
  `productconfig` string, 
  `productconfigdescription` string, 
  `subsegment` string, 
  `profitcenter` BIGINT, 
  `profitcenterdescription` string, 
  `olpg` string, 
  `numberofusers` INT, 
  `entitlementtype` string, 
  `multiuserflag` string, 
  `svcsflag` string, 
  `svcstype` string, 
  `productdetail` string, 
  `productsummary` string, 
  `updateddatetime` TIMESTAMP)
STORED as parquet
LOCATION
  'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b.db/finsys_dme_b2b_fpa_dbo_productmappings';


--MSCK REPAIR TABLE b2b.finsys_dme_b2b_fpa_dbo_productmappings_on_prem;