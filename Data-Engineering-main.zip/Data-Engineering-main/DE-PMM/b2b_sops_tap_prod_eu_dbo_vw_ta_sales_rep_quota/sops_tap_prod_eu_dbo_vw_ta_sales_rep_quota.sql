-- Databricks notebook source
CREATE EXTERNAL TABLE IF NOT EXISTS b2b.sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota_on_prem (
  `sfdc_dpq_id` string, 
  `dpq_id` string, 
  `sfdc_quota_id` string, 
  `quota_start_date` string, 
  `quota_end_date` string, 
  `active_ind` string, 
  `opg` string, 
  `opg_key` string, 
  `pay_measure` string, 
  `major_revenue_type` string, 
  `quota_amt` string, 
  `sfdc_terr_id` string, 
  `emp_id` string, 
  `emp_vcr_status` string, 
  `emp_role_status` string, 
  `role_type` string, 
  `fiscal_yr_and_qtr` string)
PARTITIONED BY ( 
  `as_of_date` string)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe' 
WITH SERDEPROPERTIES ( 
  'field.delim'='\u0001', 
  'serialization.format'='\u0001') 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b.db/sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota_on_prem';





CREATE EXTERNAL TABLE IF NOT EXISTS b2b.sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota (
  `sfdc_dpq_id` string, 
  `dpq_id` string, 
  `sfdc_quota_id` string, 
  `quota_start_date` date, 
  `quota_end_date` date, 
  `active_ind` int, 
  `opg` string, 
  `opg_key` int, 
  `pay_measure` int, 
  `major_revenue_type` string, 
  `quota_amt` double, 
  `sfdc_terr_id` string, 
  `emp_id` bigint, 
  `emp_vcr_status` string, 
  `emp_role_status` string, 
  `role_type` string, 
  `fiscal_yr_and_qtr` bigint)
PARTITIONED BY ( 
  `as_of_date` date)
STORED as parquet
LOCATION
  'abfs://or1-prod-data@azr6665prddpaasb2bdna.dfs.core.windows.net/user/hive/warehouse/b2bdna/b2b.db/sops_tap_prod_eu_dbo_vw_ta_sales_rep_quota';

