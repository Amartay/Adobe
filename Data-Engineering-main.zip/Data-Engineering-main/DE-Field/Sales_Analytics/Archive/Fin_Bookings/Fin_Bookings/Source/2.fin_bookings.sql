-- Databricks notebook source
-- DBTITLE 1,Config Optimisations
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.shuffle.partitions","auto")

-- COMMAND ----------

-- DBTITLE 1,Drop and Create Output Table
-- MAGIC %sql
-- MAGIC DROP TABLE IF EXISTS b2b.l2_sa_fin_bookings;
-- MAGIC CREATE TABLE b2b.l2_sa_fin_bookings (
-- MAGIC   parent_id STRING,
-- MAGIC   parent_name STRING,
-- MAGIC   sub_id STRING,
-- MAGIC   sub_name STRING,
-- MAGIC   
-- MAGIC   sub_geo STRING,
-- MAGIC   sub_country_code STRING,
-- MAGIC   sub_city STRING, 
-- MAGIC
-- MAGIC   end_user_id STRING,
-- MAGIC   end_user_name STRING,
-- MAGIC   dmegtmsegment STRING,
-- MAGIC   licensing_program_group STRING,
-- MAGIC   vip_contract STRING,
-- MAGIC   etla_vip_name STRING,
-- MAGIC   fiscal_yr_and_per_desc STRING,
-- MAGIC   fiscal_yr_and_wk_desc STRING,
-- MAGIC   week_end_date DATE,
-- MAGIC   fiscal_yr_and_qtr_desc STRING,
-- MAGIC   fiscal_yr_desc STRING,
-- MAGIC   geo_description STRING,
-- MAGIC   product_group STRING,
-- MAGIC   m2_products STRING,
-- MAGIC   large_deal_flag STRING,
-- MAGIC   new_deal_flag STRING,
-- MAGIC   renewal_date DATE,
-- MAGIC   renewal_wk STRING,
-- MAGIC   renewal_qtr STRING,
-- MAGIC   end_user STRING,
-- MAGIC   reseller STRING,
-- MAGIC   distributor STRING,
-- MAGIC   partner_level STRING,
-- MAGIC   ending_arr_week STRING,
-- MAGIC   cc_phone_vs_web STRING,
-- MAGIC   contract_type STRING,
-- MAGIC   ech_sub_country_code STRING,
-- MAGIC   market_area STRING,
-- MAGIC   market_segment STRING,
-- MAGIC   offering_type STRING,
-- MAGIC   route_to_market STRING,
-- MAGIC   sales_district STRING,
-- MAGIC   subs_offer STRING,
-- MAGIC   gross_new_arr DECIMAL(14,2),
-- MAGIC   net_cancelled_arr DECIMAL(14,2),
-- MAGIC   net_new_arr DECIMAL(14,2),
-- MAGIC   net_migration_arr DECIMAL(14,2),
-- MAGIC   executed_on STRING)
-- MAGIC USING DELTA
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #ETLA Fin Bookings

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC CREATE OR REPLACE TEMPORARY VIEW etla_refactored AS 
-- MAGIC
-- MAGIC -- calculate weekly movements
-- MAGIC SELECT   etla_movements.licensing_program_group,
-- MAGIC          etla_movements.parent_id,
-- MAGIC          etla_movements.parent_name,
-- MAGIC          etla_movements.sub_id,
-- MAGIC          etla_movements.sub_name,
-- MAGIC          subGeo.geo AS sub_geo,
-- MAGIC          subGeo.country_code AS sub_country_code,
-- MAGIC          subGeo.city AS sub_city,
-- MAGIC          etla_movements.end_user_id,
-- MAGIC          etla_movements.sub_name AS end_user_name,
-- MAGIC          etla_movements.fiscal_yr_and_qtr_desc,
-- MAGIC          etla_movements.fiscal_yr_and_wk_desc,
-- MAGIC          etla_movements.fiscal_yr_and_per_desc,
-- MAGIC          etla_movements.fiscal_yr_desc,
-- MAGIC          etla_movements.datedate,
-- MAGIC          etla_movements.product_group,
-- MAGIC          etla_movements.current_week_ending_arr,
-- MAGIC          etla_movements.m2_products,
-- MAGIC          etla_movements.previous_week_ending_arr,
-- MAGIC          etla_movements.vip_contract,
-- MAGIC          etla_movements.vip_name,
-- MAGIC          etla_movements.week_end_date,
-- MAGIC          etla_movements.geo_description,
-- MAGIC          etla_movements.dmegtmsegment,
-- MAGIC          etla_movements.cc_phone_vs_web,
-- MAGIC          etla_movements.contract_type,
-- MAGIC          etla_movements.ech_sub_country_code,
-- MAGIC          etla_movements.market_area,
-- MAGIC          etla_movements.market_segment,
-- MAGIC          etla_movements.offering_type,
-- MAGIC          etla_movements.route_to_market,
-- MAGIC          etla_movements.sales_district,
-- MAGIC          etla_movements.subs_offer,
-- MAGIC          etla_movements.current_week_ending_arr - coalesce(etla_movements.previous_week_ending_arr,0) as net_new_arr,
-- MAGIC          CASE WHEN etla_movements.current_week_ending_arr - coalesce(etla_movements.previous_week_ending_arr,0) > 0 THEN current_week_ending_arr - coalesce(etla_movements.previous_week_ending_arr,0) ELSE 0 END AS gross_new_arr,
-- MAGIC          CASE WHEN etla_movements.current_week_ending_arr - coalesce(etla_movements.previous_week_ending_arr,0) < 0 THEN -current_week_ending_arr + coalesce(etla_movements.previous_week_ending_arr,0) ELSE 0 END AS net_cancel_arr,
-- MAGIC          NULL AS net_migration_arr
-- MAGIC
-- MAGIC FROM (
-- MAGIC   -- Calculate previous week ending ARR
-- MAGIC   SELECT base.licensing_program_group,
-- MAGIC          base.parent_id,
-- MAGIC          base.parent_name,
-- MAGIC          base.sub_id,
-- MAGIC          base.sub_name,
-- MAGIC          base.end_user_id,
-- MAGIC          base.fiscal_yr_and_qtr_desc,
-- MAGIC          base.fiscal_yr_and_wk_desc,
-- MAGIC          base.fiscal_yr_and_per_desc,
-- MAGIC          base.fiscal_yr_desc,
-- MAGIC          base.datedate,
-- MAGIC          base.product_group,
-- MAGIC          base.current_week_ending_arr,
-- MAGIC          base.vip_contract,
-- MAGIC          base.vip_name,
-- MAGIC          base.dmegtmsegment,
-- MAGIC          base.week_end_date,
-- MAGIC          base.geo_description,
-- MAGIC          base.cc_phone_vs_web,
-- MAGIC          base.contract_type,
-- MAGIC          base.ech_sub_country_code,
-- MAGIC          base.market_area,
-- MAGIC          base.market_segment,
-- MAGIC          base.offering_type,
-- MAGIC          base.route_to_market,
-- MAGIC          base.sales_district,
-- MAGIC          base.subs_offer,
-- MAGIC          CASE WHEN upper(product_group) IN ('STOCK PHOTOGRAPHY', 'ADOBE SIGN', 'SUBSTANCE') THEN 'Y' ELSE 'N' END AS m2_products,
-- MAGIC          lag(current_week_ending_arr) OVER (PARTITION BY geo_description,vip_contract,sub_id, product_group,offering_type ORDER BY datedate) AS previous_week_ending_arr
-- MAGIC   FROM (
-- MAGIC         -- Base Table
-- MAGIC         SELECT 'ETLA' AS licensing_program_group,
-- MAGIC                 entarr01.echparentid AS parent_id,
-- MAGIC                 Max(entarr01.echparentname) AS parent_name,
-- MAGIC                 entarr01.echsubid AS sub_id,
-- MAGIC                 Max(entarr01.endusername) AS sub_name,
-- MAGIC                 Max(entarr01.enduser) AS end_user_id, -- In the original code Jai wrote he selects with MAX here - not too sure why - I have implemented this for consistency on the ECC ID 
-- MAGIC                 entarr01.fiscalyrandqtrdesc AS fiscal_yr_and_qtr_desc,
-- MAGIC                 Concat_ws('-', Substr(entarr01.fiscalyrandwk, 1, 4),Substr(entarr01.fiscalyrandwk, 5, 2)) AS fiscal_yr_and_wk_desc,
-- MAGIC                 entarr01.fiscalyrandperdesc AS fiscal_yr_and_per_desc,
-- MAGIC                 entarr01.fiscalyr AS fiscal_yr_desc,
-- MAGIC                 entarr01.datedate,
-- MAGIC                 entarr01.vipcontract AS vip_contract,
-- MAGIC                 entarr01.accountname AS vip_name,
-- MAGIC                 entarr01.dmegtmsegment AS dmegtmsegment,
-- MAGIC                 try_cast(dimdate.fiscal_wk_ending_date as DATE) AS week_end_date,
-- MAGIC                 entarr01.geodescription as geo_description,
-- MAGIC               CASE
-- MAGIC                 WHEN entarr01.productname IN ( 'SBTX', 'SBST', 'SRC' ) THEN 'Substance'
-- MAGIC                 WHEN entarr01.olpg IN ( 'ACROBAT') THEN 'Acrobat DC'
-- MAGIC                 WHEN entarr01.olpg IN ( 'SIGN', 'DCE TRANSACTION','DCE' ) THEN 'Adobe Sign'
-- MAGIC                 WHEN entarr01.olpg IN ( 'CREATIVE' ) THEN 'Creative - Professio'
-- MAGIC                 WHEN entarr01.olpg IN ( 'CCE STOCK', 'STOCK' ) THEN 'Stock Photography'
-- MAGIC                 ELSE 'Unmapped'
-- MAGIC               END AS product_group,
-- MAGIC
-- MAGIC               -- Ticket 5130: - logic taken from: https://git.corp.adobe.com/cce-dce-analytics/etl_jobs/blob/master/load_data/b2b/b2b_arr_presto.sql
-- MAGIC               'NONE' AS cc_phone_vs_web,
-- MAGIC                CASE
-- MAGIC                   WHEN entarr01.olpg = 'SIGN' AND entarr01.businesstype != 'ETLA' AND entarr01.etlaseattype LIKE '%ETLA%' THEN 'ETLA'
-- MAGIC                   WHEN entarr01.olpg = 'SIGN' AND entarr01.businesstype = 'SIGN' THEN 'SIGN_SAP_SA'
-- MAGIC                   ELSE businesstype
-- MAGIC               END AS contract_type,
-- MAGIC               org.ech_sub_country_code,
-- MAGIC               entarr01.marketarea AS market_area,
-- MAGIC               entarr01.marketsegment AS market_segment,
-- MAGIC                -- offering_type
-- MAGIC               CASE  WHEN entarr01.productname  IN ('CCAS','CCPS','CPDF','AIS','DAMC','DPS','WKF3','DCPS','SUPPORT PLAN ACROBAT','SUPPORT PLAN CC') THEN 'OTHER'
-- MAGIC                     WHEN upper(entarr01.productnamedescription ) like 'ACRO%PRO%' THEN 'ACRO PRO'
-- MAGIC                     WHEN upper(entarr01.productnamedescription ) like 'DOC%PRO%' THEN 'ACRO PRO'
-- MAGIC                     WHEN upper(entarr01.productnamedescription ) like 'ACRO%STD%' THEN 'ACRO STD'
-- MAGIC                     WHEN upper(entarr01.productnamedescription ) like 'DOC%STD%' THEN 'ACRO STD'
-- MAGIC                     WHEN entarr01.productname = 'ACRO' THEN 'ACRO STD'
-- MAGIC                     WHEN entarr01.productname IN ('CCLE','CCSV','CAUS','CCSB') THEN 'ALL_APPS'
-- MAGIC                     WHEN entarr01.olpg IN ('SIGN','DCE TRANSACTION') THEN 'SIGN'
-- MAGIC                     WHEN entarr01.productname = 'CTSK' THEN 'STOCK'
-- MAGIC                     WHEN UPPER (entarr01.productnamedescription) LIKE '%STOCK%' THEN 'STOCK'
-- MAGIC                     WHEN entarr01.productname IN ('SBST','SRC','SBTX') OR entarr01.olpg IN ('SUBSTANCE') THEN 'SUBST'
-- MAGIC                     ELSE 'SINGLE_APP'
-- MAGIC             END AS offering_type, -- logic taken from b2b_arr code, slightly refactored to save from a sub query
-- MAGIC               entarr01.sellinchanneldesc AS route_to_market,
-- MAGIC               entarr01.salesdistrict  sales_district,
-- MAGIC               'NONE' AS subs_offer,
-- MAGIC               Sum(Cast(entarr01.totalendingarr AS DOUBLE)) AS current_week_ending_arr
-- MAGIC         FROM  b2b.uda_uda_finance_arr_vw_entarr entarr01
-- MAGIC         INNER JOIN b2b_tmp.hana_ccmusage_dim_date dimdate
-- MAGIC           ON dimdate.date_key = replace(entarr01.DateDate,'-','')
-- MAGIC         -- ticket 5130 - bring in ech_sub_country_code (as in b2b_arr)
-- MAGIC         LEFT JOIN (SELECT DISTINCT end_user_id, ech_sub_country_code
-- MAGIC                     FROM b2b.ecp_ecc_org_map
-- MAGIC                     WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.ecp_ecc_org_map) ) org
-- MAGIC         ON regexp_replace(entarr01.enduser,'^0+(?!$)','')  = org.end_user_id -- Taken Directly from b2b_arr code
-- MAGIC
-- MAGIC         WHERE entarr01.SnapshotType = 'W'
-- MAGIC         AND ( entarr01.productgrouphier != 'IS17' -- non adobe sign product groups
-- MAGIC         OR ( --  ETLA data with SIGN Legacy
-- MAGIC                   entarr01.productgrouphier = 'IS17'
-- MAGIC                   AND Upper(entarr01.etlaseattype) IN ('ETLA- STANDARD', 'ETLA- HYBRID','ETLA- ACCESS' ) 
-- MAGIC             )
-- MAGIC         )
-- MAGIC         GROUP  BY entarr01.echparentid,
-- MAGIC                   entarr01.echsubid,  
-- MAGIC                   fiscalyrandqtrdesc,
-- MAGIC                   fiscalyrandperdesc,
-- MAGIC                   Concat_ws('-', Substr(fiscalyrandwk, 1, 4),
-- MAGIC                   Substr(fiscalyrandwk, 5, 2)),
-- MAGIC                   fiscalyr,
-- MAGIC                   datedate,
-- MAGIC                   entarr01.vipcontract,
-- MAGIC                   entarr01.accountname,
-- MAGIC                   entarr01.geodescription,
-- MAGIC                   try_cast(dimdate.fiscal_wk_ending_date as DATE),
-- MAGIC                   entarr01.dmegtmsegment,
-- MAGIC                   CASE
-- MAGIC                     WHEN entarr01.productname IN ( 'SBTX', 'SBST', 'SRC' ) THEN 'Substance'
-- MAGIC                     WHEN entarr01.olpg IN ( 'ACROBAT') THEN 'Acrobat DC'
-- MAGIC                     WHEN entarr01.olpg IN ( 'SIGN', 'DCE TRANSACTION','DCE' ) THEN 'Adobe Sign'
-- MAGIC                     WHEN entarr01.olpg IN ( 'CREATIVE' ) THEN 'Creative - Professio'
-- MAGIC                     WHEN entarr01.olpg IN ( 'CCE STOCK', 'STOCK' ) THEN 'Stock Photography'
-- MAGIC                     ELSE 'Unmapped'
-- MAGIC                   END,
-- MAGIC                   CASE
-- MAGIC                     WHEN entarr01.olpg = 'SIGN' AND entarr01.businesstype != 'ETLA' AND entarr01.etlaseattype LIKE '%ETLA%' THEN 'ETLA'
-- MAGIC                     WHEN entarr01.olpg = 'SIGN' AND entarr01.businesstype = 'SIGN' THEN 'SIGN_SAP_SA'
-- MAGIC                   ELSE businesstype
-- MAGIC               END,
-- MAGIC               org.ech_sub_country_code,
-- MAGIC               entarr01.marketarea,
-- MAGIC               entarr01.marketsegment,
-- MAGIC                -- offering_type
-- MAGIC               CASE  WHEN entarr01.productname  IN ('CCAS','CCPS','CPDF','AIS','DAMC','DPS','WKF3','DCPS','SUPPORT PLAN ACROBAT','SUPPORT PLAN CC') THEN 'OTHER'
-- MAGIC                     WHEN upper(entarr01.productnamedescription ) like 'ACRO%PRO%' THEN 'ACRO PRO'
-- MAGIC                     WHEN upper(entarr01.productnamedescription ) like 'DOC%PRO%' THEN 'ACRO PRO'
-- MAGIC                     WHEN upper(entarr01.productnamedescription ) like 'ACRO%STD%' THEN 'ACRO STD'
-- MAGIC                     WHEN upper(entarr01.productnamedescription ) like 'DOC%STD%' THEN 'ACRO STD'
-- MAGIC                     WHEN entarr01.productname = 'ACRO' THEN 'ACRO STD'
-- MAGIC                     WHEN entarr01.productname IN ('CCLE','CCSV','CAUS','CCSB') THEN 'ALL_APPS'
-- MAGIC                     WHEN entarr01.olpg IN ('SIGN','DCE TRANSACTION') THEN 'SIGN'
-- MAGIC                     WHEN entarr01.productname = 'CTSK' THEN 'STOCK'
-- MAGIC                     WHEN UPPER (entarr01.productnamedescription) LIKE '%STOCK%' THEN 'STOCK'
-- MAGIC                     WHEN entarr01.productname IN ('SBST','SRC','SBTX') OR entarr01.olpg IN ('SUBSTANCE') THEN 'SUBST'
-- MAGIC                     ELSE 'SINGLE_APP'
-- MAGIC             END, 
-- MAGIC               entarr01.sellinchanneldesc,
-- MAGIC               entarr01.salesdistrict     
-- MAGIC   ) base
-- MAGIC ) etla_movements
-- MAGIC LEFT JOIN ( SELECT DISTINCT s.sub_std_name_key, 
-- MAGIC                 upper(c.geo) AS geo,
-- MAGIC                 upper(s.country_code) AS country_code,
-- MAGIC                 upper(s.city) AS city   
-- MAGIC               FROM b2b.rv_td_sub s
-- MAGIC               LEFT JOIN (SELECT country_code_iso2, geo_code as geo FROM ids_coredata.dim_country) c
-- MAGIC               ON s.country_code = c.country_code_iso2) subGeo
-- MAGIC ON subGeo.sub_std_name_key = etla_movements.sub_id

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC INSERT INTO b2b.l2_sa_fin_bookings (
-- MAGIC   parent_id,parent_name,sub_id,sub_name,sub_geo,sub_country_code,sub_city,
-- MAGIC   end_user_id,end_user_name, dmegtmsegment,licensing_program_group,vip_contract,etla_vip_name,fiscal_yr_and_per_desc,fiscal_yr_and_wk_desc,
-- MAGIC   week_end_date,fiscal_yr_and_qtr_desc,fiscal_yr_desc,geo_description,product_group,m2_products,large_deal_flag,new_deal_flag,renewal_date,
-- MAGIC   renewal_wk,renewal_qtr,end_user,reseller,distributor,partner_level,
-- MAGIC   cc_phone_vs_web,contract_type,ech_sub_country_code,market_area,market_segment,offering_type,route_to_market,sales_district,subs_offer,
-- MAGIC   ending_arr_week,gross_new_arr,net_cancelled_arr,net_new_arr,net_migration_arr, executed_on )
-- MAGIC
-- MAGIC SELECT      parent_id,
-- MAGIC             parent_name,
-- MAGIC             sub_id,
-- MAGIC             sub_name,
-- MAGIC             sub_geo,
-- MAGIC             sub_country_code,
-- MAGIC             sub_city,
-- MAGIC             REGEXP_REPLACE(end_user_id, '^0+', '') AS end_user_id,
-- MAGIC             end_user_name,
-- MAGIC             dmegtmsegment,
-- MAGIC             licensing_program_group,
-- MAGIC             vip_contract,
-- MAGIC             vip_name AS etla_vip_name,
-- MAGIC             fiscal_yr_and_per_desc,
-- MAGIC             fiscal_yr_and_wk_desc,
-- MAGIC             week_end_date,
-- MAGIC             fiscal_yr_and_qtr_desc,
-- MAGIC             fiscal_yr_desc,
-- MAGIC             geo_description,
-- MAGIC             product_group,
-- MAGIC             m2_products,
-- MAGIC             NULL AS large_deal_flag, -- no idea how to calculate this for ETLA - is it the same as pivot? that seems odd, also you have no concept of "gross new subs"
-- MAGIC             CASE WHEN SUM(gross_new_arr) > 0 AND SUM(coalesce(previous_week_ending_arr,0))=0 THEN 'New Deal' ELSE 'Add On' END AS new_deal_flag,
-- MAGIC             NULL AS renewal_date, -- awaiting on b2bdme-1627 to be completed 
-- MAGIC             NULL AS renewal_wk,-- awaiting on b2bdme-1627 to be completed 
-- MAGIC             NULL AS renewal_qtr,-- awaiting on b2bdme-1627 to be completed 
-- MAGIC             NULL AS end_user,-- awaiting on b2bdme-1627 to be completed 
-- MAGIC             NULL AS reseller,-- awaiting on b2bdme-1627 to be completed 
-- MAGIC             NULL AS distributor,-- awaiting on b2bdme-1627 to be completed 
-- MAGIC             NULL AS partner_level,-- awaiting on b2bdme-1627 to be completed 
-- MAGIC             cc_phone_vs_web,
-- MAGIC             contract_type,
-- MAGIC             ech_sub_country_code,
-- MAGIC             market_area,
-- MAGIC             market_segment,
-- MAGIC             offering_type,
-- MAGIC             route_to_market,
-- MAGIC             sales_district,
-- MAGIC             subs_offer,
-- MAGIC             SUM(current_week_ending_arr) AS ending_arr_week,
-- MAGIC             SUM(gross_new_arr) AS gross_new_arr,
-- MAGIC             SUM(net_cancel_arr) AS net_cancelled_arr,
-- MAGIC             SUM(net_new_arr) AS net_new_arr,
-- MAGIC             NULL AS net_migration_arr, -- Uknown in ETLA ARR
-- MAGIC             CAST(current_timestamp() AS string) AS executed_on
-- MAGIC FROM etla_refactored
-- MAGIC GROUP BY parent_id,
-- MAGIC             parent_name,
-- MAGIC             sub_id,
-- MAGIC             sub_name,
-- MAGIC              sub_geo,
-- MAGIC             sub_country_code,
-- MAGIC             sub_city,
-- MAGIC             end_user_id,
-- MAGIC             end_user_name,
-- MAGIC             dmegtmsegment,
-- MAGIC             licensing_program_group,
-- MAGIC             vip_contract,
-- MAGIC             vip_name,
-- MAGIC             fiscal_yr_and_per_desc,
-- MAGIC             fiscal_yr_and_wk_desc,
-- MAGIC             week_end_date,
-- MAGIC             fiscal_yr_and_qtr_desc,
-- MAGIC             fiscal_yr_desc,
-- MAGIC             geo_description,
-- MAGIC             product_group,
-- MAGIC             m2_products,
-- MAGIC             cc_phone_vs_web,
-- MAGIC             contract_type,
-- MAGIC             ech_sub_country_code,
-- MAGIC             market_area,
-- MAGIC             market_segment,
-- MAGIC             offering_type,
-- MAGIC             route_to_market,
-- MAGIC             sales_district,
-- MAGIC             subs_offer

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #Pivot Fin Bookings

-- COMMAND ----------

-- DBTITLE 1,Refresh pivot metadata
REFRESH TABLE CSMB_APP.fact_csmb_subscription_detail;
REFRESH TABLE CSMB_APP.exchange_rate_type_qtrly;
REFRESH TABLE CSMB_APP.subscription_params;
REFRESH TABLE CSMB_APP.acct_segment_activity_cutoff;
REFRESH TABLE CSMB_APP.acct_segment_realign_hist;
REFRESH TABLE CSMB_APP.dim_gtm_acct_hierarchy;
REFRESH TABLE CSMB_APP.gtm_projected_segmentation;
REFRESH TABLE CSMB_APP.dim_subscription;
REFRESH TABLE CSMB_APP.dim_gtm_acct_segment;
REFRESH csmb.vw_ccm_pivot4_all;

-- COMMAND ----------

-- DBTITLE 1,Create Materialized Table From Pivot View for Base Data
DROP TABLE IF EXISTS  b2b_tmp.base_pivot_data;
CREATE TABLE b2b_tmp.base_pivot_data AS 
SELECT      
      ech_parent_id AS parent_id,
      ech_parent_name AS parent_name,
      ech_sub_id AS sub_id,
      ech_sub_name AS sub_name,
      regexp_replace(p.ecc_customer_id,'^0+(?!$)','') AS end_user_id,
      p.acct_name AS end_user_name,
      acct_name AS etla_vip_name,   
      gtm_acct_segment AS dmegtmsegment,
      CASE WHEN trim(upper(route_to_market)) = 'ADOBE.COM/CC.COM' THEN 'VIP - Direct' ELSE 'VIP - Reseller' END AS licensing_program_group,
      vip_contract,
      p.fiscal_yr_and_per_desc,
      p.fiscal_yr_and_wk_desc,
      try_cast(dimdate.fiscal_wk_ending_date as DATE) AS week_end_date,
      p.fiscal_yr_and_qtr_desc,
      p.fiscal_yr_desc,
      geo,
      CASE WHEN Trim(Upper(product_name)) IN ( 'SBST', 'SRC', 'SBTX' ) 
            THEN 'Substance'
      ELSE prod_group_hier_description
      END AS product_group,
      geo_description,
      sales_document,

      -- Added as part of Ticket 5130
      -- the logic below is lifted from the b2b_arr code: https://git.corp.adobe.com/cce-dce-analytics/etl_jobs/blob/master/load_data/b2b/b2b_arr_presto.sql
      p.cc_phone_vs_web,
      CASE WHEN p.STYPE = 'TM' AND p.vip_contract != '' AND UPPER(product_config) LIKE '%E' THEN 'EVIP'
            WHEN p.STYPE = 'TM' AND p.cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market= 'RESELLER' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market = 'ADOBE.COM/CC.COM' AND p.cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
            ELSE 'UNKNOWN'
      END AS contract_type,
      org.ech_sub_country_code,
      p.market_area,
      p.market_segment,
      CASE  WHEN product_name IN ('CCAS','CCPS','CPDF','AIS','DAMC','DPS','WKF3','DCPS','SUPPORT PLAN ACROBAT','SUPPORT PLAN CC') THEN 'OTHER'
            WHEN upper(product_name_description) like 'ACRO%PRO%' THEN 'ACRO PRO'
            WHEN upper(product_name_description) like 'DOC%PRO%' THEN 'ACRO PRO'
            WHEN upper(product_name_description) like 'ACRO%STD%' THEN 'ACRO STD'
            WHEN upper(product_name_description) like 'DOC%STD%' THEN 'ACRO STD'
            WHEN product_name = 'ACRO' THEN 'ACRO STD'
            WHEN product_name IN ('CCLE','CCSV','CAUS','CCSB') THEN 'ALL_APPS'
            WHEN cc_segment IN ('SIGN','DCE TRANSACTION') THEN 'SIGN'
            WHEN product_name = 'CTSK' THEN 'STOCK'
            WHEN UPPER (product_name_description) LIKE '%STOCK%' THEN 'STOCK'
            WHEN product_name IN ('SBST','SRC','SBTX') OR cc_segment IN ('SUBSTANCE') THEN 'SUBST'
            ELSE 'SINGLE_APP'
      END AS offering_type, -- logic taken from b2b_arr code, slightly refactored to save from a sub query
      route_to_market,
      sales_district,
      subs_offer,
      Sum(fwk_begin_arr_cfx)     AS begin_arr_week, -- Snapshot Level - populated once a week, so summing like this is fine (grouped by week)
      Sum(fwk_end_arr_cfx)       AS end_arr_week, -- Snapshot Level - populated once a week, so summing like this is fine (grouped by week)
      Sum(net_purchases_arr_cfx) AS gross_new_arr, -- Event level - only the transactions themselves populate this value
      Sum(net_cancelled_arr_cfx) AS net_cancelled_arr_cfx, -- Event level - only the transactions themselves populate this value
      Sum(net_new_arr_cfx)       AS net_new_arr, -- Snapshot Level - based off begin / end arr - so grouping like this is fine 
      Sum(net_new_arr_cfx - net_purchases_arr_cfx + net_cancelled_arr_cfx) AS net_migration_arr, -- Snapshot Level - based off begin / end arr - so grouping like this is fine 
      Sum(gross_new_subs)        AS gross_new_subs  -- Event level - only the transactions themselves populate this value
FROM   csmb.vw_ccm_pivot4_all p
INNER JOIN b2b_tmp.hana_ccmusage_dim_date dimdate
ON dimdate.date_key = p.date_key

-- ticket 5130 - bring in ech_sub_country_code (as in b2b_arr)
LEFT JOIN (SELECT DISTINCT end_user_id, ech_sub_country_code
            FROM b2b.ecp_ecc_org_map
            WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.ecp_ecc_org_map) ) org
ON regexp_replace(p.ecc_customer_id,'^0+(?!$)','')  = org.end_user_id -- Taken Directly from b2b_arr code
WHERE  NOT Isnull(vip_contract)
AND p.date_key >=20210101
GROUP  BY   ech_parent_id,
            ech_parent_name,
            regexp_replace(p.ecc_customer_id,'^0+(?!$)',''),
            ech_sub_id,
            ech_sub_name,
            gtm_acct_segment,
            CASE WHEN trim(upper(route_to_market)) = 'ADOBE.COM/CC.COM' THEN 'VIP - Direct' ELSE 'VIP - Reseller' END,
            vip_contract,
            acct_name,
            p.fiscal_yr_and_per_desc,
            p.fiscal_yr_and_wk_desc,
            try_cast(dimdate.fiscal_wk_ending_date as DATE),
            p.fiscal_yr_and_qtr_desc,
            p.fiscal_yr_desc,
            geo,
            CASE WHEN Trim(Upper(product_name)) IN ( 'SBST', 'SRC', 'SBTX' ) 
                  THEN 'Substance'
            ELSE prod_group_hier_description END,
            geo_description,
            sales_document,
             p.cc_phone_vs_web,
      CASE WHEN p.STYPE = 'TM' AND p.vip_contract != '' AND UPPER(product_config) LIKE '%E' THEN 'EVIP'
            WHEN p.STYPE = 'TM' AND p.cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market= 'RESELLER' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market = 'ADOBE.COM/CC.COM' AND p.cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
            ELSE 'UNKNOWN'
      END,
      org.ech_sub_country_code,
      p.market_area,
      p.market_segment,
      CASE  WHEN product_name IN ('CCAS','CCPS','CPDF','AIS','DAMC','DPS','WKF3','DCPS','SUPPORT PLAN ACROBAT','SUPPORT PLAN CC') THEN 'OTHER'
            WHEN upper(product_name_description) like 'ACRO%PRO%' THEN 'ACRO PRO'
            WHEN upper(product_name_description) like 'DOC%PRO%' THEN 'ACRO PRO'
            WHEN upper(product_name_description) like 'ACRO%STD%' THEN 'ACRO STD'
            WHEN upper(product_name_description) like 'DOC%STD%' THEN 'ACRO STD'
            WHEN product_name = 'ACRO' THEN 'ACRO STD'
            WHEN product_name IN ('CCLE','CCSV','CAUS','CCSB') THEN 'ALL_APPS'
            WHEN cc_segment IN ('SIGN','DCE TRANSACTION') THEN 'SIGN'
            WHEN product_name = 'CTSK' THEN 'STOCK'
            WHEN UPPER (product_name_description) LIKE '%STOCK%' THEN 'STOCK'
            WHEN product_name IN ('SBST','SRC','SBTX') OR cc_segment IN ('SUBSTANCE') THEN 'SUBST'
            ELSE 'SINGLE_APP'
      END,
      route_to_market,
      sales_district,
      subs_offer

-- COMMAND ----------

-- DBTITLE 1,Create Fin Bookings - VIP 

INSERT INTO b2b.l2_sa_fin_bookings (
  parent_id,parent_name,sub_id,sub_name,sub_geo,sub_country_code,sub_city,
  end_user_id,end_user_name, dmegtmsegment,licensing_program_group,vip_contract,etla_vip_name,fiscal_yr_and_per_desc,fiscal_yr_and_wk_desc,
  week_end_date,fiscal_yr_and_qtr_desc,fiscal_yr_desc,geo_description,product_group,m2_products,large_deal_flag,new_deal_flag,renewal_date,
  renewal_wk,renewal_qtr,end_user,reseller,distributor,partner_level,
  cc_phone_vs_web,contract_type,ech_sub_country_code,market_area,market_segment,offering_type,route_to_market,sales_district,subs_offer,
  ending_arr_week,gross_new_arr,net_cancelled_arr,net_new_arr,net_migration_arr, executed_on )

SELECT
					parent_id,
          parent_name,
          sub_id,
          sub_name,
          subGeo.geo AS sub_geo,
          subGeo.country_code AS sub_country_code,
          subGeo.city AS sub_city,
          end_user_id,
          end_user_name,
          dmegtmsegment,
          licensing_program_group,
          vip_contract,
          etla_vip_name,
          fiscal_yr_and_per_desc,
          fiscal_yr_and_wk_desc,
          week_end_date,
          fiscal_yr_and_qtr_desc,
          fiscal_yr_desc,
          geo_description,
          product_group,
          CASE WHEN UPPER(product_group) in ('STOCK PHOTOGRAPHY', 'ADOBE SIGN', 'SUBSTANCE') THEN 'Y' ELSE 'N' END AS m2_products,
          -- large deal vs run-rate flag
          case when product_group = 'Adobe Sign' and gross_new_arr_sum > 7499 then 'Large Deal'
              when product_group = 'Creative - Professio' and gross_new_arr_sum > 25000 then 'Large Deal'
                                when product_group = 'Acrobat DC' and gross_new_subs_sum > 49 then 'Large Deal'
              else 'Run Rate' end as large_deal_flag,
          -- new deal
          case when begin_arr_week_new_deal = 0 or begin_arr_week_new_deal IS NULL then 'New Deal' else 'Add-on' END as new_deal_flag,
          NULL AS renewal_date, -- awaiting on b2bdme-1627 to be completed 
          NULL AS renewal_wk,-- awaiting on b2bdme-1627 to be completed 
          NULL AS renewal_qtr,-- awaiting on b2bdme-1627 to be completed 
          NULL AS end_user,-- awaiting on b2bdme-1627 to be completed 
          NULL AS reseller,-- awaiting on b2bdme-1627 to be completed 
          NULL AS distributor,-- awaiting on b2bdme-1627 to be completed 
          NULL AS partner_level,-- awaiting on b2bdme-1627 to be completed 
          cc_phone_vs_web,
          contract_type,
          ech_sub_country_code,
          market_area,
          market_segment,
          offering_type,
          route_to_market,
          sales_district,subs_offer,
					sum(end_arr_week) AS ending_arr_week,
					sum(gross_new_arr) AS gross_new_arr,
				  sum(net_cancelled_arr_cfx) AS net_cancelled_arr,
					sum(net_new_arr) as net_new_arr,
					sum(net_migration_arr) as migrated_to_arr,
          CAST(current_timestamp() AS string) AS executed_on
FROM (
      -- Add partitioned sums 
      SELECT  base.*,
              -- Sales document is used in the first 2 to signify a specific order "Big order", it is not used to show the opening position for New Deal, which is more a representation of "week has new deal"
              sum(base.gross_new_arr) over (partition by base.vip_contract, base.sales_document, base.product_group, base.fiscal_yr_and_wk_desc) as gross_new_arr_sum,
              sum(base.gross_new_subs) over (partition by base.vip_contract, base.sales_document, base.product_group, base.fiscal_yr_and_wk_desc) as gross_new_subs_sum,
              sum(begin_arr_week) over (partition by vip_contract,licensing_program_group, fiscal_yr_and_wk_desc,geo_description) as begin_arr_week_new_deal
      FROM ( 

            -- Base pivot information
            SELECT  parent_id,
                    parent_name,
                    sub_id,
                    sub_name,
                    end_user_id,
                    end_user_name,
                    dmegtmsegment,
                    CASE WHEN UPPER(product_group) in ('STOCK PHOTOGRAPHY', 'ADOBE SIGN', 'SUBSTANCE') THEN 'Y' ELSE 'N' END AS m2_products,
                    vip_contract,
                    etla_vip_name,
                    fiscal_yr_and_per_desc,
                    fiscal_yr_and_wk_desc,
                    week_end_date,
                    fiscal_yr_and_qtr_desc,
                    fiscal_yr_desc,
                    product_group,
                    licensing_program_group,
                    geo_description,
                    sales_document,
                     cc_phone_vs_web,
                    contract_type,
                    ech_sub_country_code,
                    market_area,
                    market_segment,
                    offering_type,
                    route_to_market,
                    sales_district,subs_offer,
                    begin_arr_week, 
                    end_arr_week, 
                    gross_new_arr, 
                    net_cancelled_arr_cfx, 
                    net_new_arr, 
                    net_migration_arr, 
                    gross_new_subs
            FROM    b2b_tmp.base_pivot_data
         
      ) base
) partitionedSums
LEFT JOIN  ( 
      SELECT DISTINCT s.sub_std_name_key, 
                    upper(c.geo) AS geo,
                    upper(s.country_code) AS country_code,
                    upper(s.city) AS city   
    FROM b2b.rv_td_sub s
    LEFT JOIN (SELECT country_code_iso2, geo_code as geo FROM ids_coredata.dim_country) c
    ON s.country_code = c.country_code_iso2
) subGeo
ON subGeo.sub_std_name_key = partitionedSums.sub_id
GROUP BY
          parent_id,
          parent_name,
          sub_id,
          sub_name,
          subGeo.geo,
          subGeo.country_code,
          subGeo.city,
          end_user_id,
          end_user_name,
          dmegtmsegment,
          CASE WHEN UPPER(product_group) in ('STOCK PHOTOGRAPHY', 'ADOBE SIGN', 'SUBSTANCE') THEN 'Y' ELSE 'N' END,
          vip_contract,
          etla_vip_name,
          fiscal_yr_and_per_desc,
          fiscal_yr_and_wk_desc,
          week_end_date,
          fiscal_yr_and_qtr_desc,
          fiscal_yr_desc,
          product_group,
          licensing_program_group,
          geo_description,
          -- new deal
          case when begin_arr_week_new_deal = 0 or begin_arr_week_new_deal IS NULL then 'New Deal' else 'Add-on' END,
          -- large deal vs run-rate flag
          case when product_group = 'Adobe Sign' and gross_new_arr_sum > 7499 then 'Large Deal'
              when product_group = 'Creative - Professio' and gross_new_arr_sum > 25000 then 'Large Deal'
                                when product_group = 'Acrobat DC' and gross_new_subs_sum > 49 then 'Large Deal'
              else 'Run Rate' end,
          cc_phone_vs_web,
          contract_type,
          ech_sub_country_code,
          market_area,
          market_segment,
          offering_type,
          route_to_market,
          sales_district,
          subs_offer


-- COMMAND ----------

-- DBTITLE 1,Remove Tmp Table
DROP TABLE IF EXISTS b2b_tmp.base_pivot_data;
