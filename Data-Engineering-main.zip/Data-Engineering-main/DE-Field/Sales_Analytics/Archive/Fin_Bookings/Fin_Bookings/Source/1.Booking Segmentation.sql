-- Databricks notebook source
-- DBTITLE 1,Refresh metadata in pivot4all
REFRESH csmb.vw_ccm_pivot4_all;

-- COMMAND ----------

-- DBTITLE 1,Drop output table if exists
DROP TABLE IF EXISTS b2b.l2_sa_fin_segmentation

-- COMMAND ----------

-- DBTITLE 1,Create fin_segmentation Table
CREATE TABLE b2b.l2_sa_fin_segmentation (
subsidiary_id STRING ,
parent_id STRING,
ecc_id STRING, 
contract_id STRING, 
etla_vip_name STRING, 
amer_event_geo_flag VARCHAR(1),
emea_event_geo_flag VARCHAR(1),
apac_event_geo_flag VARCHAR(1),
japan_event_geo_flag VARCHAR(1),
amer_mm VARCHAR(1),
amer_edu VARCHAR(1), 
emea_pss VARCHAR(1),
emea_edu VARCHAR(1) );


-- COMMAND ----------

-- DBTITLE 1,Insert into fin_segmentation Table (VIP - Pivot4all) 
-- MAGIC %sql
-- MAGIC INSERT INTO b2b.l2_sa_fin_segmentation (subsidiary_id,parent_id,ecc_id,contract_id,etla_vip_name,amer_event_geo_flag,emea_event_geo_flag,apac_event_geo_flag,japan_event_geo_flag,amer_mm,amer_edu,emea_pss,emea_edu)
-- MAGIC SELECT DISTINCT  p.ech_sub_id AS subsidiary_id,
-- MAGIC         p.ech_parent_id AS parent_id,
-- MAGIC         p.ecc_customer_id AS ecc_id,
-- MAGIC         p.vip_contract AS contract_id,
-- MAGIC         acct_name AS etla_vip_name,
-- MAGIC         CASE WHEN p.geo='AMER' THEN 'Y' ELSE '-' END AS amer_event_geo_flag,
-- MAGIC         CASE WHEN  p.geo='EMEA' THEN 'Y' ELSE '-' END AS emea_event_geo_flag,
-- MAGIC         CASE WHEN  p.geo='ASIA' THEN 'Y' ELSE '-' END AS apac_event_geo_flag,
-- MAGIC         CASE WHEN  p.geo='JPN' THEN 'Y' ELSE '-' END AS japan_event_geo_flag,
-- MAGIC         CASE WHEN amermm.vip_contract IS NOT NULL THEN 'Y' ELSE '-' END AS amer_mmm,
-- MAGIC         CASE WHEN p.geo='AMER' AND p.region ='NAM' AND p.market_segment = 'EDUCATION' THEN 'Y' ELSE '-' END AS amer_edu,
-- MAGIC         CASE WHEN emea_pss.standardizedsubid IS NOT NULL THEN 'Y' ELSE '-' END AS emea_pss,
-- MAGIC         CASE WHEN p.geo='EMEA' AND p.market_segment IN ('EDUCATION','NON-PROFIT') THEN 'Y' ELSE '-' END AS emea_edu
-- MAGIC FROM csmb.vw_ccm_pivot4_all p
-- MAGIC LEFT JOIN (SELECT DISTINCT vip_contract,internal_segment
-- MAGIC           FROM b2b.agodah_mmviplist) amermm
-- MAGIC   ON p.vip_contract = amermm.vip_contract
-- MAGIC   AND amermm.internal_segment = p.prod_group_hier_description
-- MAGIC -- you are emea PSS if you have a sub ID relating to a EMEA PSS Opportunity
-- MAGIC LEFT JOIN (
-- MAGIC             SELECT opp.FullOptyId, 
-- MAGIC                     acc.standardizedsubid
-- MAGIC             FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
-- MAGIC             -- get the sub IDs
-- MAGIC             INNER JOIN (  SELECT standardizedsubid, id
-- MAGIC                           FROM b2b.uda_replicn_sf_corp_uda_vw_account
-- MAGIC                           WHERE as_of_date = ( SELECT max(as_of_date)
-- MAGIC                                                 FROM b2b.uda_replicn_sf_corp_uda_vw_account)
-- MAGIC                       ) acc ON opp.AccountID = acc.Id 
-- MAGIC             -- Limit opportunities to those flagged as EMEA_PSS in pipeline segmentation
-- MAGIC             INNER JOIN (  SELECT full_opty_id 
-- MAGIC                           FROM b2b.l2_sa_sfdc_pipeline_segmentation
-- MAGIC                           WHERE emea_pss_22_q3='Y'
-- MAGIC                           OR emea_pss_22_q4='Y'
-- MAGIC                           OR emea_pss_23='Y' ) ps
-- MAGIC             ON ps.full_opty_id = opp.fulloptyid
-- MAGIC             WHERE opp.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)
-- MAGIC             ) emea_pss
-- MAGIC ON emea_pss.standardizedsubid = p.ech_sub_id
-- MAGIC WHERE p.date_key >=20210101 
-- MAGIC AND p.event_source = 'EVENT' -- has to be event to have GEO referenced;

-- COMMAND ----------

-- DBTITLE 1,ETLA - Enterprise ARR
INSERT INTO b2b.l2_sa_fin_segmentation (subsidiary_id,parent_id,ecc_id,contract_id,etla_vip_name,amer_event_geo_flag,emea_event_geo_flag,apac_event_geo_flag,japan_event_geo_flag,amer_mm,amer_edu,emea_pss,emea_edu)
SELECT DISTINCT echsubid AS subsidiary_id,
                echparentid AS parent_id,
                'Unknown' AS ecc_id, -- not sure this exists in Ent Arr
                vipcontract AS contract_id,
                accountname AS etla_vip_name,
                CASE WHEN ent.geodescription='AMERICAS' THEN 'Y' ELSE '-' END AS amer_event_geo_flag,
                CASE WHEN  ent.geodescription='EMEA' THEN 'Y' ELSE '-' END AS emea_event_geo_flag,
                CASE WHEN  ent.geodescription='ASIA' THEN 'Y' ELSE '-' END AS apac_event_geo_flag,
                CASE WHEN  ent.geodescription='JAPAN' THEN 'Y' ELSE '-' END AS japan_event_geo_flag,
                CASE WHEN mm.Sub_ID IS NOT NULL AND ent.dmegtmsegment = 'CSMB' 
                                                AND ent.marketsegment IN ('COMMERCIAL', 'NON-PROFIT') 
                                                AND ent.region = 'NAM' 
                     THEN 'Y' ELSE '-' END AS amer_mm,
                CASE WHEN ent.productgrouphierdescription IN ('Acrobat DC', 'Adobe Sign', 'Creative - Professio', 'Stock Photography') 
                                                          AND ent.dmegtmsegment IN  ('CSMB', 'Enterprise')  
                                                          AND ent.marketsegment = 'EDUCATION' 
                                                          AND ent.region = 'NAM' 
                     THEN 'Y' ELSE '-' END AS amer_edu,
                CASE WHEN ent.geodescription='EMEA' AND ent.dmegtmsegment IN ('CSMB','Mid-Market')
                                                    AND ent.marketsegment IN ('COMMERICAL','GOVERNMENT')
                     THEN 'Y' ELSE '-' END AS emea_pss,
                CASE WHEN ent.geodescription='EMEA' AND ent.marketsegment IN ('EDUCATION','NON-PROFIT')
                     THEN 'Y' ELSE '-' END AS emea_edu
FROM b2b.uda_uda_finance_arr_vw_entarr ent
LEFT JOIN b2b.agodah_mmcoverage mm 
  ON ent.echsubid = mm.Sub_ID
WHERE ent.snapshottype = 'D'
AND ent.datedate = (SELECT MAX(datedate) FROM b2b.uda_uda_finance_arr_vw_entarr WHERE snapshottype = 'D' )