/*
    Author: Arthish Bhaskar
    Last Updated by: James Cooke (primary) and Stephen Wills
    Last Updated: 04/04/2023
    Documentation Link: https://wiki.corp.adobe.com/display/CCM/Sales+Pipeline+L2+-+HISTORY
    Last Update Description: Productionise code - standardize formatting & field names, rename output table to new format
*/

DROP TABLE IF EXISTS b2b.l2_sa_sfdc_opp_progression;

CREATE TABLE b2b.l2_sa_sfdc_opp_progression AS 
SELECT DISTINCT  opportunityid AS full_opty_id
                ,regexp_replace(substr(closedate_date,1,10),'-','') closedate_string
                ,cast(substr(closedate_date,1,10) AS DATE) AS closedate_date
                ,regexp_replace(substr(initialstage1date_date,1,10),'-','') AS initialstage1date_string
                ,cast(substr(initialstage1date_date,1,10) AS DATE) AS initialstage1date_date
                ,regexp_replace(substr(initialstage2date_date,1,10),'-','') AS initialstage2date_string
                ,cast(substr(initialstage2date_date,1,10) AS DATE) AS initialstage2date_date
                ,regexp_replace(substr(initialstage3date_date,1,10),'-','') AS initialstage3date_string
                ,cast(substr(initialstage3date_date,1,10) AS DATE) AS initialstage3date_date
                ,regexp_replace(substr(initialstage4date_date,1,10),'-','') AS initialstage4date_string
                ,cast(substr(initialstage4date_date,1,10) AS DATE) AS initialstage4date_date
                ,regexp_replace(substr(initialstage5date_date,1,10),'-','') AS initialstage5date_string
                ,cast(substr(initialstage5date_date,1,10) AS DATE) AS initialstage5date_date
                ,regexp_replace(substr(initialstage6date_date,1,10),'-','') AS initialstage6date_string
                ,cast(substr(initialstage6date_date,1,10) AS DATE) AS initialstage6date_date
                ,regexp_replace(substr(initialstage7date_date,1,10),'-','') AS initialstage7date_string
                ,cast(substr(initialstage7date_date,1,10) AS DATE) AS initialstage7date_date
                ,CAST(localtimestamp  as varchar) AS executed_on
FROM
(SELECT opportunityid
        ,max(closedate) AS closedate_date
        ,min(CASE WHEN stagename = '01 - Pre Call Plan' THEN createddate END) AS initialstage1date_date
        ,min(CASE WHEN stagename = '02 -Prospect' THEN createddate END) AS initialstage2date_date
        ,min(CASE WHEN stagename = '03 - Opportunity Qualification' THEN createddate END) AS initialstage3date_date
        ,min(CASE WHEN stagename = '04 - Circle of Influence' THEN createddate END) AS initialstage4date_date
        ,min(CASE WHEN stagename = '05 - Solution Definition' THEN createddate END) AS initialstage5date_date
        ,min(CASE WHEN stagename = '06 - Customer Commit' THEN createddate END) AS initialstage6date_date
        ,min(CASE WHEN stagename = '07 - Execute to Close' THEN createddate END) AS initialstage7date_date
 FROM b2b.uda_replicn_sf_corp_uda_vw_opportunityhistory
 GROUP BY opportunityid
)
