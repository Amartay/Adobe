
/*
    Author: Stephen Wills
    Last Updated by: James Cooke
    Last Updated: 04/04/2023
    Wiki Link: https://wiki.corp.adobe.com/display/CCM/Sales+Pipeline+L2+-+Segmentation
    Last Update Description: Updated conditions in PSS 2023 - filtered to only DIGITAL MEDIA via the core table in the reporting stage
    Depdencies: This script needs to run AFTER pipeline Core.
                             
*/

----------------------------------------------------
-- 1. Set up - fetch values we will use multiple times 
----------------------------------------------------

DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_assignment_variables;
CREATE TABLE b2b_tmp.b2b_tmp_assignment_variables (key varchar, value varchar);

INSERT INTO b2b_tmp.b2b_tmp_assignment_variables(key,value)
SELECT  'Opp - Max as of Date',
        max(as_of_date) 
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity
UNION ALL
SELECT 'Acc - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_account
UNION ALL
SELECT  'User - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_user 
UNION ALL
SELECT  'Sales Team Assignment - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment 
UNION ALL
SELECT  'Line Item - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
UNION ALL 
SELECT 'Product - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_product2;


-- create tables we query multiple times in one place; 

-- Sales Team User Names
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_sales_team_usernames;
CREATE TABLE b2b_tmp.b2b_tmp_sales_team_usernames (opportunity varchar,FullName1 varchar) ;

INSERT INTO b2b_tmp.b2b_tmp_sales_team_usernames (opportunity,FullName1) 
SELECT DISTINCT opportunity, lower(FullName1) as FullName1
FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment prodSalesAss
INNER JOIN b2b.uda_replicn_sf_corp_uda_vw_user user 
    ON user.UserID = prodSalesAss.SalesTeamMember
WHERE user.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='User - Max as of Date')
AND prodSalesAss.as_of_date = ( SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Sales Team Assignment - Max as of Date');

-- Created By Usernames
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_created_by_usernames;
CREATE TABLE b2b_tmp.b2b_tmp_created_by_usernames (opportunity varchar,FullName1 varchar) ;

INSERT INTO b2b_tmp.b2b_tmp_created_by_usernames (opportunity,FullName1) 
SELECT DISTINCT opp.fulloptyid, lower(FullName1) as FullName1
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN (    SELECT userid, FullName1 
                FROM b2b.uda_replicn_sf_corp_uda_vw_user
                WHERE as_of_date = (    SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='User - Max as of Date')
            ) createdBy 
ON createdBy.UserID = opp.createdbyid
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE) ;


-------------------------------------------------------------------
-- 2. Team Identification - Build a list of opporunity / team values
--------------------------------------------------------------------

-- Create a table that will hold our mappings
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_assignment_team_mapping;
CREATE TABLE b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id varchar, team varchar, date_period varchar);

--------------------------
-- AMER GBD FLAG
--------------------------

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT  full_opp_id,
        'AMER GBD',
        'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN    (SELECT full_opp_id, ARRAY_JOIN(array_distinct(ARRAY_AGG(team)),' | ') AS gbd_team
                FROM b2b.manual_file_amer_gbd
                GROUP BY full_opp_id) gbd
ON gbd.full_opp_id = opp.fulloptyid
WHERE gbd.gbd_team IS NOT NULL
AND opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE) ;

--------------------------
-- AMER MM FLAG
--------------------------

-- 2023;
/*
 sub id contained in gtm.agodah_mmcoverage
 country is US or CA
 opportunity reason is null or not in a specific list of reasons
*/

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT opp.fulloptyid,
       'AMER MM',
       '2023'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN  (
            SELECT DISTINCT id, 
                    standardizedsubid 
            FROM b2b.uda_replicn_sf_corp_uda_vw_account 
            WHERE as_of_date = (SELECT value
                                 FROM b2b_tmp.b2b_tmp_assignment_variables
                                 WHERE key='Acc - Max as of Date')
            AND upper(country) IN ('US','CA')
        ) acc
ON acc.id = opp.AccountID
INNER JOIN  (    
            SELECT DISTINCT sub_id as mm_coverage_subid
            FROM gtm.agodah_mmcoverage 
            WHERE parent_id <> 'Parent ID'
                AND sub_id IS NOT NULL
        )  mmCov
ON  acc.standardizedsubid = mmCov.mm_coverage_subid 
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE) 
AND (opp.reason IS NULL OR upper(opp.reason) NOT IN ('COMBINED WITH OTHER OPP','DEAL REG DUPLICATE',
                                                     'DIRECT SALES DUPLICATE','DUPLICATE','DUPLICATE OPPORTUNITY'))

UNION ALL 

-- 2022;
SELECT opp.fulloptyid,
       'AMER MM',
       '2022'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN ( SELECT DISTINCT prntid AS parent_id 
             FROM gtm.agodah_mmcoverage_2022
             WHERE prntid <> 'Parent ID'
             AND prntid IS NOT NULL ) mmCovArchive
ON opp.standardizedparentid = mmCovArchive.parent_id 
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE) ;

--------------------------
-- AMER EDU FLAG
--------------------------

/*
Filters Applied; 
        1. business_close_date >= '2021-12-04' AND
        2. ReportableASV_GrowthFX_Neutral > 0  AND
        3. OutlookProductGroup <> 'PPBU' AND
        4. majorolpg2 = 'DIGITAL MEDIA' AND
        5. region is like '%AMERICAS DME ENT EDU%','%C&B AMERICAS EDU%','%C&B EDU AMERICAS%' AND
        6. Account country is in ('US','CA') AND 
        7. Record Owner Full name <> 'SG SF' 
*/
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT opp_bcd.fulloptyid,
        'AMER EDU',
        'ALL'
FROM (
        SELECT  fulloptyid,
                AccountID,
                RecordOwner,
                CASE WHEN stage LIKE '%Booked%' 
                        AND closuredate IS NOT NULL 
                THEN try_cast(split_part(closuredate, ' ', 1) AS DATE)
                ELSE closedate 
                END AS business_close_date
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
        AND opp.CloseDate IS NOT NULL
        AND opp.CloseDate >= cast('2021-01-01' AS DATE) 
) opp_bcd
INNER JOIN ( 
                SELECT DISTINCT  OpportunityID,
                                 ProductID,
                                 OutlookProductGroup,
                                 coalesce(round(cast(ReportableASV_GrowthFX_Neutral as double), 0),0) AS ReportableASV_GrowthFX_Neutral
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                WHERE as_of_date = ( SELECT value
                                     FROM b2b_tmp.b2b_tmp_assignment_variables
                                     WHERE key='Line Item - Max as of Date')

) lineItems
ON lineItems.OpportunityID = opp_bcd.FullOptyId
INNER JOIN (    SELECT  ProductID,
                        majorolpg2
                FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                WHERE as_of_date = (SELECT value
                                     FROM b2b_tmp.b2b_tmp_assignment_variables
                                     WHERE key='Product - Max as of Date')
) prod
ON lineItems.ProductID = prod.ProductID
INNER JOIN (             
                SELECT DISTINCT opportunity 
                        FROM ( 
                        SELECT          opportunity,
                                        subregion
                        FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment
                        WHERE ( upper(subregion) LIKE '%AMERICAS DME ENT EDU%' 
                                OR upper(subregion) LIKE '%C&B AMERICAS EDU%'
                                OR upper(subregion) LIKE '%C&B EDU AMERICAS%'
                        )
                        AND as_of_date = ( SELECT value
                                          FROM b2b_tmp.b2b_tmp_assignment_variables
                                          WHERE key='Sales Team Assignment - Max as of Date')
                        )
) sales_team_ass
ON sales_team_ass.opportunity = opp_bcd.FullOptyId
INNER JOIN (    SELECT DISTINCT id
                FROM b2b.uda_replicn_sf_corp_uda_vw_account 
                WHERE country in ('US','CA')
                AND as_of_date IN (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Acc - Max as of Date')
) acc
ON acc.Id = opp_bcd.AccountID
INNER JOIN  (                 
                SELECT UserID
                FROM b2b.uda_replicn_sf_corp_uda_vw_user
                WHERE FullName1 <> 'SG SF' 
                AND as_of_date = (SELECT value
                                 FROM b2b_tmp.b2b_tmp_assignment_variables
                                 WHERE key='User - Max as of Date')
) user
ON user.UserId = opp_bcd.RecordOwner
WHERE opp_bcd.business_close_date >= cast('2021-12-04' AS DATE) 
        AND lineItems.OutlookProductGroup <> 'PPBU'
        AND lineItems.ReportableASV_GrowthFX_Neutral > 0 
        AND prod.majorolpg2 = 'DIGITAL MEDIA' ;



--------------------------
-- LATAM Enterprise
--------------------------
/*
Filters Applied; 
        1. Opportunity's product to sales team assignment sub territory contains LATAM AND
        2. Opportunity's product to sales team assignment's adobe role type is one of the following: ACCOUNT MANAGER,PRODUCT SPECIALIST AND
        3. Opportunity's product to sales team assignment's major revenue type is SUBSCRIPTION
*/

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT prodSalesAss.opportunity,
                'LATAM ENTERPRISE',
                'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment prodSalesAss
INNER JOIN b2b.uda_replicn_sf_corp_uda_vw_user user 
    ON user.UserID = prodSalesAss.SalesTeamMember
WHERE user.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='User - Max as of Date')
AND prodSalesAss.as_of_date = ( SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Sales Team Assignment - Max as of Date') 
AND upper(prodSalesAss.subterritory) LIKE '%LATAM%'
AND upper(user.adoberoletype) IN ('ACCOUNT MANAGER','PRODUCT SPECIALIST') 
AND upper(prodSalesAss.majorrevenuetype)='SUBSCRIPTION';


--------------------------------------------
-- EMEA CNX (Previously known as PHONES)
--------------------------------------------

/*
Filters Applied; 
        1. opportunity geo = EMEA  AND
        2. record owner alias like con[0-9].* 
*/
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT opp.fulloptyid,
       'EMEA CNX',
       'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN ( 
        SELECT UserID, alias
        FROM b2b.uda_replicn_sf_corp_uda_vw_user
        WHERE regexp_like(alias , '^con[0-9]')
        AND as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='User - Max as of Date')
) user 
ON user.UserId = opp.RecordOwner
WHERE opp.Geo = 'EMEA'
AND opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE) ;


--------------------------
-- EMEA PSS FLAG
--------------------------
 
-- 2022 Q3

/*
Filters Applied; 
        1. opportunity geo = EMEA  AND
        2. opportunity close date <= '2022-09-02' AND 
        3. opportunity record type <> 'SMB Opportunity' or is null 
        4. You meet at least one of the following sets of conditions;

                Group A 
                ----------
                - your sales team user is in a specific list AND 
                   PipelineAcceptedRejectedBy is not in a specific list of users 
        OR      
        
                Group B
                ----------
                - your sales team user is in a different specific list AND 
                   PipelineAcceptedRejectedBy is not in a different specific list of users AND
                   your product group IN (STOCK, CCE STOCK) AND 
                   your opportunity Name isnt like '%overage% or %payg%' AND 
                   your opportunity industry <> 'Education - Higher Ed'
        OR
                
                Group C
                ----------
                  your opportunity name is like '%3D%' or '%SUBSTANCE%' AND
                   your opportunity is accepted into the sales pipeline AND 
                   one of the following conditions is true;
                        1. the created by user is from a specific list
                        2. the salesteam user is in a specific list
                        3  the accepted rejected user is in a specific list

        AND you meet one of the following 2 sets of conditions;
                Group D
                --------
                - Deal Regisration = Y AND
                  your pipeline was accepted / rejected by specific set of users
                  Accepted into pipeline = Accepted
        OR 
                
                Deal Regisration = N
             
*/

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT in_scope_opportunities.fulloptyid,
                in_scope_opportunities.team,
                in_scope_opportunities.date_period
FROM 
(
        SELECT opp.fulloptyid,
        'EMEA PSS' AS team,
        '2022 Q3' AS date_period
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        WHERE opp.Geo = 'EMEA'
        AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
        AND opp.CloseDate IS NOT NULL
        AND opp.CloseDate >= cast('2022-06-04' AS DATE) 
        AND opp.CloseDate <= cast('2022-09-02' AS DATE)
        AND (opp.OpportunityRecordType <> 'SMB Opportunity' OR opp.OpportunityRecordType IS NULL)
) in_scope_opportunities
INNER JOIN   ( 
        
SELECT DISTINCT FullOptyId 
FROM (
                -- Group A 
                SELECT  'A' AS condition_group, 
                        opp.FullOptyId
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN  b2b_tmp.b2b_tmp_sales_team_usernames salesTeam
                ON opp.FullOptyId = salesTeam.opportunity
                INNER JOIN (
                        SELECT lower(user_name) AS user_name
                        FROM b2b.b2b_pipeline_assignment_user_list
                        WHERE condition_alias = 'A'
                        AND user_role = 'Sales Team'
                ) filterA1 ON lower(salesTeam.FullName1) = filterA1.user_name
                WHERE lower(opp.PipelineAcceptedRejectedBy) NOT IN (   SELECT lower(user_name)
                                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                                WHERE condition_alias = 'A'
                                                                AND user_role = 'Pipeline Accepted / Rejected by' )
                AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')

                UNION ALL

                -- Group B
                SELECT  'B' AS condition_group, 
                        opp.FullOptyId
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN  b2b_tmp.b2b_tmp_sales_team_usernames salesTeam
                ON opp.FullOptyId = salesTeam.opportunity
                INNER JOIN (
                        SELECT lower(user_name) AS user_name
                        FROM b2b.b2b_pipeline_assignment_user_list
                        WHERE condition_alias = 'B'
                        AND user_role = 'Sales Team'
                ) filterB ON lower(salesTeam.FullName1) = filterB.user_name
                INNER JOIN (SELECT DISTINCT OpportunityID
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                        WHERE OutlookProductGroup in ('CCE STOCK', 'STOCK')
                        AND as_of_date = (SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Line Item - Max as of Date')
                ) li ON li.OpportunityID = opp.FullOptyId
                WHERE lower(opp.PipelineAcceptedRejectedBy) NOT IN (    SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias = 'B'
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
                AND (lower(opp.Name) not like '%overage%' or lower(opp.Name) not like '%payg%') 
                AND opp.Industry <> 'Education - Higher Ed'
                AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
                UNION ALL 

                -- Group C 
                SELECT  'C',
                        opp.FullOptyId
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                LEFT JOIN ( SELECT opportunity, 
                                FullName1
                        FROM b2b_tmp.b2b_tmp_created_by_usernames  
                        WHERE lower(FullName1) IN (SELECT lower(user_name)
                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                        WHERE condition_alias='C' 
                                                        AND user_role = 'Created by'
                                                )
                ) createdBy 
                ON opp.FullOptyId = createdBy.opportunity
                LEFT JOIN (SELECT opportunity, 
                                FullName1
                        FROM b2b_tmp.b2b_tmp_sales_team_usernames  
                        WHERE lower(FullName1) IN (SELECT lower(user_name)
                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                WHERE condition_alias='C' 
                                                AND user_role = 'Sales Team')
                ) salesTeam
                ON opp.FullOptyId = salesTeam.opportunity
                WHERE (upper(opp.Name) like '%3D%' or upper(opp.Name) like '%SUBSTANCE%') 
                AND opp.AcceptintoSalesPipeline = 'Accepted'
                AND (       createdBy.opportunity IS NOT NULL 
                        OR  salesTeam.opportunity IS NOT NULL  
                        OR  lower(opp.PipelineAcceptedRejectedBy) IN (  SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias='C' 
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
                )

        ) abc_records
) ABC_Opps
ON ABC_Opps.FullOptyId=in_scope_opportunities.fulloptyid
INNER JOIN  ( 
                SELECT  'D' as condition_group,
                        opp.FullOptyId 
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                WHERE opp.DealRegistration='N'
                UNION  
                SELECT  'D' as condition_group,
                        opp.FullOptyId 
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                WHERE opp.DealRegistration='Y'
                AND lower(opp.PipelineAcceptedRejectedBy) IN (  SELECT lower(user_name)
                                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                                WHERE condition_alias='D' 
                                                                AND user_role = 'Pipeline Accepted / Rejected by' )
                AND opp.AcceptintoSalesPipeline = ' Accepted' 
) condition_D
ON condition_D.FullOptyId = in_scope_opportunities.FullOptyId;

-- PSS_2022_Q4 

/*
Filters Applied; 
        1. opportunity geo = EMEA  AND
        2. opportunity close date <= '2022-12-02 AND 
        3. DmeAccountGroup is NULL or <> 'Enterprise' AND
        4. Pipeline accepted rejected in a specific list of users (group E) AND
        5. OutlookProductGroup in ('SUBSTANCE', 'DCE', 'DCE TRANSACTION', 'ACROBAT', 'SIGN', 'CCE STOCK', 'STOCK', 'CREATIVE')	AND
        6. opp01.OpportunityRecordType <> 'SMB Opportunity' AND
        7. AND You meet one of the following 2 conditions; 
                
                --- Group F
                OutlookProductGroup in ('CCE STOCK', 'STOCK') AND
                opportunity name not like '%overage%' or '%payg%'
                OR
                OutlookProductGroup not in ('CCE STOCK', 'STOCK') 

        9. AND you need to meet one of the following 2 conditions;
                
                -- GROUP G
                PipelineAcceptedRejectedBy in a specific list of users (G1) AND
                ProductName like '%3D%' or  like '%SUBSTANCE%'
                OR
                PipelineAcceptedRejectedBy not in a specific list of users (G2)
        
        10. AND you need to meet one of the following 2 conditions;

                -- Group H
                OutlookProductGroup like '%CREATIVE% AND 
                ProductName like '%3D%' or ProductName like '%SUBSTANCE%'
                OR
                OutlookProductGroup not like '%CREATIVE% 
*/

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT in_scope_opportunities.fulloptyid,
                in_scope_opportunities.team,
                in_scope_opportunities.date_period
FROM 
(
        SELECT opp.fulloptyid,
        'EMEA PSS' AS team,
        '2022 Q4' AS date_period
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        INNER JOIN (    SELECT DISTINCT dmeaccountgroup,id
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                        AND (dmeaccountgroup IS NULL OR dmeaccountgroup <> 'Enterprise') 
                ) acc
        ON opp.AccountID = acc.Id 
        INNER JOIN (    SELECT DISTINCT OpportunityID,
                                        OutlookProductGroup
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Line Item - Max as of Date')
                        AND OutlookProductGroup IN ('SUBSTANCE', 'DCE', 'DCE TRANSACTION', 'ACROBAT', 'SIGN', 'CCE STOCK', 'STOCK', 'CREATIVE')	
                )prod
        ON prod.OpportunityID = opp.fulloptyid
        WHERE opp.Geo = 'EMEA'
        AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
        AND opp.CloseDate IS NOT NULL
        AND opp.CloseDate >= cast('2022-09-03' AS DATE) 
        AND opp.CloseDate <= cast('2022-12-02' AS DATE)
        AND (opp.OpportunityRecordType <> 'SMB Opportunity' OR opp.OpportunityRecordType IS NULL)
        AND (lower(opp.PipelineAcceptedRejectedBy) IN ( SELECT lower(user_name)
                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                WHERE condition_alias='E' 
                                                AND user_role = 'Pipeline Accepted / Rejected by' )
                                                OR lower(opp.PipelineAcceptedRejectedBy) LIKE 'dorota g__wka')
) in_scope_opportunities
INNER JOIN (    -- group F
                SELECT DISTINCT fulloptyid
                FROM (
                        SELECT opp.fulloptyid
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                        INNER JOIN (SELECT DISTINCT OpportunityID,
                                                OutlookProductGroup
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                        WHERE as_of_date = (    SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Line Item - Max as of Date') 
                                        AND OutlookProductGroup IN ('CCE STOCK', 'STOCK')
                                ) prod ON opp.fulloptyid=prod.OpportunityID
                        WHERE (lower(opp.Name) NOT LIKE '%overage%' or lower(opp.Name) NOT LIKE '%payg%') 
                        AND opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                        UNION ALL

                        SELECT opp.fulloptyid
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                        INNER JOIN (SELECT DISTINCT OpportunityID,
                                                OutlookProductGroup
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                        WHERE as_of_date = (    SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Line Item - Max as of Date') 
                                        AND OutlookProductGroup NOT IN ('CCE STOCK', 'STOCK')
                                ) prod
                        ON prod.OpportunityID = opp.fulloptyid
                        WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                ) GroupFAll
) GroupF
ON GroupF.fulloptyid=in_scope_opportunities.fulloptyid
INNER JOIN (
        -- group G
        SELECT DISTINCT fulloptyid
        FROM (
                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (    SELECT DISTINCT OpportunityID
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                                INNER JOIN ( SELECT ProductName, 
                                                ProductID
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                        WHERE as_of_date = (   SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Product - Max as of Date')
                                        AND  (upper(ProductName) LIKE '%3D%' OR upper(ProductName) LIKE '%SUBSTANCE%') 
                                        ) prod
                                ON li.ProductID = prod.ProductID 
                                WHERE li.as_of_date = ( SELECT value    
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date')
                        ) oppProd
                        ON oppProd.OpportunityID=opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                AND lower(opp.PipelineAcceptedRejectedBy) IN (
                                                        SELECT lower(user_name)
                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                        WHERE condition_alias='G1' 
                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
                UNION ALL

                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                AND lower(opp.PipelineAcceptedRejectedBy) NOT IN (     SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias='G2' 
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )

        ) GroupGAll

) GroupG
ON GroupG.fulloptyid=in_scope_opportunities.fulloptyid
INNER JOIN (
        -- group H
        SELECT DISTINCT fulloptyid
        FROM (  
                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (    SELECT DISTINCT OpportunityID
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                                INNER JOIN ( SELECT     ProductName, 
                                                        ProductID
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                        WHERE as_of_date = (   SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Product - Max as of Date')
                                        AND  (upper(ProductName) LIKE '%3D%' OR upper(ProductName) LIKE '%SUBSTANCE%') 
                                        ) prod
                                ON li.ProductID = prod.ProductID 
                                WHERE li.as_of_date = ( SELECT value    
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date')
                                AND li.OutlookProductGroup LIKE '%CREATIVE%'
                                AND (upper(prod.ProductName) LIKE '%3D%' OR upper(prod.ProductName) LIKE '%SUBSTANCE%') 
                ) oppProd
                ON oppProd.OpportunityID = opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                UNION ALL 

                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (SELECT DISTINCT OpportunityID,
                                        OutlookProductGroup
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                WHERE as_of_date = (    SELECT value
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date') 
                                AND OutlookProductGroup NOT LIKE '%CREATIVE%'
                ) prod
                ON prod.OpportunityID = opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
        ) GroupHAll

) GroupH
ON GroupH.fulloptyid=in_scope_opportunities.fulloptyid;

-- PSS_2023


/*
Filters Applied; 
        1. opportunity geo = EMEA  AND
        2. close date > 2022-12-03 AND
        3. DMeAccountGroup is null or <> 'Enterprise AND
        4. pipeline accepted by in a specific list of users (group H) AND
        5. OutlookProductGroup in ('SUBSTANCE', 'DCE', 'DCE TRANSACTION', 'ACROBAT', 'SIGN', 'CCE STOCK', 'STOCK', 'CREATIVE')	AND
        6. OpportunityRecordType <> 'SMB Opportunity' AND
        7. Account csam in a specific list of users (Group I) AND
        8. Accepted Into Sales Pipeline <> 'rejected' AND 
        9. AND You meet one of the following 2 conditions; 
                
                --- Group J
                OutlookProductGroup in ('CCE STOCK', 'STOCK') AND
                opportunity name not like '%overage%' or '%payg%'
                OR
                OutlookProductGroup not in ('CCE STOCK', 'STOCK') 
        
        10. AND you need to meet one of the following 2 conditions;
                
                -- GROUP K
                PipelineAcceptedRejectedBy in a specific list of users (K1) AND
                ProductName like '%3D%' or  like '%SUBSTANCE%'
                OR
                PipelineAcceptedRejectedBy not in a specific list of users (K2)

        11. AND you need to meet one of the following 2 conditions;

                -- Group L
                OutlookProductGroup like '%CREATIVE% AND 
                ProductName like '%3D%' or ProductName like '%SUBSTANCE%'
                OR
                OutlookProductGroup not like '%CREATIVE% 
*/

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT in_scope_opportunities.fulloptyid,
                in_scope_opportunities.team,
                in_scope_opportunities.date_period
FROM 
(
        SELECT opp.fulloptyid,
        'EMEA PSS' AS team,
        '2023' AS date_period
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        INNER JOIN (    SELECT DISTINCT dmeaccountgroup,
                                        id,
                                        coalesce(csam,'Unknown') as csam
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                        AND (dmeaccountgroup IS NULL OR dmeaccountgroup <> 'Enterprise') 
                ) acc
        ON opp.AccountID = acc.Id 
        INNER JOIN (    SELECT DISTINCT OpportunityID,
                                        OutlookProductGroup
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Line Item - Max as of Date')
                        AND OutlookProductGroup IN ('SUBSTANCE', 'DCE', 'DCE TRANSACTION', 'ACROBAT', 'SIGN', 'CCE STOCK', 'STOCK', 'CREATIVE')	
                )prod
        ON prod.OpportunityID = opp.fulloptyid
        LEFT JOIN  ( SELECT DISTINCT    userid, 
                                         lower(FullName1) AS FullName1 
                      FROM b2b.uda_replicn_sf_corp_uda_vw_user
                      WHERE as_of_date = (      SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='User - Max as of Date')
        ) csam 
        ON csam.UserID = acc.csam 
        WHERE opp.Geo = 'EMEA'
        AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
        AND opp.CloseDate > cast('2022-12-03' AS DATE) 
        AND (opp.OpportunityRecordType <> 'SMB Opportunity' OR opp.OpportunityRecordType IS NULL)
        AND (lower(opp.PipelineAcceptedRejectedBy) IN ( SELECT lower(user_name)
                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                        WHERE condition_alias='H' 
                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
                                                        OR lower(opp.PipelineAcceptedRejectedBy) LIKE 'dorota g__wka')
        AND (csam.FullName1 LIKE 'dorota g__wka'
                OR (
                        trim(csam.FullName1)=''
                        OR csam.FullName1 IS NULL )
                        OR csam.FullName1 IN (SELECT  lower(user_name) 
                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                WHERE condition_alias='I' 
                                                AND user_role = 'Csam' )
        AND upper(opp.acceptintosalespipeline) <> 'REJECTED'
        )
) in_scope_opportunities
INNER JOIN (    -- group J
                SELECT DISTINCT fulloptyid
                FROM (
                        SELECT opp.fulloptyid
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                        INNER JOIN (SELECT DISTINCT OpportunityID,
                                                OutlookProductGroup
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                        WHERE as_of_date = (    SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Line Item - Max as of Date') 
                                        AND OutlookProductGroup IN ('CCE STOCK', 'STOCK')
                                ) prod ON opp.fulloptyid=prod.OpportunityID
                        WHERE (lower(opp.Name) NOT LIKE '%overage%' or lower(opp.Name) NOT LIKE '%payg%') 
                        AND opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                        UNION ALL

                        SELECT opp.fulloptyid
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                        INNER JOIN (SELECT DISTINCT OpportunityID,
                                                OutlookProductGroup
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                        WHERE as_of_date = (    SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Line Item - Max as of Date') 
                                        AND OutlookProductGroup NOT IN ('CCE STOCK', 'STOCK')
                                ) prod
                        ON prod.OpportunityID = opp.fulloptyid
                        WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                ) GroupJAll
) GroupJ
ON GroupJ.fulloptyid=in_scope_opportunities.fulloptyid
INNER JOIN (
        -- group K
        SELECT DISTINCT fulloptyid
        FROM (
                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (    SELECT DISTINCT OpportunityID
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                                INNER JOIN ( SELECT ProductName, 
                                                ProductID
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                        WHERE as_of_date = (   SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Product - Max as of Date')
                                        AND  (upper(ProductName) LIKE '%3D%' OR upper(ProductName) LIKE '%SUBSTANCE%') 
                                        ) prod
                                ON li.ProductID = prod.ProductID 
                                WHERE li.as_of_date = ( SELECT value    
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date')
                        ) oppProd
                        ON oppProd.OpportunityID=opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                AND (lower(opp.PipelineAcceptedRejectedBy) IN (
                                                        SELECT lower(user_name)
                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                        WHERE condition_alias='K1' 
                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
                OR lower(opp.PipelineAcceptedRejectedBy) LIKE 'dorota g__wka')

                UNION ALL

                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                AND lower(opp.PipelineAcceptedRejectedBy) NOT IN (     SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias='K2' 
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )

        ) GroupKAll

) GroupK
ON GroupK.fulloptyid=in_scope_opportunities.fulloptyid
INNER JOIN (
        -- group L
        SELECT DISTINCT fulloptyid
        FROM (  
                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (    SELECT DISTINCT OpportunityID
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                                INNER JOIN ( SELECT     ProductName, 
                                                        ProductID
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                        WHERE as_of_date = (   SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Product - Max as of Date')
                                        AND  (upper(ProductName) LIKE '%3D%' OR upper(ProductName) LIKE '%SUBSTANCE%') 
                                        ) prod
                                ON li.ProductID = prod.ProductID 
                                WHERE li.as_of_date = ( SELECT value    
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date')
                                AND li.OutlookProductGroup LIKE '%CREATIVE%'
                                AND (upper(prod.ProductName) LIKE '%3D%' OR upper(prod.ProductName) LIKE '%SUBSTANCE%') 
                ) oppProd
                ON oppProd.OpportunityID = opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                UNION ALL 

                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (SELECT DISTINCT OpportunityID,
                                        OutlookProductGroup
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                WHERE as_of_date = (    SELECT value
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date') 
                                AND OutlookProductGroup NOT LIKE '%CREATIVE%'
                ) prod
                ON prod.OpportunityID = opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
        ) GroupLAll

) GroupL
ON GroupL.fulloptyid=in_scope_opportunities.fulloptyid;

-- thank god thats over..... 

--------------------------
-- EMEA EDU FLAG
--------------------------

/*
Filters Applied; 
        1. opportunity geo = EMEA
        2. account industry like %education% or industry='non-profit'
        3. line item business unit is digital media
        4. sales team member is in a specfic group (group L)
*/

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
       'EMEA EDU',
       'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN  (
            SELECT DISTINCT     id, 
                                industry 
            FROM b2b.uda_replicn_sf_corp_uda_vw_account 
            WHERE as_of_date = (SELECT value
                                 FROM b2b_tmp.b2b_tmp_assignment_variables
                                 WHERE key='Acc - Max as of Date')
            AND (lower(industry) LIKE '%education%' OR lower(industry)='non-profit')
        ) acc
ON acc.id = opp.AccountID
INNER JOIN ( 
                SELECT DISTINCT  OpportunityID
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                WHERE as_of_date = ( SELECT value
                                     FROM b2b_tmp.b2b_tmp_assignment_variables
                                     WHERE key='Line Item - Max as of Date')
                AND lower(businessunit) = 'digital media'

) lineItems
ON lineItems.OpportunityID = opp.FullOptyId
INNER JOIN  b2b_tmp.b2b_tmp_sales_team_usernames salesTeam
ON opp.FullOptyId = salesTeam.opportunity
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE)
AND opp.Geo='EMEA' 
AND lower(salesTeam.FullName1) IN (SELECT lower(user_name)
                                  FROM b2b.b2b_pipeline_assignment_user_list
                                  WHERE condition_alias='L' 
                                  AND user_role = 'Sales Team' );

--------------------------
--  EMEA RESELLER
-------------------------

/*
Filters Applied; 
        1. opportunity geo = EMEA
        2. dmeaccountgroup in Mid-Market,SMB or NULL
        3. route to market = 'Partners Involved'
        4. olpg2 = 'DIGITAL MEDIA'
*/

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT   resell.fulloptyid,
        'EMEA RESELLER',
        'ALL'
FROM (

        SELECT DISTINCT opp.fulloptyid
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        INNER JOIN ( 
                SELECT           OpportunityID,
                                 ProductID,
                                 OutlookProductGroup,
                                 coalesce(round(cast(ReportableASV_GrowthFX_Neutral as double), 0),0) AS ReportableASV_GrowthFX_Neutral
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                WHERE as_of_date = ( SELECT value
                                     FROM b2b_tmp.b2b_tmp_assignment_variables
                                     WHERE key='Line Item - Max as of Date')

                ) lineItems
        ON lineItems.OpportunityID = opp.FullOptyId
        INNER JOIN (    
                SELECT  ProductID,
                        majorolpg2
                FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                WHERE as_of_date = (SELECT value
                                           FROM b2b_tmp.b2b_tmp_assignment_variables
                                           WHERE key='Product - Max as of Date')
                ) prod
        ON lineItems.ProductID = prod.ProductID
        INNER JOIN (    SELECT Id,
                               dmeaccountgroup
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account 
                        WHERE as_of_date IN (SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                        AND (upper(dmeaccountgroup) IN ('MID-MARKET','SMB') OR dmeaccountgroup IS NULL)
        ) acc
        ON acc.Id = opp.AccountID

        WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
        AND opp.CloseDate IS NOT NULL
        AND opp.CloseDate >= cast('2021-01-01' AS DATE)
        AND upper(opp.geo)='EMEA'
        AND upper(prod.majorolpg2) = 'DIGITAL MEDIA'
        AND upper(opp.routetomarket) = 'PARTNERS INVOLVED'
) resell

--------------------------
--  EMEA GOV ENT SMB FLAG
-------------------------

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
       CASE WHEN (opp.AccountAddressCountry IN ('UK', 'DE', 'FR') 
            AND lower(opp.Industry) LIKE 'government%') THEN 'ENT'
            WHEN lower(opp.Industry) IN ('government - federal', 'government - military')
            THEN 'ENT'

            WHEN lower(opp.Industry) IN ('government - local', 'government - state') 
            THEN 'CSMB'
            WHEN (acc.DMeAccountGroup = 'SMB')
            THEN 'SMB'
            ELSE 'ENT'
        END AS team,
       'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
LEFT JOIN (    SELECT DISTINCT dmeaccountgroup,id
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                ) acc
        ON opp.AccountID = acc.Id 
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE)
AND opp.Geo='EMEA' ;


--------------------------
--  Generate L2 View 
--------------------------

DROP TABLE IF EXISTS b2b.l2_sa_sfdc_pipeline_segmentation;
CREATE TABLE b2b.l2_sa_sfdc_pipeline_segmentation  AS
SELECT DISTINCT core.full_opty_id,
                acc.account_id,
                acc.parent_id,
                acc.subsidiary_id,
                CASE WHEN amerGbd.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS amer_gbd,
                CASE WHEN amerMM22.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS amer_mm_22,
                CASE WHEN amerMM23.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS amer_mm_23,
                CASE WHEN (amerMM22.full_opty_id IS NOT NULL OR amerMM23.full_opty_id IS NOT NULL) THEN 'Y' ELSE '-' END AS amer_mm,
                CASE WHEN amerEdu.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS amer_edu,
                CASE WHEN latamEnt.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS latam_ent,
                CASE WHEN emeaCnx.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS emea_cnx,
                CASE WHEN emeaPss22q3.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS emea_pss_22_q3,
                CASE WHEN emeaPss22q4.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS emea_pss_22_q4,
                CASE WHEN emeaPss23.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS emea_pss_23,
                CASE WHEN (emeaPss22q3.full_opty_id IS NOT NULL OR emeaPss22q4.full_opty_id IS NOT NULL OR emeaPss23.full_opty_id IS NOT NULL) THEN 'Y' ELSE '-' END AS emea_pss,
                CASE WHEN emeaEdu.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS emea_edu,
                CASE WHEN emeaReseller.full_opty_id IS NOT NULL THEN 'Y' ELSE '-' END AS emea_reseller,
                CASE WHEN emeaGovEnt.full_opty_id IS NOT NULL THEN 'ENT' 
                     WHEN emeaGovCsmb.full_opty_id IS NOT NULL THEN 'CSMB'
                     WHEN emeaGovSmb.full_opty_id IS NOT NULL THEN 'SMB'  
                     ELSE '-' 
                END AS emea_gov_ent_smb,
                CAST(localtimestamp  as varchar) AS executed_on
FROM b2b.l2_sa_sfdc_pipeline_core core
INNER JOIN ( SELECT     fulloptyid,
                        accountID
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp 
        ) udaOpp
ON udaOpp.fulloptyid = core.full_opty_id
LEFT JOIN (SELECT        Id AS account_id
                        , standardizedparentid AS parent_id
                        , standardizedsubid AS subsidiary_id
                FROM b2b.uda_replicn_sf_corp_uda_vw_account
                WHERE as_of_date IN ( SELECT max(as_of_date) 
                                FROM b2b.uda_replicn_sf_corp_uda_vw_account)
        ) acc  
ON udaOpp.accountID = acc.account_id
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping amerGbd
ON core.full_opty_id = amerGbd.full_opty_id AND amerGbd.team='AMER GBD' 
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping amerMM23
ON core.full_opty_id = amerMM23.full_opty_id AND amerMM23.team='AMER MM' AND amerMM23.date_period='2023'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping amerMM22
ON core.full_opty_id = amerMM22.full_opty_id AND amerMM22.team='AMER MM' AND amerMM22.date_period='2022'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping amerEdu
ON core.full_opty_id = amerEdu.full_opty_id AND amerEdu.team='AMER EDU'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping latamEnt
ON core.full_opty_id = latamEnt.full_opty_id AND latamEnt.team='LATAM ENTERPRISE'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaCnx
ON core.full_opty_id = emeaCnx.full_opty_id AND emeaCnx.team='EMEA CNX'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaPss22q3
ON core.full_opty_id = emeaPss22q3.full_opty_id AND emeaPss22q3.team='EMEA PSS' AND emeaPss22q3.date_period='2022 Q3'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaPss22q4
ON core.full_opty_id = emeaPss22q4.full_opty_id AND emeaPss22q4.team='EMEA PSS' AND emeaPss22q4.date_period='2022 Q4'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaPss23
ON core.full_opty_id = emeaPss23.full_opty_id AND emeaPss23.team='EMEA PSS' AND emeaPss23.date_period='2023'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaEdu
ON core.full_opty_id = emeaEdu.full_opty_id AND emeaEdu.team='EMEA EDU'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaReseller
ON core.full_opty_id = emeaEdu.full_opty_id AND emeaEdu.team='EMEA RESELLER'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaGovEnt
ON core.full_opty_id = emeaGovEnt.full_opty_id AND emeaGovEnt.team='ENT'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaGovSmb
ON core.full_opty_id = emeaGovSmb.full_opty_id AND emeaGovSmb.team='SMB'
LEFT JOIN b2b_tmp.b2b_tmp_assignment_team_mapping emeaGovCsmb
ON core.full_opty_id = emeaGovCsmb.full_opty_id AND emeaGovCsmb.team='CSMB';

--------------------------
--  Clean up TMP objects
--------------------------

DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_assignment_variables;
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_sales_team_usernames;
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_created_by_usernames;
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_assignment_team_mapping;
