/*
    Author: James Cooke
    Last Updated by: James Cooke
    Last Updated:05/04/2023
    Documentation Link: TODO
    Last Update Description: Creates the pipeline opportunity booking details table showing a detailed breakdown of salesforce "predictions" vs actual bookings.
    This report shows the volume / forecasted revenues from salesforce for each product in an opportunity as well as the actual values from pivot4all

    the record type column represents Forecasted / Unforecasted sales where a forecasted sale is where a booking was made on exactly the same product code
    as stated in salesforce where an unforecasted sale is a sale in an opportunities order where no prediction was made in salesforce. 
    
    There are a number of reasons why we cannot associate a booking to a salesforce opportunity. These are as follows;

    1 - Invalid Order Number in Salesforce
    2 - No Order found in pivot4all
    3 - No Product Code in Salesforce (any bookings will be unforecasted sales)
    4 - Salesforce Product Codes doesnt Exist in SAP (any bookings will be unforecasted sales)

    A filter is put on this code you have to be in a closed - booked state (otherwise you wont have any bookings)

    Note - there are a small number of stages called Closed-Booked (no space) - due to this i uppercase and remove whitespace when looking for the closed book state

    DEPENDENCY
    This code can only be run once B2B.L2_SA_SFDC_Pipeline_Core has completed 
*/

------------------------------------------------------------------
-- Step 1 - Standardize / Clean up Order numbers
------------------------------------------------------------------

/*
 Order numbers allow us to connect from salesforce to pivot4all (actual bookings), however this is a free text fields
 in salesforce and there is no standard approach uses to separate multiple orders on an opportunity. In general I can see they
 are delimited with a variety of delimiters e.g. 1234 4324532 3423432 or 1234|4324532|3423432. This is where I parse the free
 text field and create an opportunity to order lookup with one row per parsed order.
*/

DROP TABLE IF EXISTS  b2b_tmp.b2b_pipeline_opportunity_order_lookup;
CREATE TABLE b2b_tmp.b2b_pipeline_opportunity_order_lookup (full_opty_id varchar(50),
                                                            sales_order_number_original varchar(2000),
                                                            sales_order_number_cleaned varchar(200)
                                                            ); 

INSERT INTO  b2b_tmp.b2b_pipeline_opportunity_order_lookup (full_opty_id,sales_order_number_original,sales_order_number_cleaned)
SELECT DISTINCT expanded.full_opty_id,
                core.sales_order_number as sales_order_number_original,
                expanded.order_id as sales_order_number_cleaned
FROM( ( 
    SELECT DISTINCT full_opty_id,  
                    split(
                    regexp_replace(
                            regexp_replace(
                                trim(regexp_replace(CASE WHEN substring(sales_order_number,-1) IN ('|',',','+','#',';',':','-','\','/','.')
                                                         THEN substring(sales_order_number,1,(length(sales_order_number)-1))
                                                         ELSE sales_order_number END,
                                '[^0-9\|\\\/;\.#,+\- ]','')),
                                '[\|\\\/;\.#,+\- ]',','),
                                '[,]{2,}',','),
                        ',') as orders                         
        FROM b2b.l2_sa_sfdc_pipeline_core
        WHERE  upper(replace(current_stage,' ','')) = 'CLOSED-BOOKED'
    ) 
    CROSS JOIN UNNEST(orders) AS t(order_id)
) expanded
INNER JOIN (
            SELECT DISTINCT full_opty_id,sales_order_number
            FROM b2b.l2_sa_sfdc_pipeline_core
            ) core
ON core.full_opty_id = expanded.full_opty_id;


------------------------------------------------------------------
-- Step 2 - Produce Details Report
------------------------------------------------------------------


DROP TABLE IF EXISTS  b2b.l2_sa_sfdc_opportunity_booking_details;

CREATE TABLE  b2b.l2_sa_sfdc_opportunity_booking_details AS
-- Forecasted purchases - salesforce record joins on product code and order number
SELECT DISTINCT report.opportunity_id,
                report.full_opty_id,
                report.record_type,
                report.deal_reg_id,
                report.geo,
                report.acct_dme_acct_group,
                report.licensing_program,
                report.current_stage,
                report.sales_order_number,
                report.sales_order_number_cleaned,
                report.product_group,
                report.product_code_1,
                report.prod_outlook_prod_group,
                report.business_prod_group,
                report.ori_reportable_new_asv_fx_neutral,
                report.acct_addr_country,
                report.current_close_date,
                -- we want to report these as 0's not nulls (they could join - they dont join therefore 0 were sold)
                CASE WHEN report.status = 'OK' AND report.sap_product_code IS NULL THEN report.product_code_1 ELSE report.sap_product_code END AS sap_product_code,
                CASE WHEN report.status = 'OK' AND report.actual_total_net_new_arr_cfx IS NULL THEN 0 ELSE report.actual_total_net_new_arr_cfx END AS actual_total_net_new_arr_cfx,
                CASE WHEN report.status = 'OK' AND report.actual_total_net_purchases_arr_cfx IS NULL THEN 0 ELSE report.actual_total_net_purchases_arr_cfx END AS actual_total_net_purchases_arr_cfx,
                CASE WHEN report.status = 'OK' AND report.actual_total_net_cancelled_arr_cfx IS NULL THEN 0 ELSE report.actual_total_net_cancelled_arr_cfx END AS actual_total_net_cancelled_arr_cfx,
                CASE WHEN report.status = 'OK' AND report.actual_total_migrated_to_arr_cfx IS NULL THEN 0 ELSE report.actual_total_migrated_to_arr_cfx END AS actual_total_migrated_to_arr_cfx,
                CASE WHEN report.status = 'OK' AND report.actual_total_migrated_from_arr_cfx IS NULL THEN 0 ELSE report.actual_total_migrated_from_arr_cfx END AS actual_total_migrated_from_arr_cfx,
                CASE WHEN report.status = 'OK' AND report.actual_total_gross_new_arr_cfx IS NULL THEN 0 ELSE report.actual_total_gross_new_arr_cfx END AS actual_total_gross_new_arr_cfx,
                --  I added renewals otherwise its possible to report everything joined but have sales of 0 which looks wrong (whereas in reality you have a renewal value)
                CASE WHEN report.status = 'OK' AND report.actual_total_renewal_to_arr_cfx IS NULL THEN 0 ELSE report.actual_total_renewal_to_arr_cfx END AS actual_total_renewal_to_arr_cfx,
                CASE WHEN report.status = 'OK' AND report.actual_total_gross_new_subs IS NULL THEN 0 ELSE report.actual_total_gross_new_subs END AS actual_total_gross_new_subs,
                report.status,
                CAST(localtimestamp  as varchar) AS executed_on
FROM ( 
        SELECT  core.opportunity_id,
                core.full_opty_id,
                'Forecasted Purchases' as record_type,
                core.deal_reg_id,
                core.geo,
                core.acct_dme_acct_group,
                core.licensing_program,
                core.current_stage,
                core.sales_order_number,
                orderLu.sales_order_number_cleaned,
                core.current_close_date,
                CASE WHEN li.product_code_1 IN ('SBTX', 'SBST', 'SRC') THEN 'Substance'	
                     WHEN li.prod_majorolpg1 IN ('ACROBAT','DCE') THEN 'Acrobat DC'
                     WHEN li.prod_majorolpg1 IN ('SIGN','DCE TRANSACTION') THEN 'Adobe Sign'
                     WHEN li.prod_majorolpg1 IN ('CREATIVE') THEN 'Creative - Professio'
                     WHEN li.prod_majorolpg1 IN ('CCE STOCK', 'STOCK') THEN 'Stock Photography'
                    ELSE 'Other'
                END AS product_group,
                li.prod_majorolpg1,
                li.product_code_1,
                li.prod_outlook_prod_group,
                li.business_prod_group,
                li.ori_reportable_new_asv_fx_neutral,
                core.acct_addr_country,
                pivot.sap_product_code,
                pivot.total_net_new_arr_cfx AS actual_total_net_new_arr_cfx,
                pivot.total_net_purchases_arr_cfx AS actual_total_net_purchases_arr_cfx,
                pivot.total_net_cancelled_arr_cfx AS actual_total_net_cancelled_arr_cfx,
                pivot.total_migrated_to_arr_cfx AS actual_total_migrated_to_arr_cfx,
                pivot.total_migrated_from_arr_cfx AS actual_total_migrated_from_arr_cfx,
                pivot.total_gross_new_arr_cfx AS actual_total_gross_new_arr_cfx,
                pivot.total_renewal_to_arr_cfx AS actual_total_renewal_to_arr_cfx,
                pivot.total_gross_new_subs AS actual_total_gross_new_subs,
                -- Join Status - What is the problem / why doesnt the record join
                CASE WHEN length(orderLu.sales_order_number_cleaned) < 5 OR length(orderLu.sales_order_number_cleaned) >10 
                    THEN '1 - Invalid Order Number in Salesforce'
                    WHEN porders.sales_document IS NULL 
                    THEN '2 - No Order found in pivot4all' 
                    WHEN li.product_code_1 IS NULL OR li.product_code_1='NULL' 
                    THEN '3 - No Product Code in Salesforce'
                    WHEN luProd.productname IS NULL
                    THEN '4 - Salesforce Product Codes doesnt Exist in SAP'
                ELSE 'OK' 
                END AS status
        FROM b2b.l2_sa_sfdc_pipeline_core core
        INNER JOIN  b2b.l2_sa_sfdc_pipeline_line_item li 
            ON core.full_opty_id = li.full_opty_id 
        -- get a separate row for each order (multiple orders will by default inherit all products for the opportunity - we cant do anything about that)
        LEFT JOIN b2b_tmp.b2b_pipeline_opportunity_order_lookup orderLu
            ON orderLu.full_opty_id = core.full_opty_id
        -- connect to summarized pivot4all on order and product code
        LEFT JOIN (
                    SELECT  p.sales_document as sales_document,
                            pm.productname as sap_product_code,
                            count(distinct date_date) as distinct_days_events_took_place_on,
                            sum(gross_new_arr_cfx) as total_gross_new_arr_cfx,
                            sum(migrated_from_arr_cfx) as total_migrated_from_arr_cfx,
                            sum(migrated_to_arr_cfx) as total_migrated_to_arr_cfx,
                            sum(net_cancelled_arr_cfx) as total_net_cancelled_arr_cfx,
                            sum(net_purchases_arr_cfx) as total_net_purchases_arr_cfx,
                            sum(net_new_arr_cfx) as total_net_new_arr_cfx,
                            sum(renewal_to_arr_cfx) as total_renewal_to_arr_cfx,
                            sum(gross_new_subs) as total_gross_new_subs
                    FROM ccm_subscrpn.vw_ccm_pivot4_all p
                    INNER JOIN b2b.finsys_dme_b2b_fpa_dbo_productmappings pm
                        ON p.material_number = pm.materialnumber
                    WHERE p.event_source = 'EVENT' 
                    GROUP BY p.sales_document, pm.productname 
            ) pivot
        ON REGEXP_REPLACE(pivot.sales_document, '^0+', '')  = REGEXP_REPLACE(orderLu.sales_order_number_cleaned, '^0+', '')
        AND pivot.sap_product_code = li.product_code_1
        -- establish if the product code from salesforce even exists in SAP
        LEFT JOIN ( 
                    SELECT DISTINCT productname 
                    FROM  b2b.finsys_dme_b2b_fpa_dbo_productmappings
        ) luProd
        ON li.product_code_1 = luProd.productname
        -- establish if the order exists in pivot4all (for status)
        LEFT JOIN ( SELECT DISTINCT sales_document 
                    FROM ccm_subscrpn.vw_ccm_pivot4_all p
                    WHERE p.event_source = 'EVENT' ) porders
        ON REGEXP_REPLACE(porders.sales_document, '^0+', '') = REGEXP_REPLACE(orderLu.sales_order_number_cleaned, '^0+', '')
        WHERE upper(replace(core.current_stage,' ','')) = 'CLOSED-BOOKED'
) report 
  

UNION ALL

-- Unforecasted Purchases (products booked which were not in the salesforce forecast)
SELECT DISTINCT core.opportunity_id,
                core.full_opty_id,
                'Unforecasted Purchases' as record_type,
                core.deal_reg_id,
                core.geo,
                core.acct_dme_acct_group,
                core.licensing_program,
                core.current_stage,
                core.sales_order_number,
                orderLu.sales_order_number_cleaned,
                CASE WHEN nf.sap_product_code IN ('SBTX', 'SBST', 'SRC') THEN 'Substance'	
                     WHEN nf.prod_majorolpg1 IN ('ACROBAT','DCE') THEN 'Acrobat DC'
                     WHEN nf.prod_majorolpg1 IN ('SIGN','DCE TRANSACTION') THEN 'Adobe Sign'
                     WHEN nf.prod_majorolpg1 IN ('CREATIVE') THEN 'Creative - Professio'
                     WHEN nf.prod_majorolpg1 IN ('CCE STOCK', 'STOCK') THEN 'Stock Photography'
                    ELSE 'Other'
                END AS product_group,
                nf.sap_product_code AS product_code_1,
                NULL AS prod_outlook_prod_group,
                NULL AS business_prod_group,
                0 as current_reportable_new_asv_fx_neutral,
                core.acct_addr_country,
                core.current_close_date,
                nf.sap_product_code,
                nf.actual_total_net_new_arr_cfx,
                nf.actual_total_net_purchases_arr_cfx,
                nf.actual_total_net_cancelled_arr_cfx,
                nf.actual_total_migrated_to_arr_cfx,
                nf.actual_total_migrated_from_arr_cfx,
                nf.actual_total_gross_new_arr_cfx,
                nf.actual_total_renewal_to_arr_cfx,
                nf.actual_total_gross_new_subs,
                '5 - in SAP not in Salesforce' as status,
                CAST(localtimestamp  as varchar) AS executed_on
FROM b2b.l2_sa_sfdc_pipeline_core core
LEFT JOIN b2b_tmp.b2b_pipeline_opportunity_order_lookup orderLu
                ON orderLu.full_opty_id = core.full_opty_id
INNER JOIN (
        -- Get order/product combinations  which were not forecast
        SELECT      p.sales_document as sales_document,
                    pm.productname as sap_product_code,
                    pg.prod_majorolpg1 as prod_majorolpg1,
                    count(distinct date_date) as distinct_days_events_took_place_on,
                    sum(net_new_arr_cfx) as actual_total_net_new_arr_cfx,
                    sum(gross_new_arr_cfx) as actual_total_gross_new_arr_cfx,
                    sum(migrated_from_arr_cfx) as actual_total_migrated_from_arr_cfx,
                    sum(migrated_to_arr_cfx) as actual_total_migrated_to_arr_cfx,
                    sum(net_cancelled_arr_cfx) as actual_total_net_cancelled_arr_cfx,
                    sum(net_purchases_arr_cfx) as actual_total_net_purchases_arr_cfx,
                    sum(renewal_to_arr_cfx) as actual_total_renewal_to_arr_cfx,
                    sum(gross_new_subs) as actual_total_gross_new_subs
        FROM ccm_subscrpn.vw_ccm_pivot4_all p
        INNER JOIN b2b.finsys_dme_b2b_fpa_dbo_productmappings pm
            ON p.material_number = pm.materialnumber
        -- obtain a product group for the product code
        LEFT JOIN (SELECT DISTINCT prod_majorolpg1, 
                                   product_code_1
                    FROM  b2b.l2_sa_sfdc_pipeline_line_item )pg
            ON pm.productname = pg.product_code_1
        WHERE p.event_source = 'EVENT' 
        AND concat(p.sales_document,'-',pm.productname) NOT IN (
            -- Get all predicted orders from salesforce
            SELECT DISTINCT concat(orderLu.sales_order_number_cleaned,'-',li.product_code_1) as order_prod_key
            FROM b2b.l2_sa_sfdc_pipeline_core core
            INNER JOIN b2b.l2_sa_sfdc_pipeline_line_item li 
                ON core.full_opty_id = li.full_opty_id
            INNER JOIN b2b_tmp.b2b_pipeline_opportunity_order_lookup orderLu
                ON orderLu.full_opty_id = core.full_opty_id
            WHERE li.product_code_1 IS NOT NULL 
            AND  current_stage = 'Closed - Booked'
        )
        GROUP BY p.sales_document, pm.productname, pg.prod_majorolpg1
) nf
ON nf.sales_document = orderLu.sales_order_number_cleaned
WHERE  upper(replace(core.current_stage,' ','')) = 'CLOSED-BOOKED';

---------------------------------
-- Step 3 - Clean up Tmp Table
---------------------------------

DROP TABLE IF EXISTS  b2b_tmp.b2b_pipeline_opportunity_order_lookup;