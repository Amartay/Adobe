/*
    Author: James Cooke
    Last Updated by: James Cooke
    Last Updated:06/04/2023
    Documentation Link: TODO

    This table is an aggregation of the opportunity_bookings details - it will give you for opportunity product combinations
        - ARR
        - Units Sold
        - Renewals

    DEPENDENCY
    This code can only be run once B2B.L2_SA_SFDC_201_Pipeline_Opportunity_Booking_Details has completed
*/

DROP TABLE IF EXISTS  b2b.l2_sa_sfdc_opportunity_bookings;
CREATE TABLE b2b.l2_sa_sfdc_opportunity_bookings (  full_opty_id varchar(50), 
                                                    product_code varchar(50),
                                                    gross_new_arr double,
                                                    net_purchases_arr double,
                                                    renewal double,
                                                    units double,
                                                    status varchar(200),
                                                    executed_on varchar);

INSERT INTO b2b.l2_sa_sfdc_opportunity_bookings (full_opty_id,product_code,gross_new_arr,net_purchases_arr,renewal,units, status,executed_on)

SELECT  full_opty_id,
        product_code,
        gross_new_arr,
        net_purchases_arr,
        renewal,
        units,
        CASE WHEN gross_new_arr IS NULL THEN 'No join could be made between Salesforce and Pivot4All - Check details table for further information' 
             ELSE 'OK' 
             END AS Status,
        CAST(localtimestamp  as varchar) AS executed_on
FROM (  SELECT  full_opty_id,
                lineitem_productcode1 AS product_code,
                sum(actual_total_gross_new_arr_cfx) AS gross_new_arr,
                sum(actual_total_net_purchases_arr_cfx) AS net_purchases_arr,
                sum(actual_total_renewal_to_arr_cfx) AS renewal,
                sum(actual_total_gross_new_subs) AS units
        FROM b2b.l2_sa_sfdc_opportunity_booking_details
        GROUP BY full_opty_id,lineitem_productcode1);

