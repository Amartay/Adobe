/*
    Author: Stephen Wills
    Last Updated by: James Cooke
    Last Updated: 04/04/2023
    Documentation Link: https://wiki.corp.adobe.com/display/CCM/Sales+Pipeline+L2+-+CORE
    Last Update Description: Updates Requested From Data science to make Opportunity Level, rename and remove a lot of fields
*/

DROP TABLE IF EXISTS b2b.l2_sa_sfdc_pipeline_core;
CREATE TABLE IF NOT EXISTS b2b.l2_sa_sfdc_pipeline_core (
    opportunity_id varchar
    , full_opty_id varchar
    , deal_reg_id varchar
    , deal_reg_flag varchar
    , sales_order_number varchar
    , sales_ops_reconciled varchar 
    , dme_ineligible varchar
    , dme_ineligible_reason varchar
    , vip_ea_clp_agreement_number varchar
    , sfdc_link varchar
    , opportunity_name varchar
    , acct_name varchar
    , acct_addr_country varchar
    , partner_country varchar
    , geo varchar
    , route_to_market varchar
    , licensing_program varchar
    , lm_engagement varchar
    , acct_dme_acct_group varchar
    , opp_prod_interest varchar
    , current_created_date date
    , current_created_qtr varchar
    , current_created_week varchar
    , current_created_week_in_qtr varchar
    , current_created_year_qtr varchar
    , current_close_date date
    , current_close_qtr varchar
    , current_close_week varchar
    , current_close_week_in_qtr varchar
    , current_close_year_qtr varchar
    , current_acceptintosalespipeline varchar
    , current_stage varchar
    , current_adj_commitment varchar
    , current_business_commitment varchar
    , current_closed_date_fx_rate double
    , executed_on varchar
);


INSERT INTO b2b.l2_sa_sfdc_pipeline_core
SELECT 
	  opp01.OpportunityID
	, opp01.FullOptyId
	, opp01.DealRegistrationID  
	, opp01.DealRegistration AS deal_registration_flag
    , coalesce(opp01.AdobeSalesOrderNumber,opp01.ECC_SalesOrderNumber) AS sales_order_number
    , SalesOpsReconciled AS sales_ops_reconciled  
    , DMeIneligible AS dme_ineligible  
    , ineligiblereason AS dme_ineligible_reason  
	, opp01.VIP_EA_CLP_AgreementNumber
    , concat('https://adobe.my.salesforce.com/', opp01.FullOptyId) AS sfdc_link
	, opp01.name AS opportunity_name
	, acc01.AccountName
	, opp01.AccountAddressCountry
	, opp01.PartnerCountry
	, opp01.Geo
	, opp01.RouteToMarket
	, opp01.LicensingProgram
    , opp01.lm_engagement
	, acc01.DMeAccountGroup
	, opp01.ProductInterest AS opportunity_prod_interest
	, opp01.CreatedDate AS current_created_date
	, DatesCreated01.fiscal_qtr_name AS current_created_qtr
	, DatesCreated01.fiscal_wk_in_yr AS current_created_week
	, DatesCreated01.fiscal_wk_in_qtr AS current_created_week_in_qtr
	, DatesCreated01.fiscal_yr_and_qtr_desc AS current_created_year_qtr
	, opp01.CloseDate AS Current_CloseDate
	, DatesClosed01.fiscal_qtr_name AS Current_Close_QTR
	, DatesClosed01.fiscal_wk_in_yr AS Current_Close_Week
	, DatesClosed01.fiscal_wk_in_qtr AS Current_Close_Week_in_QTR
	, DatesClosed01.fiscal_yr_and_qtr_desc AS Current_Close_Year_QTR
	, opp01.AcceptintoSalesPipeline AS current_acceptintosalespipeline
	, trim(opp01.Stage) AS current_stage
	, opp01.AdjustedCommitment AS current_adj_commitment
	, CASE WHEN opp01.Stage IN ('01 - Pre Call Plan', '02 - Prospect') THEN 'Non-Commit'
			WHEN opp01.Stage IN ('03 - Opportunity Qualification', '04 - Circle of Influence') THEN 'Upside'
			WHEN opp01.Stage = '05 - Solution Definition and Validation' THEN 'Strong Upside'
			WHEN opp01.Stage IN ('06 - Customer Commit', '07 - Execute to Close') THEN 'Forecast'
			WHEN opp01.Stage = 'Closed - Booked' THEN 'Won'
			ELSE opp01.AdjustedCommitment
			END AS business_commitment
    , round(cast(opp01.ClosedDateFX_Rate AS double), 2) AS ClosedDateFX_Rate
    , cast(localtimestamp  as varchar) AS executed_on

	FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp01
	LEFT JOIN ( SELECT  AccountName
                        , DMeAccountGroup
                        , standardizedparentid
                        , standardizedparent
                        , standardizedsubid
                        , standardizedsub
                        , country
                        , Id
                FROM b2b.uda_replicn_sf_corp_uda_vw_account
        WHERE as_of_date IN ( SELECT max(as_of_date) 
                              FROM b2b.uda_replicn_sf_corp_uda_vw_account)
        ) acc01 
    ON opp01.AccountID = acc01.Id

	-- Close Date
	LEFT JOIN ( SELECT   fiscal_qtr_name, 
                        fiscal_wk_in_yr, 
                        fiscal_wk_in_qtr, 
                        date_date, 
                        fiscal_yr, 
                        fiscal_yr_and_qtr_desc
                FROM warehouse.hana_ccmusage_dim_date) DatesClosed01 
    ON opp01.CloseDate = cast(DatesClosed01.Date_Date AS DATE)

	-- Created Date
	LEFT JOIN (SELECT   fiscal_qtr_name, 
                        fiscal_wk_in_yr, 
                        fiscal_wk_in_qtr, 
                        date_date, 
                        fiscal_yr, 
                        fiscal_yr_and_qtr_desc
        from warehouse.hana_ccmusage_dim_date) DatesCreated01 
    ON opp01.CreatedDate = cast(DatesCreated01.Date_Date AS DATE)
	WHERE opp01.as_of_date IN ( SELECT max(as_of_date) 
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)
    AND opp01.CloseDate >= cast('2021-01-01' AS DATE)
;
