/*
    Author: James Cooke
    Last Updated by: James Cooke
    Last Updated: 31/03/2023
    Description: The Assignment Pipeline refers to a lot of hard coded users meeting certain conditions
                 As part of the refactoring exercises these users and the groups they relate to are now held in this table
                 meaning that if users are added / deleted to meet these conditions no script updates are required. 
                 This SHOULD NOT be ran as part of a regular job, but created once and modified.

                 refer to the comments in Pipeline Assignment to see where these groups fit in the logic (its mainly PSS)
                 references to the previous filter values (pre refactoring) also exist in this table.
*/

DROP TABLE IF EXISTS b2b.b2b_pipeline_assignment_user_list;
CREATE TABLE b2b.b2b_pipeline_assignment_user_list (target_team varchar, quarter varchar, condition_alias varchar, original_filter_name varchar, user_role varchar, user_name varchar, condition varchar);
INSERT INTO b2b.b2b_pipeline_assignment_user_list (target_team,quarter,condition_alias,original_filter_name,user_role,user_name,condition)
VALUES  
        --A: PSS_2022Q3_Filter3
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','chris alchin','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','laura toth','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','marisa bogumil','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','dan gonzalez','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','kagan orhan','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','gilles senee','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','loic perhirin','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','peter musumeci','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','james taylor','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','oliver corbett','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','oliver heath','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','scarlet barber','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','leonie lacaille','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','julian arthur','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','magdalena boerger','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','bethan keane','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','dennis waberowski','IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter3','Sales Team','alice woods','IN'),

       --A: PSS_2022Q3_Filter4
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter4','Pipeline Accepted / Rejected by','charlotte bogaert','NOT IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter4','Pipeline Accepted / Rejected by','karine couvreur','NOT IN'),
        ('EMEA PSS','2022 Q3','A','PSS_2022Q3_Filter4','Pipeline Accepted / Rejected by','vincenzo vollaro','NOT IN'),

        --B: PSS_2022Q3_Filter5
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter5','Sales Team','malte istel','IN'),
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter5','Sales Team','katharina reeck','IN'),
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter5','Sales Team','moises crispim','IN'),
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter5','Sales Team','sebastien belliere','IN'),
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter5','Sales Team','trigun soni','IN'),

        --B: PSS_2022Q3_Filter6
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter6','Pipeline Accepted / Rejected by','dan gonzalez','NOT IN'),
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter6','Pipeline Accepted / Rejected by','kagan orhan','NOT IN'),
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter6','Pipeline Accepted / Rejected by','gilles senee','NOT IN'),
        ('EMEA PSS','2022 Q3','B','PSS_2022Q3_Filter6','Pipeline Accepted / Rejected by','charlotte bogaert','NOT IN'),

        --C: PSS_2022Q3_Filter12
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter12','Created by','charlotte bogaert','IN'),
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter12','Created by','karine couvreur','IN'),
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter12','Created by','vincenzo vollaro','IN'),

        --C: PSS_2022Q3_Filter13
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter13','Sales Team','charlotte bogaert','IN'),
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter13','Sales Team','karine couvreur','IN'),
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter13','Sales Team','vincenzo vollaro','IN'),

        --C: PSS_2022Q3_Filter14
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter14','Pipeline Accepted / Rejected by','charlotte bogaert','IN'),
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter14','Pipeline Accepted / Rejected by','karine couvreur','IN'),
        ('EMEA PSS','2022 Q3','C','PSS_2022Q3_Filter14','Pipeline Accepted / Rejected by','vincenzo vollaro','IN'),

        --D: PSS_2022Q3_Filter17
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','chris alchin','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','laura toth','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','marisa bogumil','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','vincenzo vollaro','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','charlotte bogaert','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','karine couvreur','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','katharina reeck','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','moises crispim','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','sebastien belliere','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','trigun soni','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','dan gonzalez','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','kagan orhan','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','gilles senee','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','loic perhirin','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','peter musumeci','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','james taylor','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','oliver corbett','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','oliver heath','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','scarlet barber','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','leonie lacaille','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','julian arthur','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','magdalena boerger','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','bethan keane','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','dennis waberowski','IN'),
        ('EMEA PSS','2022 Q3','D','PSS_2022Q3_Filter17','Pipeline Accepted / Rejected by','alice woods','IN'),

        --E: PSS_2022Q4_Filter2
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','charlotte bogaert','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','karine couvreur','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','vincenzo vollaro','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','malte istel','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','katharina reeck','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','moises crispim','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','sebastien belliere','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','trigun soni','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','chris alchin','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','laura toth','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','marisa bogumil','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','dan gonzalez','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','kagan orhan','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','gilles senee','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','loic perhirin','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','peter musumeci','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','james taylor','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','oliver corbett','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','oliver heath','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','scarlet barber','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','leonie lacaille','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','julian arthur','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','magdalena boerger','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','bethan keane','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','dennis waberowski','IN'),
        ('EMEA PSS','2022 Q4','E','PSS_2022Q4_Filter2','Pipeline Accepted / Rejected by','alice woods','IN'),

        --G1: PSS_2022Q4_Filter7
        ('EMEA PSS','2022 Q4','G1','PSS_2022Q4_Filter7','Pipeline Accepted / Rejected by','charlotte bogaert','IN'),
        ('EMEA PSS','2022 Q4','G1','PSS_2022Q4_Filter7','Pipeline Accepted / Rejected by','karine couvreur','IN'),
        ('EMEA PSS','2022 Q4','G1','PSS_2022Q4_Filter7','Pipeline Accepted / Rejected by','vincenzo vollaro','IN'),

        --G2: PSS_2022Q4_Filter9
        ('EMEA PSS','2022 Q4','G2','PSS_2022Q4_Filter9','Pipeline Accepted / Rejected by','charlotte bogaert','NOT IN'),
        ('EMEA PSS','2022 Q4','G2','PSS_2022Q4_Filter9','Pipeline Accepted / Rejected by','karine couvreur','NOT IN'),
        ('EMEA PSS','2022 Q4','G2','PSS_2022Q4_Filter9','Pipeline Accepted / Rejected by','vincenzo vollaro','NOT IN'),

        --H: PSS_2023_Filter2
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','timo labrenz','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','charlotte bogaert','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','karine couvreur','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','vincenzo vollaro','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','malte istel','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','katharina reeck','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','moises crispim','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','sebastien belliere','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','trigun soni','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','chris alchin','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','laura toth','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','marisa bogumil','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','dan gonzalez','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','kagan orhan','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','gilles senee','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','loic perhirin','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','peter musumeci','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','james taylor','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','oliver corbett','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','oliver heath','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','scarlet barber','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','leonie lacaille','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','julian arthur','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','magdalena boerger','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','bethan keane','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','dennis waberowski','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','alice woods','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','alissa Maier','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','dorota Główka','IN'),
        ('EMEA PSS','2023','H','PSS_2023_Filter2','Pipeline Accepted / Rejected by','dorota Glowka','IN'),

        --I PSS_2023_Filter15
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','robyn eames','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','robin dousa','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','charlotte bogaert','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','andrea bolognese','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','kagan orhan','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','trigun soni','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','jorge nadel ciordia','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','gilles senee','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','ruth weiss','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','marianna sala','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','thor magne engerbakk','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','dan gonzalez','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','doreen paltawitz','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','timo labrenz','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','karine couvreur','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','vincenzo vollaro','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','malte istel','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','katharina reeck','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','moises crispim','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','sebastien belliere','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','chris alchin','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','laura toth','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','marisa bogumil','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','loic perhirin','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','peter musumeci','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','james taylor','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','oliver corbett','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','oliver heath','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','scarlet barber','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','leonie lacaille','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','julian arthur','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','magdalena boerger','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','bethan keane','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','dennis waberowski','IN'),
        ('EMEA PSS','2023','I','PSS_2023_Filter15','Csam','alice woods','IN'),
        
        --K1 PSS_2023_Filter7
        ('EMEA PSS','2023','K1','PSS_2023_Filter7','Pipeline Accepted / Rejected by','charlotte bogaert','IN'),
        ('EMEA PSS','2023','K1','PSS_2023_Filter7','Pipeline Accepted / Rejected by','karine couvreur','IN'),
        ('EMEA PSS','2023','K1','PSS_2023_Filter7','Pipeline Accepted / Rejected by','vincenzo vollaro','IN'),
        ('EMEA PSS','2023','K1','PSS_2023_Filter2','Pipeline Accepted / Rejected by','alissa Maier','IN'),
        ('EMEA PSS','2023','K1','PSS_2023_Filter2','Pipeline Accepted / Rejected by','dorota Główka','IN'),
        ('EMEA PSS','2023','K1','PSS_2023_Filter2','Pipeline Accepted / Rejected by','dorota Glowka','IN'),

        --K2 PSS_2023_Filter9
        ('EMEA PSS','2023','K2','PSS_2023_Filter7','Pipeline Accepted / Rejected by','charlotte bogaert','NOT IN'),
        ('EMEA PSS','2023','K2','PSS_2023_Filter7','Pipeline Accepted / Rejected by','karine couvreur','NOT IN'),
        ('EMEA PSS','2023','K2','PSS_2023_Filter7','Pipeline Accepted / Rejected by','vincenzo vollaro','NOT IN'),
        ('EMEA PSS','2023','K2','PSS_2023_Filter2','Pipeline Accepted / Rejected by','dorota Główka','NOT IN'),
        ('EMEA PSS','2023','K2','PSS_2023_Filter2','Pipeline Accepted / Rejected by','dorota Glowka','NOT IN'),
        
        --L EMEA_EDU_FLAG_3_STAFF
        ('EMEA EDU','ALL','L','EMEA_EDU_FLAG_3_STAFF','Sales Team','birgit petersen','IN'),
        ('EMEA EDU','ALL','L','EMEA_EDU_FLAG_3_STAFF','Sales Team','christiane mueller','IN'),
        ('EMEA EDU','ALL','L','EMEA_EDU_FLAG_3_STAFF','Sales Team','raul lopez','IN'),
        ('EMEA EDU','ALL','L','EMEA_EDU_FLAG_3_STAFF','Sales Team','mike done','IN'),
        ('EMEA EDU','ALL','L','EMEA_EDU_FLAG_3_STAFF','Sales Team','ian brown','IN');