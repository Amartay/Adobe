/*
    Author: Stephen Wills
    Last Updated by: James Cooke
    Last Updated: 04/04/2023
    Documentation Link: https://wiki.corp.adobe.com/display/CCM/Sales+Pipeline+L2+-+LINE+ITEMS
    Last Update Description: Rename table and add product related groups
*/


DROP TABLE IF EXISTS b2b.l2_sa_sfdc_pipeline_line_item;
CREATE TABLE IF NOT EXISTS b2b.l2_sa_sfdc_pipeline_line_item (
                                                            full_opty_id varchar
                                                            , as_of_date date
                                                            , adobe_sku varchar
                                                            , om_pmbu varchar
                                                            , opportunity_product_name varchar
                                                            , outlook_product_group varchar
                                                            , product_code_1 varchar
                                                            , product_id varchar
                                                            , prod_majorolpg1 varchar
                                                            , prod_business_unit varchar
                                                            , product_profit_center_name varchar
                                                            , business_prod_group varchar
                                                            , business_prod_group_growth varchar
                                                            , ori_total_price double
                                                            , ori_reportable_new_asv_fx_neutral double
                                                            , ori_reportable_asv_growth_fx_neutral double
                                                            , ori_quantity double
                                                            , total_growth_asv double
                                                            , acrobat_growth_asv double
                                                            , acrobat_growth_asv_1 double
                                                            , frame_growth_asv double
                                                            , sign_growth_asv double
                                                            , sign_growth_asv_1 double
                                                            , stock_growth_asv double
                                                            , substance_growth_asv double
                                                            , substance_growth_asv_1 double
                                                            , creative_growth_asv double
                                                            , creative_growth_asv_1 double
                                                            , total_quantity double
                                                            , acrobat_quantity double
                                                            , creative_quantity double
                                                            , frame_quantity double
                                                            , sign_quantity double
                                                            , stock_quantity double
                                                            , substance_quantity double
                                                            , executed_on varchar
);


INSERT INTO b2b.l2_sa_sfdc_pipeline_line_item
SELECT  core01.OpportunityID
        , core01.as_of_date
        , core01.AdobeSKU
        , core01.OM_PMBU
        , core01.OpportunityProductName
        , core01.OutlookProductGroup
        , core01.ProductCode1
        , core01.ProductID
        , core01.prod_majorolpg1
        , core01.prod_business_unit
        , core01.ProductProfitCenterName
        , core01.business_prod_group
        , core01.business_prod_group_growth
        , core01.ori_TotalPrice
        , sum(core01.ori_ReportableNewASV_FX_Neutral) AS ReportableNewASV_FX_Neutral
        , sum(CASE  WHEN ORI_ReportableASV_GrowthFX_Neutral IS NULL THEN NULL
                    ELSE core01.ORI_ReportableASV_GrowthFX_Neutral
            END) AS ORI_ReportableASV_GrowthFX_Neutral
        , sum(core01.quantity) AS ori_quantity
        , sum(core01.CLEAN_ReportableASV_GrowthFX_Neutral) AS Total_Growth_ASV
        , sum(CASE  WHEN core01.business_prod_group_growth = 'ACROBAT_GROWTH' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0
                    THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral
                    ELSE 0 END) AS acrobat_growth_asv
        , sum(case 
            WHEN core01.business_prod_group_growth = 'ACROBAT_GROWTH' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.ORI_ReportableASV_GrowthFX_Neutral
            ELSE NULL END
            ) AS acrobat_growth_asv_1
        , sum(case 
            WHEN core01.business_prod_group = 'FRAME' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral
            ELSE 0 END
            ) AS frame_growth_asv
        , sum(case 
            WHEN core01.business_prod_group = 'SIGN' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral
            ELSE 0 END
            ) AS sign_growth_asv
        , sum(case 
            WHEN core01.business_prod_group = 'SIGN' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.ORI_ReportableASV_GrowthFX_Neutral
            ELSE NULL END
            ) AS sign_growth_asv_1

        , sum(case 
            WHEN core01.business_prod_group_growth = 'STOCK_GROWTH' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral
            ELSE 0 END
            ) AS stock_growth_asv
        , sum(case 
            WHEN core01.business_prod_group = 'SUBSTANCE' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral
            ELSE 0 END
            ) AS substance_growth_asv
        , sum(case 
            WHEN core01.business_prod_group = 'SUBSTANCE' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.ORI_ReportableASV_GrowthFX_Neutral
            ELSE NULL END
            ) AS substance_growth_asv_1

        , sum(case 
            WHEN core01.business_prod_group_growth = 'CREATIVE_GROWTH' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral
            ELSE 0 END
            ) AS creative_growth_asv
        , sum(case 
            WHEN core01.business_prod_group_growth = 'CREATIVE_GROWTH'  AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0
            THEN core01.ORI_ReportableASV_GrowthFX_Neutral
            ELSE NULL END
            ) AS creative_growth_asv_1

        , sum(core01.quantity) AS Total_Quantity
        , sum(case 
            WHEN core01.business_prod_group_growth = 'ACROBAT_GROWTH' AND core01.quantity >= 0
            THEN core01.quantity
            ELSE 0 END
            ) AS acrobat_quantity
        , sum(case
            WHEN core01.business_prod_group_growth = 'CREATIVE_GROWTH'      
                AND core01.quantity >= 0
            THEN core01.quantity
            ELSE 0 END
            ) AS creative_quantity
        , sum (case
            WHEN core01.business_prod_group = 'FRAME' AND core01.quantity >= 0
            THEN core01.quantity
            ELSE 0 END
            ) AS frame_quantity
        , sum (case
            WHEN core01.business_prod_group = 'SIGN' AND core01.quantity >= 0
            THEN core01.quantity
            ELSE 0 END
            ) AS sign_quantity
        , sum(case
            WHEN core01.business_prod_group_growth = 'STOCK_GROWTH' AND core01.quantity >= 0
            THEN core01.quantity
            ELSE 0 END
            ) AS stock_quantity
        , sum (case
            WHEN core01.business_prod_group = 'SUBSTANCE'      
                AND core01.quantity >= 0
            THEN core01.quantity
            ELSE 0 END
            ) AS substance_quantity
        , CAST(localtimestamp  as varchar) AS executed_on

FROM (  
        -- Business Logic to collapse down Product Group into key values which are easy to search for
        -- This logic is in this subquery so if it changes - it only need be updated here
        SELECT CASE WHEN core01_no_tag.OutlookProductGroup IN ('ACROBAT','DCE','DOCUMENT SERVICES') THEN 'ACROBAT'
                    WHEN (core01_no_tag.OutlookProductGroup IN ('CREATIVE','CCE STOCK') 
                                                            AND (core01_no_tag.ProductCode1 NOT IN ('FRAM','SBST','SRC','SBTX','3DAR') 
                                                            OR core01_no_tag.ProductCode1 IS NULL)) THEN 'CREATIVE'                           
                    WHEN (core01_no_tag.OutlookProductGroup = 'FRAME.IO' 
                                                        OR core01_no_tag.ProductCode1 = 'FRAM') THEN 'FRAME'
                    WHEN core01_no_tag.OutlookProductGroup IN ('SIGN','DCE TRANSACTION') THEN 'SIGN'
                    WHEN core01_no_tag.OutlookProductGroup = 'STOCK' THEN 'STOCK'
                    WHEN (core01_no_tag.OutlookProductGroup = 'CREATIVE'
                                                    AND core01_no_tag.ProductCode1 IN ('SBST','SRC','SBTX','3DAR'))
                                                    OR core01_no_tag.ProductProfitCenterName = '3DNI'
                                                    OR lower(core01_no_tag.OpportunityProductName) LIKE '%substance%'
                                                    OR lower(core01_no_tag.OpportunityProductName) LIKE '%3d%' THEN 'SUBSTANCE'
                    ELSE core01_no_tag.OutlookProductGroup 
                    END AS business_prod_group,
                
                -- Grouping for Growth Products
                CASE WHEN core01_no_tag.OutlookProductGroup IN ('ACROBAT','DCE') 
                     THEN 'ACROBAT_GROWTH'
                     WHEN (  core01_no_tag.OutlookProductGroup = 'CREATIVE'
                            AND (core01_no_tag.ProductCode1 NOT IN ('FRAM','SBST','SRC','SBTX','3DAR')
                            AND (core01_no_tag.OpportunityProductName NOT LIKE '%SUBSTANCE%')
                            AND (core01_no_tag.OpportunityProductName NOT LIKE '%3D%')
                            OR core01_no_tag.ProductCode1 IS NULL))
                     THEN 'CREATIVE_GROWTH'
                     WHEN core01_no_tag.OutlookProductGroup IN ('STOCK','CCE STOCK') 
                     THEN 'STOCK_GROWTH'
                     ELSE core01_no_tag.OutlookProductGroup
                END AS business_prod_group_growth,
                core01_no_tag.OpportunityID,
                core01_no_tag.as_of_date,
                core01_no_tag.AdobeSKU,
                core01_no_tag.OM_PMBU,
                core01_no_tag.OpportunityProductName,
                core01_no_tag.OutlookProductGroup,
                core01_no_tag.ProductCode1,
                core01_no_tag.ProductID,
                core01_no_tag.ProductProfitCenterName,
                core01_no_tag.ori_TotalPrice,
                core01_no_tag.ori_ReportableNewASV_FX_Neutral,
                core01_no_tag.ORI_ReportableASV_GrowthFX_Neutral,
                core01_no_tag.CLEAN_ReportableASV_GrowthFX_Neutral,
                core01_no_tag.quantity,
                core01_no_tag.prod_majorolpg1,
                core01_no_tag.prod_business_unit
        FROM
        ( 
        SELECT  OpportunityID
                    , cast(as_of_date AS DATE) AS as_of_date
                    , case 
                        WHEN AdobeSKU = '\N' THEN NULL 
                        ELSE AdobeSKU 
                        END AS AdobeSKU
                    , case
                        WHEN OM_PMBU = '\N' THEN NULL 
                        ELSE OM_PMBU
                        END AS OM_PMBU
                    , OpportunityProductName
                    , CASE WHEN OutlookProductGroup = '\N' THEN NULL 
                        ELSE OutlookProductGroup
                        END AS OutlookProductGroup
                    , CASE WHEN ProductCode1 = '\N' THEN NULL
                        ELSE ProductCode1
                        END AS ProductCode1
                    , li.ProductID
                    , prod.prod_majorolpg1
                    , prod.prod_business_unit
                    , CASE WHEN ProductProfitCenterName = '\N' THEN NULL 
                        ELSE ProductProfitCenterName 
                        END AS ProductProfitCenterName
                    , sum(round(cast(TotalPrice AS double), 2)) AS ori_TotalPrice
                    , sum(CASE WHEN ReportableNewASV_FX_Neutral IS NULL THEN 0
                        ELSE round(cast(ReportableNewASV_FX_Neutral AS double), 0)
                        END) AS ori_ReportableNewASV_FX_Neutral
                    , sum(CASE WHEN ReportableASV_GrowthFX_Neutral IS NULL THEN NULL
                        ELSE round(cast(ReportableASV_GrowthFX_Neutral AS double), 0)
                        END) AS ORI_ReportableASV_GrowthFX_Neutral
                    , sum(CASE WHEN ReportableASV_GrowthFX_Neutral IS NULL THEN 0
                        WHEN cast(ReportableASV_GrowthFX_Neutral AS double) < 0 THEN 0
                        ELSE round(cast(ReportableASV_GrowthFX_Neutral AS double), 0)
                        END) AS CLEAN_ReportableASV_GrowthFX_Neutral
                    , sum(cast(quantity AS double)) AS quantity

                    FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                    LEFT JOIN  ( SELECT     MajorOLPG1 AS prod_majorolpg1
                                            ,OutlookProductGroup AS prod_outlook_prod_group
                                            ,BusinessUnit AS prod_business_unit
                                            ,ProductID 
                                    FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                    WHERE as_of_date IN (SELECT max(as_of_date) 
                                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2)
                    ) prod 
                    ON li.ProductID = prod.ProductID

                    WHERE as_of_date IN ( SELECT max(as_of_date) 
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem
                                        )

                    GROUP BY AdobeSKU
                            , li.OM_PMBU
                            , li.OpportunityProductName
                            , li.OutlookProductGroup
                            , li.ProductCode1
                            , li.ProductID
                            , prod.prod_majorolpg1
                            , prod.prod_business_unit
                            , li.ProductProfitCenterName
                            , li.OpportunityID
                            , li.as_of_date
                ) core01_no_tag
) core01

GROUP BY core01.OpportunityID
        , core01.business_prod_group
        , core01.business_prod_group_growth
        , core01.as_of_date
        , core01.AdobeSKU
        , core01.OM_PMBU
        , core01.OpportunityProductName
        , core01.OutlookProductGroup
        , core01.ProductCode1
        , core01.ProductID
        , core01.ProductProfitCenterName
        , core01.ori_TotalPrice
        , prod_majorolpg1
        , prod_business_unit

        ;
