import pandas as pd

def getDifferences(dbx_filepath,hadoop_filepath):

    df_hadoop = pd.read_csv(hadoop_filepath, dtype=str)
    df_dbx = pd.read_csv(dbx_filepath,  dtype=str)

    # are there any differences - (this might not work if rows have duplicates in source system - so extraction code needs to be SELECT DISTINCT)
    df_unmatched_records=pd.concat([df_hadoop,df_dbx]).drop_duplicates(keep=False)

    return df_unmatched_records

def main():

    # Make a list of all the files to check - add your extracted files to this list
    file_names = ['CurrencyType']
    
    for f in file_names:
        dbx_filepath=f"Files/Databricks/{f}.csv"
        hadoop_filepath=f"Files/Hadoop/{f}.csv"

        df_differences = getDifferences(dbx_filepath,hadoop_filepath)
        
        # If we have differences log them
        if not df_differences.empty:
            print(f'Differences Found in: {f} review output file')
            output_filepath=f"Differences/{f}.csv"
            df_differences.to_csv(output_filepath)
        else: 
            print(f'{f} is the same in Hadoop & Databricks')

if __name__ == "__main__":
    main()
