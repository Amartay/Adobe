DROP TABLE IF EXISTS b2b.b2b_connections;

CREATE TABLE b2b.b2b_connections AS 
SELECT DISTINCT vip_contract 
                , sales_document
                , ech_parent_id
                , ech_sub_id
                , crm_customer_guid
                , CASE  WHEN ecc_customer_id IS NULL OR trim(ecc_customer_id)='' 
                        THEN '-'
                        ELSE  cast(ecc_customer_id AS varchar) 
                END AS ecc_customer_id
                , ech_child_key
FROM ccm_subscrpn.vw_ccm_pivot4_all
WHERE source_type is not null
AND event_source = 'SNAPSHOT'
AND date_key in ( SELECT max(date_key) 
                  FROM ccm_subscrpn.vw_ccm_pivot4_all 
                  WHERE source_type IS NOT NULL
                  AND event_source = 'SNAPSHOT' AND date_key IS NOT NULL)


