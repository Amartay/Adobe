DROP TABLE IF EXISTS b2b.b2b_cust_research_arr;

CREATE TABLE b2b.b2b_cust_research_arr AS

SELECT DISTINCT CASE WHEN main01.Parent_ID is null THEN 'None Listed' ELSE main01.Parent_ID END AS parent_id
, CASE WHEN main01.Parent_Name is null THEN 'None Listed' ELSE main01.Parent_Name END AS parent_name
, CASE WHEN main01.Parent_Country is null THEN 'None Listed' ELSE upper(main01.Parent_Country) END AS parent_country
, CASE WHEN webDomain01.state_region is null THEN 'None Listed' 
    when webDomain01.state_region = '' THEN 'None Listed' 
    ELSE UPPER(webDomain01.state_region) END AS state_region
, CASE WHEN webDomain01.city is null THEN 'None Listed' 
    when webDomain01.city = '' THEN 'None Listed' 
    ELSE UPPER(webDomain01.city) END AS city
, CASE WHEN webDomain01.postal_code is null THEN 'None Listed' 
    when webDomain01.postal_code = '' THEN 'None Listed' 
    ELSE UPPER(webDomain01.postal_code) END AS postal_code
, CASE WHEN webDomain01.website is null THEN 'None Listed' 
    when webDomain01.website = '' THEN 'None Listed' 
    ELSE lower(webDomain01.website) END AS parent_web_domain
, CASE WHEN main01.Parent_Industry is null THEN 'None Listed' 
    when main01.Parent_Industry = '' THEN 'None Listed' 
    ELSE upper(main01.Parent_Industry) END AS parent_industry
, CASE WHEN main01.Parent_Annual_Sales_USD is null THEN 0 
    ELSE cast(main01.Parent_Annual_Sales_USD AS bigint) END AS Parent_Annual_Sales_USD
, CASE WHEN main01.Parent_Tot_Emply_Count is null THEN 0
    ELSE cast(main01.Parent_Tot_Emply_Count AS int) END AS Parent_Tot_Emply_Count

, CASE WHEN main01.Sub_ID is null THEN 'None Listed' 
    when main01.Sub_ID = '' THEN 'None Listed' 
    ELSE main01.Sub_ID END AS sub_id
, CASE WHEN main01.Sub_Name is null THEN 'None Listed' 
    when main01.Sub_Name = '' THEN 'None Listed' 
    ELSE main01.Sub_Name END AS sub_name
, CASE WHEN main01.Sub_Country is null THEN 'None Listed' 
    when main01.Sub_Country = '' THEN 'None Listed' 
    ELSE upper(main01.Sub_Country) END AS sub_country
, CASE WHEN main01.Sub_Annual_Sales_USD is null THEN 0 
    ELSE cast(main01.Sub_Annual_Sales_USD AS bigint) END AS Sub_Annual_Sales_USD
, CASE WHEN main01.Sub_Tot_Emply_Count is null THEN 0 
    ELSE cast(main01.Sub_Tot_Emply_Count AS int) END AS Sub_Tot_Emply_Count
, CASE WHEN main01.Sub_Industry is null THEN 'None Listed' ELSE main01.Sub_Industry END AS sub_industry

, main01.contract_key
, main01.subscription_account_guid
, main01.crm_customer_guid AS CRM_Cust_ID
, main01.end_user_name
, main01.sfdc_accountid
, main01.ecc_customer_id

-- MM Coverage Names - at Parent Level
, CASE WHEN coverage01.dcaename is null THEN 'None Listed' 
    when coverage01.dcaename = '' THEN 'None Listed' 
    when coverage01.dcaename = '#N/A' THEN 'None Listed' 
    ELSE coverage01.dcaename END AS AE
, CASE WHEN coverage01.ae_mgr_employee_name is null THEN 'None Listed' 
    when coverage01.ae_mgr_employee_name = '' THEN 'None Listed' 
    when coverage01.ae_mgr_employee_name = '#N/A' THEN 'None Listed' 
    ELSE coverage01.ae_mgr_employee_name END AS ae_mgr
, CASE WHEN coverage01.amname is null THEN 'None Listed' 
    when coverage01.amname = '' THEN 'None Listed' 
    when coverage01.amname = '#N/A' THEN 'None Listed' 
    ELSE coverage01.amname END AS am
, CASE WHEN coverage01.am_mgr_employee_name is null THEN 'None Listed' 
    when coverage01.am_mgr_employee_name = '' THEN 'None Listed' 
    when coverage01.am_mgr_employee_name = '#N/A' THEN 'None Listed' 
    ELSE coverage01.am_mgr_employee_name END AS am_mgr
, CASE WHEN coverage01.dcpsmname is null THEN 'None Listed' 
    when coverage01.dcpsmname = '' THEN 'None Listed' 
    when coverage01.dcpsmname = '#N/A' THEN 'None Listed' 
    ELSE coverage01.dcpsmname END AS dc_psm 
, CASE WHEN coverage01.dcpsm_mgr_employee_name is null THEN 'None Listed' 
    when coverage01.dcpsm_mgr_employee_name = '' THEN 'None Listed' 
    when coverage01.dcpsm_mgr_employee_name = '#N/A' THEN 'None Listed' 
    ELSE coverage01.dcpsm_mgr_employee_name END AS dc_psm_mgr

, CASE WHEN coverage01."3daeposid" is null THEN 'None Listed' 
    when coverage01."3daeposid" = '' THEN 'None Listed' 
    when coverage01."3daeposid" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3daeposid" END AS "3d_ae_pos_id"
, CASE WHEN coverage01."3daename" is null THEN 'None Listed' 
    when coverage01."3daename" = '' THEN 'None Listed' 
    when coverage01."3daename" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3daename" END AS "3d_ae_name"
, CASE WHEN coverage01."3d_ae_mgr_employee_name" is null THEN 'None Listed' 
    when coverage01."3d_ae_mgr_employee_name" = '' THEN 'None Listed' 
    when coverage01."3d_ae_mgr_employee_name" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3d_ae_mgr_employee_name" END AS "3d_ae_mgr"

, CASE WHEN coverage01."3dpsmposid" is null THEN 'None Listed' 
    when coverage01."3dpsmposid" = '' THEN 'None Listed' 
    when coverage01."3dpsmposid" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3dpsmposid" END AS "3d_psm_pos_id"
, CASE WHEN coverage01."3dpsmname" is null THEN 'None Listed' 
    when coverage01."3dpsmname" = '' THEN 'None Listed' 
    when coverage01."3dpsmname" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3dpsmname" END AS "3d_psm_name"
, CASE WHEN coverage01."3d_psm_mgr_employee_name" is null THEN 'None Listed' 
    when coverage01."3d_psm_mgr_employee_name" = '' THEN 'None Listed' 
    when coverage01."3d_psm_mgr_employee_name" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3d_psm_mgr_employee_name" END AS "3d_psm_mgr"

-- Geographic related data
, CASE WHEN main01.Reseller_Partner is null THEN 'None Listed' 
    when main01.Reseller_Partner = '' THEN 'None Listed' 
    when main01.Reseller_Partner = '#N/A' THEN 'None Listed' 
    ELSE main01.Reseller_Partner END AS reseller_partner
, main01.geo AS Geo
, main01.region AS Region
, main01.market_area AS Market_Area
, main01.sales_district AS Sales_District

-- Contract grouping data
, main01.market_segment AS Market_Segment
, main01.dme_acct_segment AS DME_Acct_Segment
, main01.contract_type AS B2B_Contract_Type
, cast(main01.Buying_Program AS varchar) AS Buying_Program
, main01.entitlement_type AS Entitlement_Type
, main01.route_to_market AS Route_to_Market
, main01.cc_phone_vs_web AS Phone_vs_Web
, main01.store_ui AS Store_UI

-- Product focused data
, main01.product_segment AS Prod_Segment
, main01.product_name AS Prod_Name
, main01.product_name_description AS Prod_Name_Desc
, main01.subs_offer
, main01.cc_segment
, main01.cc_segment_offer
, main01.etla_seat_type
, main01.olpg
, main01.offering_type
, main01.mm_flag

-- Measures
, cast(main01.contract_start_date AS date) AS Contract_Start_Date
, main01.Start_Year_Qtr
, cast(main01.contract_end_date AS date) AS Contract_End_Date
, main01.End_Year_Qtr
, cast (main01.as_of_date AS date) AS as_of_date
, main01.Total_ARR
, main01.Total_Contract_Qty
, main01.material_number

FROM  
    (
    SELECT 
    source01.ech_parent_id AS Parent_ID
    , source01.ech_parent_name AS Parent_Name
    , source01.ech_parent_country_code AS Parent_Country
    , round(cast(source01.ech_parent_annual_sales_usd AS double), 0) AS Parent_Annual_Sales_USD
    , source01.ech_parent_tot_emp_cont AS Parent_Tot_Emply_Count
    , source01.ech_parent_industry AS Parent_Industry

    , source01.ech_sub_id AS Sub_ID
    , source01.ech_sub_name AS Sub_Name
    , source01.ech_sub_country_code AS Sub_Country
    , round(cast(source01.ech_sub_annual_sales_usd AS double), 0) AS Sub_Annual_Sales_USD
    , source01.ech_sub_tot_emp_cont AS Sub_Tot_Emply_Count
    , source01.ech_sub_industry AS Sub_Industry

    -- Best way to pull in contact details for END User is to look at SFDC data and connect to individual actuals
    -- This contact information is at Parent Level
    , concat(parentContact01.firstname, ' ', parentContact01.lastname) AS Parent_Contact_Name
    , parentEmail01.contact_name__c AS Parent_SFDC_Contact_ID

    , source01.contract_key
    , source01.contract_start_date
    , startDate01.fiscal_yr_and_qtr_desc AS Start_Year_Qtr
    , source01.contract_end_date
    , endDate01.fiscal_yr_and_qtr_desc AS End_Year_Qtr

    , reseller01.c_partner_name AS Reseller_Partner

    , source01.geo
    , source01.region
    , source01.market_area
    , source01.sales_district
    , source01.dme_acct_segment
    , source01.product_segment
    , source01.contract_type
    , CASE WHEN trim(upper(source01.route_to_market)) = 'ADOBE.COM/CC.COM' 
        THEN 'Team Direct'
        when source01.etla_seat_type <> 'NONE' 
        THEN 'ETLA'
        ELSE 'VIP'
        END AS Buying_Program

    , source01.route_to_market
    , source01.entitlement_type
    , source01.market_segment
    , source01.product_config
    , source01.product_name
    , CASE WHEN trim(upper(source01.product_name)) IN ('SBST', 'SRC', 'SBTX')
        THEN 'Substance'
        ELSE source01.product_name_description
        END AS product_name_description
    , source01.cc_phone_vs_web
    , source01.material_number
    , source01.subscription_account_guid
    , source01.end_user_id
    , source01.store_ui
    , source01.subs_offer
    , source01.cc_segment
    , source01.cc_segment_offer
    , source01.end_user_name
    , source01.etla_seat_type
    , source01.olpg
    , sum(cast(source01.fwk_end_arr AS double)) AS Total_ARR
    , sum(cast(source01.contract_quantity AS int)) AS Total_Contract_Qty    
    , source01.sales_document_type
    , source01.mm_flag
    , source01.crm_customer_guid
    , source01.offering_type
    , source01.as_of_date
    , CASE WHEN connect01.ech_child_key LIKE '%-_' THEN 'None Listed'
        WHEN connect01.ech_child_key IS NULL THEN 'None Listed'
        ELSE connect01.ech_child_key
        END AS sfdc_accountid
    , source01.end_user_id AS ecc_customer_id
        

    FROM b2b.b2b_arr source01

    -- Get the email address of Contact for Parent Contract
    LEFT JOIN (SELECT contract_id__c, account_name__c, contact_name__c, contact_email__c, sold_to_id__c 
                     FROM sourcedata.sfdc_post_sales__c) parentEmail01
        ON parentEmail01.contract_id__c = source01.vip_contract 
        AND parentEmail01.sold_to_id__c = source01.end_user_id
    LEFT JOIN (SELECT id, firstname, lastname FROM sourcedata.sfdc_contact) parentContact01
        ON parentContact01.id = parentEmail01.contact_name__c

    -- Date with QTRs for Contract Start and END dates
    LEFT JOIN (SELECT date_date AS date_id, 
                      fiscal_yr_and_qtr_desc 
                FROM warehouse.hana_ccmusage_dim_date) startDate01
        ON source01.contract_start_date = startDate01.date_id
    LEFT JOIN (SELECT date_date AS date_id, 
                            fiscal_yr_and_qtr_desc 
                    FROM warehouse.hana_ccmusage_dim_date) endDate01
        ON source01.contract_end_date = endDate01.date_id

    LEFT JOIN (SELECT bl_licensing_contract, 
                      bl_sales_document,
                      ARRAY_JOIN(array_distinct(ARRAY_AGG(c_partner_name)),' | ') AS c_partner_name
               FROM b2b.sap_hana_sys_bic_channel_an_channelink_consolidated
               GROUP BY  bl_licensing_contract, bl_sales_document) reseller01
        ON reseller01.bl_sales_document = source01.sales_document
            AND reseller01.bl_licensing_contract = source01.vip_contract

    LEFT JOIN (
        SELECT DISTINCT ecc_customer_id, 
                        ech_child_key 
        FROM b2b.b2b_connections 
        WHERE ecc_customer_id IS NOT NULL
            AND ecc_customer_id <> ''
    ) connect01     
    ON connect01.ecc_customer_id = source01.end_user_id

    WHERE source01.as_of_date = ( SELECT max(as_of_date) 
                                  FROM b2b.b2b_arr)
    AND source01.contract_type NOT IN ('PPBU', 'SIGN_ARIA')
    GROUP BY 
    source01.ech_parent_id
    , source01.ech_parent_name
    , source01.ech_parent_country_code
    , source01.ech_parent_annual_sales_usd
    , source01.ech_parent_tot_emp_cont
    , source01.ech_parent_industry
    , source01.ech_sub_id
    , source01.ech_sub_name
    , source01.ech_sub_country_code
    , source01.ech_sub_annual_sales_usd
    , source01.ech_sub_tot_emp_cont
    , source01.ech_sub_industry
    , parentEmail01.contact_email__c
    , parentEmail01.sold_to_id__c
    , parentContact01.firstname
    , parentContact01.lastname
    , parentEmail01.contact_name__c
    , source01.contract_key
    , source01.contract_start_date
    , startDate01.fiscal_yr_and_qtr_desc
    , source01.contract_end_date
    , endDate01.fiscal_yr_and_qtr_desc
    , source01.geo
    , source01.region
    , source01.market_area
    , source01.sales_district
    , source01.dme_acct_segment
    , source01.product_segment
    , source01.contract_type
    , source01.route_to_market
    , source01.entitlement_type
    , source01.market_segment
    , source01.product_config
    , source01.product_name
    , source01.product_name_description
    , source01.cc_phone_vs_web
    , source01.material_number
    , source01.subscription_account_guid
    , source01.end_user_id
    , source01.store_ui
    , source01.subs_offer
    , source01.cc_segment
    , source01.cc_segment_offer
    , source01.end_user_name
    , source01.etla_seat_type
    , source01.olpg
    , source01.sales_document_type
    , source01.mm_flag
    , reseller01.c_partner_name
    , source01.crm_customer_guid
    , source01.offering_type
    , source01.as_of_date
    , connect01.ech_child_key
    , source01.end_user_id
    ) main01


-- Pull in Abdul MM Coverage Data
LEFT JOIN (
    SELECT DISTINCT source01.parent_id
                , source01.sub_id 
                , source01.dcaename
                , AE.mgr_employee_name AS ae_mgr_employee_name
                , source01.amname
                , AM.mgr_employee_name AS am_mgr_employee_name
                , source01.dcpsmname 
                , DCPSM.mgr_employee_name AS dcpsm_mgr_employee_name
                , source01."3daeposid"
                , source01."3daename"
                , TDAE.mgr_employee_name AS "3d_ae_mgr_employee_name"
                , source01."3dpsmname"
                , source01."3dpsmposid"
                , TDPSM.mgr_employee_name AS "3d_psm_mgr_employee_name"
    FROM gtm.agodah_mmcoverage source01
    LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing AE
        ON AE.positiON_id = dcaeposid
    LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing AM
        ON AM.positiON_id = source01.amposid
    LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing DCPSM
        ON DCPSM.positiON_id = source01.dcpsmposid
    LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing TDAE
        ON TDAE.positiON_id = source01."3daeposid"
    LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing TDPSM
        ON TDPSM.positiON_id = source01."3dpsmposid"
    WHERE source01.amname is not null and source01.amname <> ''
) coverage01
ON coverage01.parent_id = main01.parent_id 
AND coverage01.sub_id = main01.sub_id

-- Pull in Firmogrpahic data on PARENT ID
LEFT JOIN (
    SELECT DISTINCT prnt_std_name_key, 
                    trim(website) AS website, 
                    trim(state_region) AS state_region, 
                    trim(city) AS city, 
                    postal_code
    FROM cce.rv_td_prnt
    WHERE website IS NOT NULL
    AND NOT regexp_like(lower(website),'gmail|hotmail|adobe|yahoo|aol|msn|icloud|protonmail|outlook|appleid|nifty|libero|shaw\.ca|live\.com\.au') 
    AND replace(website,' ','') NOT IN ('-1', '-','', '.', '....', ':')
) webDomain01 
ON webDomain01.prnt_std_name_key = main01.parent_id
;
