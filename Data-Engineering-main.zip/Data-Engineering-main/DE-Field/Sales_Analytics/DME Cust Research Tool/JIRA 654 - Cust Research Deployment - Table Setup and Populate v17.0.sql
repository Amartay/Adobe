DROP TABLE IF EXISTS b2b.b2b_cust_research_deployment;
CREATE TABLE b2b.b2b_cust_research_deployment AS 
SELECT DISTINCT
      deploySource01.contract_key
    , deploySource01.ech_parent_id AS parent_id
    , deploySource01.ech_parent_name AS parent_name
    , CASE WHEN webDomain01.website IS NULL THEN 'None Listed' 
           WHEN webDomain01.website = '' THEN 'None Listed' 
        ELSE lower(webDomain01.website) END  AS Website
    , CASE WHEN arr01.ech_sub_id IS NULL THEN 'None Listed' 
        WHEN arr01.ech_sub_id = '' THEN 'None Listed' 
        ELSE arr01.ech_sub_id END  AS sub_id
    , CASE WHEN arr01.ech_sub_name IS NULL THEN 'None Listed' 
        WHEN arr01.ech_sub_name = '' THEN 'None Listed' 
        ELSE arr01.ech_sub_name END  AS sub_name
    , deploySource01.contract_type
    , CASE WHEN arr01.end_user_name IS NULL THEN 'None Listed' 
        WHEN arr01.end_user_name = '' THEN 'None Listed' 
        ELSE arr01.end_user_name END  AS end_user_name

    , CASE WHEN connect01.ech_child_key like '%-_' THEN 'None Listed'
        WHEN connect01.ech_child_key IS NULL THEN 'None Listed'
        ELSE connect01.ech_child_key
        END  AS sfdc_accountid
    , deploySource01.end_user_id AS ecc_customer_id

    , cast(arr01.min_contract_end_date AS DATE) as min_contract_end_date
    , arr01.subscription_account_guid
    , arr01.crm_customer_guid
    , deploySource01.dme_acct_segment
    , deploySource01.mm_flag
    , deploySource01.offering_name
    , deploySource01.offering_type
    , deploySource01.market_segment
    , deploySource01.org_id
    , deploySource01.org_name
, CASE WHEN coverage01.dcaename IS NULL THEN 'None Listed' 
    WHEN coverage01.dcaename = '' THEN 'None Listed' 
    WHEN coverage01.dcaename = '#N/A' THEN 'None Listed' 
    ELSE coverage01.dcaename END  AS AE
, CASE WHEN coverage01.ae_mgr_employee_name IS NULL THEN 'None Listed' 
    WHEN coverage01.ae_mgr_employee_name = '' THEN 'None Listed' 
    WHEN coverage01.ae_mgr_employee_name = '#N/A' THEN 'None Listed' 
    ELSE coverage01.ae_mgr_employee_name END  AS ae_mgr
, CASE WHEN coverage01.amname IS NULL THEN 'None Listed' 
    WHEN coverage01.amname = '' THEN 'None Listed' 
    WHEN coverage01.amname = '#N/A' THEN 'None Listed' 
    ELSE coverage01.amname END  AS am
, CASE WHEN coverage01.am_mgr_employee_name IS NULL THEN 'None Listed' 
    WHEN coverage01.am_mgr_employee_name = '' THEN 'None Listed' 
    WHEN coverage01.am_mgr_employee_name = '#N/A' THEN 'None Listed' 
    ELSE coverage01.am_mgr_employee_name END  AS am_mgr
, CASE WHEN coverage01.dcpsmname IS NULL THEN 'None Listed' 
    WHEN coverage01.dcpsmname = '' THEN 'None Listed' 
    WHEN coverage01.dcpsmname = '#N/A' THEN 'None Listed' 
    ELSE coverage01.dcpsmname END  AS dc_psm 
, CASE WHEN coverage01.dcpsm_mgr_employee_name IS NULL THEN 'None Listed' 
    WHEN coverage01.dcpsm_mgr_employee_name = '' THEN 'None Listed' 
    WHEN coverage01.dcpsm_mgr_employee_name = '#N/A' THEN 'None Listed' 
    ELSE coverage01.dcpsm_mgr_employee_name END  AS dc_psm_mgr

, CASE WHEN coverage01."3daeposid" IS NULL THEN 'None Listed' 
    WHEN coverage01."3daeposid" = '' THEN 'None Listed' 
    WHEN coverage01."3daeposid" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3daeposid" END  AS "3d_ae_pos_id"
, CASE WHEN coverage01."3daename" IS NULL THEN 'None Listed' 
    WHEN coverage01."3daename" = '' THEN 'None Listed' 
    WHEN coverage01."3daename" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3daename" END  AS "3d_ae_name"
, CASE WHEN coverage01."3d_ae_mgr_employee_name" IS NULL THEN 'None Listed' 
    WHEN coverage01."3d_ae_mgr_employee_name" = '' THEN 'None Listed' 
    WHEN coverage01."3d_ae_mgr_employee_name" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3d_ae_mgr_employee_name" END  AS "3d_ae_mgr"

, CASE WHEN coverage01."3dpsmposid" IS NULL THEN 'None Listed' 
    WHEN coverage01."3dpsmposid" = '' THEN 'None Listed' 
    WHEN coverage01."3dpsmposid" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3dpsmposid" END  AS "3d_psm_pos_id"
, CASE WHEN coverage01."3dpsmname" IS NULL THEN 'None Listed' 
    WHEN coverage01."3dpsmname" = '' THEN 'None Listed' 
    WHEN coverage01."3dpsmname" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3dpsmname" END  AS "3d_psm_name"
, CASE WHEN coverage01."3d_psm_mgr_employee_name" IS NULL THEN 'None Listed' 
    WHEN coverage01."3d_psm_mgr_employee_name" = '' THEN 'None Listed' 
    WHEN coverage01."3d_psm_mgr_employee_name" = '#N/A' THEN 'None Listed' 
    ELSE coverage01."3d_psm_mgr_employee_name" END  AS "3d_psm_mgr"
    , sum(cast(deploySource01.local_licensed_qty AS bigint)) AS Provisioned
    , sum(cast(deploySource01.delegated AS bigint)) AS Delegated
    , sum(cast(deploySource01.activated AS bigint)) AS Activated
    , sum(cast(deploySource01.mau AS bigint)) AS MAU
    , sum(cast(deploySource01.qau AS bigint)) AS QAU
    , sum(cast(deploySource01.rmau AS bigint)) AS RMAU
    , cast(deploySource01.as_of_date AS date) AS as_of_date

    FROM b2b.b2b_deployment_usage deploySource01

    LEFT JOIN (
        SELECT DISTINCT contract_key, ech_sub_id, ech_sub_name, ARRAY_JOIN(array_distinct(ARRAY_AGG(end_user_name)),' | ') AS end_user_name, 
        offering_type, subscription_account_guid, crm_customer_guid, min(contract_end_date) AS min_contract_end_date
        FROM b2b.b2b_arr 
        WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.b2b_arr)
        AND ech_parent_id IS NOT NULL
        GROUP BY contract_key, ech_sub_id, ech_sub_name, offering_type, subscription_account_guid, crm_customer_guid
        ) arr01 ON arr01.contract_key = deploySource01.contract_key
            AND arr01.offering_type = deploySource01.offering_type

    LEFT JOIN (
        SELECT DISTINCT
        source01.parent_id
        , source01.sub_id 
        , source01.dcaename
        , AE.mgr_employee_name AS ae_mgr_employee_name
        , source01.amname
        , AM.mgr_employee_name AS am_mgr_employee_name
        , source01.dcpsmname 
        , DCPSM.mgr_employee_name AS dcpsm_mgr_employee_name
        , source01."3daeposid"
        , source01."3daename"
        , TDAE.mgr_employee_name AS "3d_ae_mgr_employee_name"
        , source01."3dpsmname"
        , source01."3dpsmposid"
        , TDPSM.mgr_employee_name AS "3d_psm_mgr_employee_name"
        FROM gtm.agodah_mmcoverage source01
        LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing AE
            ON AE.position_id = dcaeposid
        LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing AM
            ON AM.position_id = source01.amposid
        LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing DCPSM
            ON DCPSM.position_id = source01.dcpsmposid
        LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing TDAE
            ON TDAE.position_id = source01."3daeposid"
        LEFT JOIN b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing TDPSM
            ON TDPSM.position_id = source01."3dpsmposid"

        WHERE source01.amname IS NOT NULL AND source01.amname <> ''
        ) coverage01
        ON coverage01.parent_id = deploySource01.ech_parent_id
        AND coverage01.sub_id = arr01.ech_sub_id

    LEFT JOIN (
                SELECT DISTINCT prnt_std_name_key, 
                            trim(website) AS website, 
                            trim(state_region) AS state_region, 
                            trim(city) AS city, 
                            postal_code
            FROM cce.rv_td_prnt
            WHERE website IS NOT NULL
            AND NOT regexp_like(lower(website),'gmail|hotmail|adobe|yahoo|aol|msn|icloud|protonmail|outlook|appleid|nifty|libero|shaw\.ca|live\.com\.au') 
            AND replace(website,' ','') NOT IN ('-1', '-','', '.', '....', ':')
    ) webDomain01 ON webDomain01.prnt_std_name_key = deploySource01.ech_parent_id

    LEFT JOIN (
            SELECT DISTINCT ecc_customer_id, ech_child_key 
            FROM b2b.b2b_connections 
            WHERE ecc_customer_id IS NOT NULL AND ecc_customer_id <> ''
        ) connect01 ON connect01.ecc_customer_id = deploySource01.end_user_id

    WHERE deploySource01.as_of_date = (SELECT max(as_of_date) FROM b2b.b2b_deployment_usage)
    AND deploySource01.contract_type not in ('PPBU', 'SIGN_ARIA')

    GROUP BY
    deploySource01.contract_key
    , deploySource01.ech_parent_id
    , deploySource01.ech_parent_name
    , webDomain01.website
    , arr01.ech_sub_id
    , arr01.ech_sub_name
    , deploySource01.contract_type
    , deploySource01.end_user_id
    , arr01.end_user_name
    , arr01.min_contract_end_date
    , arr01.subscription_account_guid
    , arr01.crm_customer_guid
    , deploySource01.dme_acct_segment
    , deploySource01.mm_flag
    , deploySource01.offering_name
    , deploySource01.offering_type
    , deploySource01.market_segment
    , deploySource01.org_id
    , deploySource01.org_name
    , coverage01.dcaename
    , coverage01.ae_mgr_employee_name
    , coverage01.amname
    , coverage01.am_mgr_employee_name 
    , coverage01.dcpsmname
    , coverage01.dcpsm_mgr_employee_name 
    , coverage01."3daeposid"
    , coverage01."3daename"
    , coverage01."3d_ae_mgr_employee_name"
    , coverage01."3dpsmposid"
    , coverage01."3dpsmname"
    , coverage01."3d_psm_mgr_employee_name"
    , deploySource01.as_of_date
    , connect01.ech_child_key
;