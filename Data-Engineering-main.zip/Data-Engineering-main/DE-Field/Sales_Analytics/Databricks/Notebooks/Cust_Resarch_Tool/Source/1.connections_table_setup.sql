-- Databricks notebook source
-- MAGIC %md
-- MAGIC ####This Table is a Placeholder
-- MAGIC
-- MAGIC I understand this is to be replaced with an actual table generated from IDS. This therefore is a placeholder. 
-- MAGIC Once this table does exist all references to b2b.b2b_connections need to be re-pointed to the new source
-- MAGIC

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC REFRESH csmb.vw_ccm_pivot4_all;

-- COMMAND ----------

-- DBTITLE 1,Create Placeholder Table (b2b.b2b_connections)
-- MAGIC %sql
-- MAGIC DROP TABLE IF EXISTS b2b.b2b_connections;
-- MAGIC CREATE TABLE b2b.b2b_connections AS 
-- MAGIC SELECT DISTINCT vip_contract,
-- MAGIC                 sales_document,
-- MAGIC                 ech_parent_id,
-- MAGIC                 ech_sub_id,
-- MAGIC                 crm_customer_guid,
-- MAGIC                 CASE WHEN ecc_customer_id IS NULL OR ecc_customer_id ='' THEN '-'
-- MAGIC                 ELSE cast(cast(ecc_customer_id as int) as string) 
-- MAGIC                 end as ecc_customer_id,
-- MAGIC                 ech_child_key
-- MAGIC FROM csmb.vw_ccm_pivot4_all
-- MAGIC WHERE source_type IS NOT NULL
-- MAGIC AND event_source = 'SNAPSHOT'
-- MAGIC AND date_key in ( SELECT max(date_key) 
-- MAGIC                   FROM csmb.vw_ccm_pivot4_all 
-- MAGIC                   WHERE source_type IS NOT NULL 
-- MAGIC                   AND event_source = 'SNAPSHOT' 
-- MAGIC                   AND date_key IS NOT NULL
-- MAGIC                 )