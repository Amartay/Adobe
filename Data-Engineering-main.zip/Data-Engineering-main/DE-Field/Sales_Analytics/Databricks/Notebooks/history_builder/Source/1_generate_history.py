# Databricks notebook source
# DBTITLE 1,Create Log Table To Record Events In
# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS b2b_tmp.history_generation_log;
# MAGIC CREATE TABLE b2b_tmp.history_generation_log (log_id STRING, as_of_date STRING,batch_name string, table_name STRING, state STRING, err_msg STRING);
# MAGIC

# COMMAND ----------

# DBTITLE 1,Python Imports
# MAGIC %python
# MAGIC from pyspark.sql import Row
# MAGIC from pyspark.sql.types import StructType, StructField, StringType
# MAGIC from datetime import date, timedelta, datetime
# MAGIC import uuid
# MAGIC import pandas

# COMMAND ----------

# DBTITLE 1,Function to Log to Log Table
# MAGIC %python
# MAGIC def LogHistoryGeneration(log_id, as_of_date,batch_name, table_name, state, err_msg):
# MAGIC
# MAGIC     output_list = []
# MAGIC     table_row = Row('log_id','as_of_date','batch_name','table_name','state','err_msg')
# MAGIC     results_row = table_row(log_id, as_of_date,batch_name, table_name, state, err_msg)
# MAGIC     output_list.append(results_row)
# MAGIC  
# MAGIC     # Create results DF Schema
# MAGIC     results_schema = StructType([StructField("log_id", StringType(), True), \
# MAGIC                                 StructField("as_of_date", StringType(), True), \
# MAGIC                                 StructField("batch_name", StringType(), True), \
# MAGIC                                 StructField("table_name", StringType(), True), \
# MAGIC                                 StructField("state", StringType(), True), \
# MAGIC                                 StructField("err_msg", StringType(), True), \
# MAGIC                             ])
# MAGIC
# MAGIC     # Make the results datafame
# MAGIC     results_df = spark.createDataFrame(output_list, results_schema)
# MAGIC     results_df.write.mode("append").saveAsTable("b2b_tmp.history_generation_log")

# COMMAND ----------

# DBTITLE 1,Function to loop through date range and call child runbook (Modified version of pipeline Core) - As_of_date will be injected
# MAGIC %python
# MAGIC
# MAGIC def RunCoreDateBatch(start_date, end_date, batch_name):
# MAGIC
# MAGIC     # Make a collection with every day from start to end (inclusive)
# MAGIC     start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
# MAGIC     end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
# MAGIC     days_of_interest = pandas.date_range(start_date,end_date,freq='d')
# MAGIC
# MAGIC     # Loop through the collection
# MAGIC     for d in days_of_interest:
# MAGIC         
# MAGIC         # create as of date parameter to pass to child notebook
# MAGIC         current_date = "'" + str(d)[0:10] + "'"
# MAGIC         print(current_date)
# MAGIC         param = {'as_of_date': current_date }
# MAGIC
# MAGIC         try:
# MAGIC             # Call the child notebooks (Toggle as you wish) 
# MAGIC             table_name = 'Pipeline Line Core'
# MAGIC             dbutils.notebook.run("2.excute_one_day_pipeline_core", 0, param)
# MAGIC             LogHistoryGeneration(str(uuid.uuid4()),str(d)[0:10],batch_name,table_name,'OK','')
# MAGIC
# MAGIC             table_name = 'Pipeline Line Items'
# MAGIC             dbutils.notebook.run("2.excute_one_day_pipeline_line_items", 0, param)
# MAGIC             LogHistoryGeneration(str(uuid.uuid4()),str(d)[0:10],batch_name,table_name,'OK','')
# MAGIC             
# MAGIC         except Exception as e:
# MAGIC             # Log exception - continue loop
# MAGIC             errMsg = str(e)
# MAGIC             LogHistoryGeneration(str(uuid.uuid4()),str(d)[0:10],batch_name,table_name,'ERROR',errMsg)
# MAGIC             continue
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC