-- Databricks notebook source
-- DBTITLE 1,Recieve As_of_Date Parameter from Parent Notebook
-- MAGIC %python
-- MAGIC dbutils.widgets.text("as_of_date", "default", "")
-- MAGIC date_to_run = dbutils.widgets.get("as_of_date")

-- COMMAND ----------

-- DBTITLE 1,Print Parameter Received for Visual Confirmation
-- MAGIC %python
-- MAGIC print(f"Current As of Date: {date_to_run}")

-- COMMAND ----------

-- DBTITLE 1,Documentation - What is modified 
-- MAGIC %md
-- MAGIC The script below is what will be used to populate one day of history of pipeline core. It will be called many times to build up the history. It should be THE CURRENT version of the pipeline core code with the only modifications being the ability to inject a parameter into the as_of_date value. 
-- MAGIC
-- MAGIC as we cannot trust there will be a L1 load for Every day we modify the as of date selection as follows;
-- MAGIC
-- MAGIC ```
-- MAGIC  WHERE
-- MAGIC       as_of_date IN (
-- MAGIC         SELECT
-- MAGIC           max(as_of_date)
-- MAGIC         FROM
-- MAGIC           b2b.uda_replicn_sf_corp_uda_vw_account
-- MAGIC ```
-- MAGIC
-- MAGIC TO 
-- MAGIC
-- MAGIC ```
-- MAGIC  WHERE
-- MAGIC       as_of_date IN (
-- MAGIC         SELECT
-- MAGIC           max(as_of_date)
-- MAGIC         FROM
-- MAGIC           b2b.uda_replicn_sf_corp_uda_vw_account
-- MAGIC         WHERE as_of_date <= ${as_of_date}
-- MAGIC
-- MAGIC ```
-- MAGIC
-- MAGIC this is the same behaviour as would actually happen on the genuine day of execution - it would be selecting the largest date at that point in time, which might not be the actual date of execution.
-- MAGIC
-- MAGIC The as_of_date also needs to be written into the history table - this is a direct parameter pass e.g;
-- MAGIC ```
-- MAGIC SELECT ${as_of_date} AS as_of_date
-- MAGIC ````

-- COMMAND ----------

-- DBTITLE 1,Modified Pipeline Core Code
INSERT INTO b2b.l2_sa_sfdc_pipeline_core_full_history
SELECT DISTINCT 
  opp01.OpportunityID,
  opp01.FullOptyId,
  opp01.DealRegistrationID,
  opp01.DealRegistration AS deal_registration_flag,
  coalesce(
    opp01.AdobeSalesOrderNumber,
    opp01.ECC_SalesOrderNumber
  ) AS sales_order_number,
  NULL AS sales_ops_reconciled -- placeholder (underlying uda opportunity needs to be updated to insert into this value)
,
  NULL AS dme_ineligible -- placeholder (underlying uda opportunity needs to be updated to insert into this value)
,
  ineligiblereason AS dme_ineligible_reason -- placeholder (Awaiting confirmation of what value to use)
,
  opp01.VIP_EA_CLP_AgreementNumber,
  concat(
    'https://adobe.my.salesforce.com/',
    opp01.FullOptyId
  ) AS sfdc_link,
  opp01.name AS opportunity_name,
  acc01.AccountName,
  opp01.AccountAddressCountry,
  opp01.PartnerCountry,
  opp01.Geo,
  opp01.RouteToMarket,
  opp01.LicensingProgram,
  opp01.lm_engagement,
  acc01.DMeAccountGroup,
  opp01.ProductInterest AS opportunity_prod_interest,
  opp01.CreatedDate AS current_created_date,
  DatesCreated01.fiscal_qtr_name AS current_created_qtr,
  DatesCreated01.fiscal_wk_in_yr AS current_created_week,
  DatesCreated01.fiscal_wk_in_qtr AS current_created_week_in_qtr,
  DatesCreated01.fiscal_yr_and_qtr_desc AS current_created_year_qtr,
  opp01.CloseDate AS Current_CloseDate,
  DatesClosed01.fiscal_qtr_name AS Current_Close_QTR,
  DatesClosed01.fiscal_wk_in_yr AS Current_Close_Week,
  DatesClosed01.fiscal_wk_in_qtr AS Current_Close_Week_in_QTR,
  DatesClosed01.fiscal_yr_and_qtr_desc AS Current_Close_Year_QTR,
  opp01.AcceptintoSalesPipeline AS current_acceptintosalespipeline,
  trim(opp01.Stage) AS current_stage,
  opp01.AdjustedCommitment AS current_adj_commitment,
  CASE
    WHEN opp01.Stage IN ('01 - Pre Call Plan', '02 - Prospect') THEN 'Non-Commit'
    WHEN opp01.Stage IN (
      '03 - Opportunity Qualification',
      '04 - Circle of Influence'
    ) THEN 'Upside'
    WHEN opp01.Stage = '05 - Solution Definition and Validation' THEN 'Strong Upside'
    WHEN opp01.Stage IN ('06 - Customer Commit', '07 - Execute to Close') THEN 'Forecast'
    WHEN opp01.Stage = 'Closed - Booked' THEN 'Won'
    ELSE opp01.AdjustedCommitment
  END AS business_commitment,
  round(cast(opp01.ClosedDateFX_Rate AS double), 2) AS ClosedDateFX_Rate,
  opp01.pipelineacceptedrejectedby AS pipeline_accepted_rejected_by,
  opp01.Rejectionnotes AS rejection_notes,
  opp01.Rejectionreason AS rejection_reason,
  BookingStatus AS booking_status ,
  manageradjustedcommitment AS manager_adjusted_commitment,
  licensingprogramtype AS licensing_program_type,

    -- New stuff requested from DS
  opp01.primarysalesplay AS sales_play,
  opp01.approvalstatus AS approval_status,
  opp01.leadid as lead_id,
  opp01.createdbyid AS created_by_id,
  opp01.industry,
  opp01.regionadjustedcommitment AS region_adjusted_commitment,
  opp01.geoadjustedcommitment AS geo_adjusted_commitment,
  acc01.marketarea AS market_area,
  camp.name AS campaign_name,

  -- 3924 - Additional fields added 
  opp01.OpportunityDealType AS opportunity_deal_type,
  opp01.OpportunityRecordType AS opportunity_record_type,
  cast(opp01.LastModifiedDate AS date) AS last_modified_date,
  cast(datediff(current_timestamp(), opp01.LastModifiedDate) AS int) AS days_since_last_modified,
  cast(opp01.previousclosedate as date) AS previous_close_date,
  opp01.iss_involvement AS iss_involvement,
  opp01.pipelinecreator AS pipeline_creator,
  opp01.accountid AS account_id,
  cast(opp01.closureDate AS date) AS closure_date,
  acc01.acct_market_area,
  acc01.validatedbillingcountry AS billing_country,
  createby.fullname1 AS CreatedByFullName,
  opp01.recordowner AS record_owner,
  recordowner.fullname1 AS record_owner_full_name,
  camp.campaignid AS campaign_id,
  camp.campaigngroup AS campaign_group,
  dimDate.fiscal_yr_and_qtr_desc AS snapshot_quarter,
  dimDate.fiscal_yr_and_wk_desc AS snapshot_week,
  opp01.additionaldescription AS additional_description,
  CASE WHEN UPPER(camp.name) LIKE '%CS%' 
            OR UPPER(camp.name) LIKE '%NUR%' 
            OR UPPER(camp.name) LIKE '%WBR%' 
            OR UPPER(camp.name) LIKE '%DEMAND%' 
            OR UPPER(camp.name) LIKE '%RFI%' 
            OR UPPER(camp.name) LIKE '%TRIAL%' THEN 'MQL'
        WHEN opp01.leadid IS NOT NULL THEN 'BDR'
        WHEN lower(opp01.approvalstatus) in ('approved','partner and adobe shared visibility','expired') and opp01.DealRegistration='Y' THEN 'Partner'
        WHEN createdbyid IN ( SELECT RIGHT(TerritoryTeamMemberID, 18) 
                                FROM b2b.uda_replicn_sf_corp_uda_vw_adobeterritorymember t
                                WHERE UPPER(t.AdobeRoleName) like '%2023%RENEWAL SPECIALIST%' AND UPPER(t.AdobeTerritoryName) LIKE '%C&B AMERICAS%'
                              ) THEN 'AM'
        WHEN  opp01.iss_involvement  = 'Sourced' THEN 'PSM' 
        ELSE 'AE'
        END AS amer_mm_funnel_type,
  CASE  WHEN (UPPER(opp01.LM_Engagement) = '' OR opp01.LM_Engagement IS NOT NULL) THEN 'License Management'
        WHEN UPPER(opp01.PipelineCreator) LIKE '%ADM ORGANIC%' THEN 'Marketing'
        WHEN UPPER(opp01.DealRegistration) = 'Y' THEN 'Partner'
        WHEN createby.FullName1 IN ('Akshaya Megawath Jaganya', 'Sumit Ludhwani', 'Umang Somani', 'Anurag Mukherjee', 'Love Mittal','Priyanka Chauhan', 'Ruby Thomas', 'Saif Bashir', 'Sarika Behal', 'Satbir Singh', 'Neha Arora', 'Neha Jha') THEN 'CSM'
        ELSE 'Self Generated'
        END AS emea_pss_funnel_type,
  CASE  WHEN opp01.PipelineCreator = 'ADM Organic' THEN 'BDR'
        WHEN opp01.PipelineCreator = 'Sales Organic' THEN 'Sales'
        WHEN opp01.PipelineCreator = 'Partner Organic' THEN 'Partner'
        WHEN (opp01.PipelineCreator = 'ADM Joint with Partner' AND UPPER(opp01.AdditionalDescription) LIKE '%BDR%') THEN 'BDR'
        WHEN opp01.PipelineCreator = 'ADM Joint with Partner' THEN 'Partner'
        END AS apac_funnel_type,
  CASE WHEN opp01.PipelineCreator = 'BDR Organic' OR  opp01.PipelineCreator = 'BDR Joint with Partner'  THEN 'BDR'
        WHEN opp01.PipelineCreator = 'Sales Organic' OR  opp01.PipelineCreator = 'Sales Joint with Partner' THEN 'Partner'
        WHEN opp01.PipelineCreator = 'Partner Organic' THEN 'Partner'
        END AS jpn_funnel_type,
  CAST(current_timestamp() AS string) AS executed_on,
  -- modified for parameter injection
  CAST(${as_of_date} AS DATE) AS as_of_date
FROM
  b2b.uda_replicn_sf_corp_uda_vw_opportunity opp01
  LEFT JOIN (
    SELECT
      AccountName,
      DMeAccountGroup,
      standardizedparentid,
      standardizedparent,
      standardizedsubid,
      standardizedsub,
      marketarea,
      CASE WHEN marketarea IN ('Canada', 'United States') THEN Geo
            WHEN marketarea = 'Russia & CIS' THEN 'Russia & Cis'
            WHEN marketarea = 'None' THEN NULL
            WHEN marketarea = 'Strat. Latin America' THEN 'Strategic Latin America'
            WHEN marketarea IN ('Hong Kong & Taiwan', 'ANZ') THEN 'Pacific'
            WHEN marketarea = 'SSA & Israel' THEN 'Sub Saharan Africa'
            ELSE marketarea
      END AS acct_market_area,
      validatedbillingcountry,  
      country,
      Id
    FROM
      b2b.uda_replicn_sf_corp_uda_vw_account
    WHERE
      as_of_date IN (
        SELECT
          max(as_of_date)
        FROM
          b2b.uda_replicn_sf_corp_uda_vw_account
        -- modified for parameter injection
        WHERE as_of_date <= ${as_of_date}
      )
  ) acc01 ON opp01.AccountID = acc01.Id -- Close Date
  LEFT JOIN ( SELECT  campaignid,
                      name,
                      campaigngroup
              FROM b2b.uda_replicn_sf_corp_uda_vw_campaign
              WHERE as_of_date = (SELECT MAX(as_of_date) 
                                  FROM b2b.uda_replicn_sf_corp_uda_vw_campaign
                                  -- modified for parameter injection
                                  WHERE as_of_date <= ${as_of_date})
  ) camp 
  ON opp01.campaignid2 = camp.campaignid
  LEFT JOIN (
    SELECT
      fiscal_qtr_name,
      fiscal_wk_in_yr,
      fiscal_wk_in_qtr,
      date_date,
      fiscal_yr,
      fiscal_yr_and_qtr_desc
    FROM
      b2b_tmp.hana_ccmusage_dim_date
  ) DatesClosed01 ON opp01.CloseDate = cast(DatesClosed01.Date_Date AS DATE) -- Created Date
  LEFT JOIN (
    SELECT
      fiscal_qtr_name,
      fiscal_wk_in_yr,
      fiscal_wk_in_qtr,
      date_date,
      fiscal_yr,
      fiscal_yr_and_qtr_desc
    from
      b2b_tmp.hana_ccmusage_dim_date
  ) DatesCreated01 ON opp01.CreatedDate = cast(DatesCreated01.Date_Date AS DATE)
  LEFT JOIN  (  SELECT userid, fullname1
                FROM b2b.uda_replicn_sf_corp_uda_vw_user 
                WHERE as_of_date = (SELECT MAX(as_of_date) 
                                    FROM b2b.uda_replicn_sf_corp_uda_vw_user
                                    -- modified for parameter injection
                                    WHERE as_of_date <= ${as_of_date})
            ) createby 
            ON opp01.createdbyid = createby.userid
              
              
  LEFT JOIN  (  SELECT userid, fullname1
                FROM b2b.uda_replicn_sf_corp_uda_vw_user 
                WHERE as_of_date = (SELECT MAX(as_of_date) 
                                    FROM b2b.uda_replicn_sf_corp_uda_vw_user
                                    -- modified for parameter injection
                                    WHERE as_of_date <= ${as_of_date}) 
  ) recordowner 
ON opp01.recordowner = recordowner.userid 
-- This table doesnt have any history 
LEFT JOIN b2b.uda_replicn_sf_corp_uda_vw_adobeterritorymember atm
ON opp01.accountid = atm.account
LEFT JOIN Ids_coredata.dim_date dimDate 
  ON opp01.as_of_date = dimDate.calendar_date 
WHERE
  opp01.as_of_date IN (
    SELECT
      max(as_of_date)
    FROM
      b2b.uda_replicn_sf_corp_uda_vw_opportunity
    -- modified for parameter injection
        WHERE as_of_date <= ${as_of_date}
  )
  AND opp01.CloseDate >= cast('2021-01-01' AS DATE)