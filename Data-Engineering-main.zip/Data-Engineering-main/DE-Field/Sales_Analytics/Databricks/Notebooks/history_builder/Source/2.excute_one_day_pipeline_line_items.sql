-- Databricks notebook source
-- DBTITLE 1,Recieve As_of_Date Parameter from Parent Notebook
-- MAGIC %python
-- MAGIC dbutils.widgets.text("as_of_date", "default", "")
-- MAGIC date_to_run = dbutils.widgets.get("as_of_date")

-- COMMAND ----------

-- DBTITLE 1,Print Parameter Received 
-- MAGIC %python
-- MAGIC print(f"Current As of Date: {date_to_run}")

-- COMMAND ----------

-- MAGIC %md
-- MAGIC The script below is what will be used to populate one day of history of pipeline line items. It will be called many times to build up the history. It should be THE CURRENT version of the pipeline line items code with the only modifications being the ability to inject a parameter into the as_of_date value. 
-- MAGIC
-- MAGIC as we cannot trust there will be a L1 load for Every day we modify the as of date selection as follows;
-- MAGIC
-- MAGIC ```
-- MAGIC  WHERE
-- MAGIC       as_of_date IN (
-- MAGIC         SELECT
-- MAGIC           max(as_of_date)
-- MAGIC         FROM
-- MAGIC           b2b.uda_replicn_sf_corp_uda_vw_account
-- MAGIC ```
-- MAGIC
-- MAGIC TO 
-- MAGIC
-- MAGIC ```
-- MAGIC  WHERE
-- MAGIC       as_of_date IN (
-- MAGIC         SELECT
-- MAGIC           max(as_of_date)
-- MAGIC         FROM
-- MAGIC           b2b.uda_replicn_sf_corp_uda_vw_account
-- MAGIC         WHERE as_of_date <= ${as_of_date}
-- MAGIC
-- MAGIC ```
-- MAGIC
-- MAGIC this is the same behaviour as would actually happen on the genuine day of execution - it would be selecting the largest date at that point in time, which might not be the actual date of execution.
-- MAGIC
-- MAGIC The as_of_date also needs to be written into the history table - this is a direct parameter pass e.g;
-- MAGIC ```
-- MAGIC SELECT ${as_of_date} AS as_of_date
-- MAGIC ````
-- MAGIC
-- MAGIC Please also note that product does not have this parameter injection as that is a table which in theory has no history - and the current version should always be applied - this is intentionally done.
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Modified Pipeline Line Items Code
INSERT INTO b2b.l2_sa_sfdc_pipeline_line_items_full_history
SELECT  core01.OpportunityID
        , ${as_of_date} AS as_of_date
        , core01.AdobeSKU
        , core01.OM_PMBU
        , core01.OpportunityProductName
        , core01.OutlookProductGroup
        , core01.ProductCode1
        , core01.ProductID
        , core01.prod_majorolpg1
        , core01.prod_business_unit
        , core01.ProductProfitCenterName
        , core01.business_prod_group
        , core01.business_prod_group_growth
        , core01.ori_TotalPrice
        , sum(core01.ori_ReportableNewASV_FX_Neutral) AS ReportableNewASV_FX_Neutral
        , sum(CASE  WHEN ORI_ReportableASV_GrowthFX_Neutral IS NULL THEN NULL
                    ELSE core01.ORI_ReportableASV_GrowthFX_Neutral
            END) AS ORI_ReportableASV_GrowthFX_Neutral
        , sum(core01.quantity) AS ori_quantity

        -- ASV;
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth IN ('SIGN','ACROBAT','STOCK','SUBSTANCE','FRAME','EXPRESS','CREATIVE') THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS Total_Growth_ASV

        -- Sign 
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SIGN' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS sign_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SIGN' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS sign_growth_asv_1
        
        -- Acrobat
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'ACROBAT' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS acrobat_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'ACROBAT' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS acrobat_growth_asv_1

        -- Stock
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'STOCK' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS stock_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'STOCK' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS stock_growth_asv_1
       
       -- Substance
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SUBSTANCE' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS substance_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SUBSTANCE' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS substance_growth_asv_1
       
    
        -- Frame
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FRAME' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS frame_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FRAME' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS frame_growth_asv_1

        -- Express
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'EXPRESS' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS express_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'EXPRESS' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS express_growth_asv_1

        -- Creative
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'CREATIVE' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS creative_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'CREATIVE' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS creative_growth_asv_1

        -- Quantity;
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth IN ('SIGN','ACROBAT','STOCK','SUBSTANCE','FRAME','EXPRESS','CREATIVE') THEN core01.quantity ELSE 0 END),0) AS total_quantity

        -- Sign 
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SIGN' THEN core01.quantity END),0) AS sign_quantity
        -- Acrobat
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'ACROBAT' THEN core01.quantity END),0) AS acrobat_quantity
        -- Stock
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'STOCK' THEN core01.quantity END),0) AS stock_quantity
       -- Substance
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SUBSTANCE' THEN core01.quantity END),0) AS substance_quantity
        -- Frame
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FRAME' THEN core01.quantity END),0) AS frame_quantity
        -- Express
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'EXPRESS' THEN core01.quantity END),0) AS express_quantity
        -- Creative
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'CREATIVE' THEN core01.quantity END),0) AS creative_quantity
        , CAST(current_timestamp()   as string) AS executed_on

FROM (  
        -- Business Logic to collapse down Product Group into key values which are easy to search for
        -- This logic is in this subquery so if it changes - it only need be updated here
        SELECT CASE WHEN core01_no_tag.OutlookProductGroup IN ('ACROBAT','DCE','DOCUMENT SERVICES') THEN 'ACROBAT'
                    WHEN (core01_no_tag.OutlookProductGroup IN ('CREATIVE','CCE STOCK') 
                                                            AND (core01_no_tag.ProductCode1 NOT IN ('FRAM','SBST','SRC','SBTX','3DAR') 
                                                            OR core01_no_tag.ProductCode1 IS NULL)) THEN 'CREATIVE'                           
                    WHEN (core01_no_tag.OutlookProductGroup = 'FRAME.IO' 
                                                        OR core01_no_tag.ProductCode1 = 'FRAM') THEN 'FRAME'
                    WHEN core01_no_tag.OutlookProductGroup IN ('SIGN','DCE TRANSACTION') THEN 'SIGN'
                    WHEN core01_no_tag.OutlookProductGroup = 'STOCK' THEN 'STOCK'
                    WHEN (core01_no_tag.OutlookProductGroup = 'CREATIVE'
                                                    AND core01_no_tag.ProductCode1 IN ('SBST','SRC','SBTX','3DAR'))
                                                    OR core01_no_tag.ProductProfitCenterName = '3DNI'
                                                    OR lower(core01_no_tag.OpportunityProductName) LIKE '%substance%'
                                                    OR lower(core01_no_tag.OpportunityProductName) LIKE '%3d%' THEN 'SUBSTANCE'
                    ELSE core01_no_tag.OutlookProductGroup 
                    END AS business_prod_group,
                
                -- Grouping for Growth Products
                top_product_group AS business_prod_group_growth,
                core01_no_tag.OpportunityID,
                core01_no_tag.as_of_date,
                core01_no_tag.AdobeSKU,
                core01_no_tag.OM_PMBU,
                core01_no_tag.OpportunityProductName,
                core01_no_tag.OutlookProductGroup,
                core01_no_tag.ProductCode1,
                core01_no_tag.ProductID,
                core01_no_tag.ProductProfitCenterName,
                core01_no_tag.ori_TotalPrice,
                core01_no_tag.ori_ReportableNewASV_FX_Neutral,
                core01_no_tag.ORI_ReportableASV_GrowthFX_Neutral,
                core01_no_tag.CLEAN_ReportableASV_GrowthFX_Neutral,
                core01_no_tag.quantity,
                core01_no_tag.prod_majorolpg1,
                core01_no_tag.prod_business_unit
        FROM
        ( 
        SELECT  OpportunityID
                    , cast(li.as_of_date AS DATE) AS as_of_date
                    , case 
                        WHEN AdobeSKU = '\N' THEN NULL 
                        ELSE AdobeSKU 
                        END AS AdobeSKU
                    , case
                        WHEN OM_PMBU = '\N' THEN NULL 
                        ELSE OM_PMBU
                        END AS OM_PMBU
                    , OpportunityProductName
                    , CASE WHEN OutlookProductGroup = '\N' THEN NULL 
                        ELSE OutlookProductGroup
                        END AS OutlookProductGroup
                    , CASE WHEN ProductCode1 = '\N' THEN NULL
                        ELSE ProductCode1
                        END AS ProductCode1
                    , li.ProductID
                    , prod.prod_majorolpg1
                    , prod.prod_business_unit
                    , CASE WHEN ProductProfitCenterName = '\N' THEN NULL 
                        ELSE ProductProfitCenterName 
                        END AS ProductProfitCenterName
                    , prod.prod_majorolpg2
                    , prod.top_product_group
                    , sum(round(cast(TotalPrice AS double), 2)) AS ori_TotalPrice
                    , sum(CASE WHEN ReportableNewASV_FX_Neutral IS NULL THEN 0
                        ELSE round(cast(ReportableNewASV_FX_Neutral AS double), 0)
                        END) AS ori_ReportableNewASV_FX_Neutral
                    , sum(CASE WHEN ReportableASV_GrowthFX_Neutral IS NULL THEN NULL
                        ELSE round(cast(ReportableASV_GrowthFX_Neutral AS double), 0)
                        END) AS ORI_ReportableASV_GrowthFX_Neutral
                    , sum(CASE WHEN ReportableASV_GrowthFX_Neutral IS NULL THEN 0
                        WHEN cast(ReportableASV_GrowthFX_Neutral AS double) < 0 THEN 0
                        ELSE round(cast(ReportableASV_GrowthFX_Neutral AS double), 0)
                        END) AS CLEAN_ReportableASV_GrowthFX_Neutral
                    , sum(cast(quantity AS double)) AS quantity

                    FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                    LEFT JOIN  ( SELECT     MajorOLPG1 AS prod_majorolpg1
                                            ,majorolpg2 AS prod_majorolpg2
                                            ,OutlookProductGroup AS prod_outlook_prod_group
                                            ,BusinessUnit AS prod_business_unit
                                            ,ProductID 
                                            ,CASE WHEN OutlookProductGroup = 'SUBSTANCE' THEN 'SUBSTANCE'
                                                    WHEN OutlookProductGroup = 'FRAME.IO' THEN 'FRAME'
                                                    WHEN OutlookProductGroup = 'EXPRESS' THEN 'EXPRESS'
                                                    ELSE MajorOLPG1
                                                    END AS top_product_group
                                    FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                    WHERE as_of_date IN (   -- this is intentional - there shouldnt be history in this table
                                                            -- and the history that is there (not sure why) doesnt go back to the start of Q1
                                                            SELECT max(as_of_date) 
                                                            FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                                        )
                    ) prod 
                    ON li.ProductID = prod.ProductID
                    
                    INNER JOIN 
                    -- modified to select from core history for the current param date
                    ( SELECT * 
                      FROM b2b.l2_sa_sfdc_pipeline_core_full_history 
                      WHERE as_of_date = ${as_of_date} ) core
                    
                    ON li.OpportunityID = core.full_opty_id

                    WHERE li.as_of_date IN ( SELECT max(as_of_date) 
                                          FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem
                                          -- modified for param injection
                                          WHERE as_of_date <= ${as_of_date}
                                        )
                    AND upper(prod.prod_business_unit) = 'DIGITAL MEDIA'
                    AND upper(prod.prod_majorolpg2)='DIGITAL MEDIA'
                    GROUP BY AdobeSKU
                            , li.OM_PMBU
                            , li.OpportunityProductName
                            , li.OutlookProductGroup
                            , li.ProductCode1
                            , li.ProductID
                            , prod.prod_majorolpg1
                            , prod_majorolpg2
                            , top_product_group
                            , prod.prod_business_unit
                            , li.ProductProfitCenterName
                            , li.OpportunityID
                            , li.as_of_date
                ) core01_no_tag
) core01

GROUP BY core01.OpportunityID
        , core01.business_prod_group
        , core01.business_prod_group_growth
        , core01.as_of_date
        , core01.AdobeSKU
        , core01.OM_PMBU
        , core01.OpportunityProductName
        , core01.OutlookProductGroup
        , core01.ProductCode1
        , core01.ProductID
        , core01.ProductProfitCenterName
        , core01.ori_TotalPrice
        , prod_majorolpg1
        , prod_business_unit