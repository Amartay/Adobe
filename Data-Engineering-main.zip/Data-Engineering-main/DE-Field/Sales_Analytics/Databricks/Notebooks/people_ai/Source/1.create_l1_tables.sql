-- Databricks notebook source
-- DBTITLE 1,Create Participants Table
-- MAGIC %sql
-- MAGIC DROP TABLE IF EXISTS b2b.ocf_people_ai_activity_participants; 
-- MAGIC CREATE TABLE b2b.ocf_people_ai_activity_participants AS 
-- MAGIC SELECT DISTINCT   source_id as event_id,
-- MAGIC                   cast(event_date AS DATE) as event_date,
-- MAGIC                   part.peopleai_id AS participants_people_ai_id,
-- MAGIC                   part.crm_id AS pariticant_salesforce_user_id,
-- MAGIC                   part.name AS participant_name,
-- MAGIC                   part.title AS participant_job_title,
-- MAGIC                   part.email AS participant_email,
-- MAGIC                   part.role AS event_role,
-- MAGIC                   part.type AS participant_type,
-- MAGIC                   cast(part.time_spent AS double) AS time_spent_on_event,
-- MAGIC                   cast(current_timestamp() AS string) AS executed_on
-- MAGIC FROM ocf.peopleai_activity

-- COMMAND ----------

-- DBTITLE 1,Create the Activity Table
-- MAGIC %sql
-- MAGIC DROP TABLE IF EXISTS b2b.ocf_people_ai_activity;
-- MAGIC CREATE TABLE b2b.ocf_people_ai_activity AS 
-- MAGIC SELECT  event_id,
-- MAGIC         activity_id,
-- MAGIC         event_date,
-- MAGIC         activity_type,
-- MAGIC         activity_subject,
-- MAGIC         direction, 
-- MAGIC         location,
-- MAGIC         reply_received,
-- MAGIC         total_participants,
-- MAGIC         internal_participants,
-- MAGIC         external_participants,
-- MAGIC         contacts_participants,
-- MAGIC         participants_on_to_line,
-- MAGIC         participants_on_cc_line,
-- MAGIC         accepted_participants,
-- MAGIC         declined_participants,
-- MAGIC         tentative_participants, 
-- MAGIC         salesforce_parent_account_id,
-- MAGIC         parent_account_name,
-- MAGIC         salesforce_account_id,
-- MAGIC         account_name,
-- MAGIC         engagement_level,
-- MAGIC         lead,
-- MAGIC         salesforce_opportunity_id,
-- MAGIC         followed_meeting_source_id,
-- MAGIC         in_reply_to_source_id, 
-- MAGIC         follow_up_email_source_id
-- MAGIC         event_time_rank
-- MAGIC FROM  ( 
-- MAGIC         -- Looking at the Data it looks like the same activity can repeat multiple times
-- MAGIC         -- So Activity is like "planing Meeting" and event would be - planning meeting on 1st of June, Planning Meeting on 2nd of June etc.. 
-- MAGIC         SELECT  DISTINCT        a.source_id AS event_id,
-- MAGIC                                 a.uid AS activity_id,
-- MAGIC                                 cast(event_date AS DATE) as event_date,
-- MAGIC                                 type AS activity_type,
-- MAGIC                                 subject AS activity_subject,
-- MAGIC                                 direction, 
-- MAGIC                                 location,
-- MAGIC                                 reply_received,
-- MAGIC                                 stats.total_participants,
-- MAGIC                                 stats.internal_participants,
-- MAGIC                                 stats.external_participants,
-- MAGIC                                 stats.contacts_participants,
-- MAGIC                                 stats.participants_on_to_line,
-- MAGIC                                 stats.participants_on_cc_line,
-- MAGIC                                 stats.accepted_participants,
-- MAGIC                                 stats.declined_participants,
-- MAGIC                                 stats.tentative_participants, 
-- MAGIC                                 crm_status.account.parent_account_crm_id AS salesforce_parent_account_id,
-- MAGIC                                 crm_status.account.parent_account_name,
-- MAGIC                                 crm_status.account.crm_id AS salesforce_account_id,
-- MAGIC                                 crm_status.account.name AS account_name,
-- MAGIC                                 crm_status.account.engagement_level,
-- MAGIC                                 crm_status.lead AS lead,
-- MAGIC                                 crm_status.opportunity.crm_id AS salesforce_opportunity_id,
-- MAGIC                                 followed_meeting_source_id, 
-- MAGIC                                 in_reply_to_source_id,  
-- MAGIC                                 follow_up_email_source_id, 
-- MAGIC                                 ROW_NUMBER() OVER (PARTITION BY a.source_id, a.event_date ORDER BY event_date DESC ) as event_time_rank
-- MAGIC         FROM ocf.peopleai_activity a
-- MAGIC ) 
-- MAGIC WHERE event_time_rank = 1
-- MAGIC

-- COMMAND ----------

DROP TABLE IF EXISTS b2b.ocf_people_ai_contacts;
CREATE TABLE b2b.ocf_people_ai_contacts AS 
SELECT  email,
        response_activity_id,
        total_inbound_emails,
        total_inbound_emails_30d,
        total_outbound_emails,
        total_outbound_emails_30d,
        total_meetings,
        total_meetings_30d,
        total_time_spent,
        total_time_spent_30d,
        phone,
        first_name,
        last_name,
        job_title,
        department,
        seniority,
        country,
        state,
        account_crm_id,
        account_name,
        account_type,
        account_domain,
        source_peopleai_id,
        source_email,
        first_inbound_time,
        last_inbound_time,
        first_outbound_time,
        last_outbound_time,
        last_engaged_time,
        first_upcoming_meeting_time,
        first_engaged_time,
        external_id,
        lead_external_id,
        is_created_by_people_ai,
        from_cc,
        engagement_level,
        inbound_outbound_ratio,
        received_reply,
        upcoming_meeting,
        total_emails,
        total_emails_30d,
        crm_id,
        sourced_by_people_ai,
        event,
        cast(event_date as date) as event_date
FROM  ocf.peopleai_contacts 
