-- Databricks notebook source
-- DBTITLE 1,Receive Current Qtr Parameter From Parent Job
-- MAGIC %python
-- MAGIC dbutils.widgets.text("qtr_to_run", "", "")
-- MAGIC qtr_to_run = dbutils.widgets.get("qtr_to_run")
-- MAGIC
-- MAGIC print(f"Selected Quarter: {qtr_to_run}")

-- COMMAND ----------

REFRESH TABLE b2b.sap_hana_sys_bic_channel_an_channelink_consolidated;

-- COMMAND ----------

-- DBTITLE 1,Create View TMP1 From DBX Channelink Table rather than from static table
CREATE OR REPLACE VIEW  VW_Temp1 AS
SELECT  additional_text,
        CAST(atd_cxl_date_fiscal_yr_and_per_desc AS STRING) AS atd_cxl_date_fiscal_yr_and_per_desc,
        atd_cxl_date_fiscal_yr_and_qtr_desc,
        bl_end_user_name1,
        bl_licensing_contract,
        c_fin_doc_curr,
        c_market_segment,
        enterprise_bu_desc AS `ENTERPRISE_BU.description`,
        fiscal_wk_in_qtr,
        fiscal_yr_and_qtr_desc,
        geo_desc AS `GEO.description`,
        internal_segment AS `Internal Segment`,
        market_area_desc AS `MARKET_AREA.description`,
        mjr_lic_prog_desc AS `MJR_LIC_PROG.description`,
        order_date_desc AS `ORDER_DATE.description`,
        product_config_desc AS `PRODUCT_CONFIG.description`,
        region_desc AS `REGION.description`,
        reseller_geo_partner_geo_desc AS `RESELLER_GEO_PARTNER_GEO.description`,
        reseller_geo_partner_market_area_desc AS `RESELLER_GEO_PARTNER_MARKET_AREA.description`,
        reseller_geo_partner_region_desc AS `RESELLER_GEO_PARTNER_REGION.description`,
        reseller_geo_partner_sales_district_desc AS `RESELLER_GEO_PARTNER_SALES_DISTRICT.description`,
        sales_district_desc AS `SALES_DISTRICT.description`,
        sales_ops_distributor_channel_program_level,
        sales_ops_distributor_geo_partner_geo_desc AS `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO.description`,
        sales_ops_distributor_geo_partner_market_area_desc AS `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA.description`,
        sales_ops_distributor_geo_partner_region_desc AS `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION.description`,
        sales_ops_distributor_geo_partner_sales_district_desc AS `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT.description`,
        sales_ops_distributor_partnerrollup,
        sales_ops_reseller_channel_program_level,
        sales_ops_reseller_partnerrollup,
        CAST(fy_cxl_date as STRING) AS at_cxl_date_date_key, -- TODO: Replace this with the actual at_cxl_date_date_key once imported from arthish
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_ELIGIBLE_AMOUNT END) AS DECIMAL(20,2)) AS `Eligible Amt`,
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_ELIGIBLE_UNIT END) AS BIGINT)  AS `Eligible Qty`,
        CAST(sum(li_arr) AS DECIMAL(20,2)) AS li_arr,
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_TOTAL_SALES_GEO_AMT END) AS DECIMAL(20,2)) AS `Total Sales Geo Amt`,
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_TOTAL_SALES_QTY END) AS BIGINT) AS `Total Sales Qty`,
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_TOTAL_SALES_USD END) AS DECIMAL(20,2)) AS `Total Sales USD`,
        (CASE WHEN SALES_OPS_RESELLER_PARTNERROLLUP IN (SELECT impa.`Partner Name`
                                                        FROM b2b_tmp.field_radar_02_01_input_manual_platinum_adjustment impa) then 'PLATINUM'
       ELSE null END) AS `Partner Level`
FROM b2b.sap_hana_sys_bic_channel_an_channelink_consolidated a11

-- This is lifted from an alteryx workflow for RADAR - I have no idea why these filters are applied - this is simply as it is in that query  

where C_SALES_OPS_DISTRIBUTER_NAME not in ('ADOBE SYSTEMS VIP FOC')
and mjr_lic_prog_desc in ('Value Incentive Plan','VIP Market Place')
and (((a11.C_SOURCE_DATASET in ('Adobe.com', 'Lic.Adobe.com')
and a11.BL_SELL_IN_CHANNEL in ('ELC', 'PFE')
and a11.REVENUE_TYPE in ('APPS', 'ESS')
and (a11.ENTERPRISE_BU not in ('EB20')
or a11.PMBU in ('13600'))
and a11.BL_SKU_CATEGORY in ('C', 'S')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION not in ('NAM'))
or (a11.ST_REPORTING_FLG in ('Y')
and a11.C_SOURCE_DATASET in ('SELLTHRU')
and a11.SOLD_BY_CUSTOMER_CLASS in ('D')
and a11.MAJOR_PRODUCT_CONFIG in ('EDU', 'FUL', 'UPG', 'SUB')
and (a11.ENTERPRISE_BU not in ('EB20')
or a11.PMBU in ('13600'))
and a11.REGION in ('NAM')
and a11.SOLD_BY_CUSTOMER_ID in ('3188580', '1431300', '3188574', '298', '312', '1294820', '356', '3195048', '376', '377', '290', '3313503', '3301257')
and a11.C_DEMAND_VIEW in ('R'))
or (a11.ST_REPORTING_FLG in ('Y')
and a11.C_SOURCE_DATASET in ('SELLTHRU')
and a11.MAJOR_PRODUCT_CONFIG in ('EDU', 'FUL', 'UPG', 'SUB')
and (a11.ENTERPRISE_BU not in ('EB20')
or a11.PMBU in ('13600'))
and a11.SOLD_BY_CUSTOMER_ID not in ('3188574', '3188580', '3301257', '3313503')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION in ('NAM')
and a11.C_CONSIGNMENT_FLAG in ('CONS'))
or (a11.ST_REPORTING_FLG in ('Y')
and a11.C_SOURCE_DATASET in ('SELLTHRU')
and a11.SOLD_BY_CUSTOMER_CLASS in ('D')
and a11.MAJOR_PRODUCT_CONFIG in ('EDU', 'FUL', 'UPG', 'SUB')
and (a11.ENTERPRISE_BU not in ('EB20')
or a11.PMBU in ('13600'))
and a11.REGION not in ('NAM')
and a11.C_DEMAND_VIEW in ('R'))
or (a11.C_SOURCE_DATASET in ('Adobe.com', 'Lic.Adobe.com')
and a11.BL_SELL_IN_CHANNEL in ('ELC', 'PFE')
and a11.REVENUE_TYPE in ('APPS', 'ESS')
and (a11.ENTERPRISE_BU not in ('EB20')
or a11.PMBU in ('13600'))
and a11.BL_SKU_CATEGORY in ('C', 'S')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION in ('NAM'))
or (a11.MAJOR_PRODUCT_CONFIG in ('LIC', 'LMS', 'SAS', 'UPP', 'SUB')
and (a11.ENTERPRISE_BU not in ('EB20')
or a11.PMBU in ('13600'))
and a11.BL_CONTRACT_TYPE not in ('33')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION in ('NAM')
and a11.C_SOURCE_DATASET in ('JHOLD'))
or (a11.MAJOR_PRODUCT_CONFIG in ('LIC', 'LMS', 'SAS', 'UPP', 'SUB')
and (a11.ENTERPRISE_BU not in ('EB20')
or a11.PMBU in ('13600'))
and a11.BL_CONTRACT_TYPE not in ('33')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION not in ('NAM')
and a11.C_SOURCE_DATASET in ('JHOLD'))
or ((a11.PMBU in ('13600')
or a11.ENTERPRISE_BU not in ('EB20'))
and a11.C_SOURCE_DATASET in ('Licensing', 'Lic.Adobe.com')
and a11.BL_CONTRACT_TYPE not in ('05', '07', '58', '33', '59', '60')
and a11.MAJOR_PRODUCT_CONFIG in ('UPP', 'LIC', 'SAS', 'LMS', 'UPG', 'SUB')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION in ('NAM'))
or ((a11.ENTERPRISE_BU not in ('EB20')
or a11.PMBU in ('13600'))
and a11.BL_CONTRACT_TYPE not in ('59')
and a11.C_SOURCE_DATASET in ('Licensing', 'Lic.Adobe.com')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION not in ('NAM'))
or (a11.C_SOURCE_DATASET in ('Licensing >50K')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION in ('NAM'))
or (a11.C_SOURCE_DATASET in ('Licensing >50K')
and a11.C_DEMAND_VIEW in ('R')
and a11.REGION not in ('NAM')))
and a11.C_SOURCE_DATASET not in ('Adobe.com')
and a11.C_VIP_FOC_FLAG in ('NO'))
GROUP BY 
additional_text,
CAST(atd_cxl_date_fiscal_yr_and_per_desc AS STRING),
atd_cxl_date_fiscal_yr_and_qtr_desc,
bl_end_user_name1,
bl_licensing_contract,
c_fin_doc_curr,
c_market_segment,
enterprise_bu_desc,
fiscal_wk_in_qtr,
fiscal_yr_and_qtr_desc,
geo_desc,
internal_segment,
market_area_desc,
mjr_lic_prog_desc,
order_date_desc,
product_config_desc,
region_desc,
reseller_geo_partner_geo_desc,
reseller_geo_partner_market_area_desc,
reseller_geo_partner_region_desc,
reseller_geo_partner_sales_district_desc,
sales_district_desc,
sales_ops_distributor_channel_program_level,
sales_ops_distributor_geo_partner_geo_desc,
sales_ops_distributor_geo_partner_market_area_desc,
sales_ops_distributor_geo_partner_region_desc,
sales_ops_distributor_geo_partner_sales_district_desc,
sales_ops_distributor_partnerrollup,
sales_ops_reseller_channel_program_level,
sales_ops_reseller_partnerrollup,
CAST(fy_cxl_date AS STRING),
CASE WHEN SALES_OPS_RESELLER_PARTNERROLLUP IN (SELECT impa.`Partner Name`
                                                        FROM b2b_tmp.field_radar_02_01_input_manual_platinum_adjustment impa) then 'PLATINUM' ELSE null END
HAVING  fiscal_yr_and_qtr_desc = ${qtr_to_run}; 


-- COMMAND ----------

/*[Inputs]-DATETIME TOOL*/
 
CREATE OR REPLACE VIEW  VW_Temp2 as
select ADDITIONAL_TEXT,ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  BL_END_USER_NAME1,
  BL_LICENSING_CONTRACT,
  C_FIN_DOC_CURR,
  C_MARKET_SEGMENT,
  `ENTERPRISE_BU.description` AS ENTERPRISE_BU_description,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  `GEO.description` AS GEO_description,
  `MARKET_AREA.description` AS MARKET_AREA_description,
  `ORDER_DATE.description` AS ORDER_DATE_description,
  `PRODUCT_CONFIG.description` AS PRODUCT_CONFIG_description,
  `REGION.description` AS REGION_description,
  `RESELLER_GEO_PARTNER_GEO.description` AS RESELLER_GEO_PARTNER_GEO_description,
  `RESELLER_GEO_PARTNER_MARKET_AREA.description` AS RESELLER_GEO_PARTNER_MARKET_AREA_description,
  `RESELLER_GEO_PARTNER_REGION.description` AS RESELLER_GEO_PARTNER_REGION_description,
  `RESELLER_GEO_PARTNER_SALES_DISTRICT.description` AS RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  `SALES_DISTRICT.description` AS SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO.description` AS SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA.description` AS 
                                   SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION.description` AS 
                                   SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT.description` AS                            SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  (case when `Partner Level` is null then SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL
   else `Partner Level` end) as SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
  `Internal Segment`,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  `MJR_LIC_PROG.description`,
  REPLACE(AT_CXL_DATE_DATE_KEY,',','') AS `AT_CXL_DATE_DATE_KEY (ATTR)`,
  SUM(CAST(`Eligible Amt` AS DOUBLE)) AS `Eligible Amt (SUM)`,
  SUM(CAST(`Eligible Qty` AS DOUBLE)) AS `Eligible Qty (SUM)`,
  SUM(CAST(LI_ARR AS DOUBLE)) AS `LI_ARR (SUM)`,
  SUM(CAST(`Total Sales Geo Amt` AS DOUBLE)) AS `Total Sales Geo Amt (SUM)`,
  SUM(CAST(`Total Sales Qty` AS DOUBLE)) AS `Total Sales Qty (SUM)`,
  SUM(CAST(`Total Sales USD` AS DOUBLE)) AS `Total Sales USD (SUM)`,
  CAST(`ORDER_DATE.description` AS DATE) AS DateTime_Out
  from VW_Temp1
  where BL_LICENSING_CONTRACT NOT IN ('BL_LICENSING_CONTRACT')
  group by ADDITIONAL_TEXT,
  ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  BL_END_USER_NAME1,
  BL_LICENSING_CONTRACT,
  C_FIN_DOC_CURR,
  C_MARKET_SEGMENT,
  `ENTERPRISE_BU.description`,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  `GEO.description`,
  `MARKET_AREA.description`,
  `ORDER_DATE.description`,
  `PRODUCT_CONFIG.description`,
  `REGION.description`,
  `RESELLER_GEO_PARTNER_GEO.description`,
  `RESELLER_GEO_PARTNER_MARKET_AREA.description`,
  `RESELLER_GEO_PARTNER_REGION.description`,
  `RESELLER_GEO_PARTNER_SALES_DISTRICT.description`,
  `SALES_DISTRICT.description`,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO.description`,
  `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA.description`,
  `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION.description`,
  `SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT.description`,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  (case when `Partner Level` is null then SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL
   else `Partner Level` end),
  `Internal Segment`,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  `MJR_LIC_PROG.description`,
  REPLACE(AT_CXL_DATE_DATE_KEY,',',''),
  CAST(`ORDER_DATE.description` AS DATE);

-- COMMAND ----------

/*[Extracting K12 deals]-FORMULA TOOL*/
CREATE OR REPLACE VIEW  rbob_workflow_1_v7_MODULE6 AS 
SELECT ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  BL_END_USER_NAME1,
  BL_LICENSING_CONTRACT,
  C_FIN_DOC_CURR,
  C_MARKET_SEGMENT,
  ENTERPRISE_BU_description,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  GEO_description,
  MARKET_AREA_description,
  --ORDER_DATE_description,
  DateTime_Out AS ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  `Internal Segment`,
  `AT_CXL_DATE_DATE_KEY (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  ADDITIONAL_TEXT,
  `MJR_LIC_PROG.description`,
  'K12' AS `Derived Additional Text`
  from VW_Temp2 where ADDITIONAL_TEXT like '%K12%';

-- COMMAND ----------

/*[Extracting K12 deals]-SUMMARIZE TOOL*/
--Module 6 output
 
CREATE OR REPLACE VIEW  MODULE6_OUTPUT_k12_rbob_wf_1_v7 as
SELECT BL_LICENSING_CONTRACT,`Derived Additional Text`
FROM rbob_workflow_1_v7_MODULE6
GROUP BY BL_LICENSING_CONTRACT,`Derived Additional Text`;

-- COMMAND ----------

/*[No Container]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  VW_Temp3 as
select Unique_ID,
  `VIP No`,
  Upper(`Partner Name_Change`) as `Partner Name`,
  `Contract End Date`,
  `Contract CXL Date`,
  `Contract CXL Fiscal Period`,
  Contrac_CXL_Quarter as `Contract CXL Quarter`,
  `Market Segment`,
  `Target Geo`,
  `Reseller Geo Partner`,
  `Partner Type_Change` as `Partner Type`,
  Currency,
  Product,
  Units_Opportunity as `Units Opportunity`,
  `ARR Opportunity`,
  Units_Opp_VIp_Product as `Units Opportunity VIP Product`,
  `Units Opportunity VIP-Partner Wise` as `Units Opportunity Partner-VIP Wise`,
  Concat(NVL(`VIP No`,''),NVL(Contrac_CXL_Quarter,'')) as VIPQtr,
  Concat(NVL(`VIP No`,''),Upper(NVL(`Partner Name_Change`,''))) as VIPPartner
from b2b_tmp.field_radar_02_01_input_contract_level_targets_q2
where `VIP No` is not null
and `VIP No` <> '';

-- COMMAND ----------

/*[tempdataTargetVIPQtrQty]-SUMMARIZE TOOL*/
 
CREATE OR REPLACE VIEW  VW_Container447 as
select `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr,
  sum(`Units Opportunity`) as `Sum_Units opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR opportunity`
from VW_Temp3
group by `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr;

-- COMMAND ----------

/*[tempdata2TargetVIPPartner]-SUMMARIZE TOOL*/
 
CREATE OR REPLACE VIEW  VW_Temp4 as
select `VIP No`,
  `Partner Name` as `Partner name`,
  VIPPartner,
  sum(`ARR opportunity`) as `Sum_ARR opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  first(`Target Geo`) as `First_Target Geo`
from VW_Temp3
group by `VIP No`,
  `Partner Name`,
  VIPPartner;

-- COMMAND ----------

CREATE OR REPLACE VIEW  VW_Container448 as
select `VIP No`,
  `Partner name`,
  VIPPartner,
  `Sum_ARR opportunity`,
  `Sum_Units Opportunity Partner-VIP Wise`,
  `First_Target Geo`,
  Concat(NVL(`First_Target Geo`,''), NVL(`VIP No`,''),
   NVL(`Partner name`,'')) as GEOVIPPartner
from VW_Temp4;

-- COMMAND ----------

/*[Temp3]-SUMMARIZE TOOL*/
 
CREATE OR REPLACE VIEW  VW_Container449 as
select `VIP No`,
  `Partner Name` as `Partner name`,
  sum(`Units opportunity`) as `Sum_Units opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  first(`Target Geo`) as `First_Target Geo`
from VW_Temp3
group by `VIP No`,
  `Partner Name`;

-- COMMAND ----------

/*[Temp2A TargetVIPProd]-SUMMARIZE TOOL*/
 
CREATE OR REPLACE VIEW  VW_Temp5 as
select `VIP No`,
  `Product`,
  `Reseller Geo Partner`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR Opportunity`,
  sum(`Units Opportunity VIP Product`) as `Sum_Units Opportunity VIP Product`
from VW_Temp3
group by `VIP No`,
  `Product`,
  `Reseller Geo Partner`;

-- COMMAND ----------

/*[Temp2A TargetVIPProd]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  VW_Container450 as
select `VIP No`,
  `Product`,
  `Reseller Geo Partner`,
  `Sum_Units Opportunity Partner-VIP Wise`,
  `Sum_ARR Opportunity`,
  `Sum_Units Opportunity VIP Product`,
  Concat(NVL(`Reseller Geo Partner`,''), NVL(`VIP No`,''), 
  NVL(`Product`,'')) as VIPProduct
from VW_Temp5;

-- COMMAND ----------

/*[Temp5 TargetVIPPartnerProd]-SUMMARIZE TOOL*/
 
CREATE OR REPLACE VIEW  VW_Temp6 as
select `VIP No`,
  `Partner Name`,
  Product,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR Opportunity`
from VW_Temp3
group by `VIP No`,
  `Partner Name`,
  Product;

-- COMMAND ----------

/*[Temp5 TargetVIPPartnerProd]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  VW_Container451 as
select `VIP No`,
  `Partner Name`,
  Product,
  `Sum_Units Opportunity Partner-VIP Wise`,
  `Sum_ARR Opportunity`,
  Concat(NVL(`VIP No`,''), NVL(`Partner Name`,''), NVL(`Product`,'')) as VIPPartnerProduct
from VW_Temp6;

-- COMMAND ----------

/*[No Container]-UNIQUE TOOL*/
 
CREATE OR REPLACE VIEW  VW_Temp8 as
select distinct `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr,
  sum(`Units Opportunity`) as `Sum_Units opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR opportunity`
from VW_Temp3
group by `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr
order by `VIP No` asc,
  `Contract CXL Quarter` desc;

-- COMMAND ----------

/*[Update 1A]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  MODULE5_FORMULA_RBOB_WF_0201 AS (select ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  BL_END_USER_NAME1,
  BL_LICENSING_CONTRACT,
  C_FIN_DOC_CURR,
  C_MARKET_SEGMENT,
  ENTERPRISE_BU_description,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  GEO_description,
  MARKET_AREA_description,
  --ORDER_DATE_description,
  DateTime_Out AS ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  `Internal Segment`,
  `AT_CXL_DATE_DATE_KEY (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  ADDITIONAL_TEXT,
  `MJR_LIC_PROG.description`,
  Case 
  when SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL != 'PLATINUM' OR SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL IS NULL THEN SALES_OPS_DISTRIBUTOR_PARTNERROLLUP
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN SALES_OPS_RESELLER_PARTNERROLLUP
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_PARTNERROLLUP
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_PARTNERROLLUP
ELSE SALES_OPS_RESELLER_PARTNERROLLUP 
  END  AS FinalPartnerName ,
   Case 
  when SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL != 'PLATINUM' OR SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL IS NULL THEN SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL
ELSE SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL 
  END  AS FinalPartnerLevel,
  Case 
  when SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL != 'PLATINUM' OR SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL IS NULL THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN RESELLER_GEO_PARTNER_MARKET_AREA_description
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description
ELSE RESELLER_GEO_PARTNER_MARKET_AREA_description 
  END  AS PartnerMarketArea,
  Case 
  when SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL != 'PLATINUM' OR SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL IS NULL THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN RESELLER_GEO_PARTNER_REGION_description
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description
ELSE RESELLER_GEO_PARTNER_REGION_description 
  END  AS PartnerRegion,
  Case 
  when SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL != 'PLATINUM' OR SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL IS NULL THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN RESELLER_GEO_PARTNER_SALES_DISTRICT_description
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description
ELSE RESELLER_GEO_PARTNER_SALES_DISTRICT_description 
  END  AS PartnerSalesDistrict,
  Case 
  when SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL != 'PLATINUM' OR SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL IS NULL THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN RESELLER_GEO_PARTNER_GEO_description
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description
ELSE RESELLER_GEO_PARTNER_GEO_description 
  END  AS PartnerGeo,
Case 
WHEN `Internal Segment`= 'Adobe Sign'  then `Internal Segment`
else ENTERPRISE_BU_description
end as Product
from VW_Temp2);

-- COMMAND ----------

/*[Update 1A]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  MODULE5_FORMULA_RBOB_WF_0201_F as (select ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  BL_END_USER_NAME1,
  BL_LICENSING_CONTRACT,
  C_FIN_DOC_CURR,
  C_MARKET_SEGMENT,
  ENTERPRISE_BU_description,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  GEO_description,
  MARKET_AREA_description,
  --ORDER_DATE_description,
  ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  `Internal Segment`,
  `AT_CXL_DATE_DATE_KEY (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  ADDITIONAL_TEXT,
  `MJR_LIC_PROG.description`,
  FinalPartnerName,
  FinalPartnerLevel,
 CASE 
 when FinalPartnerName in ('NEXSYS INTERNATIONAL, LC' , 'INGRAM MICRO     LATAM') then Replace(PartnerMarketArea,PartnerMarketArea, 'Strat. Latin America')
 else PartnerMarketArea
 end as PartnerMarketArea,
Case 
when FinalPartnerName in ('NEXSYS INTERNATIONAL, LC' , 'INGRAM MICRO     LATAM') then Replace(PartnerRegion,PartnerRegion,'Latin America')
else PartnerRegion
end as PartnerRegion,
  PartnerSalesDistrict,
  PartnerGeo,
Product 
FROM MODULE5_FORMULA_RBOB_WF_0201);

-- COMMAND ----------

/*[Update 1A]-[Update 1B and 2A]-UNION TOOL*/
 
CREATE OR REPLACE VIEW  Module5_Joiner_rbob_0201_v17 as (
select ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  BL_END_USER_NAME1,
  BL_LICENSING_CONTRACT,
  C_FIN_DOC_CURR,
  C_MARKET_SEGMENT,
  ENTERPRISE_BU_description,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  GEO_description,
  MARKET_AREA_description,
  --ORDER_DATE_description,
  ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  `Internal Segment`,
  `AT_CXL_DATE_DATE_KEY (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  ADDITIONAL_TEXT,
  `MJR_LIC_PROG.description`,
  FinalPartnerName,
  FinalPartnerLevel,
  PartnerMarketArea, 
 PartnerRegion,
  PartnerSalesDistrict,
  PartnerGeo,
Product,
`Partner Name`,
Family as Family_Name
FROM MODULE5_FORMULA_RBOB_WF_0201_F A left join b2b_tmp.field_radar_02_01_input_radar_raw_data_partner_master_table B
on A.FinalPartnerName=B.`Partner Name`);

-- COMMAND ----------

/*[Update 1A]-[Update 1B and 2A]-FORMULA TOOL(Previous)-FORMULA TOOL-To store interim result*/
 
CREATE OR REPLACE VIEW  module5_formula_wf_0201_v07 as (select ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  BL_END_USER_NAME1,
  BL_LICENSING_CONTRACT,
  C_FIN_DOC_CURR,
  C_MARKET_SEGMENT,
  ENTERPRISE_BU_description,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  GEO_description,
  MARKET_AREA_description,
  ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  `Internal Segment`,
  `AT_CXL_DATE_DATE_KEY (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  ADDITIONAL_TEXT,
  `MJR_LIC_PROG.description`,
  --FinalPartnerName,
  FinalPartnerLevel,
  PartnerMarketArea, 
 PartnerRegion,
  PartnerSalesDistrict,
  PartnerGeo,
Product,
--`Partner Name`,
 --Family_Name,
(case 
  when (FinalPartnerName = 'INGRAM MICRO ASIA LTD.     SG' AND SALES_DISTRICT_description not in ('Singapore')) then 'INGRAM MICRO ASIA LTD.(Non SG)     SG'
  else FinalPartnerName
  end) as FinalPartnerName,

(case 
  when (Family_Name = 'INGRAM MICRO ASIA LTD.     SG' AND SALES_DISTRICT_description not in ('Singapore')) then 'INGRAM MICRO ASIA LTD.(Non SG)     SG'
  else Family_Name
  end) as Family_Name,
CONCAT(NVL(BL_LICENSING_CONTRACT,''),NVL((case 
  when (FinalPartnerName = 'INGRAM MICRO ASIA LTD.     SG' AND SALES_DISTRICT_description not in ('Singapore')) then 'INGRAM MICRO ASIA LTD.(Non SG)     SG'
  else FinalPartnerName
  end),'')) as VIPPartner,
CONCAT(NVL(BL_LICENSING_CONTRACT,''),NVL(ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,'')) as VIPQtr,
CONCAT(NVL(BL_LICENSING_CONTRACT,''),NVL((case 
  when (FinalPartnerName = 'INGRAM MICRO ASIA LTD.     SG' AND SALES_DISTRICT_description not in ('Singapore')) then 'INGRAM MICRO ASIA LTD.(Non SG)     SG'
  else FinalPartnerName
  end),''),NVL(Product,'')) as VIPPartnerProduct,
concat(NVL(GEO_description,''),NVL(BL_LICENSING_CONTRACT,''),NVL((case 
  when (FinalPartnerName = 'INGRAM MICRO ASIA LTD.     SG' AND SALES_DISTRICT_description not in ('Singapore')) then 'INGRAM MICRO ASIA LTD.(Non SG)     SG'
  else FinalPartnerName
  end),'')) as GeoVIPPartner,
concat(NVL(GEO_description,''),NVL(BL_LICENSING_CONTRACT,''),NVL(Product,'')) as VIPProduct,
case
 when GEO_description='Japan' OR MARKET_AREA_description='ANZ' then `Total Sales Geo Amt (SUM)`
 else `Total Sales USD (SUM)`
 end as CurrencyAmt,
case
 when ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC IS NULL THEN '' 
 ELSE Concat(Cast((Cast(Left(NVL(ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,''),4) as integer)-1) as string),Right(NVL(ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,''),3)) 
 END AS PurchaseQtr
FROM Module5_Joiner_rbob_0201_v17);

-- COMMAND ----------

/*[Update 1A]-[Update 1B and 2A]-DateTime Tool*/
 
CREATE OR REPLACE VIEW  VW_Temp7 as
select ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  BL_END_USER_NAME1,
  BL_LICENSING_CONTRACT,
  C_FIN_DOC_CURR,
  C_MARKET_SEGMENT,
  ENTERPRISE_BU_description,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  GEO_description,
  MARKET_AREA_description,
  ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  `Internal Segment`,
  `AT_CXL_DATE_DATE_KEY (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  ADDITIONAL_TEXT,
  `MJR_LIC_PROG.description`,
  FinalPartnerName,
  FinalPartnerLevel,
  PartnerMarketArea, 
 PartnerRegion,
  PartnerSalesDistrict,
  PartnerGeo,
Product,
Family_Name,

 VIPPartner,
VIPQtr,
VIPPartnerProduct,
GeoVIPPartner,
VIPProduct,
CurrencyAmt,
PurchaseQtr,
concat(NVL(BL_LICENSING_CONTRACT,''),NVL(PurchaseQtr,'')) as VIPFiscalQtr,
`AT_CXL_DATE_DATE_KEY (ATTR)` as CXL_Date
FROM module5_formula_wf_0201_v07;

-- COMMAND ----------

/*[Update2]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  VW_Temp9 as
select vt7.CXL_Date,
vt7.ORDER_DATE_description,
vt7.`Total Sales USD (SUM)`,
vt8.`Sum_ARR opportunity`,
vt7.`Eligible Amt (SUM)`,
vt8.`Sum_Units Opportunity Partner-VIP Wise`,
vt8.`Sum_Units opportunity`,
vt7.CurrencyAmt,
vt7.`Eligible Qty (SUM)`,
vt7.`Total Sales Qty (SUM)`,
vt7.`Total Sales Geo Amt (SUM)`,
vt7.`LI_ARR (SUM)`,
vt7.PartnerGeo,
vt7.PartnerRegion,
vt7.PartnerSalesDistrict,
vt7.FinalPartnerLevel,
vt7.`AT_CXL_DATE_DATE_KEY (ATTR)`,
vt8.`VIP No`,
vt7.FinalPartnerName,
vt7.PartnerMarketArea,
vt8.`Contract CXL Quarter`,
vt7.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
vt7.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
vt7.Family_Name,
vt7.REGION_description,
vt7.PRODUCT_CONFIG_description,
vt7.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
vt7.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
vt7.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
vt7.MARKET_AREA_description,
vt7.GEO_description,
vt7.C_FIN_DOC_CURR,
vt7.PurchaseQtr,
vt7.VIPFiscalQtr,
vt7.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
vt7.BL_END_USER_NAME1,
vt7.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
vt7.VIPProduct,
vt7.GeoVIPPartner,
vt7.C_MARKET_SEGMENT,
vt7.RESELLER_GEO_PARTNER_GEO_description,
vt7.RESELLER_GEO_PARTNER_MARKET_AREA_description,
vt7.RESELLER_GEO_PARTNER_REGION_description,
vt7.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
vt7.SALES_DISTRICT_description,
vt7.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
vt7.VIPPartnerProduct,
vt7.VIPQtr,
vt7.VIPPartner,
vt7.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
vt7.ENTERPRISE_BU_description,
vt7.FISCAL_WK_IN_QTR,
vt7.FISCAL_YR_AND_QTR_DESC,
vt7.SALES_OPS_RESELLER_PARTNERROLLUP,
vt7.BL_LICENSING_CONTRACT,
vt7.ADDITIONAL_TEXT,
vt7.`Internal Segment`,
vt7.Product,
vt7.`MJR_LIC_PROG.description`,
(case when vt8.`VIP No` is null then 'Net New'
 else
  case when vt8.`Contract CXL Quarter` >= vt7.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC then 'Add On'
   else
     case when DATEDIFF(day,vt7.ORDER_DATE_description,vt7.CXL_Date) <= 335 then
	  'Add On'
	   else
	    'Renewal'
     end		
  end
end) as OrderType
FROM VW_Temp7 vt7 left join VW_Temp8 vt8
on vt7.BL_LICENSING_CONTRACT = vt8.`VIP No`;

-- COMMAND ----------

/*[Update 2B]-SELECT TOOL*/
 
CREATE OR REPLACE VIEW  VW_Update2B_Target as
select vt9.CXL_Date,
vt9.ORDER_DATE_description,
vt9.`Total Sales USD (SUM)`,
vt9.`Sum_ARR opportunity`,
vt9.`Eligible Amt (SUM)`,
vt9.`Sum_Units Opportunity Partner-VIP Wise`,
vt9.`Sum_Units opportunity`,
vt9.CurrencyAmt,
vt9.`Eligible Qty (SUM)`,
vt9.`Total Sales Qty (SUM)`,
vt9.`Total Sales Geo Amt (SUM)`,
vt9.`LI_ARR (SUM)`,
vt9.PartnerGeo,
vt9.PartnerRegion,
vt9.PartnerSalesDistrict,
vt9.FinalPartnerLevel,
vt9.`AT_CXL_DATE_DATE_KEY (ATTR)`,
vt9.`VIP No`,
vt9.FinalPartnerName,
vt9.PartnerMarketArea,
vt9.`Contract CXL Quarter`,
vt9.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
vt9.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
vt9.Family_Name,
vt9.REGION_description,
vt9.PRODUCT_CONFIG_description,
vt9.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
vt9.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
vt9.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
vt9.MARKET_AREA_description,
vt9.GEO_description,
vt9.C_FIN_DOC_CURR,
vt9.PurchaseQtr,
vt9.VIPFiscalQtr,
vt9.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
vt9.BL_END_USER_NAME1,
vt9.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
vt9.VIPProduct,
vt9.GeoVIPPartner,
vt9.C_MARKET_SEGMENT,
vt9.RESELLER_GEO_PARTNER_GEO_description,
vt9.RESELLER_GEO_PARTNER_MARKET_AREA_description,
vt9.RESELLER_GEO_PARTNER_REGION_description,
vt9.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
vt9.SALES_DISTRICT_description,
vt9.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
vt9.VIPPartnerProduct,
vt9.VIPQtr,
vt9.VIPPartner,
vt9.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
vt9.ENTERPRISE_BU_description,
vt9.FISCAL_WK_IN_QTR,
vt9.FISCAL_YR_AND_QTR_DESC,
vt9.SALES_OPS_RESELLER_PARTNERROLLUP,
vt9.BL_LICENSING_CONTRACT,
vt9.ADDITIONAL_TEXT,
vt9.`Internal Segment`,
vt9.Product,
vt9.`MJR_LIC_PROG.description`,
vt9.OrderType,
vc448.`VIP No` as `Temp2_VIP No`
FROM VW_Temp9 vt9 left join VW_Container448 vc448
on vt9.VIPPartner = vc448.VIPPartner;

-- COMMAND ----------

/*To fetch Date(HARD CODED)*/

CREATE OR REPLACE VIEW  VW_Update2B_Source as
select fiscal_yr_and_qtr_desc as qtr,
       first(fiscal_yr_and_qtr_start_date) as First_date,
       left(fiscal_yr_and_qtr_desc,4) as Right_year
from b2b.l2_sa_sfdc_dim_date
where fiscal_yr_and_qtr_desc = ${qtr_to_run} -- Updated for Parameter Injection
group by fiscal_yr_and_qtr_desc,
         left(fiscal_yr_and_qtr_desc,4);

-- COMMAND ----------

/*[Update 2B]-APPEND FIELDS TOOL*/
 
CREATE OR REPLACE VIEW  Update2B_append_wf0201_v7 as 
select vwt.CXL_Date,
vwt.ORDER_DATE_description,
vwt.`Total Sales USD (SUM)`,
vwt.`Sum_ARR opportunity`,
vwt.`Eligible Amt (SUM)`,
vwt.`Sum_Units Opportunity Partner-VIP Wise`,
vwt.`Sum_Units opportunity`,
vwt.CurrencyAmt,
vwt.`Eligible Qty (SUM)`,
vwt.`Total Sales Qty (SUM)`,
vwt.`Total Sales Geo Amt (SUM)`,
vwt.`LI_ARR (SUM)`,
vwt.PartnerGeo,
vwt.PartnerRegion,
vwt.PartnerSalesDistrict,
vwt.FinalPartnerLevel,
vwt.`AT_CXL_DATE_DATE_KEY (ATTR)`,
vwt.`VIP No`,
vwt.FinalPartnerName,
vwt.PartnerMarketArea,
vwt.`Contract CXL Quarter`,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
vwt.Family_Name,
vwt.REGION_description,
vwt.PRODUCT_CONFIG_description,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
vwt.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
vwt.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
vwt.MARKET_AREA_description,
vwt.GEO_description,
vwt.C_FIN_DOC_CURR,
vwt.PurchaseQtr,
vwt.VIPFiscalQtr,
vwt.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
vwt.BL_END_USER_NAME1,
vwt.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
vwt.VIPProduct,
vwt.GeoVIPPartner,
vwt.C_MARKET_SEGMENT,
vwt.RESELLER_GEO_PARTNER_GEO_description,
vwt.RESELLER_GEO_PARTNER_MARKET_AREA_description,
vwt.RESELLER_GEO_PARTNER_REGION_description,
vwt.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
vwt.SALES_DISTRICT_description,
vwt.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
vwt.VIPPartnerProduct,
vwt.VIPQtr,
vwt.VIPPartner,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
vwt.ENTERPRISE_BU_description,
vwt.FISCAL_WK_IN_QTR,
vwt.FISCAL_YR_AND_QTR_DESC,
vwt.SALES_OPS_RESELLER_PARTNERROLLUP,
vwt.BL_LICENSING_CONTRACT,
vwt.ADDITIONAL_TEXT,
vwt.`Internal Segment`,
vwt.Product,
vwt.`MJR_LIC_PROG.description`,
vwt.OrderType,
vwt.`Temp2_VIP No`,
vws.First_date,
vws.Right_year
FROM VW_Update2B_Target vwt, VW_Update2B_Source vws;

-- COMMAND ----------

/*[Update 2B]-APPEND FIELDS TOOL(Previous)-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  Update2B_formula_wf0201_v7 as
select CXL_Date,
ORDER_DATE_description,
`Total Sales USD (SUM)`,
`Sum_ARR opportunity`,
`Eligible Amt (SUM)`,
`Sum_Units Opportunity Partner-VIP Wise`,
`Sum_Units opportunity`,
CurrencyAmt,
`Eligible Qty (SUM)`,
`Total Sales Qty (SUM)`,
`Total Sales Geo Amt (SUM)`,
`LI_ARR (SUM)`,
PartnerGeo,
PartnerRegion,
PartnerSalesDistrict,
FinalPartnerLevel,
`AT_CXL_DATE_DATE_KEY (ATTR)`,
`VIP No`,
FinalPartnerName,
PartnerMarketArea,
`Contract CXL Quarter`,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
Family_Name,
REGION_description,
PRODUCT_CONFIG_description,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
MARKET_AREA_description,
GEO_description,
C_FIN_DOC_CURR,
PurchaseQtr,
VIPFiscalQtr,
ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
BL_END_USER_NAME1,
ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
VIPProduct,
GeoVIPPartner,
C_MARKET_SEGMENT,
RESELLER_GEO_PARTNER_GEO_description,
RESELLER_GEO_PARTNER_MARKET_AREA_description,
RESELLER_GEO_PARTNER_REGION_description,
RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
SALES_DISTRICT_description,
SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
VIPPartnerProduct,
VIPQtr,
VIPPartner,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
ENTERPRISE_BU_description,
FISCAL_WK_IN_QTR,
FISCAL_YR_AND_QTR_DESC,
SALES_OPS_RESELLER_PARTNERROLLUP,
BL_LICENSING_CONTRACT,
ADDITIONAL_TEXT,
`Internal Segment`,
Product,
`MJR_LIC_PROG.description`,
OrderType,
`Temp2_VIP No`,
First_date,
Right_year,
Case when GEO_description in ('EMEA','Japan') OR REGION_description='North America'
then GEO_description else MARKET_AREA_description end as T1,
Case when PartnerGeo in ('EMEA','Japan') OR PartnerRegion='North America'
then PartnerGeo else PartnerMarketArea end as T2,
case when `Temp2_VIP No` IS NULL then 'Non-Incumbent' ELSE 'Incumbent' END AS Incumbent,
CASE 
WHEN OrderType='Renewal' 
THEN DATEADD(DAY,4,(DATEADD(YEAR,-1,CAST(CXL_Date AS DATE)))) 
else DATEADD(DAY,4,ORDER_DATE_description) end as date2
FROM Update2B_append_wf0201_v7;

-- COMMAND ----------

/*[Ingram India adjustment]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  VIEW_UPDATE2B_JOINL_WF_0201 AS
select CXL_Date,
ORDER_DATE_description,
`Total Sales USD (SUM)`,
`Sum_ARR opportunity`,
`Eligible Amt (SUM)`,
`Sum_Units Opportunity Partner-VIP Wise`,
`Sum_Units opportunity`,
CurrencyAmt,
`Eligible Qty (SUM)`,
`Total Sales Qty (SUM)`,
`Total Sales Geo Amt (SUM)`,
`LI_ARR (SUM)`,
PartnerGeo,
PartnerRegion,
PartnerSalesDistrict,
FinalPartnerLevel,
`AT_CXL_DATE_DATE_KEY (ATTR)`,
`VIP No`,
FinalPartnerName,
--PartnerMarketArea,
case 
 when FinalPartnerName ='INGRAM MICRO INDIA PRIVATE LIMITED     IN' AND PartnerMarketArea ='SEA' AND MARKET_AREA_description='India'
then 'India'
 else PartnerMarketArea
 end as PartnerMarketArea,
`Contract CXL Quarter`,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
Family_Name,
REGION_description,
PRODUCT_CONFIG_description,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
MARKET_AREA_description,
GEO_description,
C_FIN_DOC_CURR,
PurchaseQtr,
VIPFiscalQtr,
ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
BL_END_USER_NAME1,
ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
VIPProduct,
GeoVIPPartner,
C_MARKET_SEGMENT,
RESELLER_GEO_PARTNER_GEO_description,
RESELLER_GEO_PARTNER_MARKET_AREA_description,
RESELLER_GEO_PARTNER_REGION_description,
RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
SALES_DISTRICT_description,
SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
VIPPartnerProduct,
VIPQtr,
VIPPartner,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
ENTERPRISE_BU_description,
FISCAL_WK_IN_QTR,
FISCAL_YR_AND_QTR_DESC,
SALES_OPS_RESELLER_PARTNERROLLUP,
BL_LICENSING_CONTRACT,
ADDITIONAL_TEXT,
`Internal Segment`,
Product,
`MJR_LIC_PROG.description`,
OrderType,
`Temp2_VIP No`,
First_date,
Right_year,
case 
 when FinalPartnerName ='INGRAM MICRO INDIA PRIVATE LIMITED     IN' AND PartnerMarketArea ='SEA' AND MARKET_AREA_description='India'
then 1
 else Valid
 end as Valid,
 Incumbent,
 `Derived Week` 
 from (
select CXL_Date,
ORDER_DATE_description,
`Total Sales USD (SUM)`,
`Sum_ARR opportunity`,
`Eligible Amt (SUM)`,
`Sum_Units Opportunity Partner-VIP Wise`,
`Sum_Units opportunity`,
CurrencyAmt,
`Eligible Qty (SUM)`,
`Total Sales Qty (SUM)`,
`Total Sales Geo Amt (SUM)`,
`LI_ARR (SUM)`,
PartnerGeo,
PartnerRegion,
PartnerSalesDistrict,
FinalPartnerLevel,
`AT_CXL_DATE_DATE_KEY (ATTR)`,
`VIP No`,
FinalPartnerName,
PartnerMarketArea,
`Contract CXL Quarter`,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
Family_Name,
REGION_description,
PRODUCT_CONFIG_description,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
MARKET_AREA_description,
GEO_description,
C_FIN_DOC_CURR,
PurchaseQtr,
VIPFiscalQtr,
ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
BL_END_USER_NAME1,
ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
VIPProduct,
GeoVIPPartner,
C_MARKET_SEGMENT,
RESELLER_GEO_PARTNER_GEO_description,
RESELLER_GEO_PARTNER_MARKET_AREA_description,
RESELLER_GEO_PARTNER_REGION_description,
RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
SALES_DISTRICT_description,
SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
VIPPartnerProduct,
VIPQtr,
VIPPartner,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
ENTERPRISE_BU_description,
FISCAL_WK_IN_QTR,
FISCAL_YR_AND_QTR_DESC,
SALES_OPS_RESELLER_PARTNERROLLUP,
BL_LICENSING_CONTRACT,
ADDITIONAL_TEXT,
`Internal Segment`,
Product,
`MJR_LIC_PROG.description`,
OrderType,
`Temp2_VIP No`,
First_date,
Right_year,
case when T1=T2 THEN 1 ELSE 0 END AS Valid,
Incumbent,
Round(((DATEDIFF(DAY,First_date,Date2)+0.4)/7)) as `Derived Week`
FROM Update2B_formula_wf0201_v7) A;

-- COMMAND ----------

/*[Ingram India adjustment]-[Update 3]-SELECT TOOL*/
CREATE OR REPLACE VIEW  VIEW_OUTPUT_UPDATE2B_WORKFLOW_0201  AS SELECT VU.CXL_Date,
VU.ORDER_DATE_description,
VU.`Total Sales USD (SUM)`,
VU.`Sum_ARR opportunity`,
VU.`Eligible Amt (SUM)`,
VU.`Sum_Units Opportunity Partner-VIP Wise`,
VU.`Sum_Units opportunity`,
VU.CurrencyAmt,
VU.`Eligible Qty (SUM)`,
VU.`Total Sales Qty (SUM)`,
VU.`Total Sales Geo Amt (SUM)`,
VU.`LI_ARR (SUM)`,
VU.PartnerGeo,
VU.PartnerRegion,
VU.PartnerSalesDistrict,
VU.FinalPartnerLevel,
VU.`AT_CXL_DATE_DATE_KEY (ATTR)`,
VU.`VIP No`,
VU.FinalPartnerName,
VU.PartnerMarketArea,
VU.`Contract CXL Quarter`,
VU.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
VU.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
VU.Family_Name,
VU.REGION_description,
VU.PRODUCT_CONFIG_description,
VU.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
VU.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
VU.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
VU.MARKET_AREA_description,
VU.GEO_description,
VU.C_FIN_DOC_CURR,
VU.PurchaseQtr,
VU.VIPFiscalQtr,
VU.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
VU.BL_END_USER_NAME1,
VU.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
VU.VIPProduct,
VU.GeoVIPPartner,
VU.C_MARKET_SEGMENT,
VU.RESELLER_GEO_PARTNER_GEO_description,
VU.RESELLER_GEO_PARTNER_MARKET_AREA_description,
VU.RESELLER_GEO_PARTNER_REGION_description,
VU.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
VU.SALES_DISTRICT_description,
VU.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
VU.VIPPartnerProduct,
VU.VIPQtr,
VU.VIPPartner,
VU.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
VU.ENTERPRISE_BU_description,
VU.FISCAL_WK_IN_QTR,
VU.FISCAL_YR_AND_QTR_DESC,
VU.SALES_OPS_RESELLER_PARTNERROLLUP,
VU.BL_LICENSING_CONTRACT,
VU.ADDITIONAL_TEXT,
VU.`Internal Segment`,
VU.Product,
VU.`MJR_LIC_PROG.description`,
VU.OrderType,
VU.`Temp2_VIP No`,
VU.First_date,
VU.Right_year,
VU.Valid,
VU.Incumbent,
VU.`Derived Week`,
VT8.`Contract CXL Quarter` AS `Temp1_Contract CXL Quarter`,
(case when VU.OrderType = 'Renewal' then case when VU.PurchaseQtr IS NULL OR VU.PurchaseQtr ='' OR VU.PurchaseQtr =' ' THEN VU.PurchaseQtr
ELSE case when VU.PurchaseQtr != VT8.`Contract CXL Quarter` THEN VT8.`Contract CXL Quarter` ELSE VU.PurchaseQtr end end else VU.FISCAL_YR_AND_QTR_DESC
end) as PayoutQtr
 FROM VIEW_UPDATE2B_JOINL_WF_0201 AS VU LEFT JOIN vw_temp8 AS VT8 ON VU.BL_LICENSING_CONTRACT=VT8.`VIP No`;

-- COMMAND ----------

/*[temp4AttnVIPQtrPty]-SUMMARIZE TOOL*/
 
CREATE OR REPLACE VIEW  VW_temp4Attn as
select vt9.BL_LICENSING_CONTRACT,
vt9.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
vt9.VIPFiscalQtr,
sum(vt9.`Total Sales Qty (SUM)`) as `Sum_Total Sales Qty (SUM)`,
sum(vt9.CurrencyAmt) as Sum_CurrencyAmt
FROM VW_Temp9 vt9 left join VW_Temp8 vt8
on vt9.BL_LICENSING_CONTRACT = vt8.`VIP No`
where vt9.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC > vt8.`Contract CXL Quarter`
and vt9.OrderType = 'Renewal'
group by vt9.BL_LICENSING_CONTRACT,
vt9.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
vt9.VIPFiscalQtr;

-- COMMAND ----------

/*[temp6AttnVIPPartnerProd]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  VW_temp6Attn as
select vt9.BL_LICENSING_CONTRACT,
vt9.FinalPartnerName,
vt9.BL_LICENSING_CONTRACT as BL_LICENSING_CONTRACT2,
vt9.Product,
sum(vt9.`Total Sales Qty (SUM)`) as `Sum_Total Sales Qty (SUM)`,
sum(vt9.CurrencyAmt) as SumOfCurrencyAmt,
sum(vt9.`LI_ARR (SUM)`) as `Sum_LI_ARR (SUM)`,
concat(NVL(vt9.BL_LICENSING_CONTRACT,''), NVL(vt9.FinalPartnerName,''), NVL(vt9.Product,'')) as VIPPartnerProduct
FROM VW_Temp9 vt9 left join VW_Temp8 vt8
on vt9.BL_LICENSING_CONTRACT = vt8.`VIP No`
where vt9.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC > vt8.`Contract CXL Quarter`
and vt9.OrderType = 'Renewal'
group by vt9.BL_LICENSING_CONTRACT,
vt9.FinalPartnerName,
vt9.BL_LICENSING_CONTRACT,
vt9.Product,
concat(NVL(vt9.BL_LICENSING_CONTRACT,''), NVL(vt9.FinalPartnerName,''), NVL(vt9.Product,''));

-- COMMAND ----------

/*[temp7AttnVIPProd]-FORMULA TOOL*/
 
CREATE OR REPLACE VIEW  VW_temp7Attn as
select vt9.GEO_description,
vt9.BL_LICENSING_CONTRACT,
vt9.Product,
sum(vt9.`Total Sales Qty (SUM)`) as `Sum_Total Sales Qty (SUM)`,
sum(vt9.CurrencyAmt) as SumOfCurrencyAmt,
sum(vt9.`LI_ARR (SUM)`) as `Sum_LI_ARR (SUM)`,
concat(NVL(vt9.GEO_description,''), NVL(vt9.BL_LICENSING_CONTRACT,''), NVL(vt9.Product,'')) as VIPProduct
FROM VW_Temp9 vt9 left join VW_Temp8 vt8
on vt9.BL_LICENSING_CONTRACT = vt8.`VIP No`
where vt9.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC > vt8.`Contract CXL Quarter`
and vt9.OrderType = 'Renewal'
group by vt9.GEO_description,
vt9.BL_LICENSING_CONTRACT,
vt9.Product,
concat(NVL(vt9.GEO_description,''), NVL(vt9.BL_LICENSING_CONTRACT,''), NVL(vt9.Product,''));

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC --MODULE6_OUTPUT_rbob_wf_1_v7 ---> Extracting k12 deals
-- MAGIC drop table if exists b2b_tmp.field_radar_02_01_output_k12_deaks_pwc;
-- MAGIC create table b2b_tmp.field_radar_02_01_output_k12_deaks_pwc as
-- MAGIC (SELECT BL_LICENSING_CONTRACT as bl_licensing_contract,
-- MAGIC        `Derived Additional Text` as derived_additional_text
-- MAGIC    from MODULE6_OUTPUT_k12_rbob_wf_1_v7);

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC /*VIEW_OUTPUT_UPDATE2B_WORKFLOW_0201-INGRAM*/
-- MAGIC drop table if exists b2b_tmp.field_radar_02_01_output_rbob_intermediate_pwc;
-- MAGIC create table b2b_tmp.field_radar_02_01_output_rbob_intermediate_pwc as
-- MAGIC (SELECT cast(CXL_Date as date) as cxl_date,
-- MAGIC  ORDER_DATE_description as order_date_description,
-- MAGIC  `Total Sales USD (SUM)` as total_sales_usd_sum,
-- MAGIC  `Sum_ARR opportunity` as sum_arr_opportunity,
-- MAGIC  `Eligible Amt (SUM)` as eligible_amt_sum,
-- MAGIC  `Sum_Units Opportunity Partner-VIP Wise` as sum_units_opportunity_partner_vip_wise,
-- MAGIC  `Sum_Units opportunity` as sum_units_opportunity,
-- MAGIC  CurrencyAmt as currencyamt,
-- MAGIC  `Eligible Qty (SUM)` as eligible_qty_sum,
-- MAGIC  `Total Sales Qty (SUM)` as total_sales_qty_sum,
-- MAGIC  `Total Sales Geo Amt (SUM)` as total_sales_geo_amt_sum,
-- MAGIC  `LI_ARR (SUM)` as li_arr_sum,
-- MAGIC  PartnerGeo as partnergeo,
-- MAGIC  PartnerRegion as partnerregion,
-- MAGIC  PartnerSalesDistrict as partnersalesdistrict,
-- MAGIC  FinalPartnerLevel as finalpartnerlevel,
-- MAGIC  cast(`AT_CXL_DATE_DATE_KEY (ATTR)` as date) as at_cxl_date_date_key_attr,
-- MAGIC  `VIP No` as vip_no,
-- MAGIC  FinalPartnerName as finalpartnername,
-- MAGIC  PartnerMarketArea as partnermarketarea,
-- MAGIC  `Contract CXL Quarter` as contract_cxl_quarter,
-- MAGIC  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description as sales_ops_distributor_geo_partner_market_area_description,
-- MAGIC  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description as sales_ops_distributor_geo_partner_geo_description,
-- MAGIC  Family_Name as family_name,
-- MAGIC  REGION_description as region_description,
-- MAGIC  PRODUCT_CONFIG_description as product_config_description,
-- MAGIC  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description as sales_ops_distributor_geo_partner_region_description,
-- MAGIC  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP as sales_ops_distributor_partnerrollup,
-- MAGIC  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL as sales_ops_reseller_channel_program_level,
-- MAGIC  MARKET_AREA_description as market_area_description,
-- MAGIC  GEO_description as geo_description,
-- MAGIC  C_FIN_DOC_CURR as c_fin_doc_curr,
-- MAGIC  PurchaseQtr as purchaseqtr,
-- MAGIC  VIPFiscalQtr as vipfiscalqtr,
-- MAGIC  ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC as atd_cxl_date_fiscal_yr_and_per_desc,
-- MAGIC  BL_END_USER_NAME1 as bl_end_user_name1,
-- MAGIC  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC as atd_cxl_date_fiscal_yr_and_qtr_desc,
-- MAGIC  VIPProduct as vipproduct,
-- MAGIC  GeoVIPPartner as geovippartner,
-- MAGIC  C_MARKET_SEGMENT as c_market_segment,
-- MAGIC  RESELLER_GEO_PARTNER_GEO_description as reseller_geo_partner_geo_description,
-- MAGIC  RESELLER_GEO_PARTNER_MARKET_AREA_description as reseller_geo_partner_market_area_description,
-- MAGIC  RESELLER_GEO_PARTNER_REGION_description as reseller_geo_partner_region_description ,
-- MAGIC  RESELLER_GEO_PARTNER_SALES_DISTRICT_description as reseller_geo_partner_sales_district_description,
-- MAGIC  SALES_DISTRICT_description as sales_district_description,
-- MAGIC  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL as sales_ops_distributor_channel_program_level,
-- MAGIC  VIPPartnerProduct as vippartnerproduct,
-- MAGIC  VIPQtr as vipqtr,
-- MAGIC  VIPPartner as vippartner,
-- MAGIC  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description as sales_ops_distributor_geo_partner_sales_district_description,
-- MAGIC  ENTERPRISE_BU_description as enterprise_bu_description,
-- MAGIC  FISCAL_WK_IN_QTR as fiscal_wk_in_qtr ,
-- MAGIC  FISCAL_YR_AND_QTR_DESC as fiscal_yr_and_qtr_desc,
-- MAGIC  SALES_OPS_RESELLER_PARTNERROLLUP as sales_ops_reseller_partnerrollup,
-- MAGIC  BL_LICENSING_CONTRACT as bl_licensing_contract,
-- MAGIC  ADDITIONAL_TEXT as additional_text,
-- MAGIC  `Internal Segment` as internal_segment,
-- MAGIC  Product as product,
-- MAGIC  `MJR_LIC_PROG.description` as mjr_lic_prog_description,
-- MAGIC  OrderType as order_type,
-- MAGIC  `Temp2_VIP No` as temp2_vip_no,
-- MAGIC  First_date as first_date,
-- MAGIC  cast(Right_year as bigint) as right_year,
-- MAGIC  cast(Valid as bigint) as valid,
-- MAGIC  Incumbent as incumbent,
-- MAGIC  cast(`Derived Week` as string) as derived_week,
-- MAGIC  `Temp1_Contract CXL Quarter` as temp1_contract_cxl_quarter,
-- MAGIC  PayoutQtr as payoutqtr
-- MAGIC from VIEW_OUTPUT_UPDATE2B_WORKFLOW_0201);

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC /*container 447 Output*/
-- MAGIC drop table if exists b2b_tmp.field_radar_02_01_output_temp1_pwc;
-- MAGIC create table b2b_tmp.field_radar_02_01_output_temp1_pwc as
-- MAGIC (select `VIP No` as vip_no,
-- MAGIC   `Contract CXL Quarter` as contract_cxl_quarter,
-- MAGIC    VIPQtr as vipqtr,
-- MAGIC   `Sum_Units opportunity` as sum_units_opportunity,
-- MAGIC   `Sum_Units Opportunity Partner-VIP Wise` as sum_units_opportunity_partner_vip_wise,
-- MAGIC   `Sum_ARR opportunity` as sum_arr_opportunity from 
-- MAGIC VW_Container447);

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC /*Container450*/
-- MAGIC drop table if exists b2b_tmp.field_radar_02_01_output_temp2a_pwc;
-- MAGIC create table b2b_tmp.field_radar_02_01_output_temp2a_pwc as
-- MAGIC (select `VIP No` as vip_no,
-- MAGIC   `Product` as product,
-- MAGIC   `Reseller Geo Partner` as reseller_geo_partner,
-- MAGIC   `Sum_Units Opportunity Partner-VIP Wise` as sum_units_opportunity_partner_vip_wise ,
-- MAGIC   `Sum_ARR Opportunity` as sum_arr_opportunity,
-- MAGIC   `Sum_Units Opportunity VIP Product` as sum_units_opportunity_vip_product,
-- MAGIC   VIPProduct as vipproduct
-- MAGIC from VW_Container450);

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC /*Container451*/
-- MAGIC drop table if exists b2b_tmp.field_radar_02_01_output_temp5_pwc;
-- MAGIC create table b2b_tmp.field_radar_02_01_output_temp5_pwc as
-- MAGIC (select `VIP No` as vip_no,
-- MAGIC   `Partner Name` as partner_name ,
-- MAGIC   Product as product,
-- MAGIC   cast(`Sum_Units Opportunity Partner-VIP Wise` as double) as sum_units_opportunity_partner_vip_wise,
-- MAGIC   `Sum_ARR Opportunity` as sum_arr_opportunity ,
-- MAGIC    VIPPartnerProduct as vippartnerproduct
-- MAGIC from VW_Container451);

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC /*Container452*/
-- MAGIC drop table if exists b2b_tmp.field_radar_02_01_output_temp4_pwc;
-- MAGIC create table b2b_tmp.field_radar_02_01_output_temp4_pwc as
-- MAGIC (select  BL_LICENSING_CONTRACT as bl_licensing_contract ,
-- MAGIC ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC as atd_cxl_date_fiscal_yr_and_qtr_desc ,
-- MAGIC VIPFiscalQtr as vipfiscalqtr,
-- MAGIC `Sum_Total Sales Qty (SUM)` as sum_total_sales_qty_sum,
-- MAGIC  Sum_CurrencyAmt as sum_currencyamt 
-- MAGIC FROM VW_temp4Attn);

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC /*Container453*/
-- MAGIC drop table if exists b2b_tmp.field_radar_02_01_output_temp6_pwc;
-- MAGIC create table b2b_tmp.field_radar_02_01_output_temp6_pwc as
-- MAGIC (select BL_LICENSING_CONTRACT as bl_licensing_contract,
-- MAGIC FinalPartnerName as finalpartnername,
-- MAGIC  BL_LICENSING_CONTRACT2 as bl_licensing_contract2,
-- MAGIC Product as product,
-- MAGIC  `Sum_Total Sales Qty (SUM)` as sum_total_sales_qty_sum,
-- MAGIC  SumOfCurrencyAmt as sumofcurrencyamt,
-- MAGIC  `Sum_LI_ARR (SUM)` as sum_li_arr_sum,
-- MAGIC  VIPPartnerProduct as vippartnerproduct
-- MAGIC FROM VW_temp6Attn);

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC /*Container454*/
-- MAGIC drop table if exists b2b_tmp.field_radar_02_01_output_temp7_pwc;
-- MAGIC create table b2b_tmp.field_radar_02_01_output_temp7_pwc as
-- MAGIC (select  GEO_description as geo_description ,
-- MAGIC  BL_LICENSING_CONTRACT as bl_licensing_contract,
-- MAGIC  Product as product,
-- MAGIC  `Sum_Total Sales Qty (SUM)` as sum_total_sales_qty_sum,
-- MAGIC  SumOfCurrencyAmt as sumofcurrencyamt ,
-- MAGIC `Sum_LI_ARR (SUM)` as sum_li_arr_sum,
-- MAGIC  VIPProduct as vipproduct
-- MAGIC FROM VW_temp7Attn);

