-- Databricks notebook source
-- DBTITLE 1,Receive Current Qtr Parameter From Parent Job
-- MAGIC %python
-- MAGIC dbutils.widgets.text("qtr_to_run", "", "")
-- MAGIC qtr_to_run = dbutils.widgets.get("qtr_to_run")
-- MAGIC
-- MAGIC print(f"Selected Quarter: {qtr_to_run}")

-- COMMAND ----------

create or replace view  view_0204_wf_temp1 as 
select A1.contract_cancellation_qtr,
A1.partner_region,
A1.partner_sales_district,
A1.order_date,
A1.date_derived,
A1.sales_district_description,
A1.partner_name,
A1.actual_expansion_revenue,
A1.end_user_name,
A1.arr,
A1.actual_exp_arr,
A1.renewal_to_go,
A1.market_area,
A1.week_derived,
A1.test,
quota_region as target_region	,
A1.partner_market_area,
A1.sumofunits_opportunity_partner_vip_wise,
A1.sumofarr_opportunity,
A1.vip_id,
A1.market_segment,
A1.enterprise_bu,
A1.week,
A1.geo,
A1.partner_level,
A1.reseller_rollup_for_emea_and_hkt,
Geo2 as target_geo,
A1.reseller_level,
A1.order_type,
A1.sumoffinal_revenue,
A1.incumbency_flag,
A1.target_payout_agg,
A1.payout_percentage_agg,
A1.payout_quarter_agg,
A1.renewal_status_agg,
A1.partner_rollup,
A1.Product,
A1.product_config_description,
A1.teams_vs_enterprise,
A1.derived_additional_text,
A1.market_segment_derived,
A1.distributor_rollup,
A1.major_licensing_program,
A1.measure,
A1.sum_total_sales_qty_sum,
A1.product_name_description from 

(select A.contract_cancellation_qtr,
A.vip_id,
A.market_segment,
A.enterprise_bu,
A.product,
A.week,
A.geo,
A.partner_level,
A.reseller_rollup_for_emea_and_hkt,
A.reseller_level,
A.partner_rollup,
A.order_type,
A.sumoffinal_revenue,
A.incumbency_flag,
A.target_payout_agg,
A.payout_percentage_agg,
A.payout_quarter_agg,
A.renewal_status_agg,
A.sumofarr_opportunity,
A.sumofunits_opportunity_partner_vip_wise,
A.sum_total_sales_qty_sum,
A.partner_market_area,
A.partner_region,
A.partner_sales_district,
A.order_date,
--A.date_derived,
to_date(A.date_derived,'d/M/yyyy')  AS date_derived,
A.sales_district_description,
A.partner_name,
A.actual_expansion_revenue,
A.end_user_name,
A.arr,
A.actual_exp_arr,
A.renewal_to_go,
A.distributor_rollup,
A.market_area,
A.week_derived,
A.test,
A.product_config_description,
A.major_licensing_program,
A.teams_vs_enterprise,
A.derived_additional_text,
A.market_segment_derived,
A.measure,
A.product_name_description,
B.Region AS quota_region,
B.Geo AS Geo2
from b2b_tmp.field_radar_02_03_output_rbob_data_format_pwc A LEFT JOIN  -- updated to point to non-static version
 b2b_tmp.field_radar_02_04_input_radar_raw_data_partner_master_table B ON 
A.partner_rollup = B.partner_name
) A1





-- COMMAND ----------

create or replace view view_0204_wf_temp2 as select contract_cancellation_qtr,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
--test,
case 
when test='1' then 'Valid' else 'Invalid' end as test ,
target_region	,
partner_market_area,
sumofunits_opportunity_partner_vip_wise as units_opportunity_attr,
sumofarr_opportunity as arr_opportunity_sum,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
 target_geo,
reseller_level,
order_type,
sumoffinal_revenue as eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
partner_rollup,
Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
sum_total_sales_qty_sum,
product_name_description,
case 
when Geo = 'Americas' and market_area in ('United States','Canada')
then 'North America' 
else 
case 
when Geo in ('EMEA','Japan') then Geo else market_area 
end 
end as selling_geo,
case 
when target_geo = 'Americas' 
then case when partner_region='North America' 
then 'North America' else partner_market_area end 
else case when target_geo = 'Asia' then partner_market_area else  target_geo
end 
end as reseller_geo,
null AS target_for_summary_total,
null as actual_expansion_revenue_for_rebate_tracker ,
null as actual_expansion_revenue_arr ,
substr((case 
	when order_type IN ('Renewal','Expansion') 
	THEN DATEADD(YEAR,-1,date_derived ) 
	else order_date end),1,10) as date_derived_for_forecast
from view_0204_wf_temp1 

-- COMMAND ----------

create or replace view view_0204_wf_temp3 as select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 cast(target_for_summary_total as string) as target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 cast(actual_expansion_revenue_for_rebate_tracker as string) as actual_expansion_revenue_for_rebate_tracker,
cast(actual_expansion_revenue_arr as string) as actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast
 from view_0204_wf_temp2

-- COMMAND ----------

/* contrainer name : SoftwareOne FR Adjustment creating view to store results of partner_rollup in ('SOFTWAREONE AG     CH','SOFTWAREONE DEUTSCHLAND GMBH     DE') and vip_id='B1A55067E73A8DFEF99A'*/
create or replace view view_0204_wf_temp4_true as select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
'SOFTWAREONE FRANCE SAS     FR' as partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
'SOFTWAREONE FRANCE SAS     FR' as partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 actual_expansion_revenue_for_rebate_tracker,
actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast from 
(select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 actual_expansion_revenue_for_rebate_tracker,
actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast
 from view_0204_wf_temp3
 where partner_rollup in ('SOFTWAREONE AG     CH','SOFTWAREONE DEUTSCHLAND GMBH     DE') and vip_id='B1A55067E73A8DFEF99A') A2

-- COMMAND ----------

/* contrainer name : SoftwareOne FR Adjustment 
Creating view to store results of partner_rollup not in ('SOFTWAREONE AG     CH','SOFTWAREONE DEUTSCHLAND GMBH     DE') and vip_id!='B1A55067E73A8DFEF99A'*/
create or replace view view_0204_wf_temp4_False as 
select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 actual_expansion_revenue_for_rebate_tracker,
actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast
 from view_0204_wf_temp3
--where partner_rollup not in ('SOFTWAREONE AG     CH','SOFTWAREONE DEUTSCHLAND GMBH     DE') and vip_id!='B1A55067E73A8DFEF99A' -- this is wrong it blocks VIP 8B9DD08F5825100719AA, which is SOFTWAREONE DEUTSCHLAND GMBH     DE with a differnt VIP
where concat(partner_rollup,'-',vip_id) NOT IN (SELECT concat(partner_rollup,'-',vip_id) FROM view_0204_wf_temp4_true) -- if you are not true - you are false, personally I would just flag the record and exclude it in one query 

-- COMMAND ----------

/* contrainer name : SoftwareOne FR Adjustment union */
create or replace view view_0204_wf_temp5 as
 select * from view_0204_wf_temp4_true
union
select * from view_0204_wf_temp4_False

-- COMMAND ----------

/* contrainer name : SoftwareOne FR Adjustment creating view to store results of partner_rollup = 'INGRAM MICRO DISTRIB     DE' and market_area = 'Benelux' and major_licensing_program in ('VIP Market Place','VIP MP Booster'*/
create or replace view view_0204_wf_temp6_true as select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
'INGRAM MICRO B.V.     NL' as partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
'INGRAM MICRO B.V.     NL' as partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 actual_expansion_revenue_for_rebate_tracker,
actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast from 
(select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 actual_expansion_revenue_for_rebate_tracker,
actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast
  from view_0204_wf_temp5
 where partner_rollup = 'INGRAM MICRO DISTRIB     DE' and market_area = 'Benelux' and major_licensing_program in ('VIP Market Place','VIP MP Booster') ) A2

-- COMMAND ----------

/* contrainer name : SoftwareOne FR Adjustment 
Creating view to store results of partner_rollup not equal to 'INGRAM MICRO DISTRIB     DE' and market_area not equal to 'Benelux' and major_licensing_program not in ('VIP Market Place','VIP MP Booster'*/
create or replace view view_0204_wf_temp6_false as select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 actual_expansion_revenue_for_rebate_tracker,
actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast
  from view_0204_wf_temp5
 except
 select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu,
week,
geo,
partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
target_payout_agg,
payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 actual_expansion_revenue_for_rebate_tracker,
actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast
  from view_0204_wf_temp5
 where partner_rollup = 'INGRAM MICRO DISTRIB     DE' 
 and 
 market_area = 'Benelux' and 
 major_licensing_program in ('VIP Market Place','VIP MP Booster')

 

-- COMMAND ----------

/* contrainer name : SoftwareOne FR Adjustment union */
create or replace view view_0204_wf_temp7 as
 select * from view_0204_wf_temp6_true
union
select * from view_0204_wf_temp6_False

-- COMMAND ----------

/*no container filter->formula->creating view to store interim result*/
create or replace view view_0204_wf_temp8 as select contract_cancellation_qtr,
vip_id,
market_segment,
enterprise_bu as enterprose_bu,
week,
geo,
'DISTRIBUTOR' as partner_level,
reseller_rollup_for_emea_and_hkt,
reseller_level,
'DOUGLAS STEWART' as partner_rollup,
order_type,
 eligible_revenue_agg,
incumbency_flag,
eligible_revenue_agg*0.013  as target_payout_agg,
'0.013' as payout_percentage_agg,
payout_quarter_agg,
renewal_status_agg,
arr_opportunity_sum,
units_opportunity_attr,
sum_total_sales_qty_sum,
partner_market_area,
partner_region,
partner_sales_district,
order_date,
date_derived,
sales_district_description,
'DOUGLAS STEWART' as partner_name,
actual_expansion_revenue,
end_user_name,
arr,
actual_exp_arr,
renewal_to_go,
market_area,
week_derived,
test,
 target_for_summary_total,
 target_geo,
target_region	,
selling_geo,
 reseller_geo,
 actual_expansion_revenue_for_rebate_tracker,
actual_expansion_revenue_arr,
 Product,
product_config_description,
teams_vs_enterprise,
derived_additional_text,
market_segment_derived,
distributor_rollup,
major_licensing_program,
measure,
product_name_description,
 date_derived_for_forecast
 from view_0204_wf_temp3
 where market_segment='EDUCATION' and partner_region='North America' and partner_rollup <> 'DOUGLAS STEWART'

-- COMMAND ----------

/* contrainer name : SoftwareOne FR Adjustment union */
create or replace view view_0204_wf_temp9 as
 select * from view_0204_wf_temp8
union
select * from view_0204_wf_temp7

-- COMMAND ----------

create or replace view view_0204final_output_table as select  
contract_cancellation_qtr
,vip_id
,market_segment
,enterprose_bu
,week
,geo
,partner_level
,reseller_rollup_for_emea_and_hkt as reseller_rollup_for_emea_and_hkt
,reseller_level
,partner_rollup
,order_type
,eligible_revenue_agg
,incumbency_flag
,target_payout_agg
,cast(payout_percentage_agg as double) as payout_percentage_agg
,payout_quarter_agg
,renewal_status_agg
,cast(arr_opportunity_sum as double) as arr_opportunity_sum
,cast(units_opportunity_attr as double) as units_opportunity_attr
,cast(sum_total_sales_qty_sum as double) as sum_total_sales_qty_sum
,partner_market_area
,partner_region
,partner_sales_district
,order_date
,date_derived
,sales_district_description
,partner_name
,cast(actual_expansion_revenue as double) as actual_expansion_revenue
,end_user_name
,cast(arr as double) as arr
,cast(actual_exp_arr as double) as actual_exp_arr
,cast(renewal_to_go as double) as renewal_to_go
,market_area
,week_derived
,test
,cast(target_for_summary_total as double) as target_for_summary_total
,target_geo
,target_region
,selling_geo
,reseller_geo
,cast(actual_expansion_revenue_for_rebate_tracker as double) as actual_expansion_revenue_for_rebate_tracker
,cast(actual_expansion_revenue_arr as double) as actual_expansion_revenue_arr
,Product
,product_config_description
,teams_vs_enterprise
,derived_additional_text
,market_segment_derived
,distributor_rollup
,major_licensing_program
,measure
,product_name_description
,cast(date_derived_for_forecast as date) as date_derived_for_forecast
from view_0204_wf_temp9


-- COMMAND ----------

drop table if exists b2b_tmp.field_radar_02_04_output_achievement_data_pwc;
create table b2b_tmp.field_radar_02_04_output_achievement_data_pwc as select * from view_0204final_output_table