-- Databricks notebook source
-- DBTITLE 1,Receive Current Qtr Parameter From Parent Job
-- MAGIC %python
-- MAGIC dbutils.widgets.text("qtr_to_run", "", "")
-- MAGIC qtr_to_run = dbutils.widgets.get("qtr_to_run")
-- MAGIC
-- MAGIC print(f"Selected Quarter: {qtr_to_run}")

-- COMMAND ----------

-- DBTITLE 1,Update Select so it comes from channel link not a static source
-- I have to rename the fields to what they are in the alyerx code
CREATE OR REPLACE VIEW VW_CONTAINER226 AS
SELECT  additional_text,
        CAST(atd_cxl_date_fiscal_yr_and_per_desc AS STRING) AS atd_cxl_date_fiscal_yr_and_per_desc,
        atd_cxl_date_fiscal_yr_and_qtr_desc,
        bl_end_user_name1,
        bl_licensing_contract,
        c_fin_doc_curr,
        c_market_segment,
        enterprise_bu_desc AS enterprise_bu_description,
        fiscal_wk_in_qtr,
        fiscal_yr_and_qtr_desc,
        geo_desc AS geo_description,
        internal_segment,
        market_area_desc AS market_area_description,
        mjr_lic_prog_desc AS mjr_lic_prog_description,
        order_date_desc AS order_date_description,
        product_config_desc AS product_config_description,
        product_name_desc AS product_name_description,
        region_desc AS region_description,
        reseller_geo_partner_geo_desc AS reseller_geo_partner_geo_description,
        reseller_geo_partner_market_area_desc AS reseller_geo_partner_market_area_description,
        reseller_geo_partner_region_desc AS reseller_geo_partner_region_description,
        reseller_geo_partner_sales_district_desc AS reseller_geo_partner_sales_district_description,
        sales_district_desc AS sales_district_description,
        sales_ops_distributor_channel_program_level,
        sales_ops_distributor_geo_partner_geo_desc AS sales_ops_distributor_geo_partner_geo_description,
        sales_ops_distributor_geo_partner_market_area_desc AS sales_ops_distributor_geo_partner_market_area_description,
        sales_ops_distributor_geo_partner_region_desc AS sales_ops_distributor_geo_partner_region_description,
        sales_ops_distributor_geo_partner_sales_district_desc AS sales_ops_distributor_geo_partner_sales_district_description,
        sales_ops_distributor_partnerrollup,
        sales_ops_reseller_channel_program_level,
        sales_ops_reseller_partnerrollup,
        CAST(fy_cxl_date as STRING) AS at_cxl_date_date_key, 
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_ELIGIBLE_AMOUNT END) AS DECIMAL(20,2)) AS  eligible_amt,
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_ELIGIBLE_UNIT END) AS BIGINT) AS  eligible_qty,
        CAST(sum(li_arr) AS DECIMAL(20,2)) AS li_arr,
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_TOTAL_SALES_GEO_AMT END) AS DECIMAL(20,2)) AS total_sales_geo_amt,
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_TOTAL_SALES_QTY END) AS BIGINT) AS total_sales_qty,
        CAST(sum(CASE WHEN a11.C_SOURCE_DATASET='Other_Billing' AND a11.MAJOR_PRODUCT_CONFIG IN('EDU','FUL','UPG') THEN 0 ELSE a11.C_TOTAL_SALES_USD END) AS DECIMAL(20,2)) AS total_sales_usd
FROM b2b.sap_hana_sys_bic_channel_an_channelink_consolidated  a11
-- This is lifted from an alteryx workflow for RADAR - I have no idea why these filters are applied - this is simply as it is in that query  
WHERE C_SALES_OPS_DISTRIBUTER_NAME NOT IN ('ADOBE SYSTEMS VIP FOC')
AND mjr_lic_prog_desc IN ('Value Incentive Plan','VIP Market Place')
AND (((a11.C_SOURCE_DATASET IN ('Adobe.com', 'Lic.Adobe.com')
AND a11.BL_SELL_IN_CHANNEL IN ('ELC', 'PFE')
AND a11.REVENUE_TYPE IN ('APPS', 'ESS')
AND (a11.ENTERPRISE_BU NOT IN ('EB20')
OR a11.PMBU IN ('13600'))
AND a11.BL_SKU_CATEGORY IN ('C', 'S')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION NOT IN ('NAM'))
OR (a11.ST_REPORTING_FLG IN ('Y')
AND a11.C_SOURCE_DATASET IN ('SELLTHRU')
AND a11.SOLD_BY_CUSTOMER_CLASS IN ('D')
AND a11.MAJOR_PRODUCT_CONFIG IN ('EDU', 'FUL', 'UPG', 'SUB')
AND (a11.ENTERPRISE_BU NOT IN ('EB20')
OR a11.PMBU IN ('13600'))
AND a11.REGION IN ('NAM')
AND a11.SOLD_BY_CUSTOMER_ID IN ('3188580', '1431300', '3188574', '298', '312', '1294820', '356', '3195048', '376', '377', '290', '3313503', '3301257')
AND a11.C_DEMAND_VIEW IN ('R'))
OR (a11.ST_REPORTING_FLG IN ('Y')
AND a11.C_SOURCE_DATASET IN ('SELLTHRU')
AND a11.MAJOR_PRODUCT_CONFIG IN ('EDU', 'FUL', 'UPG', 'SUB')
AND (a11.ENTERPRISE_BU NOT IN ('EB20')
OR a11.PMBU IN ('13600'))
AND a11.SOLD_BY_CUSTOMER_ID NOT IN ('3188574', '3188580', '3301257', '3313503')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION IN ('NAM')
AND a11.C_CONSIGNMENT_FLAG IN ('CONS'))
OR (a11.ST_REPORTING_FLG IN ('Y')
AND a11.C_SOURCE_DATASET IN ('SELLTHRU')
AND a11.SOLD_BY_CUSTOMER_CLASS IN ('D')
AND a11.MAJOR_PRODUCT_CONFIG IN ('EDU', 'FUL', 'UPG', 'SUB')
AND (a11.ENTERPRISE_BU NOT IN ('EB20')
OR a11.PMBU IN ('13600'))
AND a11.REGION NOT IN ('NAM')
AND a11.C_DEMAND_VIEW IN ('R'))
OR (a11.C_SOURCE_DATASET IN ('Adobe.com', 'Lic.Adobe.com')
AND a11.BL_SELL_IN_CHANNEL IN ('ELC', 'PFE')
AND a11.REVENUE_TYPE IN ('APPS', 'ESS')
AND (a11.ENTERPRISE_BU NOT IN ('EB20')
OR a11.PMBU IN ('13600'))
AND a11.BL_SKU_CATEGORY IN ('C', 'S')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION IN ('NAM'))
OR (a11.MAJOR_PRODUCT_CONFIG IN ('LIC', 'LMS', 'SAS', 'UPP', 'SUB')
AND (a11.ENTERPRISE_BU NOT IN ('EB20')
OR a11.PMBU IN ('13600'))
AND a11.BL_CONTRACT_TYPE NOT IN ('33')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION IN ('NAM')
AND a11.C_SOURCE_DATASET IN ('JHOLD'))
OR (a11.MAJOR_PRODUCT_CONFIG IN ('LIC', 'LMS', 'SAS', 'UPP', 'SUB')
AND (a11.ENTERPRISE_BU NOT IN ('EB20')
OR a11.PMBU IN ('13600'))
AND a11.BL_CONTRACT_TYPE NOT IN ('33')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION NOT IN ('NAM')
AND a11.C_SOURCE_DATASET IN ('JHOLD'))
OR ((a11.PMBU IN ('13600')
OR a11.ENTERPRISE_BU NOT IN ('EB20'))
AND a11.C_SOURCE_DATASET IN ('Licensing', 'Lic.Adobe.com')
AND a11.BL_CONTRACT_TYPE NOT IN ('05', '07', '58', '33', '59', '60')
AND a11.MAJOR_PRODUCT_CONFIG IN ('UPP', 'LIC', 'SAS', 'LMS', 'UPG', 'SUB')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION IN ('NAM'))
OR ((a11.ENTERPRISE_BU NOT IN ('EB20')
OR a11.PMBU IN ('13600'))
AND a11.BL_CONTRACT_TYPE NOT IN ('59')
AND a11.C_SOURCE_DATASET IN ('Licensing', 'Lic.Adobe.com')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION NOT IN ('NAM'))
OR (a11.C_SOURCE_DATASET IN ('Licensing >50K')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION IN ('NAM'))
OR (a11.C_SOURCE_DATASET IN ('Licensing >50K')
AND a11.C_DEMAND_VIEW IN ('R')
AND a11.REGION NOT IN ('NAM')))
AND a11.C_SOURCE_DATASET NOT IN ('Adobe.com')
AND a11.C_VIP_FOC_FLAG IN ('NO'))

-- Additional Filters applied in Alteryx workflow 
AND geo_desc = 'Japan'
AND product_name_desc IN ('Adobe Stock Large','Adobe Stock Other','Adobe Stock Small','Adobe XD - Pro','After Effects - Pro','Animate - Pro','Audition - Pro','CC All Apps - Pro','CCT & Stock','Dreamweaver - Pro','Illustrator - Pro','InCopy - Pro','InDesign - Pro','Lightroom - Pro','Photoshop - Pro','Premiere Pro - Pro','Premiere Rush - Pro','Stock Credit Pack','Stock Enterprise')

GROUP BY  
additional_text,
CAST(atd_cxl_date_fiscal_yr_and_per_desc AS STRING),
atd_cxl_date_fiscal_yr_and_qtr_desc,
bl_end_user_name1,
bl_licensing_contract,
c_fin_doc_curr,
c_market_segment,
enterprise_bu_desc,
fiscal_wk_in_qtr,
fiscal_yr_and_qtr_desc,
geo_desc,
internal_segment,
market_area_desc,
mjr_lic_prog_desc,
order_date_desc,
product_config_desc,
product_name_desc,
region_desc,
reseller_geo_partner_geo_desc,
reseller_geo_partner_market_area_desc,
reseller_geo_partner_region_desc,
reseller_geo_partner_sales_district_desc,
sales_district_desc,
sales_ops_distributor_channel_program_level,
sales_ops_distributor_geo_partner_geo_desc,
sales_ops_distributor_geo_partner_market_area_desc,
sales_ops_distributor_geo_partner_region_desc,
sales_ops_distributor_geo_partner_sales_district_desc,
sales_ops_distributor_partnerrollup,
sales_ops_reseller_channel_program_level,
sales_ops_reseller_partnerrollup,
CAST(fy_cxl_date as STRING)
HAVING fiscal_yr_and_qtr_desc = ${qtr_to_run} -- filter on the quarter passed as a parameter

-- COMMAND ----------

/*[Inputs]-DATETIME TOOL*/

Create or Replace View VW_Inputs0202 as
select additional_text,
  atd_cxl_date_fiscal_yr_and_per_desc,
  atd_cxl_date_fiscal_yr_and_qtr_desc,
  bl_end_user_name1,
  bl_licensing_contract,
  c_fin_doc_curr,
  c_market_segment,
  enterprise_bu_description as ENTERPRISE_BU_description,
  fiscal_wk_in_qtr,
 fiscal_yr_and_qtr_desc,
  geo_description as GEO_description,
  market_area_description as MARKET_AREA_description,
 order_date_description as ORDER_DATE_description,
  product_name_description,
  product_config_description as PRODUCT_CONFIG_description,
  region_description as REGION_description,
  reseller_geo_partner_geo_description as RESELLER_GEO_PARTNER_GEO_description,
  reseller_geo_partner_market_area_description as RESELLER_GEO_PARTNER_MARKET_AREA_description,
  reseller_geo_partner_region_description as RESELLER_GEO_PARTNER_REGION_description,
  reseller_geo_partner_sales_district_description as RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  sales_district_description as SALES_DISTRICT_description,
  sales_ops_distributor_channel_program_level,
  sales_ops_distributor_geo_partner_geo_description as SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  sales_ops_distributor_geo_partner_market_area_description as SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  sales_ops_distributor_geo_partner_region_description as SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  sales_ops_distributor_geo_partner_sales_district_description as SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  sales_ops_distributor_partnerrollup,
  sales_ops_reseller_channel_program_level,
  internal_segment,
  sales_ops_reseller_partnerrollup,
 mjr_lic_prog_description,
  REPLACE(at_cxl_date_date_key,',','') as `at_cxl_date_date_key (ATTR)`,
  sum(cast(eligible_amt as double)) as `Eligible Amt (SUM)`,
  sum(cast(eligible_qty as double)) as `Eligible Qty (SUM)`,
  sum(cast(LI_ARR as double)) as `LI_ARR (SUM)`,
  sum(cast(total_sales_geo_amt as double)) as `Total Sales Geo Amt (SUM)`,
  sum(cast(total_sales_qty as double)) as `Total Sales Qty (SUM)`,
  sum(cast(total_sales_usd as double)) as `Total Sales USD (SUM)`,
  CAST(order_date_description AS DATE) AS DateTime_Out
  from VW_CONTAINER226
  where bl_licensing_contract not in ('bl_licensing_contract')
  group by additional_text,
  atd_cxl_date_fiscal_yr_and_per_desc,
  atd_cxl_date_fiscal_yr_and_qtr_desc,
  bl_end_user_name1,
  bl_licensing_contract,
  c_fin_doc_curr,
  c_market_segment,
  enterprise_bu_description,
  fiscal_wk_in_qtr,
 fiscal_yr_and_qtr_desc,
  geo_description,
  market_area_description,
 order_date_description,
  product_name_description,
  product_config_description,
  region_description,
  reseller_geo_partner_geo_description,
  reseller_geo_partner_market_area_description,
  reseller_geo_partner_region_description,
  reseller_geo_partner_sales_district_description,
  sales_district_description,
  sales_ops_distributor_channel_program_level,
  sales_ops_distributor_geo_partner_geo_description,
  sales_ops_distributor_geo_partner_market_area_description,
  sales_ops_distributor_geo_partner_region_description,
  sales_ops_distributor_geo_partner_sales_district_description,
  sales_ops_distributor_partnerrollup,
  sales_ops_reseller_channel_program_level,
  internal_segment,
  sales_ops_reseller_partnerrollup,
 mjr_lic_prog_description,
  REPLACE(at_cxl_date_date_key,',',''),
  CAST(order_date_description AS DATE);

-- COMMAND ----------

/*[No Container]-FORMULA TOOL*/

Create or Replace View VW_0202UPDATE1B2ALEFTJOINER as
select atd_cxl_date_fiscal_yr_and_per_desc,
  atd_cxl_date_fiscal_yr_and_qtr_desc,
  bl_end_user_name1,
  bl_licensing_contract,
  c_fin_doc_curr,
  c_market_segment,
  ENTERPRISE_BU_description,
  fiscal_wk_in_qtr,
 fiscal_yr_and_qtr_desc,
  GEO_description,
  MARKET_AREA_description,
  ORDER_DATE_description,
  --DateTime_Out as ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  sales_ops_distributor_channel_program_level,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  sales_ops_distributor_partnerrollup,
  sales_ops_reseller_channel_program_level,
  sales_ops_reseller_partnerrollup,
  internal_segment,
  `at_cxl_date_date_key (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  additional_text,
 mjr_lic_prog_description,
  product_name_description,
  FinalPartnerName,
FinalPartnerLevel,
 CASE 
 when FinalPartnerName in ('NEXSYS INTERNATIONAL, LC' , 'INGRAM MICRO     LATAM') then Replace(PartnerMarketArea,PartnerMarketArea, 'Strat. Latin America')
 else PartnerMarketArea
 end as PartnerMarketArea,
Case 
when FinalPartnerName in ('NEXSYS INTERNATIONAL, LC' , 'INGRAM MICRO     LATAM') then Replace(PartnerRegion,PartnerRegion,'Latin America')
else PartnerRegion
end as PartnerRegion,
PartnerSalesDistrict,
PartnerGeo,
Product from (select atd_cxl_date_fiscal_yr_and_per_desc,
  atd_cxl_date_fiscal_yr_and_qtr_desc,
  bl_end_user_name1,
  bl_licensing_contract,
  c_fin_doc_curr,
  c_market_segment,
  ENTERPRISE_BU_description,
  fiscal_wk_in_qtr,
 fiscal_yr_and_qtr_desc,
  GEO_description,
  MARKET_AREA_description,
  ORDER_DATE_description,
  --DateTime_Out as ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  sales_ops_distributor_channel_program_level,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  sales_ops_distributor_partnerrollup,
  sales_ops_reseller_channel_program_level,
  sales_ops_reseller_partnerrollup,
  internal_segment,
  `at_cxl_date_date_key (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  additional_text,
 mjr_lic_prog_description,
  product_name_description,
  Case 
  when sales_ops_reseller_channel_program_level != 'PLATINUM' OR sales_ops_reseller_channel_program_level IS NULL THEN sales_ops_distributor_partnerrollup
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN sales_ops_reseller_partnerrollup
WHEN GEO_description='EMEA' THEN sales_ops_distributor_partnerrollup
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN sales_ops_distributor_partnerrollup
ELSE sales_ops_reseller_partnerrollup 
  END  AS FinalPartnerName,
  Case 
  when sales_ops_reseller_channel_program_level != 'PLATINUM' OR sales_ops_reseller_channel_program_level IS NULL THEN sales_ops_distributor_channel_program_level
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN sales_ops_reseller_channel_program_level
WHEN GEO_description='EMEA' THEN sales_ops_distributor_channel_program_level
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN sales_ops_distributor_channel_program_level
ELSE sales_ops_reseller_channel_program_level 
  END  AS FinalPartnerLevel,
  Case 
  when sales_ops_reseller_channel_program_level != 'PLATINUM' OR sales_ops_reseller_channel_program_level IS NULL THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN RESELLER_GEO_PARTNER_MARKET_AREA_description
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description
ELSE RESELLER_GEO_PARTNER_MARKET_AREA_description 
  END  AS PartnerMarketArea,
  Case 
  when sales_ops_reseller_channel_program_level != 'PLATINUM' OR sales_ops_reseller_channel_program_level IS NULL THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN RESELLER_GEO_PARTNER_REGION_description
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description
ELSE RESELLER_GEO_PARTNER_REGION_description 
  END  AS PartnerRegion,
  Case 
  when sales_ops_reseller_channel_program_level != 'PLATINUM' OR sales_ops_reseller_channel_program_level IS NULL THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN RESELLER_GEO_PARTNER_SALES_DISTRICT_description
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description
ELSE RESELLER_GEO_PARTNER_SALES_DISTRICT_description 
  END  AS PartnerSalesDistrict,
  Case 
  when sales_ops_reseller_channel_program_level != 'PLATINUM' OR sales_ops_reseller_channel_program_level IS NULL THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description
  WHEN GEO_description IN( 'Americas','Japan' )
  THEN RESELLER_GEO_PARTNER_GEO_description
WHEN GEO_description='EMEA' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description
WHEN MARKET_AREA_description='Hong Kong & Taiwan' THEN SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description
ELSE RESELLER_GEO_PARTNER_GEO_description 
  END  AS PartnerGeo,
  Case 
WHEN internal_segment= 'Adobe Sign'  then internal_segment
else ENTERPRISE_BU_description
end as Product
  from VW_Inputs0202) A;

-- COMMAND ----------

/*[Extracting K12 deals]-FORMULA TOOL*/
Create or Replace View VW_ExtractK12deals as
select atd_cxl_date_fiscal_yr_and_per_desc,
  atd_cxl_date_fiscal_yr_and_qtr_desc,
  bl_end_user_name1,
  bl_licensing_contract,
  c_fin_doc_curr,
  c_market_segment,
  ENTERPRISE_BU_description,
  fiscal_wk_in_qtr,
 fiscal_yr_and_qtr_desc,
  GEO_description,
  MARKET_AREA_description,
  ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  sales_ops_distributor_channel_program_level,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  sales_ops_distributor_partnerrollup,
  sales_ops_reseller_channel_program_level,
  sales_ops_reseller_partnerrollup,
  internal_segment,
  `at_cxl_date_date_key (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  additional_text,
 mjr_lic_prog_description,
  product_name_description,
  'K12' AS `Derived Additional Text`
  from VW_Inputs0202
  where additional_text like '%K12%';

-- COMMAND ----------

/*[Extracting K12 deals]-SUMMARIZE TOOL*/

Create or Replace View VW_CONTAINER228 as
SELECT bl_licensing_contract,`Derived Additional Text`
FROM VW_ExtractK12deals
GROUP BY bl_licensing_contract,`Derived Additional Text`;

-- COMMAND ----------

select * from b2b_tmp.field_radar_02_02_input_radar_raw_data_partner_master_table;

-- COMMAND ----------

/*[No Container]-02 02 INPUT RADAR - Raw Data.xlsx-SELECT TOOL*/

Create or Replace View VW_0202UPDATE1B2ARIGHT as
SELECT partner_name, family
FROM b2b_tmp.field_radar_02_02_input_radar_raw_data_partner_master_table;

-- COMMAND ----------

/*[Update 1B and 2A]-SELECT TOOL*/

Create or Replace View VW_0202UPDATE1B1ASELECT as
select vl.atd_cxl_date_fiscal_yr_and_per_desc,
  vl.atd_cxl_date_fiscal_yr_and_qtr_desc,
  vl.bl_end_user_name1,
  vl.bl_licensing_contract,
  vl.c_fin_doc_curr,
  vl.c_market_segment,
  vl.ENTERPRISE_BU_description,
  vl.fiscal_wk_in_qtr,
  vl.FISCAL_YR_AND_QTR_DESC,
  vl.GEO_description,
  vl.MARKET_AREA_description,
  vl.ORDER_DATE_description,
  vl.PRODUCT_CONFIG_description,
  vl.REGION_description,
  vl.RESELLER_GEO_PARTNER_GEO_description,
  vl.RESELLER_GEO_PARTNER_MARKET_AREA_description,
  vl.RESELLER_GEO_PARTNER_REGION_description,
  vl.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  vl.SALES_DISTRICT_description,
  vl.sales_ops_distributor_channel_program_level,
  vl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  vl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  vl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  vl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  vl.sales_ops_distributor_partnerrollup,
  vl.sales_ops_reseller_channel_program_level,
  vl.sales_ops_reseller_partnerrollup,
  vl.internal_segment,
  vl.`at_cxl_date_date_key (ATTR)`,
  vl.`Eligible Amt (SUM)`,
  vl.`Eligible Qty (SUM)`,
  vl.`LI_ARR (SUM)`,
  vl.`Total Sales Geo Amt (SUM)`,
  vl.`Total Sales Qty (SUM)`,
  vl.`Total Sales USD (SUM)`,
  vl.additional_text,
  vl.mjr_lic_prog_description,
  vl.product_name_description,
  vl.FinalPartnerName,
  vl.FinalPartnerLevel,
  vl.PartnerMarketArea,
  vl.PartnerRegion,
  vl.PartnerSalesDistrict,
  vl.PartnerGeo,
  vl.Product,
  --vr.partner_name,
  vr.family as family_Name
from VW_0202UPDATE1B2ALEFTJOINER vl left join VW_0202UPDATE1B2ARIGHT vr
on vl.FinalPartnerName = vr.partner_name;

-- COMMAND ----------

/*[Update 1B and 2A]-DATETIME TOOL*/

Create or Replace View VW_UPDATE1B2ADATETIME as
select atd_cxl_date_fiscal_yr_and_per_desc,
  atd_cxl_date_fiscal_yr_and_qtr_desc,
  bl_end_user_name1,
  bl_licensing_contract,
  c_fin_doc_curr,
  c_market_segment,
  ENTERPRISE_BU_description,
  fiscal_wk_in_qtr,
 fiscal_yr_and_qtr_desc,
  GEO_description,
  MARKET_AREA_description,
  ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  sales_ops_distributor_channel_program_level,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  sales_ops_distributor_partnerrollup,
  sales_ops_reseller_channel_program_level,
  sales_ops_reseller_partnerrollup,
  internal_segment,
  `at_cxl_date_date_key (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  additional_text,
 mjr_lic_prog_description,
  product_name_description,
  FinalPartnerName,
  FinalPartnerLevel,
  PartnerMarketArea,
  PartnerRegion,
  PartnerSalesDistrict,
  PartnerGeo,
  Product,
  family_Name,
VIPPartner,
VIPQtr,
VIPPartnerProduct,
GeoVIPPartner,
VIPProduct,
CurrencyAmt,
PurchaseQtr,
concat(NVL(bl_licensing_contract,''),NVL(PurchaseQtr,'')) as VIPFiscalQtr,
`at_cxl_date_date_key (ATTR)` as CXL_Date
from (select atd_cxl_date_fiscal_yr_and_per_desc,
  atd_cxl_date_fiscal_yr_and_qtr_desc,
  bl_end_user_name1,
  bl_licensing_contract,
  c_fin_doc_curr,
  c_market_segment,
  ENTERPRISE_BU_description,
  fiscal_wk_in_qtr,
 fiscal_yr_and_qtr_desc,
  GEO_description,
  MARKET_AREA_description,
  ORDER_DATE_description,
  PRODUCT_CONFIG_description,
  REGION_description,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  sales_ops_distributor_channel_program_level,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  sales_ops_distributor_partnerrollup,
  sales_ops_reseller_channel_program_level,
  sales_ops_reseller_partnerrollup,
  internal_segment,
  `at_cxl_date_date_key (ATTR)`,
  `Eligible Amt (SUM)`,
  `Eligible Qty (SUM)`,
  `LI_ARR (SUM)`,
  `Total Sales Geo Amt (SUM)`,
  `Total Sales Qty (SUM)`,
  `Total Sales USD (SUM)`,
  additional_text,
 mjr_lic_prog_description,
  product_name_description,
  FinalPartnerName,
  FinalPartnerLevel,
  PartnerMarketArea,
  PartnerRegion,
  PartnerSalesDistrict,
  PartnerGeo,
  Product,
  family_Name,
  CONCAT(NVL(bl_licensing_contract,''),NVL(FinalPartnerName,'')) as VIPPartner,
CONCAT(NVL(bl_licensing_contract,''),NVL(atd_cxl_date_fiscal_yr_and_qtr_desc,'')) as VIPQtr,
CONCAT(NVL(bl_licensing_contract,''),NVL(FinalPartnerName,''),NVL(Product,'')) as VIPPartnerProduct,
concat(NVL(GEO_description,''),NVL(bl_licensing_contract,''),NVL(FinalPartnerName,'')) as GeoVIPPartner,
concat(NVL(GEO_description,''),NVL(bl_licensing_contract,''),NVL(Product,'')) as VIPProduct,
case
 when GEO_description='Japan' OR MARKET_AREA_description='ANZ' then `Total Sales Geo Amt (SUM)`
 else `Total Sales USD (SUM)`
 end as CurrencyAmt,
case
 when atd_cxl_date_fiscal_yr_and_qtr_desc IS NULL THEN '' 
 ELSE Concat(Cast((Cast(Left(NVL(atd_cxl_date_fiscal_yr_and_qtr_desc,''),4) as integer)-1) as string),Right(NVL(atd_cxl_date_fiscal_yr_and_qtr_desc,''),3)) 
 END AS PurchaseQtr
from VW_0202UPDATE1B1ASELECT) B;

-- COMMAND ----------

select * from b2b_tmp.field_radar_02_02_input_contract_level_targets_q2

-- COMMAND ----------

/*[No Container]-FORMULA TOOL*/

Create or Replace View VW_0202INPUTCONTRACTFORMULA as
select Unique_ID,
  `VIP No`,
  Upper(`Partner Name_Change`) as partner_name,
  `Contract End Date`,
  `Contract CXL Date`,
  `Contract CXL Fiscal Period`,
  Contrac_CXL_Quarter as `Contract CXL Quarter`,
  `Market Segment`,
  `Target Geo`,
  `Reseller Geo Partner`,
  `Partner Type_Change` as `Partner Type`,
  Currency,
  Product,
  cast(Units_Opportunity as double) as `Units Opportunity`,
  cast(`ARR Opportunity` as double),
  cast(Units_Opp_VIp_Product as double) as `Units Opportunity VIP Product`,
  cast(`Units Opportunity VIP-Partner Wise`as double) as `Units Opportunity Partner-VIP Wise`,
  Concat(NVL(`VIP No`,''),NVL(Contrac_CXL_Quarter,'')) as VIPQtr,
  Concat(NVL(`VIP No`,''),Upper(NVL(`Partner Name_Change`,''))) as VIPPartner
from b2b_tmp.field_radar_02_02_input_contract_level_targets_q2
where `VIP No` is not null
and `VIP No` <> '';

-- COMMAND ----------

/*[tempdata1TargetVIPQtrQty]-SUMMARIZE TOOL*/

Create or Replace View VW_CONTAINER229 as
select `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr,
  sum(`Units Opportunity`) as `Sum_Units opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR opportunity`
from VW_0202INPUTCONTRACTFORMULA
group by `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr;

-- COMMAND ----------

/*[tempdata2TargetVIPPartner]-SUMMARIZE TOOL*/

Create or Replace View VW_TEMPDATA2TARGETVIPPARTNER as
select `VIP No`,
  partner_name as partner_name,
  VIPPartner,
  sum(`ARR opportunity`) as `Sum_ARR opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  first(`Target Geo`) as `First_Target Geo`
from VW_0202INPUTCONTRACTFORMULA
group by `VIP No`,
  partner_name,
  VIPPartner;

-- COMMAND ----------

/*[tempdata2TargetVIPPartner]-FORMULA TOOL*/

Create or Replace View VW_CONTAINER230 as
select `VIP No`,
  partner_name,
  VIPPartner,
  `Sum_ARR opportunity`,
  `Sum_Units Opportunity Partner-VIP Wise`,
  `First_Target Geo`,
  Concat(NVL(`First_Target Geo`,''), NVL(`VIP No`,''), NVL(partner_name,'')) as GEOVIPPartner
from VW_TEMPDATA2TARGETVIPPARTNER;

-- COMMAND ----------

/*[Temp3]-SUMMARIZE TOOL*/
Create or Replace View VW_CONTAINER231 as
select `VIP No`,
  partner_name as partner_name,
  sum(`Units opportunity`) as `Sum_Units opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  first(`Target Geo`) as `First_Target Geo`
from VW_0202INPUTCONTRACTFORMULA
group by `VIP No`,
  partner_name;

-- COMMAND ----------

/*[Temp2A TargetVIPProd]-SUMMARIZE TOOL*/

Create or Replace View VW_TEMP2ATARGETVIPPROD as
select `VIP No`,
  `Product`,
  `Reseller Geo Partner`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR Opportunity`,
  sum(`Units Opportunity VIP Product`) as `Sum_Units Opportunity VIP Product`
from VW_0202INPUTCONTRACTFORMULA
group by `VIP No`,
  `Product`,
  `Reseller Geo Partner`;

-- COMMAND ----------

/*[Temp2A TargetVIPProd]-FORMULA TOOL*/

Create or Replace View VW_CONTAINER232 as
select `VIP No`,
  `Product`,
  `Reseller Geo Partner`,
  `Sum_Units Opportunity Partner-VIP Wise`,
  `Sum_ARR Opportunity`,
  `Sum_Units Opportunity VIP Product`,
  Concat(NVL(`Reseller Geo Partner`,''), NVL(`VIP No`,''), NVL(`Product`,'')) as VIPProduct
from VW_TEMP2ATARGETVIPPROD;

-- COMMAND ----------

/*[Temp5 TargetVIPPartnerProd]-SUMMARIZE TOOL*/

Create or Replace View VW_TEMP5TARGETVIPPARTNERPROD as
select `VIP No`,
  partner_name,
  Product,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR Opportunity`
from VW_0202INPUTCONTRACTFORMULA
group by `VIP No`,
  partner_name,
  Product;

-- COMMAND ----------

/*[Temp5 TargetVIPPartnerProd]-FORMULA TOOL*/

Create or Replace View VW_CONTAINER233 as
select `VIP No`,
  partner_name,
  Product,
  `Sum_Units Opportunity Partner-VIP Wise`,
  `Sum_ARR Opportunity`,
  Concat(NVL(`VIP No`,''), NVL(partner_name,''), NVL(`Product`,'')) as VIPPartnerProduct
from VW_TEMP5TARGETVIPPARTNERPROD;

-- COMMAND ----------

/*[No Container]-UNIQUE TOOL*/

Create or Replace VIEW VW_0202SORTUNIQUE as
select distinct `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr,
  sum(`Units Opportunity`) as `Sum_Units opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR opportunity`
from VW_0202INPUTCONTRACTFORMULA
group by `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr
order by `VIP No` asc,
  `Contract CXL Quarter` desc;


-- COMMAND ----------

/*[No Container]-UNIQUE TOOL*/

Create or Replace View VW_0202SORTUNIQUE1 as
select distinct `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr,
  sum(`Units Opportunity`) as `Sum_Units opportunity`,
  sum(`Units Opportunity Partner-VIP Wise`) as `Sum_Units Opportunity Partner-VIP Wise`,
  sum(`ARR Opportunity`) as `Sum_ARR opportunity`
from VW_0202INPUTCONTRACTFORMULA
group by `VIP No`,
  `Contract CXL Quarter`,
  VIPQtr
order by `VIP No` asc,
  `Contract CXL Quarter` asc;

-- COMMAND ----------

/*[Update2]-FORMULA TOOL*/

Create or Replace View VW_0202UPDATE2FORMULA as
select vud.CXL_Date,
  vud.ORDER_DATE_description,
  vud.`Total Sales USD (SUM)`,
  vsu.`Sum_ARR opportunity`,
  vud.`Eligible Amt (SUM)`,
  vsu.`Sum_Units Opportunity Partner-VIP Wise`,
  vsu.`Sum_Units opportunity`,
  vud.CurrencyAmt,
  vud.`Eligible Qty (SUM)`,
  vud.`Total Sales Qty (SUM)`,
  vud.`Total Sales Geo Amt (SUM)`,
  vud.`LI_ARR (SUM)`,
  vud.PartnerGeo,
  vud.PartnerRegion,
  vud.PartnerSalesDistrict,
  vud.FinalPartnerLevel,
  vud.`at_cxl_date_date_key (ATTR)`,
  vsu.`VIP No`,
  vud.FinalPartnerName,
  vud.PartnerMarketArea,
  vsu.`Contract CXL Quarter`,
  vud.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  vud.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  vud.family_Name,
  vud.REGION_description,
  vud.PRODUCT_CONFIG_description,
  vud.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  vud.sales_ops_distributor_partnerrollup,
  vud.sales_ops_reseller_channel_program_level,
  vud.MARKET_AREA_description,
  vud.GEO_description,
  vud.c_fin_doc_curr,
  vud.PurchaseQtr,
  vud.VIPFiscalQtr,
  vud.atd_cxl_date_fiscal_yr_and_per_desc,
  --vsu.VIPQtr as Temp1VIPQtr,
  vud.bl_end_user_name1,
  vud.atd_cxl_date_fiscal_yr_and_qtr_desc,
  vud.VIPProduct,
  vud.GeoVIPPartner,
  vud.c_market_segment,
  vud.RESELLER_GEO_PARTNER_GEO_description,
  vud.RESELLER_GEO_PARTNER_MARKET_AREA_description,
  vud.RESELLER_GEO_PARTNER_REGION_description,
  vud.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  vud.SALES_DISTRICT_description,
  vud.sales_ops_distributor_channel_program_level,
  vud.VIPPartnerProduct,
  vud.VIPQtr,
  vud.VIPPartner,
  vud.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  vud.ENTERPRISE_BU_description,
  vud.fiscal_wk_in_qtr,
  vud.FISCAL_YR_AND_QTR_DESC,
  vud.sales_ops_reseller_partnerrollup,
  vud.bl_licensing_contract,
  vud.additional_text,
  vud.internal_segment,
  vud.Product,
  vud.mjr_lic_prog_description,
  vud.product_name_description,
  (case when vsu.`VIP No` is null then 'Net New'
  else
   case when vsu.`Contract CXL Quarter` >= vud.atd_cxl_date_fiscal_yr_and_qtr_desc then 'Add On'
    else
      case when DATEDIFF(day,vud.ORDER_DATE_description,vud.CXL_Date) <= 335 then
	     'Add On'
	    else
	     'Renewal'
      end		
   end
  end) as OrderType
from VW_UPDATE1B2ADATETIME vud LEFT JOIN VW_0202SORTUNIQUE vsu
ON vud.bl_licensing_contract = vsu.`VIP No`;

-- COMMAND ----------

/*[Update 2B]-SELECT TOOL*/

Create or Replace View VW_0202UPDATE2BTARGET as
select vud.CXL_Date,
  vud.ORDER_DATE_description,
  vud.`Total Sales USD (SUM)`,
  vud.`Sum_ARR opportunity`,
  vud.`Eligible Amt (SUM)`,
  vud.`Sum_Units Opportunity Partner-VIP Wise`,
  vud.`Sum_Units opportunity`,
  vud.CurrencyAmt,
  vud.`Eligible Qty (SUM)`,
  vud.`Total Sales Qty (SUM)`,
  vud.`Total Sales Geo Amt (SUM)`,
  vud.`LI_ARR (SUM)`,
  vud.PartnerGeo,
  vud.PartnerRegion,
  vud.PartnerSalesDistrict,
  vud.FinalPartnerLevel,
  vud.`at_cxl_date_date_key (ATTR)`,
  vud.`VIP No`,
  vud.FinalPartnerName,
  vud.PartnerMarketArea,
  vud.`Contract CXL Quarter`,
  vud.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  vud.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  vud.family_Name,
  vud.REGION_description,
  vud.PRODUCT_CONFIG_description,
  vud.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  vud.sales_ops_distributor_partnerrollup,
  vud.sales_ops_reseller_channel_program_level,
  vud.MARKET_AREA_description,
  vud.GEO_description,
  vud.c_fin_doc_curr,
  vud.PurchaseQtr,
  vud.VIPFiscalQtr,
  vud.atd_cxl_date_fiscal_yr_and_per_desc,
  vud.bl_end_user_name1,
  vud.atd_cxl_date_fiscal_yr_and_qtr_desc,
  vud.VIPProduct,
  vud.GeoVIPPartner,
  vud.c_market_segment,
  vud.RESELLER_GEO_PARTNER_GEO_description,
  vud.RESELLER_GEO_PARTNER_MARKET_AREA_description,
  vud.RESELLER_GEO_PARTNER_REGION_description,
  vud.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  vud.SALES_DISTRICT_description,
  vud.sales_ops_distributor_channel_program_level,
  vud.VIPPartnerProduct,
  vud.VIPQtr,
  vud.VIPPartner,
  vud.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  vud.ENTERPRISE_BU_description,
  vud.fiscal_wk_in_qtr,
  vud.FISCAL_YR_AND_QTR_DESC,
  vud.sales_ops_reseller_partnerrollup,
  vud.bl_licensing_contract,
  vud.additional_text,
  vud.internal_segment,
  vud.Product,
  vud.mjr_lic_prog_description,
  vud.product_name_description,
  vud.OrderType,
  vc230.`VIP No` as `Temp2_VIP No`
  --vc230.partner_name as `Temp2_Partner Name`,
  --vc230.VIPPartner as Temp2_VIPPartner,
  --vc230.`Sum_ARR opportunity` as `Temp2_Sum_ARR opportunity`,
  --vc230.`Sum_Units Opportunity Partner-VIP Wise` as `Temp2_Sum_Units Opportunity Partner-VIP Wise`,
  --vc230.`First_Target Geo`,
  --vc230.GEOVIPPartner as Temp2_GeoVIPPartner
from VW_0202UPDATE2FORMULA vud left join vw_container230 vc230
on vud.VIPPartner = vc230.VIPPartner;

-- COMMAND ----------

/*To fetch Date(HARD CODED)*/

Create or Replace View VW_0202UPDATE2BSOURCE as
select fiscal_yr_and_qtr_desc as qtr,
       first(fiscal_yr_and_qtr_start_date) as First_date,
       left(fiscal_yr_and_qtr_desc,4) as Right_year
from b2b.l2_sa_sfdc_dim_date
where fiscal_yr_and_qtr_desc = ${qtr_to_run} -- filter on injected quarter
group by fiscal_yr_and_qtr_desc,
         left(fiscal_yr_and_qtr_desc,4);

-- COMMAND ----------

/*[Update 2B]-APPEND FIELDS TOOL*/

Create or Replace View VW_0202UPDATE2BAPPENDFIELDS as
select vwt.CXL_Date,
vwt.ORDER_DATE_description,
vwt.`Total Sales USD (SUM)`,
vwt.`Sum_ARR opportunity`,
vwt.`Eligible Amt (SUM)`,
vwt.`Sum_Units Opportunity Partner-VIP Wise`,
vwt.`Sum_Units opportunity`,
vwt.CurrencyAmt,
vwt.`Eligible Qty (SUM)`,
vwt.`Total Sales Qty (SUM)`,
vwt.`Total Sales Geo Amt (SUM)`,
vwt.`LI_ARR (SUM)`,
vwt.PartnerGeo,
vwt.PartnerRegion,
vwt.PartnerSalesDistrict,
vwt.FinalPartnerLevel,
vwt.`at_cxl_date_date_key (ATTR)`,
vwt.`VIP No`,
vwt.FinalPartnerName,
vwt.PartnerMarketArea,
vwt.`Contract CXL Quarter`,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
vwt.family_Name,
vwt.REGION_description,
vwt.PRODUCT_CONFIG_description,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
vwt.sales_ops_distributor_partnerrollup,
vwt.sales_ops_reseller_channel_program_level,
vwt.MARKET_AREA_description,
vwt.GEO_description,
vwt.c_fin_doc_curr,
vwt.PurchaseQtr,
vwt.VIPFiscalQtr,
vwt.atd_cxl_date_fiscal_yr_and_per_desc,
vwt.bl_end_user_name1,
vwt.atd_cxl_date_fiscal_yr_and_qtr_desc,
vwt.VIPProduct,
vwt.GeoVIPPartner,
vwt.c_market_segment,
vwt.RESELLER_GEO_PARTNER_GEO_description,
vwt.RESELLER_GEO_PARTNER_MARKET_AREA_description,
vwt.RESELLER_GEO_PARTNER_REGION_description,
vwt.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
vwt.SALES_DISTRICT_description,
vwt.sales_ops_distributor_channel_program_level,
vwt.VIPPartnerProduct,
vwt.VIPQtr,
vwt.VIPPartner,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
vwt.ENTERPRISE_BU_description,
vwt.fiscal_wk_in_qtr,
vwt.FISCAL_YR_AND_QTR_DESC,
vwt.sales_ops_reseller_partnerrollup,
vwt.bl_licensing_contract,
vwt.additional_text,
vwt.internal_segment,
vwt.Product,
vwt.mjr_lic_prog_description,
vwt.product_name_description,
vwt.OrderType,
vwt.`Temp2_VIP No`,
vws.First_date,
vws.Right_year
FROM VW_0202UPDATE2BTARGET vwt, VW_0202UPDATE2BSOURCE vws;

-- COMMAND ----------

/*[Update 2B]-FORMULA TOOL*/

Create or Replace View VW_0202UPDATE2BLASTFORMULA as
select CXL_Date,
ORDER_DATE_description,
`Total Sales USD (SUM)`,
`Sum_ARR opportunity`,
`Eligible Amt (SUM)`,
`Sum_Units Opportunity Partner-VIP Wise`,
`Sum_Units opportunity`,
CurrencyAmt,
`Eligible Qty (SUM)`,
`Total Sales Qty (SUM)`,
`Total Sales Geo Amt (SUM)`,
`LI_ARR (SUM)`,
PartnerGeo,
PartnerRegion,
PartnerSalesDistrict,
FinalPartnerLevel,
`at_cxl_date_date_key (ATTR)`,
`VIP No`,
FinalPartnerName,
PartnerMarketArea,
`Contract CXL Quarter`,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
family_Name,
REGION_description,
PRODUCT_CONFIG_description,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
sales_ops_distributor_partnerrollup,
sales_ops_reseller_channel_program_level,
MARKET_AREA_description,
GEO_description,
c_fin_doc_curr,
PurchaseQtr,
VIPFiscalQtr,
atd_cxl_date_fiscal_yr_and_per_desc,
bl_end_user_name1,
atd_cxl_date_fiscal_yr_and_qtr_desc,
VIPProduct,
GeoVIPPartner,
c_market_segment,
RESELLER_GEO_PARTNER_GEO_description,
RESELLER_GEO_PARTNER_MARKET_AREA_description,
RESELLER_GEO_PARTNER_REGION_description,
RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
SALES_DISTRICT_description,
sales_ops_distributor_channel_program_level,
VIPPartnerProduct,
VIPQtr,
VIPPartner,
SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
ENTERPRISE_BU_description,
fiscal_wk_in_qtr,
FISCAL_YR_AND_QTR_DESC,
sales_ops_reseller_partnerrollup,
bl_licensing_contract,
additional_text,
internal_segment,
Product,
mjr_lic_prog_description,
product_name_description,
OrderType,
`Temp2_VIP No`,
First_date,
Right_year,
case when T1=T2 THEN 1 ELSE 0 END AS Valid,
Incumbent,
Round(((DATEDIFF(DAY,First_date,Date2)+0.4)/7)) as `Derived Week`
FROM (
select vwt.CXL_Date,
vwt.ORDER_DATE_description,
vwt.`Total Sales USD (SUM)`,
vwt.`Sum_ARR opportunity`,
vwt.`Eligible Amt (SUM)`,
vwt.`Sum_Units Opportunity Partner-VIP Wise`,
vwt.`Sum_Units opportunity`,
vwt.CurrencyAmt,
vwt.`Eligible Qty (SUM)`,
vwt.`Total Sales Qty (SUM)`,
vwt.`Total Sales Geo Amt (SUM)`,
vwt.`LI_ARR (SUM)`,
vwt.PartnerGeo,
vwt.PartnerRegion,
vwt.PartnerSalesDistrict,
vwt.FinalPartnerLevel,
vwt.`at_cxl_date_date_key (ATTR)`,
vwt.`VIP No`,
vwt.FinalPartnerName,
vwt.PartnerMarketArea,
vwt.`Contract CXL Quarter`,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
vwt.family_Name,
vwt.REGION_description,
vwt.PRODUCT_CONFIG_description,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
vwt.sales_ops_distributor_partnerrollup,
vwt.sales_ops_reseller_channel_program_level,
vwt.MARKET_AREA_description,
vwt.GEO_description,
vwt.c_fin_doc_curr,
vwt.PurchaseQtr,
vwt.VIPFiscalQtr,
vwt.atd_cxl_date_fiscal_yr_and_per_desc,
vwt.bl_end_user_name1,
vwt.atd_cxl_date_fiscal_yr_and_qtr_desc,
vwt.VIPProduct,
vwt.GeoVIPPartner,
vwt.c_market_segment,
vwt.RESELLER_GEO_PARTNER_GEO_description,
vwt.RESELLER_GEO_PARTNER_MARKET_AREA_description,
vwt.RESELLER_GEO_PARTNER_REGION_description,
vwt.RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
vwt.SALES_DISTRICT_description,
vwt.sales_ops_distributor_channel_program_level,
vwt.VIPPartnerProduct,
vwt.VIPQtr,
vwt.VIPPartner,
vwt.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
vwt.ENTERPRISE_BU_description,
vwt.fiscal_wk_in_qtr,
vwt.FISCAL_YR_AND_QTR_DESC,
vwt.sales_ops_reseller_partnerrollup,
vwt.bl_licensing_contract,
vwt.additional_text,
vwt.internal_segment,
vwt.Product,
vwt.mjr_lic_prog_description,
vwt.product_name_description,
vwt.OrderType,
vwt.`Temp2_VIP No`,
vwt.First_date,
vwt.Right_year,
Case when GEO_description in ('EMEA','Japan') OR REGION_description='North America'
then GEO_description else MARKET_AREA_description end as T1,
Case when PartnerGeo in ('EMEA','Japan') OR PartnerRegion='North America'
then PartnerGeo else PartnerMarketArea end as T2,
case when `Temp2_VIP No` IS NULL then 'Non-Incumbent' ELSE 'Incumbent' END AS Incumbent,
CASE 
WHEN OrderType='Renewal' 
THEN DATEADD(DAY,4,(DATEADD(YEAR,-1,CAST(CXL_Date AS DATE)))) 
else DATEADD(DAY,4,ORDER_DATE_description) end as date2
FROM VW_0202UPDATE2BAPPENDFIELDS vwt);

-- COMMAND ----------

/*[Update 3]-SELECT TOOL*/

Create or Replace View VW_0202UPDATE3FORMULA1 as
select vuf.additional_text as `Derived Additional Text`,
vuf.bl_end_user_name1 as `End User Name`,
vuf.bl_licensing_contract as `VIP ID`,
vuf.c_market_segment as `Market Segment`,
vsu.`Contract CXL Quarter` as `Contract Cancellation Qtr`,
vuf.CurrencyAmt as `SumOfFinal_Revenue`,
vuf.`Derived Week` as `Week Derived`,
vuf.`Eligible Qty (SUM)`,
vuf.ENTERPRISE_BU_description as `Enterprise BU`,
vuf.family_Name as partner_name,
vuf.FinalPartnerLevel as `Partner Level`,
vuf.FinalPartnerName as `Partner Rollup`,
vuf.fiscal_wk_in_qtr as `Week`,
vuf.GEO_description as `Geo`,
vuf.Incumbent as `Incumbency Flag`,
vuf.`LI_ARR (SUM)` as ARR,
vuf.MARKET_AREA_description as `Market Area`,
vuf.mjr_lic_prog_description as `Major Licensing Program`,
vuf.ORDER_DATE_description as `Order Date`,
vuf.OrderType as `Order Type`,
vuf.PartnerMarketArea as `Partner Market Area`,
vuf.PartnerRegion as `Partner Region`,
vuf.PartnerSalesDistrict as `Partner Sales District`,
(case when vuf.OrderType = 'Renewal' then case when vuf.PurchaseQtr IS NULL OR vuf.PurchaseQtr ='' OR vuf.PurchaseQtr =' ' THEN vuf.PurchaseQtr
ELSE case when vuf.PurchaseQtr != vsu.`Contract CXL Quarter` THEN vsu.`Contract CXL Quarter` ELSE vuf.PurchaseQtr end end else vuf.FISCAL_YR_AND_QTR_DESC
end) as `Payout Quarter (AGG)`,
vuf.Product,
vuf.PRODUCT_CONFIG_description,
vuf.product_name_description,
vuf.SALES_DISTRICT_description,
vuf.sales_ops_distributor_partnerrollup as `Distributor Rollup`,
vuf.sales_ops_reseller_channel_program_level as `Reseller Level`,
vuf.sales_ops_reseller_partnerrollup as `Reseller Rollup(For EMEA & HKT)`,
vuf.`Sum_ARR opportunity` as `SumOfARR opportunity`,
vuf.`Sum_Units Opportunity Partner-VIP Wise` as `SumOfUnits Opportunity Partner-VIP Wise`,
vuf.Valid as Test
FROM VW_0202UPDATE2BLASTFORMULA vuf left join VW_0202SORTUNIQUE vsu
on vuf.bl_licensing_contract = vsu.`VIP No`
where vuf.OrderType <> 'Renewal';

-- COMMAND ----------

/*[Update 3]-FORMULA TOOL*/

Create or Replace View VW_0202UPDATE3FORMULA2 as
select `Derived Additional Text`,
`End User Name`,
`VIP ID`,
`Market Segment`,
`Contract Cancellation Qtr`,
`SumOfFinal_Revenue`,
`Week Derived`,
`Eligible Qty (SUM)`,
`Enterprise BU`,
partner_name,
`Partner Level`,
`Partner Rollup`,
`Week`,
Geo,
`Incumbency Flag`,
ARR,
`Market Area`,
`Major Licensing Program`,
`Order Date`,
`Order Type`,
`Partner Market Area`,
`Partner Region`,
`Partner Sales District`,
concat('Quarter', ' 0', nvl(Right(`Payout Quarter (AGG)`, 1), ''), ' ', nvl(Left(`Payout Quarter (AGG)`, 4),'')) as `Payout Quarter (AGG)`,
Product,
PRODUCT_CONFIG_description,
product_name_description,
SALES_DISTRICT_description,
`Distributor Rollup`,
`Reseller Level`,
`Reseller Rollup(For EMEA & HKT)`,
`SumOfARR opportunity`,
`SumOfUnits Opportunity Partner-VIP Wise`,
Test,
(case 
when `Partner Rollup` = 'DOUGLAS STEWART' then 0.012 
else case when Geo = 'Americas' and `Incumbency Flag` = 'Non-Incumbent' and 
`Order Type` = 'Renewal' then 0
else case when Geo in ('Americas','Asia') then case when `Incumbency Flag` = 'Incumbent' then 0.04 
else 0.02
end
else 1
end
end
end) as `Payout Percentage (AGG)`,
(case 
when `Partner Rollup` = 'DOUGLAS STEWART' then 0.012*`SumOfFinal_Revenue`
else case when Geo = 'Americas' and `Incumbency Flag` = 'Non-Incumbent' and 
`Order Type` = 'Renewal' then 0
else case when Geo in ('Americas','Asia') then case when `Incumbency Flag` = 'Incumbent' then 0.04*`SumOfFinal_Revenue`
else 0.02*`SumOfFinal_Revenue`
end
else 1*`SumOfFinal_Revenue`
end
end
end) as `Target Payout (AGG)`,
'NA' as `Renewal Status (AGG)`,
`Order Date` AS `Date Derived`,
'0' AS `Actual Expansion Revenue`,
'0' as `Actual Exp ARR`,
'0' as `Renewal To-Go`,
(case when PRODUCT_CONFIG_description like '%Entrprse%' then 'Enterprise'
else 'Teams' end) as `Teams Vs Enterprise`,
(case when `Market Segment` = 'EDUCATION' then
  case when `Derived Additional Text` like '%K12%' then 'K12'
    else 'HED'
  end
else `Market Segment` 
end) as `Market Segment Derived`,
'M1' as Measure
FROM VW_0202UPDATE3FORMULA1;

-- COMMAND ----------

/*[Update 3]-FORMULA TOOL*/

Create or Replace View VW_0202UPDATE3FORMULA3 as
select `Derived Additional Text`,
`End User Name`,
`VIP ID`,
`Market Segment`,
`Contract Cancellation Qtr`,
(`SumOfFinal_Revenue`*-1) as `SumOfFinal_Revenue`,
`Week Derived`,
(`Eligible Qty (SUM)`*-1) as `Eligible Qty (SUM)`,
`Enterprise BU`,
partner_name,
`Partner Level`,
`Partner Rollup`,
`Week`,
Geo,
`Incumbency Flag`,
(ARR*-1) as ARR,
`Market Area`,
`Major Licensing Program`,
`Order Date`,
`Order Type`,
`Partner Market Area`,
`Partner Region`,
`Partner Sales District`,
`Payout Quarter (AGG)`,
Product,
PRODUCT_CONFIG_description,
product_name_description,
SALES_DISTRICT_description,
`Distributor Rollup`,
`Reseller Level`,
`Reseller Rollup(For EMEA & HKT)`,
(`SumOfARR opportunity`*-1) as `SumOfARR opportunity`,
(`SumOfUnits Opportunity Partner-VIP Wise`*-1) as `SumOfUnits Opportunity Partner-VIP Wise`,
Test,
`Payout Percentage (AGG)`,
(`Target Payout (AGG)`*-1) as `Target Payout (AGG)`,
`Renewal Status (AGG)`,
`Date Derived`,
`Actual Expansion Revenue`,
`Actual Exp ARR`,
`Renewal To-Go`,
`Teams Vs Enterprise`,
`Market Segment Derived`,
'M2' as Measure
FROM VW_0202UPDATE3FORMULA2;

-- COMMAND ----------

/*[Update 3]-UNION TOOL*/
Create or Replace View VW_0202UPDATE3UNION as
select * from VW_0202UPDATE3FORMULA2
union
select * from VW_0202UPDATE3FORMULA3;

-- COMMAND ----------

/*[temp4AttnVIPQtrQty]-SUMMARIZE TOOL*/

Create or Replace View VW_CONTAINER234 as
select vud.bl_licensing_contract,
  vud.atd_cxl_date_fiscal_yr_and_qtr_desc,
  vud.VIPFiscalQtr,
  sum(vud.`Eligible Qty (SUM)`) as `Sum_Eligible Qty (SUM)`,
  sum(vud.CurrencyAmt) as Sum_CurrencyAmt
from VW_0202UPDATE2FORMULA vud left join VW_0202SORTUNIQUE1 vsu
on vud.bl_licensing_contract = vsu.`VIP No`
where vud.atd_cxl_date_fiscal_yr_and_qtr_desc > vsu.`Contract CXL Quarter`
AND vud.OrderType = 'Renewal'
group by vud.bl_licensing_contract,
  vud.atd_cxl_date_fiscal_yr_and_qtr_desc,
  vud.VIPFiscalQtr;

-- COMMAND ----------

/*[temp6AttnVIPPartnerProd]-FORMULA TOOL*/

Create or Replace View VW_CONTAINER235 as
select vud.bl_licensing_contract,
  vud.FinalPartnerName,
  vud.bl_licensing_contract as bl_licensing_contract2,
  vud.Product,
  sum(vud.`Eligible Qty (SUM)`) as `SumOfEligible Qty (SUM)`,
  sum(vud.CurrencyAmt) as `SumOfCurrencyAmt`,
  sum(vud.`LI_ARR (SUM)`) as `Sum_LI_ARR (SUM)`,
  concat(nvl(vud.bl_licensing_contract,''), nvl(vud.FinalPartnerName,''), nvl(vud.Product,'')) as VIPPartnerProduct
from VW_0202UPDATE2FORMULA vud left join VW_0202SORTUNIQUE1 vsu
on vud.bl_licensing_contract = vsu.`VIP No`
where vud.atd_cxl_date_fiscal_yr_and_qtr_desc > vsu.`Contract CXL Quarter`
and vud.OrderType = 'Renewal'
group by vud.bl_licensing_contract,
  vud.FinalPartnerName,
  vud.bl_licensing_contract,
  vud.Product,
  concat(nvl(vud.bl_licensing_contract,''), nvl(vud.FinalPartnerName,''), nvl(vud.Product,''));

-- COMMAND ----------

/*[temp7AttnVIPProd]-FORMULA TOOL*/

Create or Replace View VW_CONTAINER236 as
select vud.GEO_description,
  vud.bl_licensing_contract,
  vud.Product,
  sum(vud.`Eligible Qty (SUM)`) as `SumOfEligible Qty (SUM)`,
  sum(vud.CurrencyAmt) as SumOfCurrencyAmt,
  sum(vud.`LI_ARR (SUM)`) as `Sum_LI_ARR (SUM)`,
  concat(nvl(vud.GEO_description,''), nvl(vud.bl_licensing_contract,''), nvl(vud.Product,'')) as VIPProduct
from VW_0202UPDATE2FORMULA vud left join VW_0202SORTUNIQUE1 vsu
on vud.bl_licensing_contract = vsu.`VIP No`
where vud.atd_cxl_date_fiscal_yr_and_qtr_desc > vsu.`Contract CXL Quarter`
and vud.OrderType = 'Renewal'
group by vud.GEO_description,
  vud.bl_licensing_contract,
  vud.Product,
  concat(nvl(vud.GEO_description,''), nvl(vud.bl_licensing_contract,''), nvl(vud.Product,''));

-- COMMAND ----------

/*Container227*/

drop table if exists b2b_tmp.field_radar_02_02_output_rbob_intermediate_jpn_ccpro_stock_pwc;
create table b2b_tmp.field_radar_02_02_output_rbob_intermediate_jpn_ccpro_stock_pwc as
(select `Derived Additional Text` as derived_additional_text,
`End User Name`as end_user_name,
`VIP ID` as vip_id,
`Market Segment` as market_segment,
`Contract Cancellation Qtr` as contract_cancellation_qtr,
SumOfFinal_Revenue as sumoffinal_revenue,
cast(`Week Derived` as string) as week_derived,
`Eligible Qty (SUM)` as eligible_qty_sum,
`Enterprise BU` as enterprise_bu,
partner_name,
`Partner Level` as partner_level,
`Partner Rollup` as partner_rollup,
(CASE WHEN len(week) = 1 THEN concat(0, week)
 ELSE week
  END) AS week,
Geo as geo,
`Incumbency Flag` as incumbency_flag,
ARR as arr,
`Market Area` as market_area,
`Major Licensing Program` as major_licensing_program,
cast(`Order Date` as date) as order_date,
`Order Type` as order_type,
`Partner Market Area` as partner_market_area,
`Partner Region` as partner_region,
`Partner Sales District` as partner_sales_district,
`Payout Quarter (AGG)` as payout_quarter_agg,
Product as product,
PRODUCT_CONFIG_description as product_config_description,
product_name_description,
SALES_DISTRICT_description as sales_district_description,
`Distributor Rollup` as distributor_rollup,
`Reseller Level` as reseller_level,
`Reseller Rollup(For EMEA & HKT)` as reseller_rollup_for_emea_and_hkt,
`SumOfARR opportunity` as sumofarr_opportunity,
`SumOfUnits Opportunity Partner-VIP Wise` as sumofunits_opportunity_partner_vip_wise,
cast(Test as bigint) as test,
cast(`Payout Percentage (AGG)` as double) as payout_percentage_agg,
`Target Payout (AGG)` as target_payout_agg,
cast(`Renewal Status (AGG)` as double) as renewal_status_agg,
cast(`Date Derived` as date) as date_derived,
cast(`Actual Expansion Revenue` as double) as actual_expansion_revenue,
cast(`Actual Exp ARR` as double) as actual_exp_arr,
cast(`Renewal To-Go` as double) as renewal_to_go,
`Teams Vs Enterprise` as teams_vs_enterprise,
`Market Segment Derived` as market_segment_derived,
Measure as measure
from VW_0202UPDATE3UNION);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## DEBUG

-- COMMAND ----------

SELECT count(*), sum(sumoffinal_revenue) FROM b2b_tmp.field_radar_02_02_output_rbob_intermediate_jpn_ccpro_stock_pwc


-- COMMAND ----------

SELECT * 
FROM VW_CONTAINER226
WHERE bl_end_user_name1 LIKE 'ACES DIRECT%'