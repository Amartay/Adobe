-- Databricks notebook source
-- DBTITLE 1,Receive Current Qtr Parameter From Parent Job
-- MAGIC %python
-- MAGIC dbutils.widgets.text("qtr_to_run", "", "")
-- MAGIC qtr_to_run = dbutils.widgets.get("qtr_to_run")
-- MAGIC
-- MAGIC print(f"Selected Quarter: {qtr_to_run}")

-- COMMAND ----------

Create or replace view view_add_column as
Select *, 'NA' as PRODUCT_NAME_description from b2b_tmp.field_radar_02_01_output_rbob_intermediate_pwc; -- updated to point to non-static version

create or replace table b2b_tmp.view_Record_id  as select *, -- JC update: Made this into a table so that multiple different references dont cause conflicting results
row_number() over( order by Order_Type ) as Record_ID
from view_add_column;

-- COMMAND ----------

-- View for Filtering "Renewal" records from RboB Intermediate 
create or replace view view_filter_Renewal as (
  select 
  Record_ID,
  CXL_Date,
  ORDER_DATE_description,
  Total_Sales_USD_SUM,
  Sum_ARR_opportunity,
  Eligible_Amt_SUM,
  CurrencyAmt,
  Eligible_Qty_SUM,
  Total_Sales_Qty_SUM,
  Total_Sales_Geo_Amt_SUM,
  LI_ARR_SUM,
  PartnerGeo,
  PartnerRegion,
  PartnerSalesDistrict,
  FinalPartnerLevel,
  AT_CXL_DATE_DATE_KEY_ATTR,
  VIP_No,
  FinalPartnerName,
  PartnerMarketArea,
  Contract_CXL_Quarter,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description,
  Family_Name,
  REGION_description,
  PRODUCT_CONFIG_description,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description,
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP,
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL,
  MARKET_AREA_description,
  GEO_description,
  C_FIN_DOC_CURR,
  PurchaseQtr,
  VIPFiscalQtr,
  ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC,
  BL_END_USER_NAME1,
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC,
  VIPProduct,
  GeoVIPPartner,
  C_MARKET_SEGMENT,
  RESELLER_GEO_PARTNER_GEO_description,
  RESELLER_GEO_PARTNER_MARKET_AREA_description,
  RESELLER_GEO_PARTNER_REGION_description,
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description,
  SALES_DISTRICT_description,
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL,
  VIPPartnerProduct,
  VIPQtr,
  VIPPartner,
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description,
  ENTERPRISE_BU_description,
  FISCAL_WK_IN_QTR,
  FISCAL_YR_AND_QTR_DESC,
  SALES_OPS_RESELLER_PARTNERROLLUP,
  BL_LICENSING_CONTRACT,
  ADDITIONAL_TEXT,
  Internal_Segment,
  Product,
  MJR_LIC_PROG_description,
  Order_Type,
  Temp2_VIP_No,
  First_date,
  Right_year,
  Valid,
  Incumbent,
  Derived_Week,
  Temp1_Contract_CXL_Quarter,
  PayoutQtr,
  PRODUCT_NAME_description
  from b2b_tmp.view_Record_id
  where Order_Type ='Renewal'
)

-- COMMAND ----------

Create or replace view view_temp7_temp2a_ljoin as
Select it7t.BL_LICENSING_CONTRACT , it7t.Sum_Total_Sales_Qty_SUM , it7t.SumOfCurrencyAmt ,it7t.VIPProduct, it2at.Sum_Units_Opportunity_Partner_VIP_Wise 
from b2b_tmp.field_radar_02_01_output_temp7_pwc as it7t -- updated to point to non-static version
left outer join 
b2b_tmp.field_radar_02_01_output_temp2a_pwc as it2at  -- updated to point to non-static version
on it7t.VIPProduct = it2at.VIPProduct

-- COMMAND ----------

-- Left join on Filtered record with joined output of temp7 and temp2a
Create or replace view view_vt7t2_renewal as
Select vfr.Record_ID, vfr.Order_Type, vt7t2.Sum_Total_Sales_Qty_SUM , vt7t2.Sum_Units_Opportunity_Partner_VIP_Wise from view_filter_Renewal as vfr
left join view_temp7_temp2a_ljoin as vt7t2
on vfr.VIPProduct=vt7t2.VIPProduct

-- COMMAND ----------

Create or replace view view_renewal_final as
Select vvtr.Record_ID,
CASE  
When vvtr.Sum_Total_Sales_Qty_SUM > vvtr.Sum_Units_Opportunity_Partner_VIP_Wise then 'Expansion'
When vvtr.Sum_Units_Opportunity_Partner_VIP_Wise is null then 'Expansion'
when vvtr.Sum_Total_Sales_Qty_SUM = vvtr.Sum_Units_Opportunity_Partner_VIP_Wise then 'Full Renewal'
Else 'Partial Renewal' 
End as Renewal_Status
 from view_vt7t2_renewal as vvtr

-- COMMAND ----------

 /* Here we are creating view for Left minus table only i.e, records only present in Left Table */
 Create or replace view view_Left_minus as
 Select jr.Record_ID , 
 jr.CXL_Date, 
 jr.ORDER_DATE_description, 
 jr.Total_Sales_USD_SUM, 
 jr.Sum_ARR_opportunity, 
 jr.Eligible_Amt_SUM, jr.
  Sum_Units_Opportunity_Partner_VIP_Wise, jr.
  Sum_Units_opportunity, jr.
  CurrencyAmt, jr.
  Eligible_Qty_SUM, jr.
  Total_Sales_Qty_SUM, jr.
  Total_Sales_Geo_Amt_SUM, jr.
  LI_ARR_SUM, jr.
  PartnerGeo, jr.
  PartnerRegion, jr.
  PartnerSalesDistrict, jr.
  FinalPartnerLevel, jr.
  AT_CXL_DATE_DATE_KEY_ATTR, jr.
  VIP_No, jr.
  FinalPartnerName, jr.
  PartnerMarketArea, jr.
  Contract_CXL_Quarter, jr.
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description, jr.
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, jr.
  Family_Name, jr.
  REGION_description, jr.
  PRODUCT_CONFIG_description, jr.
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, jr.
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, jr.
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, jr.
  MARKET_AREA_description, jr.
  GEO_description, jr.
  C_FIN_DOC_CURR, jr.
  PurchaseQtr, jr.
  VIPFiscalQtr, jr.
  ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, jr.
  BL_END_USER_NAME1, jr.
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, jr.
  VIPProduct, jr.
  GeoVIPPartner, jr.
  C_MARKET_SEGMENT, jr.
  RESELLER_GEO_PARTNER_GEO_description, jr.
  RESELLER_GEO_PARTNER_MARKET_AREA_description, jr.
  RESELLER_GEO_PARTNER_REGION_description, jr.
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description, jr.
  SALES_DISTRICT_description, jr.
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, jr.
  VIPPartnerProduct, jr.
  VIPQtr, jr.
  VIPPartner, jr.
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, jr.
  ENTERPRISE_BU_description, jr.
  FISCAL_WK_IN_QTR, jr.
  FISCAL_YR_AND_QTR_DESC, jr.
  SALES_OPS_RESELLER_PARTNERROLLUP, jr.
  BL_LICENSING_CONTRACT, jr.
  Product, jr.
  MJR_LIC_PROG_description, jr.
  Order_Type, jr.
  Temp2_VIP_No, jr.
  Valid, jr.
  Incumbent, jr.
  Derived_Week, jr.
  Temp1_Contract_CXL_Quarter, jr.
  PayoutQtr,
  jr.ADDITIONAL_TEXT,
  jr.Internal_Segment,
  jr.First_date,
  jr.Right_year,
  jr.PRODUCT_NAME_description,
  st.Renewal_Status from b2b_tmp.view_Record_id as jr
  left outer join view_renewal_final as st
  on jr.Record_ID=st.Record_ID
  where st.Record_ID is null

-- COMMAND ----------

/* Here we are creating view for Inner Join only i.e, common records present in both Left and Right Table */
Create or replace view view_Inner_join as
Select jr.Record_ID , 
 jr.CXL_Date, jr.ORDER_DATE_description, jr.
  Total_Sales_USD_SUM, jr.
  Sum_ARR_opportunity, jr.
  Eligible_Amt_SUM, jr.
  Sum_Units_Opportunity_Partner_VIP_Wise, jr.
  Sum_Units_opportunity, jr.
  CurrencyAmt, jr.
  Eligible_Qty_SUM, jr.
  Total_Sales_Qty_SUM, jr.
  Total_Sales_Geo_Amt_SUM, jr.
  LI_ARR_SUM, jr.
  PartnerGeo, jr.
  PartnerRegion, jr.
  PartnerSalesDistrict, jr.
  FinalPartnerLevel, jr.
  AT_CXL_DATE_DATE_KEY_ATTR, jr.
  VIP_No, jr.
  FinalPartnerName, jr.
  PartnerMarketArea, jr.
  Contract_CXL_Quarter, jr.
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description, jr.
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, jr.
  Family_Name, jr.
  REGION_description, jr.
  PRODUCT_CONFIG_description, jr.
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, jr.
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, jr.
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, jr.
  MARKET_AREA_description, jr.
  GEO_description, jr.
  C_FIN_DOC_CURR, jr.
  PurchaseQtr, jr.
  VIPFiscalQtr, jr.
  ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, jr.
  BL_END_USER_NAME1, jr.
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, jr.
  VIPProduct, jr.
  GeoVIPPartner, jr.
  C_MARKET_SEGMENT, jr.
  RESELLER_GEO_PARTNER_GEO_description, jr.
  RESELLER_GEO_PARTNER_MARKET_AREA_description, jr.
  RESELLER_GEO_PARTNER_REGION_description, jr.
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description, jr.
  SALES_DISTRICT_description, jr.
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, jr.
  VIPPartnerProduct, jr.
  VIPQtr, jr.
  VIPPartner, jr.
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, jr.
  ENTERPRISE_BU_description, jr.
  FISCAL_WK_IN_QTR, jr.
  FISCAL_YR_AND_QTR_DESC, jr.
  SALES_OPS_RESELLER_PARTNERROLLUP, jr.
  BL_LICENSING_CONTRACT, jr.
  Product, jr.
  MJR_LIC_PROG_description, jr.
  Order_Type, jr.
  Temp2_VIP_No, jr.
  Valid, jr.
  Incumbent, jr.
  Derived_Week, jr.
  Temp1_Contract_CXL_Quarter, jr.
  PayoutQtr,
  NULL as ADDITIONAL_TEXT,
  NULL as Internal_Segment,
  NULL as First_date,
  NULL as Right_year,
  NULL as PRODUCT_NAME_description,
  st.Renewal_Status from b2b_tmp.view_Record_id as jr
  inner join view_renewal_final as st
  on jr.Record_ID=st.Record_ID

-- COMMAND ----------

Create or replace view view_Final_Join as
Select lm.* from view_Left_minus as lm
union all 
Select ij.* from view_Inner_join as ij

-- COMMAND ----------

Create or replace view view_Left_Filter_3B as
 Select vfj.*, 
    t4t.BL_LICENSING_CONTRACT as Right_BL_LICENSING_CONTRACT , t4t.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC as Right_ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC , t4t.VIPFiscalQtr as Right_VIPFiscalQtr, t4t.Sum_Total_Sales_Qty_SUM as Temp4_total_sales_qty, t4t.Sum_CurrencyAmt as Temp4_Sum_CurrencyAmt
     from view_Final_Join as vfj
    left outer join b2b_tmp.field_radar_02_01_output_temp4_pwc as t4t  -- updated to point to non-static version
  on vfj.VIPFiscalQtr=t4t.VIPFiscalQtr
  where (Renewal_Status="Full Renewal" OR Renewal_Status="Partial Renewal") AND (Sum_Total_Sales_Qty_SUM != 0 OR Sum_Total_Sales_Qty_SUM IS NULL)

-- COMMAND ----------

Create or replace view view_Left_join2_3B as
Select vlf.*, it1.VIP_No as Right_VIP_No, it1.Contract_CXL_Quarter as Right_Contract_CXL_Quarter , it1.VIPQtr as Right_VIPQtr , it1.Sum_Units_opportunity as Right_Sum_Units_opportunity , it1.Sum_Units_Opportunity_Partner_VIP_Wise as Right_Sum_Units_Opportunity_Partner_VIP_Wise , it1.Sum_ARR_opportunity as Temp1_Sum_ARR_opportunity
 from view_Left_Filter_3B as vlf
left outer join b2b_tmp.field_radar_02_01_output_temp1_pwc as it1  -- updated to point to non-static version
on vlf.VIPFiscalQtr=it1.VIPQtr

-- COMMAND ----------

Create or replace view view_Formula_3B as
Select Record_ID, CurrencyAmt, BL_LICENSING_CONTRACT, Temp4_Sum_CurrencyAmt, Temp1_Sum_ARR_opportunity,
CASE
WHEN Temp4_Sum_CurrencyAmt-Temp1_Sum_ARR_opportunity>0 then 0
ELSE (Temp1_Sum_ARR_opportunity-Temp4_Sum_CurrencyAmt)*CurrencyAmt/Temp4_Sum_CurrencyAmt
END as Renewal_To_Go
from view_Left_join2_3B

-- COMMAND ----------

Create or replace view view_Final_left_3B as
Select vfj.*, vfr.Renewal_To_Go
from view_Final_Join as vfj
left outer join view_Formula_3B as vfr
on vfj.Record_ID=vfr.Record_ID

-- COMMAND ----------

/*Creating Output Table for container "temp9 AttnVIPProdIncum"*/
drop table if exists b2b_tmp.field_radar_02_03_output_Temp9_pwc;
Create table b2b_tmp.field_radar_02_03_output_Temp9_pwc as 
(Select GEO_description ,BL_LICENSING_CONTRACT, Product, 
Sum( Total_Sales_Qty_SUM) as Sum_Total_Sales_Qty_SUM, Sum(CurrencyAmt) as SumOfCurrencyAmt, 
Sum(LI_ARR_SUM) as Sum_LI_ARR_SUM, 
concat(GEO_description,BL_LICENSING_CONTRACT,Product) as VIPProduct 
from view_Final_left_3B
where Order_Type = 'Renewal' AND Incumbent = 'Incumbent'
group by GEO_description ,BL_LICENSING_CONTRACT, Product);

/*Creating Output Table for container "temp9b AttnVIPProdNonIncum"*/
drop table if exists b2b_tmp.field_radar_02_03_output_Temp9b_pwc;
Create table b2b_tmp.field_radar_02_03_output_Temp9b_pwc as 
(Select GEO_description ,BL_LICENSING_CONTRACT, Product, Sum( Total_Sales_Qty_SUM) as Sum_Total_Sales_Qty_SUM, Sum(CurrencyAmt) as SumOfCurrencyAmt, 
Sum(LI_ARR_SUM) as Sum_LI_ARR_SUM, concat(GEO_description,BL_LICENSING_CONTRACT,Product) as VIPProduct from view_Final_left_3B
where Order_Type = 'Renewal' AND Incumbent = 'Non-Incumbent'
group by GEO_description ,BL_LICENSING_CONTRACT, Product);

-- COMMAND ----------


-- JC modified - this table was hard coded - but it represents the current quarter and the previous quarter
Create or replace view view_Calendar as

-- get the current quarter
Select distinct Cast(fiscal_yr_and_qtr_desc as String) as year_and_qtr from b2b.l2_sa_sfdc_dim_date
where fiscal_yr_and_qtr_desc = ${qtr_to_run} 

union all 

-- get the previous quarter
Select distinct Cast(previous_fiscal_yr_and_qtr_desc as String) as year_and_qtr from b2b.l2_sa_sfdc_dim_date
where fiscal_yr_and_qtr_desc = ${qtr_to_run}  





-- COMMAND ----------

 drop table if exists b2b_tmp.Joins_Update4_1;
 Create table b2b_tmp.Joins_Update4_1 as
 (Select vfl.* from view_Final_left_3B as vfl
 inner join view_Calendar as vc
 on vfl.PayoutQtr = vc.year_and_qtr
 where vfl.Valid = 1);

-- COMMAND ----------

 drop table if exists b2b_tmp.Joins_Update4_2;
 Create table b2b_tmp.Joins_Update4_2 as
 (Select vju.Record_ID, 
  vju.CXL_Date, 
  vju.ORDER_DATE_description, 
  vju.Total_Sales_USD_SUM, 
  vju.Sum_ARR_opportunity, 
  vju.Eligible_Amt_SUM, 
  vju.Sum_Units_Opportunity_Partner_VIP_Wise, 
  vju.Sum_Units_opportunity, 
  vju.CurrencyAmt, 
  vju.Total_Sales_Qty_SUM, 
  vju.Total_Sales_Geo_Amt_SUM, 
  vju.LI_ARR_SUM, 
  vju.PartnerGeo, 
  vju.PartnerRegion, 
  vju.PartnerSalesDistrict, 
  vju.FinalPartnerLevel, 
  vju.AT_CXL_DATE_DATE_KEY_ATTR, 
  vju.VIP_No, 
  vju.FinalPartnerName, 
  vju.PartnerMarketArea, 
  vju.Contract_CXL_Quarter, 
  vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description, 
  vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
  vju.Family_Name, 
  vju.REGION_description, 
  vju.PRODUCT_CONFIG_description, 
  vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
  vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
  vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
  vju.MARKET_AREA_description, 
  vju.GEO_description, 
  vju.C_FIN_DOC_CURR, 
  vju.PurchaseQtr, 
  vju.VIPFiscalQtr, 
  vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
  vju.BL_END_USER_NAME1, 
  vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
  vju.VIPProduct, 
  vju.GeoVIPPartner, 
  vju.C_MARKET_SEGMENT, 
  vju.RESELLER_GEO_PARTNER_GEO_description, 
  vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
  vju.RESELLER_GEO_PARTNER_REGION_description, 
  vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
  vju.SALES_DISTRICT_description, 
  vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
  vju.VIPPartnerProduct, 
  vju.VIPQtr, 
  vju.VIPPartner, 
  vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
  vju.ENTERPRISE_BU_description, 
  vju.FISCAL_WK_IN_QTR, 
  vju.FISCAL_YR_AND_QTR_DESC, 
  vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
  vju.BL_LICENSING_CONTRACT, 
  vju.Product, 
  vju.MJR_LIC_PROG_description, 
  vju.Order_Type, 
  vju.Temp2_VIP_No, 
  vju.Valid, 
  vju.Incumbent, 
  vju.Derived_Week, 
  vju.Temp1_Contract_CXL_Quarter, 
  vju.PayoutQtr, 
  vju.ADDITIONAL_TEXT, 
  vju.Internal_Segment, 
  vju.First_date, 
  vju.Right_year, 
  vju.PRODUCT_NAME_description, 
  vju.Renewal_Status, 
  vju.Renewal_To_Go,
  vju.Eligible_Qty_SUM,
  it6.Product as Right_Product,
  it6.Sum_Total_Sales_Qty_SUM as AVPP_Sum_of_Total_sales_Qty_sum,
  it6.SumOfCurrencyAmt as AVPP_Sum_of_currency,
  it6.Sum_LI_ARR_SUM as AVPP_SumOf_LI_ARR_SUM,
  it6.VIPPartnerProduct as AVPP_VIPPartnerProduct from b2b_tmp.Joins_Update4_1 as vju
 left join b2b_tmp.field_radar_02_01_output_temp6_pwc as it6  -- updated to point to non-static version
 on vju.VIPPartnerProduct = it6.VIPPartnerProduct
 where it6.VIPPartnerProduct is null
 Union all
 Select vju.Record_ID, 
  vju.CXL_Date, 
  vju.ORDER_DATE_description, 
  vju.Total_Sales_USD_SUM, 
  vju.Sum_ARR_opportunity, 
  vju.Eligible_Amt_SUM, 
  vju.Sum_Units_Opportunity_Partner_VIP_Wise, 
  vju.Sum_Units_opportunity, 
  vju.CurrencyAmt, 
  vju.Total_Sales_Qty_SUM, 
  vju.Total_Sales_Geo_Amt_SUM, 
  vju.LI_ARR_SUM, 
  vju.PartnerGeo, 
  vju.PartnerRegion, 
  vju.PartnerSalesDistrict, 
  vju.FinalPartnerLevel, 
  vju.AT_CXL_DATE_DATE_KEY_ATTR, 
  vju.VIP_No, 
  vju.FinalPartnerName, 
  vju.PartnerMarketArea, 
  vju.Contract_CXL_Quarter, 
  vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description, 
  vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
  vju.Family_Name, 
  vju.REGION_description, 
  vju.PRODUCT_CONFIG_description, 
  vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
  vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
  vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
  vju.MARKET_AREA_description, 
  vju.GEO_description, 
  vju.C_FIN_DOC_CURR, 
  vju.PurchaseQtr, 
  vju.VIPFiscalQtr, 
  vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
  vju.BL_END_USER_NAME1, 
  vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
  vju.VIPProduct, 
  vju.GeoVIPPartner, 
  vju.C_MARKET_SEGMENT, 
  vju.RESELLER_GEO_PARTNER_GEO_description, 
  vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
  vju.RESELLER_GEO_PARTNER_REGION_description, 
  vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
  vju.SALES_DISTRICT_description, 
  vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
  vju.VIPPartnerProduct, 
  vju.VIPQtr, 
  vju.VIPPartner, 
  vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
  vju.ENTERPRISE_BU_description, 
  vju.FISCAL_WK_IN_QTR, 
  vju.FISCAL_YR_AND_QTR_DESC, 
  vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
  vju.BL_LICENSING_CONTRACT, 
  vju.Product, 
  vju.MJR_LIC_PROG_description, 
  vju.Order_Type, 
  vju.Temp2_VIP_No, 
  vju.Valid, 
  vju.Incumbent, 
  vju.Derived_Week, 
  vju.Temp1_Contract_CXL_Quarter, 
  vju.PayoutQtr, 
  vju.ADDITIONAL_TEXT, 
  vju.Internal_Segment, 
  vju.First_date, 
  vju.Right_year, 
  vju.PRODUCT_NAME_description, 
  vju.Renewal_Status, 
  vju.Renewal_To_Go,
  Null as Eligible_Qty_SUM,
  it6.Product as Right_Product,
  it6.Sum_Total_Sales_Qty_SUM as AVPP_Sum_of_Total_sales_Qty_sum,
  it6.SumOfCurrencyAmt as AVPP_Sum_of_currency,
  it6.Sum_LI_ARR_SUM as AVPP_SumOf_LI_ARR_SUM,
  it6.VIPPartnerProduct as AVPP_VIPPartnerProduct 
  from b2b_tmp.Joins_Update4_1 as vju
 inner join b2b_tmp.field_radar_02_01_output_temp6_pwc as it6  -- updated to point to non-static version
 on vju.VIPPartnerProduct = it6.VIPPartnerProduct);

-- COMMAND ----------

 drop table if exists b2b_tmp.Joins_Update4_3;
 Create table b2b_tmp.Joins_Update4_3 as
 (Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.ADDITIONAL_TEXT, 
 vju.Internal_Segment,
 vju.Eligible_Qty_SUM,
 vju.Right_Product,
 it5.Sum_ARR_opportunity as TVPP_sum_ARR_Opty ,   
 it5.Sum_Units_Opportunity_Partner_VIP_Wise as TVPP_Sum_units_opty_Partner_VIP_wise  ,  
 it5.VIPPartnerProduct as TVPP_VIPPartnerProduct 
 from b2b_tmp.Joins_Update4_2 as vju
 left join  b2b_tmp.field_radar_02_01_output_temp5_pwc it5  -- updated to point to non-static version
 on vju.AVPP_VIPPartnerProduct = it5.VIPPartnerProduct
 where it5.VIPPartnerProduct is null
Union all 
Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 Null as ADDITIONAL_TEXT, 
 Null as Internal_Segment,
 Null as Eligible_Qty_SUM,
 Null as Right_Product,
 it5.Sum_ARR_opportunity as TVPP_sum_ARR_Opty ,   
 it5.Sum_Units_Opportunity_Partner_VIP_Wise as TVPP_Sum_units_opty_Partner_VIP_wise  ,  
 it5.VIPPartnerProduct as TVPP_VIPPartnerProduct 
 from b2b_tmp.Joins_Update4_2 as vju
 inner join b2b_tmp.field_radar_02_01_output_temp5_pwc as it5  -- updated to point to non-static version
 on vju.AVPP_VIPPartnerProduct = it5.VIPPartnerProduct);

-- COMMAND ----------

 drop table if exists b2b_tmp.Joins_Update4_4;
 Create table b2b_tmp.Joins_Update4_4 as
 (Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.TVPP_sum_ARR_Opty ,   
 vju.TVPP_Sum_units_opty_Partner_VIP_wise  ,  
 vju.TVPP_VIPPartnerProduct,
 vju.ADDITIONAL_TEXT, 
 vju.Internal_Segment,
 vju.Eligible_Qty_SUM,
 vju.Right_Product,
 it7.Sum_Total_Sales_Qty_SUM as AVP_Sum_of_Total_Sales_Qty_sum,
 it7.SumOfCurrencyAmt as AVP_SumOfCurrencyAmt ,
 it7.Sum_LI_ARR_SUM as AVP_SumOf_LI_ARR_SUM,
 it7.VIPProduct as AVP_VIPProduct
 from b2b_tmp.Joins_Update4_3 as vju
 left join  b2b_tmp.field_radar_02_01_output_temp7_pwc as it7  -- updated to point to non-static version
 on vju.VIPProduct = it7.VIPProduct
 where it7.VIPProduct is null
 Union all
 Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.TVPP_sum_ARR_Opty ,   
 vju.TVPP_Sum_units_opty_Partner_VIP_wise  ,  
 vju.TVPP_VIPPartnerProduct,
 Null as ADDITIONAL_TEXT, 
 Null as Internal_Segment,
 Null as Eligible_Qty_SUM,
 Null as Right_Product,
 it7.Sum_Total_Sales_Qty_SUM as AVP_Sum_of_Total_Sales_Qty_sum,
 it7.SumOfCurrencyAmt as AVP_SumOfCurrencyAmt ,
 it7.Sum_LI_ARR_SUM as AVP_SumOf_LI_ARR_SUM,
 it7.VIPProduct as AVP_VIPProduct
 from b2b_tmp.Joins_Update4_3 as vju
 inner join  b2b_tmp.field_radar_02_01_output_temp7_pwc as it7  -- updated to point to non-static version
 on vju.VIPProduct = it7.VIPProduct);

-- COMMAND ----------

 drop table if exists b2b_tmp.Joins_Update4_5;
 Create table b2b_tmp.Joins_Update4_5 as
 (Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.TVPP_sum_ARR_Opty ,   
 vju.TVPP_Sum_units_opty_Partner_VIP_wise  ,  
 vju.TVPP_VIPPartnerProduct,
 vju.AVP_Sum_of_Total_Sales_Qty_sum,
 vju.AVP_SumOfCurrencyAmt ,
 vju.AVP_SumOf_LI_ARR_SUM,
 vju.AVP_VIPProduct,
 vju.ADDITIONAL_TEXT, 
 vju.Internal_Segment,
 vju.Eligible_Qty_SUM,
 vju.Right_Product,
 it2a.Reseller_Geo_Partner,
 it2a.Sum_Units_Opportunity_Partner_VIP_Wise as TVP_Sum_Units_Opportunity_Partner_VIP_Wise,
 it2a.Sum_ARR_opportunity as TVP_Sum_ARR_Opportunity
 from b2b_tmp.Joins_Update4_4 as vju
 left join b2b_tmp.field_radar_02_01_output_temp2a_pwc as it2a  -- updated to point to non-static version
 on vju.AVP_VIPProduct = it2a.VIPProduct
 where it2a.VIPProduct is null
 Union all
 Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.TVPP_sum_ARR_Opty ,   
 vju.TVPP_Sum_units_opty_Partner_VIP_wise  ,  
 vju.TVPP_VIPPartnerProduct,
 vju.AVP_Sum_of_Total_Sales_Qty_sum,
 vju.AVP_SumOfCurrencyAmt ,
 vju.AVP_SumOf_LI_ARR_SUM,
 vju.AVP_VIPProduct,
 vju.ADDITIONAL_TEXT, 
 vju.Internal_Segment,
 Null as Eligible_Qty_SUM,
 vju.Right_Product,
 it2a.Reseller_Geo_Partner,
 it2a.Sum_Units_Opportunity_Partner_VIP_Wise as TVP_Sum_Units_Opportunity_Partner_VIP_Wise,
 it2a.Sum_ARR_opportunity as TVP_Sum_ARR_Opportunity
 from b2b_tmp.Joins_Update4_4 as vju
 inner join b2b_tmp.field_radar_02_01_output_temp2a_pwc as it2a  -- updated to point to non-static version
 on vju.AVP_VIPProduct = it2a.VIPProduct);

-- COMMAND ----------

/*
In Alteryx, this is the code for Joins Update4 in centre of workflow BEFORE the massive central logic
*/

drop table if exists b2b_tmp.Joins_Update4_6;
Create table b2b_tmp.Joins_Update4_6 as
 (Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.TVPP_sum_ARR_Opty,   
 vju.TVPP_Sum_units_opty_Partner_VIP_wise,  
 vju.TVPP_VIPPartnerProduct,
 vju.AVP_Sum_of_Total_Sales_Qty_sum,
 vju.AVP_SumOfCurrencyAmt,
 vju.AVP_SumOf_LI_ARR_SUM,
 vju.AVP_VIPProduct,
 vju.Reseller_Geo_Partner,
 vju.TVP_Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.TVP_Sum_ARR_Opportunity,
 vju.ADDITIONAL_TEXT, 
 vju.Internal_Segment,
 vju.Eligible_Qty_SUM,
 vju.Right_Product,
 it9i.Sum_Total_Sales_Qty_SUM as AVPI_Sum_of_Total_Sales_Qty_sum,
 it9i.SumOfCurrencyAmt as AVPI_SumOfCurrencyAmount,
 it9i.Sum_LI_ARR_SUM as AVPI_SumOf_LI_ARR_SUM
 from b2b_tmp.Joins_Update4_5 as vju
 left join b2b_tmp.field_radar_02_03_output_Temp9_pwc as it9i
 on vju.VIPProduct = it9i.VIPProduct
 where it9i.VIPProduct is null
 Union all
 Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.TVPP_sum_ARR_Opty,   
 vju.TVPP_Sum_units_opty_Partner_VIP_wise,  
 vju.TVPP_VIPPartnerProduct,
 vju.AVP_Sum_of_Total_Sales_Qty_sum,
 vju.AVP_SumOfCurrencyAmt,
 vju.AVP_SumOf_LI_ARR_SUM,
 vju.AVP_VIPProduct,
 vju.Reseller_Geo_Partner,
 vju.TVP_Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.TVP_Sum_ARR_Opportunity,
 Null as ADDITIONAL_TEXT, 
 Null as Internal_Segment,
 Null as Eligible_Qty_SUM,
 Null as Right_Product,
 it9i.Sum_Total_Sales_Qty_SUM as AVPI_Sum_of_Total_Sales_Qty_sum,
 it9i.SumOfCurrencyAmt as AVPI_SumOfCurrencyAmount,
 it9i.Sum_LI_ARR_SUM as AVPI_SumOf_LI_ARR_SUM
 from b2b_tmp.Joins_Update4_5 as vju
 inner join b2b_tmp.field_radar_02_03_output_Temp9_pwc as it9i
 on vju.VIPProduct = it9i.VIPProduct);

-- COMMAND ----------

 drop table if exists b2b_tmp.Joins_Update4_7;
 Create table b2b_tmp.Joins_Update4_7 as
 (Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.TVPP_sum_ARR_Opty,   
 vju.TVPP_Sum_units_opty_Partner_VIP_wise,  
 vju.TVPP_VIPPartnerProduct,
 vju.AVP_Sum_of_Total_Sales_Qty_sum,
 vju.AVP_SumOfCurrencyAmt,
 vju.AVP_SumOf_LI_ARR_SUM,
 vju.AVP_VIPProduct,
 vju.Reseller_Geo_Partner,
 vju.TVP_Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.TVP_Sum_ARR_Opportunity,
 vju.AVPI_Sum_of_Total_Sales_Qty_sum,
 vju.AVPI_SumOfCurrencyAmount,
 vju.AVPI_SumOf_LI_ARR_SUM,
 vju.ADDITIONAL_TEXT, 
 vju.Internal_Segment,
 vju.Eligible_Qty_SUM,
 vju.Right_Product,
 it9bn.Sum_Total_Sales_Qty_SUM as AVPNI_Sum_of_Total_sales_QTY_Sum,
 it9bn.Sum_LI_ARR_SUM as AVPNI_SumOf_LI_ARR_SUM,	
 it9bn.SumOfCurrencyAmt	as AVPNI_SumOfCurrencyAmount
 from b2b_tmp.Joins_Update4_6 as vju
 left join b2b_tmp.field_radar_02_03_output_Temp9b_pwc as it9bn
 on vju.VIPProduct = it9bn.VIPProduct
 where it9bn.VIPProduct is null
 Union all
 Select vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_Sum_of_currency,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,
 vju.TVPP_sum_ARR_Opty,   
 vju.TVPP_Sum_units_opty_Partner_VIP_wise,  
 vju.TVPP_VIPPartnerProduct,
 vju.AVP_Sum_of_Total_Sales_Qty_sum,
 vju.AVP_SumOfCurrencyAmt,
 vju.AVP_SumOf_LI_ARR_SUM,
 vju.AVP_VIPProduct,
 vju.Reseller_Geo_Partner,
 vju.TVP_Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.TVP_Sum_ARR_Opportunity,
 vju.AVPI_Sum_of_Total_Sales_Qty_sum,
 vju.AVPI_SumOfCurrencyAmount,
 vju.AVPI_SumOf_LI_ARR_SUM,
 Null as ADDITIONAL_TEXT, 
 Null as Internal_Segment,
 Null as Eligible_Qty_SUM,
 Null as Right_Product,
 it9bn.Sum_Total_Sales_Qty_SUM as AVPNI_Sum_of_Total_sales_QTY_Sum,
 it9bn.Sum_LI_ARR_SUM as AVPNI_SumOf_LI_ARR_SUM,	
 it9bn.SumOfCurrencyAmt	as AVPNI_SumOfCurrencyAmount
 from b2b_tmp.Joins_Update4_6 as vju
 inner join b2b_tmp.field_radar_02_03_output_Temp9b_pwc as it9bn
 on vju.VIPProduct = it9bn.VIPProduct);

-- COMMAND ----------

Create or replace view view_Filter_part1_update4_cleansing as
Select nvl(vju.AVPP_Sum_of_currency,0) as AVPP_Sum_of_currency,
 nvl(vju.TVPP_sum_ARR_Opty,0) as TVPP_sum_ARR_Opty,
 nvl(vju.TVPP_Sum_units_opty_Partner_VIP_wise,0) as TVPP_Sum_units_opty_Partner_VIP_wise,
 nvl(vju.TVP_Sum_Units_Opportunity_Partner_VIP_Wise,0) as TVP_Sum_Units_Opportunity_Partner_VIP_Wise,
 nvl(vju.TVP_Sum_ARR_Opportunity,0) as TVP_Sum_ARR_Opportunity,
 vju.Record_ID, 
 vju.CXL_Date,
 vju.ORDER_DATE_description,
 vju.Total_Sales_USD_SUM,
 vju.Sum_ARR_opportunity,
 vju.Eligible_Amt_SUM,
 vju.Sum_Units_Opportunity_Partner_VIP_Wise,
 vju.Sum_Units_opportunity,
 vju.CurrencyAmt,
 vju.Total_Sales_Qty_SUM,
 vju.Total_Sales_Geo_Amt_SUM,
 vju.LI_ARR_SUM,
 vju.PartnerGeo,
 vju.PartnerRegion,
 vju.PartnerSalesDistrict,
 vju.FinalPartnerLevel,
 vju.AT_CXL_DATE_DATE_KEY_ATTR,
 vju.VIP_No,
 vju.FinalPartnerName,
 vju.PartnerMarketArea,
 vju.Contract_CXL_Quarter,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description,
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
 vju.Family_Name, 
 vju.REGION_description, 
 vju.PRODUCT_CONFIG_description, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
 vju.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
 vju.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
 vju.MARKET_AREA_description, 
 vju.GEO_description, 
 vju.C_FIN_DOC_CURR, 
 vju.PurchaseQtr, 
 vju.VIPFiscalQtr, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
 vju.BL_END_USER_NAME1, 
 vju.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
 vju.VIPProduct, 
 vju.GeoVIPPartner, 
 vju.C_MARKET_SEGMENT, 
 vju.RESELLER_GEO_PARTNER_GEO_description, 
 vju.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
 vju.RESELLER_GEO_PARTNER_REGION_description, 
 vju.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.SALES_DISTRICT_description, 
 vju.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
 vju.VIPPartnerProduct, 
 vju.VIPQtr, 
 vju.VIPPartner, 
 vju.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
 vju.ENTERPRISE_BU_description, 
 vju.FISCAL_WK_IN_QTR, 
 vju.FISCAL_YR_AND_QTR_DESC, 
 vju.SALES_OPS_RESELLER_PARTNERROLLUP, 
 vju.BL_LICENSING_CONTRACT, 
 vju.Product, 
 vju.MJR_LIC_PROG_description, 
 vju.Order_Type, 
 vju.Temp2_VIP_No, 
 vju.Valid, 
 vju.Incumbent, 
 vju.Derived_Week, 
 vju.Temp1_Contract_CXL_Quarter, 
 vju.PayoutQtr,  
 vju.First_date, 
 vju.Right_year, 
 vju.PRODUCT_NAME_description, 
 vju.Renewal_Status, 
 vju.Renewal_To_Go,
 vju.AVPP_Sum_of_Total_sales_Qty_sum,
 vju.AVPP_SumOf_LI_ARR_SUM,
 vju.AVPP_VIPPartnerProduct,    
 vju.TVPP_VIPPartnerProduct,
 vju.AVP_Sum_of_Total_Sales_Qty_sum,
 vju.AVP_SumOfCurrencyAmt,
 vju.AVP_SumOf_LI_ARR_SUM,
 vju.AVP_VIPProduct,
 vju.Reseller_Geo_Partner,
 vju.AVPI_Sum_of_Total_Sales_Qty_sum,
 vju.AVPI_SumOfCurrencyAmount,
 vju.AVPI_SumOf_LI_ARR_SUM,
 vju.ADDITIONAL_TEXT, 
 vju.Internal_Segment,
 vju.Eligible_Qty_SUM,
 vju.Right_Product,
 vju.AVPNI_Sum_of_Total_sales_QTY_Sum,
 vju.AVPNI_SumOf_LI_ARR_SUM,	
 vju.AVPNI_SumOfCurrencyAmount,
 0 as Expansion_Seats,
 0 as Expansion_ARR_temp,
 0 as Expansion_NIR_temp,
 0 as Units_Expansion_temp
 from b2b_tmp.Joins_Update4_7 as vju

-- COMMAND ----------

Create or replace view view_Filter_part1_update4_filter1_true as
Select *  from view_Filter_part1_update4_cleansing
where Renewal_Status = 'Expansion';

Create or replace view view_Filter_part1_update4_filter1_false as
Select *  from view_Filter_part1_update4_cleansing
where Renewal_Status != 'Expansion' or Renewal_Status is null;

-- COMMAND ----------

Create or replace view view_Filter_part1_update4_filter2_true as
Select *  from view_Filter_part1_update4_filter1_true
where Incumbent = 'Incumbent';

Create or replace view view_Filter_part1_update4_filter2_false as
Select *  from view_Filter_part1_update4_filter1_true
where Incumbent != 'Incumbent';

-- COMMAND ----------

Create or replace view view_Filter_part1_update4_filter3_true as
Select *  from view_Filter_part1_update4_filter2_true
where TVPP_sum_ARR_Opty >0;

Create or replace view view_Filter_part1_update4_filter3_false as
Select *  from view_Filter_part1_update4_filter2_true
where TVPP_sum_ARR_Opty <=0;

-- COMMAND ----------

Create or replace view view_NIR_filter1 as
Select Record_ID,
CurrencyAmt,
AVPP_Sum_of_currency,
Expansion_Seats,
Expansion_ARR_temp,
Case 
when AVPP_Sum_of_currency > TVPP_sum_ARR_Opty then
  Case 
  when IndPartnerExp > IncumPartnersExp then IncumPartnersExp
  else IndPartnerExp
  end
else 0
end as Expansion_NIR_temp,
Units_Expansion_temp
from (Select *, (AVPP_Sum_of_currency-TVPP_sum_ARR_Opty) as IndPartnerExp,
 (AVPI_SumOfCurrencyAmount-TVP_Sum_ARR_Opportunity) as IncumPartnersExp
 from view_Filter_part1_update4_filter3_true)

-- COMMAND ----------

Create or replace view view_NIR_filter2 as
Select Record_ID,
CurrencyAmt,
AVPP_Sum_of_currency,
Expansion_Seats,
Expansion_ARR_temp,
Case 
when TVP_Sum_ARR_Opportunity>0 then
 Case 
 when (AVPI_SumOfCurrencyAmount > TVP_Sum_ARR_Opportunity) then
   Case
   When (IncumPartnersExpansion >= AVPP_Sum_of_currency) then AVPP_Sum_of_currency
   else IncumPartnersExpansion
   end
 else 0 
 end
else AVPP_Sum_of_currency
end as Expansion_NIR_temp,
Units_Expansion_temp
from (Select *,
 (AVPI_SumOfCurrencyAmount-TVP_Sum_ARR_Opportunity) as IncumPartnersExpansion
 from view_Filter_part1_update4_filter3_false)

-- COMMAND ----------

Create or replace view view_NIR_CalcNonIncExp_filter as
Select Record_ID,
CurrencyAmt,
AVPP_Sum_of_currency,
Expansion_Seats,
Expansion_ARR_temp,
Case
when TVP_Sum_ARR_Opportunity > 0 then
  Case 
  when AVPI_SumOfCurrencyAmount > TVP_Sum_ARR_Opportunity then AVPP_Sum_of_currency
  else
   Case
   When AVP_SumOfCurrencyAmt>TVP_Sum_ARR_Opportunity then (AVP_SumOfCurrencyAmt-TVP_Sum_ARR_Opportunity)*MultipleNon_IncumPartnersRatio
   else 0
   end
  end
else AVPP_Sum_of_currency
end as Expansion_NIR_temp,
Units_Expansion_temp
from 
(Select *,
 Case
 when AVPNI_SumOfCurrencyAmount>0 then (AVPP_Sum_of_currency/AVPNI_SumOfCurrencyAmount)
 else 0 
 end as MultipleNon_IncumPartnersRatio
from view_filter_part1_update4_filter2_false);

-- COMMAND ----------

drop table if exists b2b_tmp.nir_union;
Create table b2b_tmp.nir_union as
(Select Record_ID,
Expansion_Seats,
nvl((Expansion_NIR_temp*(CurrencyAmt/AVPP_Sum_of_currency)),0) as Expansion_NIR from view_NIR_filter1
Union all
Select Record_ID,
Expansion_Seats,
nvl((Expansion_NIR_temp*(CurrencyAmt/AVPP_Sum_of_currency)),0) as Expansion_NIR from view_NIR_filter2
Union all
Select Record_ID,
Expansion_Seats,
nvl((Expansion_NIR_temp*(CurrencyAmt/AVPP_Sum_of_currency)),0) as Expansion_NIR from view_NIR_CalcNonIncExp_filter
Union all
Select Record_ID,
Expansion_Seats,
nvl((Expansion_NIR_temp*(CurrencyAmt/AVPP_Sum_of_currency)),0) as Expansion_NIR from view_Filter_part1_update4_filter1_false);

-- COMMAND ----------

Create or replace view view_Seats_filter1 as
Select Record_ID,
Total_Sales_Qty_SUM,
AVPP_Sum_of_Total_sales_Qty_sum,
Case 
when TVPP_Sum_units_opty_Partner_VIP_wise>0 then
  Case 
  when (AVPP_Sum_of_Total_sales_Qty_sum > TVPP_Sum_units_opty_Partner_VIP_wise) then
    Case 
    when IndPartnerExp > IncumPartnersExp then IncumPartnersExp
    else IndPartnerExp
    end
  else 0
  end
else 
  Case
  when TVP_Sum_Units_Opportunity_Partner_VIP_Wise > 0 then
    Case
    When AVPI_Sum_of_Total_Sales_Qty_sum > TVP_Sum_Units_Opportunity_Partner_VIP_Wise then
      Case 
      When (IncumPartnersExp >= AVPP_Sum_of_Total_sales_Qty_sum) then AVPP_Sum_of_Total_sales_Qty_sum
      else IncumPartnersExp
      end
    else 0
    end
  else AVPP_Sum_of_Total_sales_Qty_sum
  end
end as Units_Expansion_temp
from (Select *,
 (AVPP_Sum_of_Total_sales_Qty_sum-TVPP_Sum_units_opty_Partner_VIP_wise) as IndPartnerExp,
 (AVPI_Sum_of_Total_sales_Qty_sum-TVP_Sum_Units_Opportunity_Partner_VIP_Wise) as IncumPartnersExp
 from view_Filter_part1_update4_filter2_true)

-- COMMAND ----------

Create or replace view view_Seats_CalcNonIncExp_filter as
Select Record_ID,
Total_Sales_Qty_SUM,
AVPP_Sum_of_Total_sales_Qty_sum,
Case
when TVP_Sum_Units_Opportunity_Partner_VIP_Wise > 0 then
  Case 
  when AVPI_Sum_of_Total_sales_Qty_sum > TVP_Sum_Units_Opportunity_Partner_VIP_Wise then AVPP_Sum_of_Total_sales_Qty_sum
  else
   Case
   When AVP_Sum_of_Total_sales_Qty_sum>TVP_Sum_Units_Opportunity_Partner_VIP_Wise then (AVP_Sum_of_Total_sales_Qty_sum-TVP_Sum_Units_Opportunity_Partner_VIP_Wise)*MultipleNon_IncumPartnersRatio
   else 0
   end
  end
else AVPP_Sum_of_Total_sales_Qty_sum
end as Units_Expansion_temp
from 
(Select *,
 Case
 when AVPNI_Sum_of_Total_sales_QTY_Sum>0 then (AVPP_Sum_of_Total_sales_Qty_sum/AVPNI_Sum_of_Total_sales_QTY_Sum)
else 0 
end as MultipleNon_IncumPartnersRatio
from view_filter_part1_update4_filter2_false);

-- COMMAND ----------

drop table if exists b2b_tmp.seats_union;
Create table b2b_tmp.seats_union as
(Select Record_ID,
nvl((Units_Expansion_temp*(Total_Sales_Qty_SUM/AVPP_Sum_of_Total_sales_Qty_sum)),0) as Units_Expansion from view_Seats_filter1
Union all
Select Record_ID,
nvl((Units_Expansion_temp*(Total_Sales_Qty_SUM/AVPP_Sum_of_Total_sales_Qty_sum)),0) as Units_Expansion from view_Seats_CalcNonIncExp_filter
Union all
Select Record_ID,
nvl((Units_Expansion_temp*(Total_Sales_Qty_SUM/AVPP_Sum_of_Total_sales_Qty_sum)),0) as Units_Expansion from view_Filter_part1_update4_filter1_false);

-- COMMAND ----------

Create or replace view view_ARR_filter1 as
Select Record_ID,
LI_ARR_SUM,
AVPP_SumOf_LI_ARR_SUM,
Case 
when AVPP_SumOf_LI_ARR_SUM > TVPP_sum_ARR_Opty then
  Case 
  when IndPartnerExp > IncumPartnersExp then IncumPartnersExp
  else IndPartnerExp
  end
else 0
end as Expansion_ARR_temp
from (Select *, (AVPP_SumOf_LI_ARR_SUM-TVPP_sum_ARR_Opty) as IndPartnerExp,
 (AVPI_SumOf_LI_ARR_SUM-TVP_Sum_ARR_Opportunity) as IncumPartnersExp
 from view_Filter_part1_update4_filter3_true)

-- COMMAND ----------

Create or replace view view_ARR_filter2 as
Select Record_ID,
LI_ARR_SUM,
AVPP_SumOf_LI_ARR_SUM,
Case 
when TVP_Sum_ARR_Opportunity>0 then
 Case 
 when (AVPI_SumOf_LI_ARR_SUM > TVP_Sum_ARR_Opportunity) then
   Case
   When (IncumPartnersExpansion >= AVPP_SumOf_LI_ARR_SUM) then AVPP_SumOf_LI_ARR_SUM
   else IncumPartnersExpansion
   end
 else 0 
 end
else AVPP_SumOf_LI_ARR_SUM
end as Expansion_ARR_temp
from (Select *,
 (AVPI_SumOf_LI_ARR_SUM-TVP_Sum_ARR_Opportunity) as IncumPartnersExpansion
 from view_Filter_part1_update4_filter3_false)

-- COMMAND ----------

Create or replace view view_ARR_CalcNonIncExp_filter as
Select Record_ID,
LI_ARR_SUM,
AVPP_SumOf_LI_ARR_SUM,
Case
when TVP_Sum_ARR_Opportunity > 0 then
  Case 
  when AVPI_SumOf_LI_ARR_SUM > TVP_Sum_ARR_Opportunity then AVPP_SumOf_LI_ARR_SUM
  else
   Case
   When AVP_SumOf_LI_ARR_SUM>TVP_Sum_ARR_Opportunity then (AVP_SumOf_LI_ARR_SUM-TVP_Sum_ARR_Opportunity)*MultipleNon_IncumPartnersRatio
   else 0
   end
  end
else AVPP_SumOf_LI_ARR_SUM
end as Expansion_ARR_temp
from 
(Select *,
 Case
 when AVPNI_SumOf_LI_ARR_SUM>0 then (AVPP_SumOf_LI_ARR_SUM/AVPNI_SumOf_LI_ARR_SUM)
else 0 
end as MultipleNon_IncumPartnersRatio
from view_filter_part1_update4_filter2_false);

-- COMMAND ----------

drop table if exists b2b_tmp.arr_union;
Create table b2b_tmp.arr_union as
(Select Record_ID,
nvl((Expansion_ARR_temp*(LI_ARR_SUM/AVPP_SumOf_LI_ARR_SUM)),0) as Expansion_ARR from view_ARR_filter1
Union all
Select Record_ID,
nvl((Expansion_ARR_temp*(LI_ARR_SUM/AVPP_SumOf_LI_ARR_SUM)),0) as Expansion_ARR from view_ARR_filter2
Union all
Select Record_ID,
nvl((Expansion_ARR_temp*(LI_ARR_SUM/AVPP_SumOf_LI_ARR_SUM)),0) as Expansion_ARR from view_ARR_CalcNonIncExp_filter
Union all
Select Record_ID,
nvl((Expansion_ARR_temp*(LI_ARR_SUM/AVPP_SumOf_LI_ARR_SUM)),0) as Expansion_ARR from view_Filter_part1_update4_filter1_false);

-- COMMAND ----------

Create or replace view view_Join_Multiple as 
Select ven.*,vt.Expansion_ARR,vt.Units_Expansion from b2b_tmp.nir_union as ven
full outer join
(Select ves.Record_ID,ves.Units_Expansion,vea.Expansion_ARR from b2b_tmp.seats_union as ves
full outer join b2b_tmp.arr_union as vea
on ves.Record_ID = vea.Record_ID) as vt
on ven.Record_ID = vt.Record_ID

-- COMMAND ----------

Create or replace view view_Join_Union_AfterJM as
Select vfl.Record_ID, 
  vfl.CXL_Date, 
  vfl.ORDER_DATE_description, 
  vfl.Total_Sales_USD_SUM, 
  vfl.Sum_ARR_opportunity, 
  vfl.Eligible_Amt_SUM, 
  vfl.Sum_Units_Opportunity_Partner_VIP_Wise, 
  vfl.Sum_Units_opportunity, 
  vfl.CurrencyAmt, 
  vfl.Eligible_Qty_SUM,
  vfl.Total_Sales_Qty_SUM, 
  vfl.Total_Sales_Geo_Amt_SUM, 
  vfl.LI_ARR_SUM, 
  vfl.PartnerGeo, 
  vfl.PartnerRegion, 
  vfl.PartnerSalesDistrict, 
  vfl.FinalPartnerLevel, 
  vfl.AT_CXL_DATE_DATE_KEY_ATTR, 
  vfl.VIP_No, 
  vfl.FinalPartnerName, 
  vfl.PartnerMarketArea, 
  vfl.Contract_CXL_Quarter, 
  vfl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description, 
  vfl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
  vfl.Family_Name, 
  vfl.REGION_description, 
  vfl.PRODUCT_CONFIG_description, 
  vfl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
  vfl.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
  vfl.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
  vfl.MARKET_AREA_description, 
  vfl.GEO_description, 
  vfl.C_FIN_DOC_CURR, 
  vfl.PurchaseQtr, 
  vfl.VIPFiscalQtr, 
  vfl.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
  vfl.BL_END_USER_NAME1, 
  vfl.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
  vfl.VIPProduct, 
  vfl.GeoVIPPartner, 
  vfl.C_MARKET_SEGMENT, 
  vfl.RESELLER_GEO_PARTNER_GEO_description, 
  vfl.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
  vfl.RESELLER_GEO_PARTNER_REGION_description, 
  vfl.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
  vfl.SALES_DISTRICT_description, 
  vfl.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
  vfl.VIPPartnerProduct, 
  vfl.VIPQtr, 
  vfl.VIPPartner, 
  vfl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
  vfl.ENTERPRISE_BU_description, 
  vfl.FISCAL_WK_IN_QTR, 
  vfl.FISCAL_YR_AND_QTR_DESC, 
  vfl.SALES_OPS_RESELLER_PARTNERROLLUP, 
  vfl.BL_LICENSING_CONTRACT, 
  vfl.Product, 
  vfl.MJR_LIC_PROG_description, 
  vfl.Order_Type, 
  vfl.Temp2_VIP_No, 
  vfl.Valid, 
  vfl.Incumbent, 
  vfl.Derived_Week, 
  vfl.Temp1_Contract_CXL_Quarter, 
  vfl.PayoutQtr,
  vfl.Renewal_Status, 
  vfl.ADDITIONAL_TEXT, 
  vfl.Internal_Segment, 
  vfl.First_date, 
  vfl.Right_year, 
  vfl.PRODUCT_NAME_description, 
  vfl.Renewal_To_Go,
  vjm.Units_Expansion,			
  vjm.Expansion_Seats,			
  vjm.Expansion_NIR,			
  vjm.Expansion_ARR from view_Final_left_3B as vfl
 left outer join view_Join_Multiple as vjm
 on vfl.Record_ID = vjm.Record_ID
 where vjm.Record_ID is null
 Union all
 Select vfl.Record_ID, 
  vfl.CXL_Date, 
  vfl.ORDER_DATE_description, 
  vfl.Total_Sales_USD_SUM, 
  vfl.Sum_ARR_opportunity, 
  vfl.Eligible_Amt_SUM, 
  vfl.Sum_Units_Opportunity_Partner_VIP_Wise, 
  vfl.Sum_Units_opportunity, 
  vfl.CurrencyAmt, 
  vfl.Eligible_Qty_SUM,
  vfl.Total_Sales_Qty_SUM, 
  vfl.Total_Sales_Geo_Amt_SUM, 
  vfl.LI_ARR_SUM, 
  vfl.PartnerGeo, 
  vfl.PartnerRegion, 
  vfl.PartnerSalesDistrict, 
  vfl.FinalPartnerLevel, 
  vfl.AT_CXL_DATE_DATE_KEY_ATTR, 
  vfl.VIP_No, 
  vfl.FinalPartnerName, 
  vfl.PartnerMarketArea, 
  vfl.Contract_CXL_Quarter, 
  vfl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description, 
  vfl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
  vfl.Family_Name, 
  vfl.REGION_description, 
  vfl.PRODUCT_CONFIG_description, 
  vfl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
  vfl.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
  vfl.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
  vfl.MARKET_AREA_description, 
  vfl.GEO_description, 
  vfl.C_FIN_DOC_CURR, 
  vfl.PurchaseQtr, 
  vfl.VIPFiscalQtr, 
  vfl.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
  vfl.BL_END_USER_NAME1, 
  vfl.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
  vfl.VIPProduct, 
  vfl.GeoVIPPartner, 
  vfl.C_MARKET_SEGMENT, 
  vfl.RESELLER_GEO_PARTNER_GEO_description, 
  vfl.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
  vfl.RESELLER_GEO_PARTNER_REGION_description, 
  vfl.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
  vfl.SALES_DISTRICT_description, 
  vfl.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
  vfl.VIPPartnerProduct, 
  vfl.VIPQtr, 
  vfl.VIPPartner, 
  vfl.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
  vfl.ENTERPRISE_BU_description, 
  vfl.FISCAL_WK_IN_QTR, 
  vfl.FISCAL_YR_AND_QTR_DESC, 
  vfl.SALES_OPS_RESELLER_PARTNERROLLUP, 
  vfl.BL_LICENSING_CONTRACT, 
  vfl.Product, 
  vfl.MJR_LIC_PROG_description, 
  vfl.Order_Type, 
  vfl.Temp2_VIP_No, 
  vfl.Valid, 
  vfl.Incumbent, 
  vfl.Derived_Week, 
  vfl.Temp1_Contract_CXL_Quarter, 
  vfl.PayoutQtr,
  vfl.Renewal_Status, 
  Null as ADDITIONAL_TEXT, 
  Null as Internal_Segment, 
  vfl.First_date, 
  vfl.Right_year, 
  Null as PRODUCT_NAME_description, 
  vfl.Renewal_To_Go,
  vjm.Units_Expansion,			
  vjm.Expansion_Seats,			
  vjm.Expansion_NIR,			
  vjm.Expansion_ARR from view_Final_left_3B as vfl
 inner join view_Join_Multiple as vjm
 on vfl.Record_ID = vjm.Record_ID

-- COMMAND ----------

/*
This is first set of logic just after the large central column in Alteryx code. Called Update 6 in Alteryx
*/

Create or replace view view_Update6_Formula as
Select *,
Case 
when Renewal_Status ='Expansion' then (CurrencyAmt-Expansion_NIR)
else CurrencyAmt
end as Final_Revenue,
Case 
when Renewal_Status ='Expansion' then (LI_ARR_SUM-Expansion_ARR)
else LI_ARR_SUM
end as Final_Revenue_ARR
from view_Join_Union_AfterJM

-- COMMAND ----------

Create or replace view view_Update7_IJoin as
Select * from view_Update6_Formula as vuf
inner join view_calendar as vc
on vuf.PayoutQtr = vc.year_and_qtr;

Create or replace view view_Update7_Filter as
Select * from view_Update7_IJoin
where Renewal_Status = 'Expansion';

-- COMMAND ----------

Create or replace view view_Update7_Select_Formula as
Select vuf.Record_ID, 
  vuf.CXL_Date, 
  vuf.ORDER_DATE_description, 
  vuf.Total_Sales_USD_SUM, 
  vuf.Sum_ARR_opportunity, 
  vuf.Eligible_Amt_SUM, 
  vuf.Sum_Units_Opportunity_Partner_VIP_Wise, 
  vuf.Sum_Units_opportunity, 
  vuf.CurrencyAmt, 
  vuf.Eligible_Qty_SUM,
  vuf.Total_Sales_Qty_SUM, 
  vuf.Total_Sales_Geo_Amt_SUM, 
  vuf.LI_ARR_SUM, 
  vuf.PartnerGeo, 
  vuf.PartnerRegion, 
  vuf.PartnerSalesDistrict, 
  vuf.FinalPartnerLevel, 
  vuf.AT_CXL_DATE_DATE_KEY_ATTR, 
  vuf.VIP_No, 
  vuf.FinalPartnerName, 
  vuf.PartnerMarketArea, 
  vuf.Contract_CXL_Quarter, 
  vuf.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description, 
  vuf.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
  vuf.Family_Name, 
  vuf.REGION_description, 
  vuf.PRODUCT_CONFIG_description, 
  vuf.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
  vuf.SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
  vuf.SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
  vuf.MARKET_AREA_description, 
  vuf.GEO_description, 
  vuf.C_FIN_DOC_CURR, 
  vuf.PurchaseQtr, 
  vuf.VIPFiscalQtr, 
  vuf.ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
  vuf.BL_END_USER_NAME1, 
  vuf.ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
  vuf.VIPProduct, 
  vuf.GeoVIPPartner, 
  vuf.C_MARKET_SEGMENT, 
  vuf.RESELLER_GEO_PARTNER_GEO_description, 
  vuf.RESELLER_GEO_PARTNER_MARKET_AREA_description, 
  vuf.RESELLER_GEO_PARTNER_REGION_description, 
  vuf.RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
  vuf.SALES_DISTRICT_description, 
  vuf.SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
  vuf.VIPPartnerProduct, 
  vuf.VIPQtr, 
  vuf.VIPPartner, 
  vuf.SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
  vuf.ENTERPRISE_BU_description, 
  vuf.FISCAL_WK_IN_QTR, 
  vuf.FISCAL_YR_AND_QTR_DESC, 
  vuf.SALES_OPS_RESELLER_PARTNERROLLUP, 
  vuf.BL_LICENSING_CONTRACT, 
  vuf.Product, 
  vuf.MJR_LIC_PROG_description, 
  Renewal_Status as Order_Type, 
  vuf.Temp2_VIP_No, 
  vuf.Valid, 
  vuf.Incumbent, 
  vuf.Derived_Week, 
  vuf.Temp1_Contract_CXL_Quarter, 
  vuf.PayoutQtr,
  vuf.Renewal_Status, 
  vuf.ADDITIONAL_TEXT, 
  vuf.Internal_Segment, 
  vuf.First_date, 
  vuf.Right_year, 
  vuf.PRODUCT_NAME_description, 
  vuf.Renewal_To_Go,
  vuf.Units_Expansion,			
  vuf.Expansion_Seats,			
  vuf.Expansion_NIR,			
  vuf.Expansion_ARR,
  Expansion_NIR as Final_Revenue,		
  Expansion_ARR as Final_Revenue_ARR 
from view_Update7_Filter as vuf

-- COMMAND ----------

drop table if exists b2b_tmp.Update7_FinalUnion;
Create table b2b_tmp.Update7_FinalUnion as
(Select * from view_Update6_Formula
Union all
Select * from view_Update7_Select_Formula);

-- COMMAND ----------

Create or replace view view_Select_Formula_AfterUpdate7 as
Select ts.*,
Case
  when ts.Order_Type = 'Expansion' then ts.FISCAL_YR_AND_QTR_DESC
  else ts.Payout_Quarter_wo_Exp
end as PayoutQtr
from ( Select Record_ID, 
  CXL_Date, 
  ORDER_DATE_description, 
  Total_Sales_USD_SUM, 
  Sum_ARR_opportunity, 
  Eligible_Amt_SUM, 
  Sum_Units_Opportunity_Partner_VIP_Wise, 
  Sum_Units_opportunity, 
  CurrencyAmt, 
  Eligible_Qty_SUM,
  Total_Sales_Qty_SUM, 
  Total_Sales_Geo_Amt_SUM, 
  LI_ARR_SUM, 
  PartnerGeo, 
  PartnerRegion, 
  PartnerSalesDistrict, 
  FinalPartnerLevel, 
  AT_CXL_DATE_DATE_KEY_ATTR, 
  VIP_No, 
  FinalPartnerName, 
  PartnerMarketArea, 
  Contract_CXL_Quarter, 
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_MARKET_AREA_description, 
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_GEO_description, 
  Family_Name, 
  REGION_description, 
  PRODUCT_CONFIG_description, 
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_REGION_description, 
  SALES_OPS_DISTRIBUTOR_PARTNERROLLUP, 
  SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL, 
  MARKET_AREA_description, 
  GEO_description, 
  C_FIN_DOC_CURR, 
  PurchaseQtr, 
  VIPFiscalQtr, 
  ATD_CXL_DATE_FISCAL_YR_AND_PER_DESC, 
  BL_END_USER_NAME1, 
  ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC, 
  VIPProduct, 
  GeoVIPPartner, 
  C_MARKET_SEGMENT, 
  RESELLER_GEO_PARTNER_GEO_description, 
  RESELLER_GEO_PARTNER_MARKET_AREA_description, 
  RESELLER_GEO_PARTNER_REGION_description, 
  RESELLER_GEO_PARTNER_SALES_DISTRICT_description, 
  SALES_DISTRICT_description, 
  SALES_OPS_DISTRIBUTOR_CHANNEL_PROGRAM_LEVEL, 
  VIPPartnerProduct, 
  VIPQtr, 
  VIPPartner, 
  SALES_OPS_DISTRIBUTOR_GEO_PARTNER_SALES_DISTRICT_description, 
  ENTERPRISE_BU_description, 
  FISCAL_WK_IN_QTR, 
  FISCAL_YR_AND_QTR_DESC, 
  SALES_OPS_RESELLER_PARTNERROLLUP, 
  BL_LICENSING_CONTRACT, 
  Product, 
  MJR_LIC_PROG_description, 
  Order_Type, 
  Temp2_VIP_No, 
  Valid, 
  Incumbent, 
  Derived_Week, 
  Temp1_Contract_CXL_Quarter, 
  PayoutQtr as Payout_Quarter_wo_Exp,
  Renewal_Status, 
  ADDITIONAL_TEXT, 
  Internal_Segment, 
  First_date, 
  Right_year, 
  PRODUCT_NAME_description, 
  Renewal_To_Go,
  Units_Expansion,			
  Expansion_Seats,			
  Expansion_NIR,			
  Expansion_ARR,
  Final_Revenue,		
  Final_Revenue_ARR
  from b2b_tmp.Update7_FinalUnion) as ts

-- COMMAND ----------

Create or replace view view_Update8_Formula as
Select *,
Case  
 when FinalPartnerName = 'DOUGLAS STEWART' then 0.013
 ELSE
CASE
 when GEO_description = 'Americas' AND Incumbent = 'Non-Incumbent' AND Order_Type = 'Renewal' then 0
ELSE
CASE
   when GEO_description in ('Americas','Asia') then
  CASE
    WHEN Incumbent ='Incumbent' THEN 0.04
    ELSE 0.02 END
ELSE 1 END
END
END as Payout_Pcnt,
Case  
 when FinalPartnerName = 'DOUGLAS STEWART' then 0.013*Final_Revenue
 ELSE
CASE
 when GEO_description = 'Americas' AND Incumbent = 'Non-Incumbent' AND Order_Type = 'Renewal' then 0
ELSE
CASE
   when GEO_description in ('Americas','Asia') then
  CASE
    WHEN Incumbent ='Incumbent' THEN 0.04*Final_Revenue
    ELSE 0.02*Final_Revenue  END
ELSE 1*Final_Revenue  END
END
END as Target_Payout
from view_Select_Formula_AfterUpdate7

-- COMMAND ----------

drop table if exists b2b_tmp.field_radar_02_03_output_invalid_sales_for_ACT_pwc;
Create table b2b_tmp.field_radar_02_03_output_invalid_sales_for_ACT_pwc as
(Select * from view_Update8_Formula
where Valid != 1);

Create or replace view view_RBoBDataFormat_Filter_True as
Select * from view_Update8_Formula
where Valid = 1;

-- COMMAND ----------

drop table if exists b2b_tmp.input_temp1_Sort;
Create table b2b_tmp.input_temp1_Sort as
(Select * from b2b_tmp.field_radar_02_01_output_temp1_pwc  -- updated to point to non-static version
order by VIP_No ASC,Contract_CXL_Quarter DESC);

drop table if exists b2b_tmp.RBoBDataFormat_LJoin;
Create table b2b_tmp.RBoBDataFormat_LJoin as
(Select vrft.*,
  vit1.VIP_No as Right_VIP_No,
  vit1.Sum_Units_Opportunity_Partner_VIP_Wise as Right_Sum_Units_Opportunity_Partner_VIP_Wise,
  vit1.Sum_ARR_opportunity as Right_Sum_ARR_opportunity
 from view_RBoBDataFormat_Filter_True as vrft
 left join b2b_tmp.input_temp1_Sort as vit1
 on vrft.BL_LICENSING_CONTRACT = vit1.VIP_No);

-- COMMAND ----------

Create or replace view view_RBoBDataFormat_Summarize as
Select 
Sum(Final_Revenue) as SumOfFinal_Revenue,
Sum(Total_Sales_Qty_SUM) as Sum_Total_Sales_Qty_SUM,
Sum(Final_Revenue_ARR)as Final_Revenue_ARR,
Sum(Expansion_NIR) as Expansion_NIR,
Sum(Expansion_ARR) as Expansion_ARR,
ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC ,
BL_LICENSING_CONTRACT ,
C_MARKET_SEGMENT ,
ENTERPRISE_BU_description ,
Product ,
FISCAL_WK_IN_QTR ,
GEO_description ,
FinalPartnerLevel ,
SALES_OPS_RESELLER_PARTNERROLLUP ,
SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL ,
FinalPartnerName ,
Order_Type ,
Incumbent ,
Target_Payout ,
Payout_Pcnt ,
PayoutQtr ,
Renewal_Status ,
Right_Sum_ARR_opportunity as SumOf_ARR_opportunity,
Sum_Units_Opportunity_Partner_VIP_Wise as SumOf_Units_Opportunity_Partner_VIP_Wise,
PartnerMarketArea ,
PartnerRegion ,
PartnerSalesDistrict ,
ORDER_DATE_description ,
CXL_Date ,
SALES_DISTRICT_description ,
Family_Name ,
BL_END_USER_NAME1 ,
Renewal_To_Go ,
SALES_OPS_DISTRIBUTOR_PARTNERROLLUP ,
MARKET_AREA_description ,
Derived_Week ,
Valid ,
ADDITIONAL_TEXT ,
PRODUCT_CONFIG_description ,
MJR_LIC_PROG_description ,
PRODUCT_NAME_description
from b2b_tmp.RBoBDataFormat_LJoin
Group by 6,	7,	8,	9,	10,	11,	12,	13,	14,	15,	16,	17,	18,	19,	20,	21,	22,	23,	24,	25,	26,	27,	28,	29,	30,	31,	32,	33,	34,	35,	36,	37,	38,	39,	40,41

-- COMMAND ----------

Create or replace view view_RBoBDataFormat_IJoin as
Select vrs.*,
vc.year_and_qtr as Right_year_and_qtr
from view_RBoBDataFormat_Summarize as vrs
inner join view_calendar as vc
on vrs.PayoutQtr = vc.year_and_qtr

-- COMMAND ----------

Create or replace view view_PostProcessing_Formula as
Select 
SumOfFinal_Revenue,
Sum_Total_Sales_Qty_SUM,
Final_Revenue_ARR,
Expansion_NIR,
Expansion_ARR,
ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC ,
BL_LICENSING_CONTRACT ,
C_MARKET_SEGMENT ,
ENTERPRISE_BU_description ,
Product ,
FISCAL_WK_IN_QTR ,
GEO_description ,
Case 
when FinalPartnerLevel IN ('SPEC ED/COM' , 'SPEC GOV', 'GENERAL - ALL VERTICALS') then 'DISTRIBUTOR' 
when FinalPartnerName = 'NEXSYS DE CENTROAMERICA     CR' then 'DISTRIBUTOR'
else FinalPartnerLevel
end as FinalPartnerLevel ,
SALES_OPS_RESELLER_PARTNERROLLUP ,
SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL ,
FinalPartnerName ,
Order_Type ,
Incumbent ,
Target_Payout ,
Payout_Pcnt ,
concat('Quarter',' 0',Right(PayoutQtr,1),' ',Left(PayoutQtr, 4)) as PayoutQtr ,
Renewal_Status ,
SumOf_ARR_opportunity,
SumOf_Units_Opportunity_Partner_VIP_Wise,
PartnerMarketArea ,
PartnerRegion ,
PartnerSalesDistrict ,
ORDER_DATE_description ,
CXL_Date ,
SALES_DISTRICT_description ,
Family_Name ,
BL_END_USER_NAME1 ,
Renewal_To_Go ,
SALES_OPS_DISTRIBUTOR_PARTNERROLLUP ,
MARKET_AREA_description ,
Derived_Week ,
Valid ,
ADDITIONAL_TEXT ,
PRODUCT_CONFIG_description ,
MJR_LIC_PROG_description ,
PRODUCT_NAME_description,
Right_year_and_qtr
from view_RBoBDataFormat_IJoin

-- COMMAND ----------

Create or replace view view_PostProcessing_LJoin as
Select *
from view_PostProcessing_Formula as vpf
left outer join b2b_tmp.field_radar_02_03_input_ids_to_be_excluded as iie -- not updated this file is static 
on vpf.BL_LICENSING_CONTRACT = iie.vip_no

-- COMMAND ----------

Create or replace view view_PostProcessing_Select_AfterLjoin as
Select 
Valid as Test,
Sum_Total_Sales_Qty_SUM,
Target_Payout as Target_Payout_AGG,
SALES_OPS_RESELLER_PARTNERROLLUP as Reseller_Rollup_For_EMEA_and_HKT,
SALES_OPS_RESELLER_CHANNEL_PROGRAM_LEVEL as Reseller_Level,
SALES_OPS_DISTRIBUTOR_PARTNERROLLUP as Distributor_Rollup,
SALES_DISTRICT_description,
SumOf_Units_Opportunity_Partner_VIP_Wise,
SumOf_ARR_opportunity,
Renewal_To_Go,
Renewal_Status as Renewal_Status_AGG,
PRODUCT_NAME_description,
PRODUCT_CONFIG_description,
Product,
PayoutQtr as Payout_Quarter_AGG,
Payout_Pcnt as Payout_Percentage_AGG,
PartnerSalesDistrict ,
PartnerRegion,
PartnerMarketArea,
Order_Type,
ORDER_DATE_description as Order_Date,
MJR_LIC_PROG_description as Major_Licensing_Program,
MARKET_AREA_description as Market_Area,
Incumbent as Incumbency_Flag,
GEO_description as Geo,
FISCAL_WK_IN_QTR as Week,
FinalPartnerName as Partner_Rollup,
FinalPartnerLevel as Partner_Level,
Final_Revenue_ARR as ARR,
SumOfFinal_Revenue,
Family_Name as Partner_Name,
Expansion_NIR as Actual_Expansion_Revenue,
Expansion_ARR as Actual_Exp_ARR,
ENTERPRISE_BU_description as Enterprise_BU,
Derived_Week as Week_Derived,
CXL_Date as Date_Derived,
C_MARKET_SEGMENT as Market_Segment,
BL_LICENSING_CONTRACT as VIP_ID,
BL_END_USER_NAME1 as End_User_Name,
ATD_CXL_DATE_FISCAL_YR_AND_QTR_DESC as Contract_Cancellation_Qtr,
ADDITIONAL_TEXT,
Right_year_and_qtr
from view_PostProcessing_LJoin

-- COMMAND ----------

Create or replace view view_PostProcessing_Filter_Formula_Select as
Select Test,
Sum_Total_Sales_Qty_SUM,
Target_Payout_AGG,
Reseller_Rollup_For_EMEA_and_HKT,
Reseller_Level,
Distributor_Rollup,
SALES_DISTRICT_description,
SumOf_Units_Opportunity_Partner_VIP_Wise,
SumOf_ARR_opportunity,
Renewal_To_Go,
Renewal_Status_AGG,
PRODUCT_NAME_description,
PRODUCT_CONFIG_description,
Product,
Payout_Quarter_AGG,
Payout_Percentage_AGG,
PartnerSalesDistrict ,
PartnerRegion,
PartnerMarketArea,
Order_Type,
Order_Date,
Major_Licensing_Program,
Market_Area,
Incumbency_Flag,
Geo,
cast(Week as int),
Case 
When Partner_Rollup = 'INGRAM MICRO ASIA LTD.     SG' AND SALES_DISTRICT_description != 'Singapore' then
	'INGRAM MICRO ASIA LTD.(Non SG)     SG' 
else Partner_Rollup
end as Partner_Rollup,
Partner_Level,
cast(ARR as float),
SumOfFinal_Revenue,
Case
when Partner_Rollup = 'INGRAM MICRO ASIA LTD.     SG' AND SALES_DISTRICT_description != 'Singapore' then 'INGRAM MICRO ASIA LTD.(Non SG)     SG'
else Partner_Name
end as Partner_Name,
Actual_Expansion_Revenue,
Actual_Exp_ARR,
Enterprise_BU,
Week_Derived,
Date_Derived,
Market_Segment,
VIP_ID,
End_User_Name,
Contract_Cancellation_Qtr,
ADDITIONAL_TEXT,
Case
When Contains(PRODUCT_CONFIG_description,'Entrprse') then 'Enterprise' 
else 'Teams' 
end as Teams_Vs_Enterprise
from view_PostProcessing_Select_AfterLjoin
where Partner_Level in ('PLATINUM' , 'DISTRIBUTOR')

-- COMMAND ----------

Create or replace view view_Market_Segment_Derived_Ljoin as
Select vpf.*, ik12.*
from view_PostProcessing_Filter_Formula_Select as vpf
left outer join b2b_tmp.field_radar_02_01_output_k12_deaks_pwc as ik12  -- updated to point to non-static version
on vpf.VIP_ID = ik12.bl_licensing_contract

-- COMMAND ----------

Create or replace view view_Market_Segment_Derived_Formula_Select_Formula as
Select Test,
Sum_Total_Sales_Qty_SUM,
Target_Payout_AGG,
Reseller_Rollup_For_EMEA_and_HKT,
Reseller_Level,
Distributor_Rollup,
SALES_DISTRICT_description,
SumOf_Units_Opportunity_Partner_VIP_Wise,
SumOf_ARR_opportunity,
Renewal_To_Go,
Renewal_Status_AGG,
PRODUCT_NAME_description,
PRODUCT_CONFIG_description,
Product,
Payout_Quarter_AGG,
Payout_Percentage_AGG,
PartnerSalesDistrict ,
PartnerRegion,
PartnerMarketArea,
Order_Type,
Order_Date,
Major_Licensing_Program,
Market_Area,
Incumbency_Flag,
Geo,
Week,
Partner_Rollup,
Partner_Level,
ARR,
SumOfFinal_Revenue,
Partner_Name,
Actual_Expansion_Revenue,
Actual_Exp_ARR,
Enterprise_BU,
Week_Derived,
Date_Derived,
Market_Segment,
VIP_ID,
End_User_Name,
Contract_Cancellation_Qtr,
Derived_Additional_Text,
Case
When Contains(PRODUCT_CONFIG_description,'Entrprse') then "Enterprise" 
else 'Teams' 
end as Teams_Vs_Enterprise,
Case
when Market_Segment = 'EDUCATION' then
   Case
   when Derived_Additional_Text like '%K12%' then 'K12'
   else 'HED'
   end
else Market_Segment
end as Market_Segment_Derived,
Case 
when Geo = 'Japan' then 
  Case 
  when (Enterprise_BU= 'Document Cloud' AND Order_Type != 'Renewal') then 'M1' 
  else 'M2' 
  end
else
 Case
 When Enterprise_BU = 'Document Cloud' then 'M2' 
 else 'M1' 
 end 
end as Measure
from view_Market_Segment_Derived_Ljoin

-- COMMAND ----------

Create or replace view view_VIP_MP_BOOSTER_Filter_Formula_Select as
Select Test,
Sum_Total_Sales_Qty_SUM,
Reseller_Rollup_For_EMEA_and_HKT,
Reseller_Level,
Distributor_Rollup,
SALES_DISTRICT_description,
SumOf_Units_Opportunity_Partner_VIP_Wise,
SumOf_ARR_opportunity,
Renewal_To_Go,
'VIP MP Booster' as Renewal_Status_AGG,
PRODUCT_NAME_description,
PRODUCT_CONFIG_description,
Product,
Payout_Quarter_AGG,
Payout_Percentage_AGG,
PartnerSalesDistrict ,
PartnerRegion,
PartnerMarketArea,
Order_Type,
Order_Date,
'VIP MP Booster' as Major_Licensing_Program,
Market_Area,
Incumbency_Flag,
Geo,
Week,
Partner_Rollup,
Partner_Level,
Partner_Name,
Actual_Expansion_Revenue,
Actual_Exp_ARR,
Enterprise_BU,
Week_Derived,
Date_Derived,
Market_Segment,
VIP_ID,
End_User_Name,
Contract_Cancellation_Qtr,
Derived_Additional_Text,
Teams_Vs_Enterprise,
Market_Segment_Derived,
Measure,
(0.1*SumOfFinal_Revenue) as Booster_Revenue,
(0.1*Target_Payout_AGG) as Target_Payout_Booster,
(0.1*ARR) as Booster_ARR
from view_Market_Segment_Derived_Formula_Select_Formula
where Geo = 'EMEA' AND Major_Licensing_Program = 'VIP Market Place'

-- COMMAND ----------

drop table if exists b2b_tmp.field_radar_02_03_output_rbob_data_format_pwc;
Create table b2b_tmp.field_radar_02_03_output_rbob_data_format_pwc as
(Select 
Cast(actual_exp_arr as double) as actual_exp_arr,
Cast(actual_expansion_revenue as double) as actual_expansion_revenue,
arr ,
contract_cancellation_qtr ,
date_derived ,
derived_additional_text ,
distributor_rollup ,
end_user_name ,
enterprise_bu ,
geo ,
incumbency_flag ,
major_licensing_program ,
market_area ,
market_segment ,
market_segment_derived ,
measure ,
Cast(order_date as date) as order_date,
Order_Type as order_type,
partner_level ,
partner_name ,
partner_rollup ,
partner_market_area ,
partner_region ,
partner_sales_district ,
payout_percentage_agg ,
payout_quarter_agg ,
product ,
product_config_description ,
product_name_description ,
renewal_status_agg ,
Cast(renewal_to_go as double) as renewal_to_go,
reseller_level ,
reseller_rollup_for_emea_and_hkt as reseller_rollup_for_emea_and_hkt ,
sales_district_description ,
Cast(eligible_qty_sum as double) as sum_total_sales_qty_sum ,
sumofarr_opportunity ,
sumofunits_opportunity_partner_vip_wise ,
sumoffinal_revenue,
target_payout_agg ,
teams_vs_enterprise ,
Cast(test as double) as test,
vip_id ,
case 
  When Cast(Week_Derived as int) in (1,2,3,4,5,6,7,8,9) then  concat(0, Week_Derived)
  When Cast(Week_Derived as int) in (-1,-2,-3,-4,-5,-6,-7,-8,-9) then  concat('-',0, substring(Week_Derived,2))
  else Week_Derived
end as week_derived,
case 
  When Week in (1,2,3,4,5,6,7,8,9) then  concat(0, substring(Week,1))
  else Week
end as week 
from b2b_tmp.field_radar_02_02_output_rbob_intermediate_jpn_ccpro_stock_pwc  -- updated to point to non-static version
union all
Select 
Cast(Actual_Exp_ARR as double) ,
Cast(Actual_Expansion_Revenue as double) ,
ARR ,
Contract_Cancellation_Qtr ,
Date_Derived ,
Derived_Additional_Text ,
Distributor_Rollup ,
End_User_Name ,
Enterprise_BU ,
Geo ,
Incumbency_Flag ,
Major_Licensing_Program ,
Market_Area ,
Market_Segment ,
Market_Segment_Derived ,
Measure ,
Cast(Order_Date as date) ,
Order_Type,
Partner_Level ,
Partner_Name ,
Partner_Rollup ,
PartnerMarketArea ,
PartnerRegion ,
PartnerSalesDistrict ,
Payout_Percentage_AGG ,
Payout_Quarter_AGG ,
Product ,
PRODUCT_CONFIG_description ,
PRODUCT_NAME_description ,
Renewal_Status_AGG ,
Cast(Renewal_To_Go as double),
Reseller_Level ,
Reseller_Rollup_For_EMEA_and_HKT ,
SALES_DISTRICT_description ,
Cast(Sum_Total_Sales_Qty_SUM as double),
SumOf_ARR_opportunity ,
SumOf_Units_Opportunity_Partner_VIP_Wise ,
SumOfFinal_Revenue ,
Target_Payout_AGG ,
Teams_Vs_Enterprise ,
Cast(Test as double),
VIP_ID ,
case 
  When Cast(Week_Derived as int) in (1,2,3,4,5,6,7,8,9) then  concat(0, Week_Derived)
  When Cast(Week_Derived as int) in (-1,-2,-3,-4,-5,-6,-7,-8,-9) then  concat('-',0, substring(Week_Derived,2))
  else Week_Derived
end as Week_Derived ,
case 
  When Week in (1,2,3,4,5,6,7,8,9) then  concat(0, substring(Week,1))
  else Week
end as Week 
from view_Market_Segment_Derived_Formula_Select_Formula
union all
Select 
Cast(Actual_Exp_ARR as double) ,
Cast(Actual_Expansion_Revenue as double) ,
Booster_ARR as ARR ,
Contract_Cancellation_Qtr ,
Date_Derived ,
Derived_Additional_Text ,
Distributor_Rollup ,
End_User_Name ,
Enterprise_BU ,
Geo ,
Incumbency_Flag ,
Major_Licensing_Program ,
Market_Area ,
Market_Segment ,
Market_Segment_Derived ,
Measure ,
Cast(Order_Date as date) ,
Order_Type,
Partner_Level ,
Partner_Name ,
Partner_Rollup ,
PartnerMarketArea ,
PartnerRegion ,
PartnerSalesDistrict ,
Payout_Percentage_AGG ,
Payout_Quarter_AGG ,
Product ,
PRODUCT_CONFIG_description ,
PRODUCT_NAME_description ,
Renewal_Status_AGG ,
Cast(Renewal_To_Go as double),
Reseller_Level ,
Reseller_Rollup_For_EMEA_and_HKT ,
SALES_DISTRICT_description ,
Cast(Sum_Total_Sales_Qty_SUM as double),
SumOf_ARR_opportunity ,
SumOf_Units_Opportunity_Partner_VIP_Wise ,
Booster_Revenue as SumOfFinal_Revenue ,
Target_Payout_Booster as Target_Payout_AGG ,
Teams_Vs_Enterprise ,
Cast(Test as double),
VIP_ID ,
case 
  When Cast(Week_Derived as int) in (1,2,3,4,5,6,7,8,9) then  concat(0, Week_Derived)
  When Cast(Week_Derived as int) in (-1,-2,-3,-4,-5,-6,-7,-8,-9) then  concat('-',0, substring(Week_Derived,2))
  else Week_Derived
end as Week_Derived,
case 
  When Week in (1,2,3,4,5,6,7,8,9) then  concat(0, substring(Week,1))
  else Week
end as Week 
from view_VIP_MP_BOOSTER_Filter_Formula_Select);

-- COMMAND ----------

drop table if exists b2b_tmp.field_radar_02_03_output_vip_mp_booster_pwc;
Create table b2b_tmp.field_radar_02_03_output_vip_mp_booster_pwc  as
(Select 
Sum(Booster_Revenue) as sum_eligible_revenue_agg,
Cast(Sum(Sum_Total_Sales_Qty_SUM) as double) as sum_sum_total_sales_qty_sum,
partner_rollup,
market_segment,
enterprise_bu,
case 
  When Cast(Week_Derived as int) in (1,2,3,4,5,6,7,8,9) then  concat(0, Week_Derived)
  When Cast(Week_Derived as int) in (-1,-2,-3,-4,-5,-6,-7,-8,-9) then  concat('-',0, substring(Week_Derived,2))
  else Week_Derived
end as week_derived,
incumbency_flag,
order_type,
Case
when Measure = 'M1' then 'VIP MP Booster M1' 
else 'VIP MP Booster M2' 
end as measure
from view_VIP_MP_BOOSTER_Filter_Formula_Select
group by 3,4,5,6,7,8,9);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### DEBUG

-- COMMAND ----------

--Debug
SELECT 'Data Format' as name, count(*) FROM b2b_tmp.field_radar_02_03_output_rbob_data_format_pwc
UNION ALL 
SELECT 'mp booster', count(*) FROM b2b_tmp.field_radar_02_03_output_vip_mp_booster_pwc

-- COMMAND ----------

SELECT DISTINCT vip_id  FROM  b2b_tmp.field_radar_02_03_output_rbob_data_format_pwc WHERE vip_id = '8B9DD08F5825100719AA'