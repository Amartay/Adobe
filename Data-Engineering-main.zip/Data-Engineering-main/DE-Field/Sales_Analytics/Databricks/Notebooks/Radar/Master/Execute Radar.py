# Databricks notebook source
# DBTITLE 1,Receive Quarter to Execute on Via Widget
# This is passed via the workflow that executes this notebook. 
dbutils.widgets.text("quarter_date", "current", "")
qtr_to_run = dbutils.widgets.get("quarter_date")

# COMMAND ----------

# DBTITLE 1,If the value passed to this script is "current" - Obtain the current quarter - otherwise use the value input
if qtr_to_run.lower().replace("'","") == "current": 
    
    # Fetch the quarter for the current date using the adobe calendar table
    get_current_qtr_sql = ( " SELECT fiscal_yr_and_qtr_desc" 
                            " FROM b2b.l2_sa_sfdc_dim_date  "
                            " WHERE calendar_date = current_date() "                       
    ) 

    current_qtf_df = sqlContext.sql(get_current_qtr_sql)
    qtr_to_run = current_qtf_df.head()[0]


# force the qtr to be wrapped in quotes (incase someone types it without them)
if not (qtr_to_run.startswith("'") and qtr_to_run.endswith("'")):
    qtr_to_run = "'"+qtr_to_run+"'"

print(qtr_to_run)

# COMMAND ----------

notebooks_to_run = ["../Radar Process/1 - rbob/02 01 - rbob workflow",
                    "../Radar Process/1 - rbob/02 02 - rbob workflow",
                    "../Radar Process/1 - rbob/02 03 - rbob workflow",
                    "../Radar Process/1 - rbob/02 04 - rbob workflow"
              
                   ]



# Loop through the jobs list and run - passing the qtr to run
for n in notebooks_to_run:
    retValue = dbutils.notebook.run(n,0,{"qtr_to_run": qtr_to_run})