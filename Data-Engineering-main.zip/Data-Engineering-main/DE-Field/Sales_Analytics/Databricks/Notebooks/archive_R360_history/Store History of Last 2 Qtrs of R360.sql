-- Databricks notebook source
-- DBTITLE 1,removed any data logged today - incase for some reason you run this multiple times in a day
DELETE FROM b2b_stg.retention_360_3_month_rolling_history
WHERE AS_OF_DATE = current_date()

-- COMMAND ----------

-- DBTITLE 1,Insert todays Data
-- See Ticket (https://jira.corp.adobe.com/browse/B2BDME-6206)
-- As instructed on this ticket - this code is lifted from stage 01 05 - R360 (https://adb-7285815854578748.8.azuredatabricks.net/?o=7285815854578748#notebook/2407388750527576/command/2407388750527578)

INSERT INTO  b2b_stg.retention_360_3_month_rolling_history (
  EXPANSION_AT_RENEWAL_DIFF,
  EXPANSION_AT_RENEWAL_SAME,
  TEAM_GROUP_ID,
  MARKET_AREA,
  MARKET_SEGMENT,
  RENEWAL_FISCAL_YR_AND_QTR_DESC,
  UP_FOR_RENEWAL,
  CC_SEGMENTS,
  CLOUD_TYPE,
  TERM_END_ACTIVE_POST_REACTIVATION,
  END_TERM_REACTIVATION,
  END_TERM_REACTIVATION_ARR,
  END_USER,
  END_TERM_MIGRATION_TO,
  END_TERM_MIGRATION_FROM,
  PARTNER_LEVEL,
  CONTRACT_END_DATE,
  RENEWAL_DATE,
  RENEWAL_DATE_FISCAL_YR_AND_WK_DESC,
  RENEWAL_TO_DATE,
  ROUTE_TO_MARKET,
  TERM_END_ACTIVE_POST_REACTIVATION_ARR,
  UP_FOR_RENEWAL_ARR,
  FISCAL_YR_QTR_DESC,
  AS_OF_DATE)



  SELECT  cast(EXPANSION_AT_RENEWAL_DIFF as double) as EXPANSION_AT_RENEWAL_DIFF, 
        cast(EXPANSION_AT_RENEWAL_SAME as double) as EXPANSION_AT_RENEWAL_SAME,
        TEAM_GROUP_ID,
        MARKET_AREA,
        MARKET_SEGMENT,
        RENEWAL_FISCAL_YR_AND_QTR_DESC,
        cast(UP_FOR_RENEWAL  as double) as UP_FOR_RENEWAL,
        CC_SEGMENTS,
        CLOUD_TYPE,
        cast(TERM_END_ACTIVE_POST_REACTIVATION as double) as TERM_END_ACTIVE_POST_REACTIVATION,
        cast(END_TERM_REACTIVATION as double) as END_TERM_REACTIVATION,
        cast(END_TERM_REACTIVATION_ARR as double) as END_TERM_REACTIVATION_ARR,
        END_USER,
        cast(END_TERM_MIGRATION_TO as double) as END_TERM_MIGRATION_TO,
        cast(END_TERM_MIGRATION_FROM as double) as END_TERM_MIGRATION_FROM,
        PARTNER_LEVEL,
        CONTRACT_END_DATE,
        RENEWAL_DATE_DATE,
        RENEWAL_DATE_FISCAL_YR_AND_WK_DESC,
        cast(RENEWAL_TO_DATE as double) as RENEWAL_TO_DATE,
        ROUTE_TO_MARKET,
        cast(TERM_END_ACTIVE_POST_REACTIVATION_ARR as double) as TERM_END_ACTIVE_POST_REACTIVATION_ARR,
        cast(UP_FOR_RENEWAL_ARR as double) as UP_FOR_RENEWAL_ARR,
        RENEWAL_FISCAL_YR_AND_QTR_DESC AS FISCAL_YR_QTR_DESC,
        current_date() AS AS_OF_DATE
  FROM csmb.vw_retention_360_team
WHERE ROUTE_TO_MARKET = 'RESELLER' 
AND RENEWAL_FISCAL_YR_AND_QTR_DESC IN (
  SELECT fiscal_yr_and_qtr_desc
  FROM b2b.l2_sa_sfdc_dim_date 
  WHERE calendar_date = current_date()
  UNION 
  SELECT previous_fiscal_yr_and_qtr_desc
  FROM b2b.l2_sa_sfdc_dim_date 
  WHERE calendar_date = current_date()
 ) -- Filter to previous and current quarter as instructed in the ticket

-- COMMAND ----------

-- DBTITLE 1,Delete any snapshots > 90 days old (mentioned in the ticket)
DELETE FROM b2b_stg.retention_360_3_month_rolling_history
WHERE AS_OF_DATE < date_add(current_date(),-90)
