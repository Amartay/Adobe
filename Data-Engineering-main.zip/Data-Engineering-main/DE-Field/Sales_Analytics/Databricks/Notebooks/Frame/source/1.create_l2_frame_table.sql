-- Databricks notebook source
DROP TABLE IF EXISTS b2b.l2_frame_sfdc_pipeline;
CREATE TABLE b2b.l2_frame_sfdc_pipeline (
  as_of_date DATE,
  opportunity_id STRING,
  full_opty_id STRING,
  deal_reg_id STRING,
  deal_reg_flag STRING,
  sales_order_number STRING,
  sales_ops_reconciled STRING,
  dme_ineligible STRING,
  dme_ineligible_reason STRING,
  vip_ea_clp_agreement_number STRING,
  sfdc_link STRING,
  opportunity_name STRING,
  acct_name STRING,
  acct_addr_country STRING,
  partner_country STRING,
  geo STRING,
  route_to_market STRING,
  licensing_program STRING,
  lm_engagement STRING,
  acct_dme_acct_group STRING,
  opp_prod_interest STRING,
  current_created_date DATE,
  current_created_year_qtr STRING,
  current_created_week_in_qtr STRING,
  current_created_week STRING,
  current_close_date DATE,
  current_close_year_qtr STRING,
  current_close_week_in_qtr STRING,
  current_close_week STRING,
  current_acceptintosalespipeline STRING,
  current_stage STRING,
  current_adj_commitment STRING,
  current_business_commitment STRING,
  current_closed_date_fx_rate STRING,
  pipeline_accepted_rejected_by STRING,
  rejection_notes STRING,
  rejection_reason STRING,
  booking_status STRING,
  manager_adjusted_commitment STRING,
  licensing_program_type STRING,
  sales_play STRING,
  approval_status STRING,
  lead_id STRING,
  created_by_id STRING,
  industry STRING,
  region_adjusted_commitment STRING,
  geo_adjusted_commitment STRING,
  market_area STRING,
  campaign_name STRING,
  opportunity_deal_type STRING,
  opportunity_record_type STRING,
  last_modified_date DATE,
  days_since_last_modified BIGINT,
  previous_close_date STRING,
  iss_involvement STRING,
  pipeline_creator STRING,
  account_id STRING,
  closure_date DATE,
  acct_market_area STRING,
  billing_country STRING,
  created_by_full_name STRING,
  record_owner STRING,
  record_owner_full_name STRING,
  campaign_id STRING,
  campaign_group STRING,
  snapshot_quarter STRING,
  snapshot_week STRING,
  snapshot_week_in_qtr STRING,
  additional_description STRING,
  partner_account_name STRING,
  region STRING,
  sales_region STRING,
  sub_market_area STRING,
  estimated_revenue_usd STRING,
  record_owner_division STRING,
  record_owner_name STRING,
  record_owner_role_name STRING,
  record_owner_alias STRING,
  highest_stage_value STRING,
  created_alias STRING,
  sql_date DATE,
  total_new_asv_fx_neutral STRING,
  account_manager_approval_status STRING,
  days_since_deal_reg_next_steps_modified STRING,
  days_since_next_steps_modified BIGINT,
  stage_duration_in_days BIGINT,
  closed_date_fx_rate STRING,
  reason STRING,
  am_approved_reject_date STRING,
  sourcing_partner_id STRING,
  sourcing_partner_name STRING,
  is_closed BOOLEAN,
  plan_type STRING,
  forecasted_incremental_arr DOUBLE,
  executed_on DATE)
USING delta;


-- COMMAND ----------

-- DBTITLE 1,Main Query
---------------------------------------------------------
-- Original Query provided by Sanda in Jira Ticket https://jira.corp.adobe.com/browse/B2BDME-5274
-- Minor refactoring changes to make it work in DBX 
---------------------------------------------------------

INSERT INTO b2b.l2_frame_sfdc_pipeline (
as_of_date,
opportunity_id,
full_opty_id,
deal_reg_id,
deal_reg_flag,
sales_order_number,
sales_ops_reconciled,
dme_ineligible,
dme_ineligible_reason,
vip_ea_clp_agreement_number,
sfdc_link,
opportunity_name,
acct_name,
acct_addr_country,
partner_country,
geo,
route_to_market,
licensing_program,
lm_engagement,
acct_dme_acct_group,
opp_prod_interest,
current_created_date,
current_created_year_qtr,
current_created_week_in_qtr,
current_created_week,
current_close_date,
current_close_year_qtr,
current_close_week_in_qtr,
current_close_week,
current_acceptintosalespipeline,
current_stage,
current_adj_commitment,
current_business_commitment,
current_closed_date_fx_rate,
pipeline_accepted_rejected_by,
rejection_notes,
rejection_reason,
booking_status,
manager_adjusted_commitment,
licensing_program_type,
sales_play,
approval_status,
lead_id,
created_by_id,
industry,
region_adjusted_commitment,
geo_adjusted_commitment,
market_area,
campaign_name,
opportunity_deal_type,
opportunity_record_type,
last_modified_date,
days_since_last_modified,
previous_close_date,
iss_involvement,
pipeline_creator,
account_id,
closure_date,
acct_market_area,
billing_country,
created_by_full_name,
record_owner,
record_owner_full_name,
campaign_id,
campaign_group,
snapshot_quarter,
snapshot_week,
snapshot_week_in_qtr,
additional_description,
partner_account_name,
region,
sales_region,
sub_market_area,
estimated_revenue_usd,
record_owner_division,
record_owner_name,
record_owner_role_name,
record_owner_alias,
highest_stage_value,
created_alias,
sql_date,
total_new_asv_fx_neutral,
account_manager_approval_status,
days_since_deal_reg_next_steps_modified,
days_since_next_steps_modified,
stage_duration_in_days,
closed_date_fx_rate,
reason,
am_approved_reject_date,
sourcing_partner_id,
sourcing_partner_name,
is_closed,
plan_type,
forecasted_incremental_arr,
executed_on)
SELECT    opp.as_of_date AS as_of_date
        , opp.adobe_opportunity_id AS opportunity_id
        , opp.id AS full_opty_id
        , opp.adobe_dr AS deal_reg_id
        , CAST(NULL AS STRING) AS deal_reg_flag
        , CAST(NULL AS STRING) AS sales_order_number
        , CAST(NULL AS STRING) AS sales_ops_reconciled
        , CAST(NULL AS STRING) AS dme_ineligible
        , CAST(NULL AS STRING) AS dme_ineligible_reason
        , CAST(NULL AS STRING) AS vip_ea_clp_agreement_number
        , CAST(NULL AS STRING)  AS sfdc_link
        , opp.name AS opportunity_name
        , acc.name AS acct_name 
        , acc.adobe_country_code AS acct_addr_country 
        , CAST(NULL AS STRING)  AS partner_country
        , acc.adobe_geo AS geo 
        , CAST(NULL AS STRING)  AS route_to_market
        , CASE
            WHEN opp.etla_deal_type IS NULL THEN 'Standalone'
            WHEN UPPER(opp.etla_deal_type) LIKE '%TRANSFORMATIONAL%' THEN 'SPP (Transformational)'
            ELSE 'ETLA'
            END AS licensing_program 
        , CAST(NULL AS STRING)  AS lm_engagement
        , opp.sales_team_type AS acct_dme_acct_group
        , CAST(NULL AS STRING)  AS opp_prod_interest
        -- Check with Sandra what they currently have displayed in these date fields - I dont have any examples of this - these are correct
        -- values but might not be in the expected format - e.g. week 01 vs 1, 2023-Q3 vs Q3 etc.. 
        , CAST(opp.created_date AS DATE) AS current_created_date
        , concat('FY',right(createDt.fiscal_yr,2),' - ', createDt.fiscal_qtr_name)  AS current_created_year_qtr
        , createDt.fiscal_wk_in_qtr AS current_created_week_in_qtr
        , createDt.fiscal_wk_in_yr AS  current_created_week
        , CAST(opp.close_date AS DATE) AS current_close_date
        , concat('FY',right(closeDt.fiscal_yr,2),' - ', closeDt.fiscal_qtr_name) AS current_close_year_qtr
        , closeDt.fiscal_wk_in_qtr AS current_close_week_in_qtr
        , closeDt.fiscal_wk_in_yr AS  current_close_week
        , CASE WHEN opp.ae_accepted__c IS NOT NULL THEN 'Accepted' ELSE NULL END AS current_acceptintosalespipeline
        , opp.stage_name AS current_stage
        , opp.adjusted_commitment AS current_adj_commitment
        , CAST(NULL AS STRING)  AS current_business_commitment
        , CAST(NULL AS STRING)  AS current_closed_date_fx_rate
        , CAST(NULL AS STRING)  AS pipeline_accepted_rejected_by
        , CAST(NULL AS STRING)  AS rejection_notes
        , opp.rejection_reason__c AS rejection_reason
        , CAST(NULL AS STRING)  AS booking_status
        , CAST(NULL AS STRING)  AS manager_adjusted_commitment
        , opp.type AS licensing_program_type  
        , CAST(NULL AS STRING)  AS sales_play
        , CAST(NULL AS STRING)  AS approval_status
        , opp.adobe_lead AS lead_id
        , opp.created_by_id AS created_by_id
        , acc.industry AS industry
        , CAST(NULL AS STRING)  AS region_adjusted_commitment
        , CAST(NULL AS STRING)  AS geo_adjusted_commitment
        , acc.adobe_market_area AS market_area 
        , camp.name AS campaign_name 
        , CAST(NULL AS STRING)  AS opportunity_deal_type
        , opp.record_type_name__c AS opportunity_record_type
        , CAST(opp.last_modified_date AS DATE) AS last_modified_date
        , DATEDIFF(DAY, CAST(opp.last_modified_date AS DATE), current_date()) AS days_since_last_modified
        , CAST(NULL AS STRING)  AS previous_close_date
        , CAST(NULL AS STRING)  AS iss_involvement
        , CAST(NULL AS STRING)  AS pipeline_creator
        , opp.account_id AS account_id
        , CAST(NULL AS DATE)  AS closure_date
        , acc.adobe_market_area AS acct_market_area 
        , opp.billing_country AS billing_country
        , CAST(NULL AS STRING) AS created_by_full_name 
        , opp.owner_id AS record_owner
        , CAST(NULL AS STRING) AS record_owner_full_name  
        , opp.campaign_id AS campaign_id
        , CAST(NULL AS STRING) AS campaign_group   

        -- Confirm formats here 
        , curDt.fiscal_yr_and_qtr_desc AS snapshot_quarter
        , curDt.fiscal_wk_in_yr AS snapshot_week
        , curDt.fiscal_wk_in_qtr AS snapshot_week_in_qtr
        , CAST(NULL AS STRING) AS additional_description
        , CAST(NULL AS STRING) AS partner_account_name
        , CAST(NULL AS STRING) AS region
        , CAST(NULL AS STRING) AS sales_region
        , CAST(NULL AS STRING) AS sub_market_area
        , CAST(NULL AS STRING) AS estimated_revenue_usd
        , CAST(NULL AS STRING) AS record_owner_division
        , CAST(NULL AS STRING) AS record_owner_name
        , CAST(NULL AS STRING) AS record_owner_role_name
        , CAST(NULL AS STRING) AS record_owner_alias
        , CAST(NULL AS STRING) AS highest_stage_value
        , CAST(NULL AS STRING) AS created_alias
        , CAST(opp.ae_accepted__c AS DATE ) AS sql_date
        , CAST(NULL AS STRING) AS total_new_asv_fx_neutral
        , CAST(NULL AS STRING) AS account_manager_approval_status
        , CAST(NULL AS STRING) AS days_since_deal_reg_next_steps_modified
        , DATEDIFF(DAY, CAST(opp.next_steps_last_updated AS DATE), current_date()) AS days_since_next_steps_modified
        , opp.days_in_current_stage AS stage_duration_in_days
        , CAST(NULL AS STRING) AS closed_date_fx_rate
        , CAST(NULL AS STRING) AS reason
        , CAST(NULL AS STRING) AS am_approved_reject_date
        , CAST(NULL AS STRING) AS sourcing_partner_id
        , CAST(NULL AS STRING) AS sourcing_partner_name
        , opp.is_closed
        , opp.plan_type__c AS plan_type
        , opp.forecasted_incremental_arr
        , current_date() AS executed_on
FROM b2b.l1_sa_frameio_sfdc_opportunities_snapshot opp
LEFT JOIN ( 
              SELECT id,
                    name,
                    adobe_sfdc_id,
                    adobe_parent_id,
                    adobe_sub_id,
                    adobe_geo,
                    adobe_market_area,
                    adobe_country_code,
                    billing_country,
                    adobe_segment,
                    industry
              FROM b2b.l1_sa_frameio_sfdc_accounts
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.l1_sa_frameio_sfdc_accounts)
) acc 
ON opp.account_id = acc.id

LEFT JOIN (  SELECT id, 
                    name
             FROM b2b.l1_sa_frameio_sfdc_campaigns 
             WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.l1_sa_frameio_sfdc_campaigns)
) camp
ON  opp.campaign_id = camp.id
-- Date Dimension Stuff - get quarters for dates etc.. 
LEFT JOIN Ids_coredata.dim_date closeDt ON  CAST(opp.close_date AS DATE) = CAST(closeDt.calendar_date AS DATE)
LEFT JOIN Ids_coredata.dim_date createDt ON  CAST(opp.created_date AS DATE) = CAST(createDt.calendar_date AS DATE)
LEFT JOIN Ids_coredata.dim_date acceptDt ON  CAST(opp.ae_accepted__c AS DATE) = CAST(acceptDt.calendar_date AS DATE)
LEFT JOIN Ids_coredata.dim_date curDt ON current_date() = CAST(curDt.calendar_date AS DATE)
WHERE opp.as_of_date = (SELECT max(as_of_date) FROM b2b.l1_sa_frameio_sfdc_opportunities_snapshot )
AND CAST(opp.created_date AS DATE)  >= '2021-01-01' -- same filter we have in Core


-- COMMAND ----------

-- DBTITLE 1,Remove todays Records - incase you have to run this twice in a day
DELETE FROM  b2b.l2_frame_sfdc_pipeline_snapshot
WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.l2_frame_sfdc_pipeline)

-- COMMAND ----------

INSERT INTO b2b.l2_frame_sfdc_pipeline_snapshot (
as_of_date,
opportunity_id,
full_opty_id,
deal_reg_id,
deal_reg_flag,
sales_order_number,
sales_ops_reconciled,
dme_ineligible,
dme_ineligible_reason,
vip_ea_clp_agreement_number,
sfdc_link,
opportunity_name,
acct_name,
acct_addr_country,
partner_country,
geo,
route_to_market,
licensing_program,
lm_engagement,
acct_dme_acct_group,
opp_prod_interest,
current_created_date,
current_created_year_qtr,
current_created_week_in_qtr,
current_created_week,
current_close_date,
current_close_year_qtr,
current_close_week_in_qtr,
current_close_week,
current_acceptintosalespipeline,
current_stage,
current_adj_commitment,
current_business_commitment,
current_closed_date_fx_rate,
pipeline_accepted_rejected_by,
rejection_notes,
rejection_reason,
booking_status,
manager_adjusted_commitment,
licensing_program_type,
sales_play,
approval_status,
lead_id,
created_by_id,
industry,
region_adjusted_commitment,
geo_adjusted_commitment,
market_area,
campaign_name,
opportunity_deal_type,
opportunity_record_type,
last_modified_date,
days_since_last_modified,
previous_close_date,
iss_involvement,
pipeline_creator,
account_id,
closure_date,
acct_market_area,
billing_country,
created_by_full_name,
record_owner,
record_owner_full_name,
campaign_id,
campaign_group,
snapshot_quarter,
snapshot_week,
snapshot_week_in_qtr,
additional_description,
partner_account_name,
region,
sales_region,
sub_market_area,
estimated_revenue_usd,
record_owner_division,
record_owner_name,
record_owner_role_name,
record_owner_alias,
highest_stage_value,
created_alias,
sql_date,
total_new_asv_fx_neutral,
account_manager_approval_status,
days_since_deal_reg_next_steps_modified,
days_since_next_steps_modified,
stage_duration_in_days,
closed_date_fx_rate,
reason,
am_approved_reject_date,
sourcing_partner_id,
sourcing_partner_name,
is_closed,
plan_type,
forecasted_incremental_arr,
executed_on)

SELECT  as_of_date,
        opportunity_id,
        full_opty_id,
        deal_reg_id,
        deal_reg_flag,
        sales_order_number,
        sales_ops_reconciled,
        dme_ineligible,
        dme_ineligible_reason,
        vip_ea_clp_agreement_number,
        sfdc_link,
        opportunity_name,
        acct_name,
        acct_addr_country,
        partner_country,
        geo,
        route_to_market,
        licensing_program,
        lm_engagement,
        acct_dme_acct_group,
        opp_prod_interest,
        current_created_date,
        current_created_year_qtr,
        current_created_week_in_qtr,
        current_created_week,
        current_close_date,
        current_close_year_qtr,
        current_close_week_in_qtr,
        current_close_week,
        current_acceptintosalespipeline,
        current_stage,
        current_adj_commitment,
        current_business_commitment,
        current_closed_date_fx_rate,
        pipeline_accepted_rejected_by,
        rejection_notes,
        rejection_reason,
        booking_status,
        manager_adjusted_commitment,
        licensing_program_type,
        sales_play,
        approval_status,
        lead_id,
        created_by_id,
        industry,
        region_adjusted_commitment,
        geo_adjusted_commitment,
        market_area,
        campaign_name,
        opportunity_deal_type,
        opportunity_record_type,
        last_modified_date,
        days_since_last_modified,
        previous_close_date,
        iss_involvement,
        pipeline_creator,
        account_id,
        closure_date,
        acct_market_area,
        billing_country,
        created_by_full_name,
        record_owner,
        record_owner_full_name,
        campaign_id,
        campaign_group,
        snapshot_quarter,
        snapshot_week,
        snapshot_week_in_qtr,
        additional_description,
        partner_account_name,
        region,
        sales_region,
        sub_market_area,
        estimated_revenue_usd,
        record_owner_division,
        record_owner_name,
        record_owner_role_name,
        record_owner_alias,
        highest_stage_value,
        created_alias,
        sql_date,
        total_new_asv_fx_neutral,
        account_manager_approval_status,
        days_since_deal_reg_next_steps_modified,
        days_since_next_steps_modified,
        stage_duration_in_days,
        closed_date_fx_rate,
        reason,
        am_approved_reject_date,
        sourcing_partner_id,
        sourcing_partner_name,
        is_closed,
        plan_type,
        forecasted_incremental_arr,
        executed_on
FROM b2b.l2_frame_sfdc_pipeline;
