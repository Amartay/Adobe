-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Sales Pipeline - Opp Progression
-- MAGIC
-- MAGIC Sales Pipeline - Opp Progression
-- MAGIC Wiki Page: https://wiki.corp.adobe.com/display/CCM/Sales+Pipeline+L2+-+Opp+Progression
-- MAGIC
-- MAGIC Tasks Performed in Notebook:
-- MAGIC
-- MAGIC Obtain dates for every opportunity at each stage
-- MAGIC Make two versions of each date obtained (date type and string type)
-- MAGIC Produce output table (b2b.l2_sa_sfdc_opp_progression)
-- MAGIC Insert into Full History Table (Snapshot) (b2b.l2_sa_sfdc_opp_progression_snapshot)
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Cleaning up the Dates
-- MAGIC %md
-- MAGIC Jira Ticket https://jira.corp.adobe.com/browse/B2BDME-4098  requested a number of changes / cleanup to the dates held in this table. This view below is where these changes are made and is kept as a separate object so it can be easily queried on its own to aid for any future tweaks / debugging as after this point the dates in the history table might not be the actual dates shown for a given field. 

-- COMMAND ----------

-- DBTITLE 1,Clean up the Dates
CREATE OR REPLACE TEMPORARY VIEW opp_history_cleaned AS 
SELECT  opportunityid,
        -- They only want to see closed dates (and backfill from those) for successful opportunities 
        CASE WHEN upper(replace(current_stage,' ','')) = 'CLOSED-BOOKED' THEN closedate_date ELSE NULL END AS closedate_date,
        CASE  WHEN initialstage2date_date < initialstage1date_date THEN initialstage2date_date
              WHEN initialstage3date_date < initialstage1date_date THEN initialstage3date_date
              WHEN initialstage4date_date < initialstage1date_date THEN initialstage4date_date
              WHEN initialstage5date_date < initialstage1date_date THEN initialstage5date_date
              WHEN initialstage6date_date < initialstage1date_date THEN initialstage6date_date
              WHEN initialstage7date_date < initialstage1date_date THEN initialstage7date_date
              ELSE initialstage1date_date END AS initialstage1date_cleaned,
        CASE  WHEN initialstage3date_date < initialstage2date_date THEN initialstage3date_date
              WHEN initialstage4date_date < initialstage2date_date THEN initialstage4date_date
              WHEN initialstage5date_date < initialstage2date_date THEN initialstage5date_date
              WHEN initialstage6date_date < initialstage2date_date THEN initialstage6date_date
              WHEN initialstage7date_date < initialstage2date_date THEN initialstage7date_date
              ELSE initialstage2date_date END AS initialstage2date_cleaned,
        CASE  WHEN initialstage4date_date < initialstage3date_date THEN initialstage4date_date
              WHEN initialstage5date_date < initialstage3date_date THEN initialstage5date_date
              WHEN initialstage6date_date < initialstage3date_date THEN initialstage6date_date
              WHEN initialstage7date_date < initialstage3date_date THEN initialstage7date_date
              ELSE initialstage3date_date END AS initialstage3date_cleaned,
        CASE  WHEN initialstage5date_date < initialstage4date_date THEN initialstage5date_date
              WHEN initialstage6date_date < initialstage4date_date THEN initialstage6date_date
              WHEN initialstage7date_date < initialstage4date_date THEN initialstage7date_date
              ELSE initialstage4date_date END AS initialstage4date_cleaned,
        CASE  WHEN initialstage6date_date < initialstage5date_date THEN initialstage6date_date
              WHEN initialstage7date_date < initialstage5date_date THEN initialstage7date_date
              ELSE initialstage5date_date END AS initialstage5date_cleaned,
        CASE  WHEN initialstage7date_date < initialstage6date_date THEN initialstage7date_date
              ELSE initialstage6date_date END AS initialstage6date_cleaned,
        initialstage7date_date AS initialstage7date_cleaned
FROM 
(
        SELECT opportunityid
                -- note: this closed date was requested to be taken from the core table (ticket 4098)
                ,max(core.closure_date) AS closedate_date
                ,min(CASE WHEN upper(replace(stagename,' ','')) IN ('01-PRECALLPLAN','1-PRECALLPLAN','01-PRECALLPLAN01-PRECALLPLAN') THEN createddate END) AS initialstage1date_date
                ,min(CASE WHEN upper(replace(stagename,' ','')) IN ('02-PROSPECT','STAGE2-PROSPECT') THEN createddate END) AS initialstage2date_date
                ,min(CASE WHEN upper(replace(stagename,' ','')) IN ('03-OPPORTUNITYQUALIFICATION','03-OPPORTUNITYQUALIFICATION03-OPPORTUNITYQUALIFICATION') THEN createddate END) AS initialstage3date_date
                ,min(CASE WHEN upper(replace(stagename,' ','')) = '04-CIRCLEOFINFLUENCE' THEN createddate END) AS initialstage4date_date
                ,min(CASE WHEN upper(replace(stagename,' ','')) IN ('05-SOLUTIONDEFINITION','05-SOLUTIONDEFINITIONANDVALIDATION','05-SOLUTIONDEFINITION05-SOLUTIONDEFINITION') THEN createddate END) AS initialstage5date_date
                ,min(CASE WHEN upper(replace(stagename,' ','')) = '06-CUSTOMERCOMMIT' THEN createddate END) AS initialstage6date_date
                ,min(CASE WHEN upper(replace(stagename,' ','')) = '07-EXECUTETOCLOSE' THEN createddate END) AS initialstage7date_date
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunityhistory h 
        -- Restrict to just those records filtered in pipeline Core
        INNER JOIN b2b.l2_sa_sfdc_pipeline_core core   
                ON h.opportunityid = core.full_opty_id
        WHERE h.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunityhistory )
        GROUP BY opportunityid
) minDateStage
INNER JOIN (  SELECT full_opty_id, 
                    current_stage
             FROM b2b.l2_sa_sfdc_pipeline_core  ) coreStage 
ON minDateStage.opportunityid = coreStage.full_opty_id


-- COMMAND ----------

-- DBTITLE 1,Populate the History Table
DROP TABLE IF EXISTS b2b.l2_sa_sfdc_opp_progression; 
CREATE TABLE b2b.l2_sa_sfdc_opp_progression AS 
SELECT full_opty_id,
       closedate_string,
       closedate_date,
       initialstage1date_string,
       initialstage1date_date,
       initialstage2date_string,
       initialstage2date_date,
       initialstage3date_string,
       initialstage3date_date,
       initialstage4date_string,
       initialstage4date_date,
       initialstage5date_string,
       initialstage5date_date,
       initialstage6date_string,
       initialstage6date_date,
       initialstage7date_string,
       initialstage7date_date,
       stage3Date.fiscal_yr_and_qtr_desc AS initialstage3date_qtr,
       stage3Date.fiscal_yr_and_wk_desc AS initialstage3date_week,
       stage4Date.fiscal_yr_and_qtr_desc AS initialstage4date_qtr,
       stage4Date.fiscal_yr_and_wk_desc AS initialstage4date_week,
       stage5Date.fiscal_yr_and_qtr_desc AS initialstage5date_qtr,
       stage5Date.fiscal_yr_and_wk_desc AS initialstage5date_week,
       stage6Date.fiscal_yr_and_qtr_desc AS initialstage6date_qtr,
       stage6Date.fiscal_yr_and_wk_desc AS initialstage6date_week,
       stage7Date.fiscal_yr_and_qtr_desc AS initialstage7date_qtr,
       stage7Date.fiscal_yr_and_wk_desc AS initialstage7date_week,
       executed_on
FROM ( 

        SELECT  full_opty_id,
                closedate_string,
                closedate_date,
                coalesce(initialstage1date_string,initialstage2date_string,initialstage3date_string,initialstage4date_string,
                        initialstage5date_string,initialstage6date_string,initialstage7date_string,closedate_string,NULL) AS initialstage1date_string,
                coalesce(initialstage1date_date,initialstage2date_date,initialstage3date_date,initialstage4date_date,
                        initialstage5date_date,initialstage6date_date,initialstage7date_date,closedate_date,NULL) AS initialstage1date_date,
                coalesce(initialstage2date_string,initialstage3date_string,initialstage4date_string,
                        initialstage5date_string,initialstage6date_string,initialstage7date_string,closedate_string,NULL) AS initialstage2date_string,
                coalesce(initialstage2date_date,initialstage3date_date,initialstage4date_date,
                        initialstage5date_date,initialstage6date_date,initialstage7date_date,closedate_date,NULL) AS initialstage2date_date,
                coalesce(initialstage3date_string,initialstage4date_string,
                        initialstage5date_string,initialstage6date_string,initialstage7date_string,closedate_string,NULL) AS initialstage3date_string,
                coalesce(initialstage3date_date,initialstage4date_date,
                        initialstage5date_date,initialstage6date_date,initialstage7date_date,closedate_date,NULL) AS initialstage3date_date,
                coalesce(initialstage4date_string,initialstage5date_string,initialstage6date_string,initialstage7date_string,closedate_string,NULL) AS initialstage4date_string,
                coalesce(initialstage4date_date,initialstage5date_date,initialstage6date_date,initialstage7date_date,closedate_date,NULL) AS initialstage4date_date,
                coalesce(initialstage5date_string,initialstage6date_string,initialstage7date_string,closedate_string,NULL) AS initialstage5date_string,
                coalesce(initialstage5date_date,initialstage6date_date,initialstage7date_date,closedate_date,NULL) AS initialstage5date_date,
                coalesce(initialstage6date_string,initialstage7date_string,closedate_string,NULL) AS initialstage6date_string,
                coalesce(initialstage6date_date,initialstage7date_date,closedate_date,NULL) AS initialstage6date_date,
                coalesce(initialstage7date_string,closedate_string,NULL) AS initialstage7date_string,
                coalesce(initialstage7date_date,closedate_date,NULL) AS initialstage7date_date,
                executed_on
        FROM ( 
        SELECT DISTINCT  opportunityid AS full_opty_id
                              ,regexp_replace(substr(closedate_date,1,10),'-','') closedate_string
                              ,cast(substr(closedate_date,1,10) AS DATE) AS closedate_date
                              ,regexp_replace(substr(initialstage1date_cleaned,1,10),'-','') AS initialstage1date_string
                              ,cast(substr(initialstage1date_cleaned,1,10) AS DATE) AS initialstage1date_date
                              ,regexp_replace(substr(initialstage2date_cleaned,1,10),'-','') AS initialstage2date_string
                              ,cast(substr(initialstage2date_cleaned,1,10) AS DATE) AS initialstage2date_date
                              ,regexp_replace(substr(initialstage3date_cleaned,1,10),'-','') AS initialstage3date_string
                              ,cast(substr(initialstage3date_cleaned,1,10) AS DATE) AS initialstage3date_date
                              ,regexp_replace(substr(initialstage4date_cleaned,1,10),'-','') AS initialstage4date_string
                              ,cast(substr(initialstage4date_cleaned,1,10) AS DATE) AS initialstage4date_date
                              ,regexp_replace(substr(initialstage5date_cleaned,1,10),'-','') AS initialstage5date_string
                              ,cast(substr(initialstage5date_cleaned,1,10) AS DATE) AS initialstage5date_date
                              ,regexp_replace(substr(initialstage6date_cleaned,1,10),'-','') AS initialstage6date_string
                              ,cast(substr(initialstage6date_cleaned,1,10) AS DATE) AS initialstage6date_date
                              ,regexp_replace(substr(initialstage7date_cleaned,1,10),'-','') AS initialstage7date_string
                              ,cast(substr(initialstage7date_cleaned,1,10) AS DATE) AS initialstage7date_date
                              ,cast(current_timestamp() AS STRING) AS executed_on
        FROM opp_history_cleaned hc
        ) r 
) x
LEFT JOIN Ids_coredata.dim_date stage3Date ON x.initialstage3date_string = stage3Date.date_key
LEFT JOIN Ids_coredata.dim_date stage4Date ON x.initialstage4date_string = stage4Date.date_key
LEFT JOIN Ids_coredata.dim_date stage5Date ON x.initialstage5date_string = stage5Date.date_key
LEFT JOIN Ids_coredata.dim_date stage6Date ON x.initialstage6date_string = stage6Date.date_key
LEFT JOIN Ids_coredata.dim_date stage7Date ON x.initialstage7date_string = stage7Date.date_key