-- Databricks notebook source
-- MAGIC %md
-- MAGIC ### Funnel Types
-- MAGIC This table is dependent on both core and segmentation and therefore was separated to a new table. Any changes to the exiting groups for segmentation will be automatically carried through to this report. However new segmentation groups will need to be factored in.
-- MAGIC
-- MAGIC The Ticket that led to the creation of this table is https://jira.corp.adobe.com/browse/B2BDME-4045
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Create a lookup table to provide a tidy delimited list of each segmentation group for an opportunity
CREATE OR REPLACE TEMPORARY VIEW identified_segments AS 
SELECT DISTINCT allSegments.full_opty_id,
                allSegments.all_segments_str,
                -- Flag the no / multiple segments as issues - show the ones which are ok
                CASE WHEN allSegments.all_segments_str RLIKE '\\|' THEN 'Multiple'
                      WHEN allSegments.all_segments_str = '' THEN 'None Identified'
                      ELSE allSegments.all_segments_str 
                      END AS identified_segment
FROM ( 
        SELECT full_opty_id,
        -- Make the elements distinct, pipe separated but remove any leading or trailing pipes or multiple pipes in a row
            CASE WHEN right(trim(replace(regexp_replace(array_join(array_distinct(segment_arr),'|'),'^\\|+', ''),'||','|')),1 ) = '|'
                 THEN substring(trim(replace(regexp_replace(array_join(array_distinct(segment_arr),'|'),'^\\|+', ''),'||','|')), 1,len(trim(replace(regexp_replace(array_join(array_distinct(segment_arr),'|'),'^\\|+', ''),'||','|'))) -1)
                 ELSE trim(replace(regexp_replace(array_join(array_distinct(segment_arr),'|'),'^\\|+', ''),'||','|')) 
                 END AS all_segments_str
        FROM ( 
              SELECT  full_opty_id,
                      array(
                            CASE WHEN amer_gbd = 'Y' THEN 'AMER GBD' ELSE '' END,
                            CASE WHEN amer_mm_22 = 'Y' THEN 'AMER MM' ELSE '' END,
                            CASE WHEN amer_mm_23 = 'Y' THEN 'AMER MM' ELSE '' END,
                            CASE WHEN amer_edu = 'Y' THEN 'AMER EDU' ELSE '' END,
                            CASE WHEN latam_ent = 'Y' THEN 'LATAM ENT' ELSE '' END,
                            CASE WHEN emea_cnx = 'Y' THEN 'EMEA CNX' ELSE '' END,
                            CASE WHEN emea_pss_22_q3 = 'Y' THEN 'EMEA PSS' ELSE '' END,
                            CASE WHEN emea_pss_22_q4 = 'Y' THEN 'EMEA PSS' ELSE '' END,
                            CASE WHEN emea_pss_23 = 'Y' THEN 'EMEA PSS' ELSE '' END,
                            CASE WHEN emea_edu = 'Y' THEN 'EMEA EDU' ELSE '' END,
                            CASE WHEN emea_reseller = 'Y' THEN 'EMEA RESELLER' ELSE '' END,
                            CASE WHEN apac_ent = 'Y' THEN 'APAC' ELSE '' END,
                            CASE WHEN apac_smb = 'Y' THEN 'APAC' ELSE '' END,
                            CASE WHEN japan_ent = 'Y' THEN 'JAPAN ENT' ELSE '' END 
                          ) as segment_arr
              FROM b2b.l2_sa_sfdc_pipeline_segmentation
        ) Arr
) allSegments


-- COMMAND ----------

-- DBTITLE 1,Drop Output Table
DROP TABLE IF EXISTS b2b.l2_sa_sfdc_pipeline_funnel_types;

-- COMMAND ----------

-- DBTITLE 1,Identify Individual Funnel Types From their Segment + Global Value
CREATE TABLE b2b.l2_sa_sfdc_pipeline_funnel_types AS 
SELECT  funnelTypes.full_opty_id,
        funnelTypes.all_segments_str,
        funnelTypes.identified_segment,
        CASE WHEN amer_mm_funnel_type = 'MQL'
                  OR  funnelTypes.emea_pss_funnel_type = 'Marketing' 
                  OR funnelTypes.amer_edu_funnel_type = 'MQL'
                  OR funnelTypes.latam_ent_funnel_type = 'MQL' 
                  OR  funnelTypes.emea_edu_funnel_type = 'Marketing' 
             THEN 'MQL Sourced'
             WHEN funnelTypes.amer_mm_funnel_type = 'Partner'
                  OR funnelTypes.emea_pss_funnel_type = 'Partner'
                  OR funnelTypes.emea_edu_funnel_type = 'Partner'
                  OR funnelTypes.apac_funnel_type = 'Partner'
                  OR funnelTypes.japan_funnel_type = 'Partner'
                  OR funnelTypes.amer_edu_funnel_type = 'Partner'
                  OR funnelTypes.latam_ent_funnel_type = 'Partner'
            THEN 'Partner Sourced'
            WHEN funnelTypes.emea_pss_funnel_type IN ('CSM','Self Generated')
                 OR funnelTypes.emea_edu_funnel_type IN ('CSM','Self Generated')
                 OR funnelTypes.apac_funnel_type ='Sales'
                 OR funnelTypes.japan_funnel_type ='Sales'
            THEN 'Seller Sourced'
            WHEN funnelTypes.amer_mm_funnel_type IN ('BDR','AM')
                OR funnelTypes.amer_edu_funnel_type IN ('BDR','AM')
                OR funnelTypes.latam_ent_funnel_type IN ('BDR','AM')
            THEN 'Seller Sourced - Inbound'
            WHEN funnelTypes.amer_mm_funnel_type IN ('AE','PSM')
                OR funnelTypes.amer_edu_funnel_type IN ('AE','PSM')
                OR funnelTypes.latam_ent_funnel_type IN ('AE','PSM')
            THEN 'Seller Sourced - Outbound' 
             WHEN funnelTypes.apac_funnel_type = 'BDR'
                OR funnelTypes.japan_funnel_type = 'BDR'
            THEN 'BDR Sourced'
            WHEN funnelTypes.emea_pss_funnel_type = 'License Management' 
                  OR funnelTypes.emea_edu_funnel_type = 'License Management' 
            THEN 'License Management Sourced'
            ELSE 'No Funnel Identified'
            END AS global_funnel_name,
        funnelTypes.amer_mm_funnel_type,
        funnelTypes.emea_pss_funnel_type,
        funnelTypes.emea_edu_funnel_type,
        funnelTypes.apac_funnel_type,
        funnelTypes.japan_funnel_type,
        funneltypes.amer_edu_funnel_type,
        funnelTypes.latam_ent_funnel_type
FROM ( 
SELECT  core.full_opty_id,
        seg.all_segments_str,
        seg.identified_segment,
        /* Amer MM Funnel Type */
        CASE  WHEN seg.all_segments_str RLIKE 'AMER MM' AND upper(core.campaign_name) RLIKE 'CS|NUR|WBR|DEMAND|RFI|TRIAL' THEN 'MQL'
              WHEN seg.all_segments_str RLIKE 'AMER MM' AND core.lead_id IS NOT NULL THEN 'BDR'
              WHEN seg.all_segments_str RLIKE 'AMER MM' AND lower(core.approval_status) IN ('approved','partner and adobe shared visibility','expired') and core.deal_reg_flag = 'Y' THEN 'Partner'
              WHEN seg.all_segments_str RLIKE 'AMER MM' AND  core.created_by_id IN ( SELECT RIGHT(TerritoryTeamMemberID, 18) 
                                                                                FROM b2b.uda_replicn_sf_corp_uda_vw_adobeterritorymember t
                                                                                  WHERE UPPER(t.AdobeRoleName) like '%2023%RENEWAL SPECIALIST%' 
                                                                                  AND UPPER(t.AdobeTerritoryName) LIKE '%C&B AMERICAS%' ) THEN 'AM'
              WHEN seg.all_segments_str RLIKE 'AMER MM' AND lower(core.iss_involvement) = 'sourced' THEN 'PSM'
              WHEN seg.all_segments_str RLIKE 'AMER MM' THEN 'AE' 
        END AS amer_mm_funnel_type,
        /* Emea Pss Funnel Type */
        CASE  WHEN seg.all_segments_str RLIKE 'EMEA PSS' AND (core.lm_engagement='' OR core.lm_engagement IS NOT NULL) THEN 'License Management'
              WHEN seg.all_segments_str RLIKE 'EMEA PSS' AND upper(core.pipeline_creator) LIKE '%ADM ORGANIC%' THEN 'Marketing'
              WHEN seg.all_segments_str RLIKE 'EMEA PSS' AND upper(core.deal_reg_flag) = 'Y' THEN 'Partner'
              WHEN seg.all_segments_str RLIKE 'EMEA PSS' AND lower(core.created_by_full_name) IN ( 'akshaya megawath jaganya', 
                                                                                                  'sumit ludhwani', 
                                                                                                  'umang somani', 
                                                                                                  'anurag mukherjee', 
                                                                                                  'love mittal',
                                                                                                  'priyanka chauhan', 
                                                                                                  'ruby thomas', 
                                                                                                  'saif bashir', 
                                                                                                  'sarika behal', 
                                                                                                  'satbir singh', 
                                                                                                  'neha arora', 
                                                                                                  'neha jha') THEN 'CSM'
              WHEN seg.all_segments_str RLIKE 'EMEA PSS' THEN 'Self Generated'
        END AS emea_pss_funnel_type,
        /* Emea EDU Funnel Type - Ticket 4756 */
        CASE  WHEN seg.all_segments_str RLIKE 'EMEA EDU' AND (core.lm_engagement='' OR core.lm_engagement IS NOT NULL) THEN 'License Management'
              WHEN seg.all_segments_str RLIKE 'EMEA EDU' AND upper(core.deal_reg_flag) = 'Y' THEN 'Partner'
              WHEN seg.all_segments_str RLIKE 'EMEA EDU' AND   (core.sourcing_partner_name ='' OR core.sourcing_partner_name IS NOT NULL) THEN 'Partner'
              WHEN seg.all_segments_str RLIKE 'EMEA EDU' AND upper(core.pipeline_creator) LIKE '%ADM ORGANIC%' THEN 'Marketing'
              WHEN seg.all_segments_str RLIKE 'EMEA EDU' AND  lower(core.created_by_full_name) IN ('anurag mukherjee',
                                                                                                   'catherine wynne',
                                                                                                   'lorena kraft',
                                                                                                   'louise hopkins',
                                                                                                   'marion giraud',
                                                                                                   'robert schriever',
                                                                                                   'satbir singh' ) THEN 'CSM'
             WHEN seg.all_segments_str RLIKE 'EMEA EDU' THEN 'Self Generated'
       END AS emea_edu_funnel_type,

        /* APAC  */
        CASE      WHEN seg.all_segments_str RLIKE 'APAC' AND lower(core.pipeline_creator) = 'adm organic' THEN 'BDR'
                  WHEN seg.all_segments_str RLIKE 'APAC' AND lower(core.pipeline_creator) = 'sales organic' THEN 'Sales'
                  WHEN seg.all_segments_str RLIKE 'APAC' AND lower(core.pipeline_creator) = 'partner organic' THEN 'Partner'
                  WHEN seg.all_segments_str RLIKE 'APAC' AND lower(core.pipeline_creator) IN ('sales joint with partners','sales joint with partner') THEN 'Partner'
                  WHEN seg.all_segments_str RLIKE 'APAC' AND (lower(core.pipeline_creator) IN ('adm joint with partner','adm joint with partners') AND upper(core.additional_description) LIKE '%BDR%' )THEN 'BDR'
                  WHEN seg.all_segments_str RLIKE 'APAC' AND lower(core.pipeline_creator) IN ('adm joint with partner','adm joint with partners') THEN 'Partner'
            END AS apac_funnel_type,
          /* Japan Ent Funnel Type */
          CASE WHEN seg.all_segments_str RLIKE 'JAPAN ENT' AND lower(core.pipeline_creator) = 'bdr organic' OR  core.pipeline_creator = 'bdr joint with partner'  THEN 'BDR'
              WHEN seg.all_segments_str RLIKE 'JAPAN ENT' AND lower(core.pipeline_creator) = 'sales organic' OR  lower(core.pipeline_creator) = 'sales joint with partner' THEN 'Sales'
              WHEN seg.all_segments_str RLIKE 'JAPAN ENT' AND lower(core.pipeline_creator) = 'partner organic' THEN 'Partner'
          END AS japan_funnel_type,
          /* Amer EDU Funnel Type */
          CASE  WHEN seg.all_segments_str RLIKE 'AMER EDU' AND upper(core.campaign_name) RLIKE 'CS|NUR|WBR|DEMAND|RFI|TRIAL' THEN 'MQL'
                WHEN seg.all_segments_str RLIKE 'AMER EDU' AND core.lead_id IS NOT NULL THEN 'BDR'
                WHEN seg.all_segments_str RLIKE 'AMER EDU' AND lower(core.approval_status) IN ('approved','partner and adobe shared visibility','expired') AND core.deal_reg_flag = 'Y' THEN 'Partner'
                WHEN seg.all_segments_str RLIKE 'AMER EDU' AND  core.created_by_id IN ( SELECT RIGHT(TerritoryTeamMemberID, 18) 
                                                                                  FROM b2b.uda_replicn_sf_corp_uda_vw_adobeterritorymember t
                                                                                    WHERE UPPER(t.AdobeRoleName) like '%2023%RENEWAL SPECIALIST%' 
                                                                                    AND UPPER(t.AdobeTerritoryName) LIKE '%C&B AMERICAS%' ) THEN 'AM'
                WHEN seg.all_segments_str RLIKE 'AMER EDU' AND lower(core.iss_involvement) = 'sourced' THEN 'PSM'
                WHEN seg.all_segments_str RLIKE 'AMER EDU' THEN 'AE' 
          END AS amer_edu_funnel_type,
          /* Latam Ent Funnel Type */
          CASE  WHEN seg.all_segments_str RLIKE 'LATAM ENT' AND upper(core.campaign_name) RLIKE 'CS|NUR|WBR|DEMAND|RFI|TRIAL' THEN 'MQL'
                WHEN seg.all_segments_str RLIKE 'LATAM ENT' AND core.lead_id IS NOT NULL THEN 'BDR'
                WHEN seg.all_segments_str RLIKE 'LATAM ENT' AND lower(core.approval_status) IN ('approved','partner and adobe shared visibility','expired') AND core.deal_reg_flag = 'Y' THEN 'Partner'
                WHEN seg.all_segments_str RLIKE 'LATAM ENT' AND  core.created_by_id IN ( SELECT RIGHT(TerritoryTeamMemberID, 18) 
                                                                                  FROM b2b.uda_replicn_sf_corp_uda_vw_adobeterritorymember t
                                                                                    WHERE UPPER(t.AdobeRoleName) like '%2023%RENEWAL SPECIALIST%' 
                                                                                    AND UPPER(t.AdobeTerritoryName) LIKE '%C&B AMERICAS%' ) THEN 'AM'
                WHEN seg.all_segments_str RLIKE 'LATAM ENT' AND lower(core.iss_involvement) = 'sourced' THEN 'PSM'
                WHEN seg.all_segments_str RLIKE 'LATAM ENT' THEN 'AE' 
          END AS latam_ent_funnel_type
FROM b2b.l2_sa_sfdc_pipeline_core core
LEFT JOIN identified_segments seg
  ON core.full_opty_id = seg.full_opty_id                                         
) funnelTypes


