-- Databricks notebook source
-- MAGIC %md
-- MAGIC Sales Pipeline - Core
-- MAGIC Wiki Page: https://wiki.corp.adobe.com/display/CCM/Sales+Pipeline+L2+-+Core
-- MAGIC
-- MAGIC Tasks Performed in Notebook:
-- MAGIC
-- MAGIC - Produce output table (b2b.l2_sa_sfdc_pipeline_core)
-- MAGIC - Insert into Full History Table (Snapshot) (b2b.l2_sa_sfdc_pipeline_core_snapshot)
-- MAGIC

-- COMMAND ----------

-- MAGIC %run "/b2bdme/dates"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #L2 CHECK BEFORE WORKFLOW STARTS
-- MAGIC #df_dummy = spark.createDataFrame(TABLE_LIST, StringType()).select(col("value").alias("TableName"))
-- MAGIC for tab in ['b2b.uda_replicn_sf_corp_uda_vw_opportunity','b2b.uda_replicn_sf_corp_uda_vw_account','b2b.uda_replicn_sf_corp_uda_vw_campaign','b2b.uda_replicn_sf_corp_uda_vw_opportunityhistory','b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem','b2b.uda_replicn_sf_corp_uda_vw_product2','b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment','b2b.uda_uda_masterdata_dbo_vw_td_date','b2b.uda_replicn_sf_corp_uda_vw_userrole','b2b.uda_replicn_sf_corp_uda_vw_user']:
-- MAGIC     final_df = spark.sql("""select * from {tab} where as_of_date = '{YESTERDAY}'""".format(YESTERDAY = YESTERDAY,tab = tab)).count()
-- MAGIC     print(final_df)
-- MAGIC     if final_df != 0:
-- MAGIC         pass
-- MAGIC     else:
-- MAGIC         raise Exception("Source tables does not have latest data")
-- MAGIC        # dbutils.notebook.exit("Source tables does not have latest data")

-- COMMAND ----------

-- DBTITLE 1,Create Pipeline Source Lookup Table (Ticket 5772)
CREATE OR REPLACE TABLE b2b_tmp.pipeline_creation_lookup (full_opty_id STRING, pipeline_creation_source STRING);

-- License Management 
INSERT INTO b2b_tmp.pipeline_creation_lookup (full_opty_id,pipeline_creation_source)
SELECT DISTINCT o.fulloptyid,
                'License Management' AS  pipeline_creation_source 
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity o
WHERE o.as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)
AND upper(coalesce(o.geo,'')) <> 'JAPAN'
AND coalesce(o.lm_engagement,'') <> '' 
AND upper(coalesce(o.licensingprogramtype,'')) <> 'RENEWAL';

-- Marketing
INSERT INTO b2b_tmp.pipeline_creation_lookup (full_opty_id,pipeline_creation_source)
SELECT DISTINCT o.fulloptyid,
                'Marketing'
FROM  b2b.uda_replicn_sf_corp_uda_vw_campaign c 
LEFT JOIN ( SELECT fulloptyid,
                    campaignid2
             FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity
             WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)
             AND upper(coalesce(licensingprogramtype,'')) <> 'RENEWAL' 
) o
ON  c.id = o.campaignid2 -- TODO: Is this join correct? it looks like this should be replaced with c.ID - but this is not contained in DBX currently 
WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_campaign)
AND upper(c.spenders) IN ('CORPORATE MARKETING','DEMAND GENERATION','FIELD MARKETING')
AND upper(c.bu_campaign) IN ('DIGITAL MEDIA PROFESSIONAL',
                            'DIGITAL MEDIA ACROBAT',
                            'DIGITAL MEDIA CONSUMER',
                            'DOCUMENT CLOUD',
                            'DIGITAL MEDIA SOLUTIONS',
                            'DIGITAL MEDIA INTERACTIVE DEVELOPER',
                            'ADOBE SIGN',
                            'DIGITAL MEDIA ECHOSIGN',
                            'DIGITAL MEDIA SIGN',
                            'DIGITAL MEDIA')
AND  upper(c.methodofdistribution) NOT LIKE '%NONE%STORE IN DATABASE%' -- there are 4 variants of this status caused by poor data quality - thus the wildcarding
AND  upper(c.name) NOT RLIKE 'FORPROMOTION|TEST|CSAM'
AND o.fulloptyid IS NOT NULL 
AND o.fulloptyid NOT IN (SELECT full_opty_id FROM b2b_tmp.pipeline_creation_lookup ); -- your ID isnt already taken by another creation source

-- Partner
INSERT INTO b2b_tmp.pipeline_creation_lookup (full_opty_id,pipeline_creation_source)
SELECT DISTINCT  o.fulloptyid,
                 'Partner'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity o
LEFT JOIN ( SELECT opportunityid
             FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem  
             WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem)
             AND upper(outlookproductgroup) RLIKE 'ECHOSIGN|DPS|LIVECYCLE'
) li
ON o.fulloptyid = li.opportunityid
WHERE o.as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)
AND upper(coalesce(o.licensingprogramtype,'')) <> 'RENEWAL'
AND li.opportunityid IS NULL -- if you have one of the outlook product groups mentioned in the opportunity - I exclude the whole opportunity. 
AND upper(o.program) IN ('ACROBAT', 'CSBU', 'AMERICAS DESKTOP', 'PPBU','APAC DESKTOP', 'EMEA DESKTOP')
AND upper(coalesce(o.PartnerAccountName,'')) NOT RLIKE 'DO NOT USE|TEST'
AND coalesce(o.PartnerAccountName,'') <> ''
AND upper(coalesce(o.approvalstatus,'')) <> 'NEW'
AND coalesce(o.createddate,'') <> '' 
AND coalesce(o.AccountLevel,'') <> '' 
AND o.fulloptyid NOT IN (SELECT full_opty_id FROM b2b_tmp.pipeline_creation_lookup ); -- your ID isnt already taken by another creation source

-- Everthing else (Seller)
INSERT INTO b2b_tmp.pipeline_creation_lookup (full_opty_id,pipeline_creation_source)
SELECT o.fulloptyid,
       'Seller'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity o
WHERE o.as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)
AND o.fulloptyid NOT IN (SELECT full_opty_id FROM b2b_tmp.pipeline_creation_lookup ) ;


-- COMMAND ----------

REFRESH TABLE Ids_coredata.dim_date;

-- COMMAND ----------

-- DBTITLE 1,Drop Output Table
DROP TABLE IF EXISTS b2b.l2_sa_sfdc_pipeline_core;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS b2b.l2_sa_sfdc_pipeline_core (
  as_of_date date, 
  opportunity_id string,
  full_opty_id string,
  deal_reg_id string,
  deal_reg_flag string,
  sales_order_number string,
  sales_ops_reconciled string,
  dme_ineligible string,
  dme_ineligible_reason string,
  vip_ea_clp_agreement_number string,
  sfdc_link string,
  opportunity_name string,
  acct_name string,
  acct_addr_country string,
  partner_country string,
  geo string,
  route_to_market string,
  licensing_program string,
  lm_engagement string,
  acct_dme_acct_group string,
  opp_prod_interest string,
  current_created_date date,
  current_created_qtr string,
  current_created_week string,
  current_created_week_in_qtr string,
  current_created_year_qtr string,
  current_close_date date,
  current_close_qtr string,
  current_close_week string,
  current_close_week_in_qtr string,
  current_close_year_qtr string,
  current_acceptintosalespipeline string,
  current_stage string,
  current_adj_commitment string,
  current_business_commitment string,
  current_closed_date_fx_rate double,
  pipeline_accepted_rejected_by string,
  rejection_notes string,
  rejection_reason string,
  booking_status string,
  manager_adjusted_commitment string,
  licensing_program_type string,
  sales_play string,
  approval_status string,
  lead_id string,
  created_by_id string,
  industry string,
  region_adjusted_commitment string,
  geo_adjusted_commitment string,
  market_area string,
  campaign_name string,
  -- new fields from ticket 3924
  opportunity_deal_type string,
  opportunity_record_type string,
  last_modified_date date,
  days_since_last_modified int,
  previous_close_date date,
  iss_involvement string,
  pipeline_creator string,
  account_id string,
  closure_date date,
  acct_market_area string,
  billing_country string,
  created_by_full_name string,
  record_owner string,
  record_owner_full_name string,
  campaign_id string,
  campaign_group string,
  snapshot_quarter string,
  snapshot_week string,
  additional_description string,
 
  -- updates from 3953
  partner_account_name string,
  region string,
  sales_region string,
  sub_market_area string,
  estimated_revenue_usd double,
  record_owner_division string,
  record_owner_name string,
  record_owner_role_name string,
  record_owner_alias string,
  highest_stage_value string,
  created_alias string,
  sql_date date,
  total_new_asv_fx_neutral double,
  account_manager_approval_status string,
  days_since_deal_reg_next_steps_modified bigint,
  days_since_next_steps_modified bigint,
  stage_duration_in_days bigint,
  closed_date_fx_rate double,
  reason string,
  am_approved_reject_date date,
  sourcing_partner_id string,
  sourcing_partner_name string,
  track_adoption string,

  -- 5510 - New Changes; 
  account_level string,
  internal_approval_status string,
  opportunity_status string,
  program string,
  revenue_assurance_status string,
  probability_percent int,
  pipeline_creation_source string, -- ticket 5572
  next_steps string, -- ticket 6901
  executed_on string
);

-- COMMAND ----------

-- DBTITLE 1,Insert Records into  b2b.l2_sa_sfdc_pipeline_core
INSERT INTO b2b.l2_sa_sfdc_pipeline_core
SELECT DISTINCT 
  opp01.as_of_date,
  opp01.OpportunityID,
  opp01.FullOptyId,
  opp01.DealRegistrationID,
  opp01.DealRegistration AS deal_registration_flag,
  coalesce(
    opp01.AdobeSalesOrderNumber,
    opp01.ECC_SalesOrderNumber
  ) AS sales_order_number,
  opp01.salesopsreconciled AS sales_ops_reconciled,
  opp01.dmeineligible AS dme_ineligible,
  opp01.ineligiblereason AS dme_ineligible_reason,
  opp01.VIP_EA_CLP_AgreementNumber,
  concat(
    'https://adobe.my.salesforce.com/',
    opp01.FullOptyId
  ) AS sfdc_link,
  opp01.name AS opportunity_name,
  acc01.AccountName,
  opp01.AccountAddressCountry,
  opp01.PartnerCountry,
  opp01.Geo,
  opp01.RouteToMarket,
  opp01.LicensingProgram,
  opp01.lm_engagement,
  acc01.DMeAccountGroup,
  opp01.ProductInterest AS opportunity_prod_interest,
  opp01.CreatedDate AS current_created_date,
  DatesCreated01.fiscal_qtr_name AS current_created_qtr,
  DatesCreated01.fiscal_wk_in_yr AS current_created_week,
  DatesCreated01.fiscal_wk_in_qtr AS current_created_week_in_qtr,
  DatesCreated01.fiscal_yr_and_qtr_desc AS current_created_year_qtr,
  opp01.CloseDate AS Current_CloseDate,
  DatesClosed01.fiscal_qtr_name AS Current_Close_QTR,
  DatesClosed01.fiscal_wk_in_yr AS Current_Close_Week,
  DatesClosed01.fiscal_wk_in_qtr AS Current_Close_Week_in_QTR,
  DatesClosed01.fiscal_yr_and_qtr_desc AS Current_Close_Year_QTR,
  opp01.AcceptintoSalesPipeline AS current_acceptintosalespipeline,
  trim(opp01.Stage) AS current_stage,
  opp01.AdjustedCommitment AS current_adj_commitment,
  CASE
    WHEN opp01.Stage IN ('01 - Pre Call Plan', '02 - Prospect') THEN 'Non-Commit'
    WHEN opp01.Stage IN (
      '03 - Opportunity Qualification',
      '04 - Circle of Influence'
    ) THEN 'Upside'
    WHEN opp01.Stage = '05 - Solution Definition and Validation' THEN 'Strong Upside'
    WHEN opp01.Stage IN ('06 - Customer Commit', '07 - Execute to Close') THEN 'Forecast'
    WHEN opp01.Stage = 'Closed - Booked' THEN 'Won'
    ELSE opp01.AdjustedCommitment
  END AS business_commitment,
  round(cast(opp01.ClosedDateFX_Rate AS double), 2) AS ClosedDateFX_Rate,
  opp01.pipelineacceptedrejectedby AS pipeline_accepted_rejected_by,
  opp01.Rejectionnotes AS rejection_notes,
  opp01.Rejectionreason AS rejection_reason,
  BookingStatus AS booking_status ,
  manageradjustedcommitment AS manager_adjusted_commitment,
  licensingprogramtype AS licensing_program_type,

    -- New stuff requested from DS
  opp01.primarysalesplay AS sales_play,
  opp01.approvalstatus AS approval_status,
  opp01.leadid as lead_id,
  opp01.createdbyid AS created_by_id,
  opp01.industry,
  opp01.regionadjustedcommitment AS region_adjusted_commitment,
  opp01.geoadjustedcommitment AS geo_adjusted_commitment,
  acc01.marketarea AS market_area,
  camp.name AS campaign_name,

  -- 3924 - Additional fields added 
  opp01.OpportunityDealType AS opportunity_deal_type,
  opp01.OpportunityRecordType AS opportunity_record_type,
  cast(opp01.LastModifiedDate AS date) AS last_modified_date,
  cast(datediff(current_timestamp(), opp01.LastModifiedDate) AS int) AS days_since_last_modified,
  cast(opp01.previousclosedate as date) AS previous_close_date,
  opp01.iss_involvement AS iss_involvement,
  opp01.pipelinecreator AS pipeline_creator,
  opp01.accountid AS account_id,
  cast(opp01.closureDate AS date) AS closure_date,
  acc01.acct_market_area,
  acc01.validatedbillingcountry AS billing_country,
  createby.fullname1 AS CreatedByFullName,
  opp01.recordowner AS record_owner,
  recordowner.fullname1 AS record_owner_full_name,
  camp.campaignid AS campaign_id,
  camp.campaigngroup AS campaign_group,
  dimDate.fiscal_yr_and_qtr_desc AS snapshot_quarter,
  dimDate.fiscal_yr_and_wk_desc AS snapshot_week,
  opp01.additionaldescription AS additional_description,
  -- updates from 3953
  opp01.PartnerAccountName as partner_account_name,
  acc01.region,
  acc01.salesregion,
  acc01.SubMarketArea,
  cast(opp01.estimatedrevenueinusd AS DOUBLE) AS estimated_revenue_usd,
  recordowner.division AS record_owner_division,
  recordowner.fullname1 AS record_owner_name,
  recordowner.role_name AS record_owner_role_name,
  recordowner.alias AS record_owner_alias,
  opp01.HighestStageValue AS highest_stage_value,
  createby.alias AS created_alias,
  CAST(opp01.SQL_Date AS DATE) AS sql_date,
  CAST(opp01.TotalNewASV_FX_Neutral AS DOUBLE) AS total_new_asv_fx_neutral,
  opp01.AccountManagerApprovalStatus AS account_manager_approval_status,
  
  -- Updates in ticket 4238
  CAST(opp01.dayssincedealregnextstepsmodified AS BIGINT) AS days_since_deal_reg_next_steps_modified,
  CAST(opp01.dayssincenextstepsmodified AS BIGINT) AS days_since_next_steps_modified,
  CAST(opp01.stagedurationindays AS BIGINT) AS stage_duration_in_days,
  CAST(opp01.ClosedDateFX_Rate AS DOUBLE) AS closed_date_fx_rate,
  opp01.reason,

  -- 4362 
  CAST(opp01.AM_ApproveRejectDate AS DATE) AS am_approved_reject_date,
  opp01.sourcingpartner AS sourcing_partner_id,
  sourcingpartner.sourcing_partner_name,
  opp01.trackadoption AS track_adoption,

  -- 5510 - New Changes; 
  opp01.AccountLevel AS account_level,
  opp01.InternalApprovalStatus AS internal_approval_status,
  opp01.Status AS opportunity_status,
  opp01.Program AS program,
  opp01.RevenueAssuranceStatus AS revenue_assurance_status,
  CAST(opp01.ProbabilityPercent as int) AS probability_percent,
  sourcelu.pipeline_creation_source,

  -- 6901 - Add Next Steps Field; 
  opp01.nextsteps AS next_steps,

  -- 6901 - Add Next Steps Field; 
  CAST(current_timestamp() AS string) AS executed_on
FROM
  b2b.uda_replicn_sf_corp_uda_vw_opportunity opp01
  LEFT JOIN (
    SELECT
      AccountName,
      DMeAccountGroup,
      standardizedparentid,
      standardizedparent,
      standardizedsubid,
      standardizedsub,
      marketarea,
      CASE WHEN marketarea IN ('Canada', 'United States') THEN Geo
            WHEN marketarea = 'Russia & CIS' THEN 'Russia & Cis'
            WHEN marketarea = 'None' THEN NULL
            WHEN marketarea = 'Strat. Latin America' THEN 'Strategic Latin America'
            WHEN marketarea IN ('Hong Kong & Taiwan', 'ANZ') THEN 'Pacific'
            WHEN marketarea = 'SSA & Israel' THEN 'Sub Saharan Africa'
            ELSE marketarea
      END AS acct_market_area,
      validatedbillingcountry,  
      country,
      Id,
      region,
      salesregion,
      SubMarketArea
    FROM
      b2b.uda_replicn_sf_corp_uda_vw_account
    WHERE
      as_of_date IN (
        SELECT
          max(as_of_date)
        FROM
          b2b.uda_replicn_sf_corp_uda_vw_account
      )
  ) acc01 ON opp01.AccountID = acc01.Id -- Close Date
  LEFT JOIN ( SELECT  campaignid,
                      name,
                      campaigngroup
              FROM b2b.uda_replicn_sf_corp_uda_vw_campaign
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_campaign)
  ) camp 
  ON opp01.campaignid2 = camp.campaignid
  LEFT JOIN (
    SELECT
      fiscal_qtr_name,
      fiscal_wk_in_yr,
      fiscal_wk_in_qtr,
      date_date,
      fiscal_yr,
      fiscal_yr_and_qtr_desc
    FROM
      b2b_tmp.hana_ccmusage_dim_date
  ) DatesClosed01 ON opp01.CloseDate = cast(DatesClosed01.Date_Date AS DATE) -- Created Date
  LEFT JOIN (
    SELECT
      fiscal_qtr_name,
      fiscal_wk_in_yr,
      fiscal_wk_in_qtr,
      date_date,
      fiscal_yr,
      fiscal_yr_and_qtr_desc
    from
      b2b_tmp.hana_ccmusage_dim_date
  ) DatesCreated01 ON opp01.CreatedDate = cast(DatesCreated01.Date_Date AS DATE)
  LEFT JOIN  (  SELECT userid, fullname1, alias
                FROM b2b.uda_replicn_sf_corp_uda_vw_user 
                WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_user)
            ) createby 
            ON opp01.createdbyid = createby.userid
              
              
  LEFT JOIN  (  SELECT userid, fullname1, division, fullname1, ur.name as role_name, u.alias
                FROM b2b.uda_replicn_sf_corp_uda_vw_user u 
                LEFT JOIN b2b.uda_replicn_sf_corp_uda_vw_userrole ur
                      ON ur.roleid = u.roleid 
                WHERE u.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_user) 
                AND ur.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_userrole)
  ) recordowner 
ON opp01.recordowner = recordowner.userid 
LEFT JOIN ( SELECT id, AccountName AS sourcing_partner_name
            FROM b2b.uda_replicn_sf_corp_uda_vw_account
            WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_account)
) sourcingpartner
ON sourcingpartner.id = opp01.sourcingpartner
LEFT JOIN Ids_coredata.dim_date dimDate 
  ON opp01.as_of_date = dimDate.calendar_date 
LEFT JOIN  b2b_tmp.pipeline_creation_lookup sourcelu
  ON opp01.fulloptyid = sourcelu.full_opty_id
WHERE
  opp01.as_of_date IN (
    SELECT
      max(as_of_date)
    FROM
      b2b.uda_replicn_sf_corp_uda_vw_opportunity
  )
  AND opp01.CloseDate >= cast('2021-01-01' AS DATE)
  AND opp01.flag='D'

-- COMMAND ----------

-- DBTITLE 1,Delete Todays Data From Snapshot Table (shouldn't exist at this point - but just incase you need to re-run this code a few times you wont insert the same data multiple times)
DELETE FROM
  b2b.l2_sa_sfdc_pipeline_core_snapshot
WHERE
  as_of_date = (SELECT MAX(as_of_date) FROM  b2b.l2_sa_sfdc_pipeline_core)

-- COMMAND ----------

-- DBTITLE 1,Insert into Snapshot (History Table) - Table is partitioned on as_of_date
INSERT INTO
  b2b.l2_sa_sfdc_pipeline_core_snapshot (
  opportunity_id,
  full_opty_id,
  deal_reg_id,
  deal_reg_flag,
  sales_order_number,
  sales_ops_reconciled,
  dme_ineligible,
  dme_ineligible_reason,
  vip_ea_clp_agreement_number,
  sfdc_link,
  opportunity_name,
  acct_name,
  acct_addr_country,
  partner_country,
  geo,
  route_to_market,
  licensing_program,
  lm_engagement,
  acct_dme_acct_group,
  opp_prod_interest,
  current_created_date,
  current_created_qtr,
  current_created_week,
  current_created_week_in_qtr,
  current_created_year_qtr,
  current_close_date,
  current_close_qtr,
  current_close_week,
  current_close_week_in_qtr,
  current_close_year_qtr,
  current_acceptintosalespipeline,
  current_stage,
  current_adj_commitment,
  current_business_commitment,
  current_closed_date_fx_rate,
  pipeline_accepted_rejected_by,
  rejection_notes,
  rejection_reason,
  booking_status,
  manager_adjusted_commitment,
  licensing_program_type,
  sales_play,
  approval_status,
  lead_id,
  created_by_id,
  industry,
  region_adjusted_commitment,
  geo_adjusted_commitment,
  market_area,
  campaign_name,
  opportunity_deal_type,
  opportunity_record_type,
  last_modified_date,
  days_since_last_modified,
  previous_close_date,
  iss_involvement,
  pipeline_creator,
  account_id,
  closure_date,
  acct_market_area,
  billing_country,
  created_by_full_name,
  record_owner,
  record_owner_full_name,
  campaign_id,
  campaign_group,
  snapshot_quarter,
  snapshot_week,
  additional_description,
  partner_account_name,
  region,
  sales_region,
  sub_market_area,
  estimated_revenue_usd,
  record_owner_division,
  record_owner_name,
  record_owner_role_name,
  record_owner_alias,
  highest_stage_value,
  created_alias,
  sql_date,
  total_new_asv_fx_neutral,
  account_manager_approval_status,
  days_since_deal_reg_next_steps_modified,
  days_since_next_steps_modified,
  stage_duration_in_days,
  closed_date_fx_rate,
  reason,
  am_approved_reject_date,
  sourcing_partner_id,
  sourcing_partner_name,
  track_adoption,
  account_level,
  internal_approval_status,
  opportunity_status,
  program,
  revenue_assurance_status,
  probability_percent,
  pipeline_creation_source,
  next_steps,
  executed_on,
  as_of_date)
  
SELECT
  opportunity_id,
  full_opty_id,
  deal_reg_id,
  deal_reg_flag,
  sales_order_number,
  sales_ops_reconciled,
  dme_ineligible,
  dme_ineligible_reason,
  vip_ea_clp_agreement_number,
  sfdc_link,
  opportunity_name,
  acct_name,
  acct_addr_country,
  partner_country,
  geo,
  route_to_market,
  licensing_program,
  lm_engagement,
  acct_dme_acct_group,
  opp_prod_interest,
  current_created_date,
  current_created_qtr,
  current_created_week,
  current_created_week_in_qtr,
  current_created_year_qtr,
  current_close_date,
  current_close_qtr,
  current_close_week,
  current_close_week_in_qtr,
  current_close_year_qtr,
  current_acceptintosalespipeline,
  current_stage,
  current_adj_commitment,
  current_business_commitment,
  current_closed_date_fx_rate,
  pipeline_accepted_rejected_by,
  rejection_notes,
  rejection_reason,
  booking_status,
  manager_adjusted_commitment,
  licensing_program_type,
  sales_play,
  approval_status,
  lead_id,
  created_by_id,
  industry,
  region_adjusted_commitment,
  geo_adjusted_commitment,
  market_area,
  campaign_name,
  opportunity_deal_type,
  opportunity_record_type,
  last_modified_date,
  days_since_last_modified,
  previous_close_date,
  iss_involvement,
  pipeline_creator,
  account_id,
  closure_date,
  acct_market_area,
  billing_country,
  created_by_full_name,
  record_owner,
  record_owner_full_name,
  campaign_id,
  campaign_group,
  snapshot_quarter,
  snapshot_week,
  additional_description,
  partner_account_name,
  region,
  sales_region,
  sub_market_area,
  estimated_revenue_usd,
  record_owner_division,
  record_owner_name,
  record_owner_role_name,
  record_owner_alias,
  highest_stage_value,
  created_alias,
  sql_date,
  total_new_asv_fx_neutral,
  account_manager_approval_status,
  days_since_deal_reg_next_steps_modified,
  days_since_next_steps_modified,
  stage_duration_in_days,
  closed_date_fx_rate,
  reason,
  am_approved_reject_date,
  sourcing_partner_id,
  sourcing_partner_name,
  track_adoption,
  account_level,
  internal_approval_status,
  opportunity_status,
  program,
  revenue_assurance_status,
  probability_percent,
  pipeline_creation_source,
  next_steps,
  executed_on,
  as_of_date
FROM
  b2b.l2_sa_sfdc_pipeline_core
