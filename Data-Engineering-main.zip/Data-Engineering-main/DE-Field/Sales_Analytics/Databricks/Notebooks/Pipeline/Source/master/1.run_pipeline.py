# Databricks notebook source
# DBTITLE 1,Declare Shared Functions (to allow us to log these job events)
# MAGIC %run ../../sales_analytics_shared_functions/declare_shared_functions

# COMMAND ----------

# DBTITLE 1,Run Pipeline Job - Opp Progerssion, Core, Line item, Segmentation & booking
# Declare Variables 
has_error = False
start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
myid = str(uuid.uuid4())
job_name = "Sales Pipeline"
logging_table = 'b2b.sales_analytics_job_log'

# List what notebooks need to run in the job;
notebooks_to_run = ["../1.create_pipeline_core",
                    "../2.create_pipeline_opp_progression",
                    "../3.create_pipeline_line_item",
                    "../4.create_pipeline_segmentation",
                    "../5.pipeline_bookings",
                    "../7.create_salesforce_user_hierarchy",
                    "../8.create_pipeline_funnel_types"
                   ]



# Log Job Start 
LogJobStart(myid,job_name,start_time,logging_table)

# Loop through the jobs list and run
for n in notebooks_to_run:

  try:    
    # Excute the current Job
    retValue = dbutils.notebook.run(n,0)

   # Catch Exceptions
  except Exception as e:
    has_error = True
    err_msg = f"Error in {n} Err Msg: " + str(e).replace("'",'')
    LogJobEnd(myid,job_name,start_time,"Error",err_msg,logging_table)
    if has_error:
        raise Exception("An Error Has occured - Please Check the Logs")

# Log Successful Job End
LogJobEnd(myid,job_name,start_time,"Success",'',logging_table)