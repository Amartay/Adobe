-- Databricks notebook source
-- MAGIC %md
-- MAGIC Connect Salesforce opportunities to their bookings in VIP and ELTA 

-- COMMAND ----------

-- DBTITLE 1,Step One - Split Salesforce Sales order numbers so they have one line per Sales Order Number
 DROP TABLE IF EXISTS  b2b_tmp.b2b_pipeline_opportunity_order_lookup;
 CREATE TABLE b2b_tmp.b2b_pipeline_opportunity_order_lookup (full_opty_id string,
                                                             sales_order_number_original string,
                                                             sales_order_number_cleaned string
                                                             ); 

 INSERT INTO  b2b_tmp.b2b_pipeline_opportunity_order_lookup (full_opty_id,sales_order_number_original,sales_order_number_cleaned)
 SELECT DISTINCT  full_opty_id,
         sales_order_number_original,
         explode(array_remove(orders,'')) as sales_order_number_cleaned
 FROM (
 SELECT DISTINCT full_opty_id,
                 sales_order_number as sales_order_number_original,
                     split(
                     regexp_replace(
                             regexp_replace(
                                 trim(regexp_replace(CASE WHEN substring(sales_order_number,-1) IN ('|',',','+','#',';',':','-','\\','/','.')
                                                          THEN substring(sales_order_number,1,(length(sales_order_number)-1))
                                                          ELSE sales_order_number END,
                                 '[A-za-z]','')),
                                 '[^0-9]',','),
                                 '[,]{2,}',','),
                         ',') as orders          
         FROM b2b.l2_sa_sfdc_pipeline_core
         WHERE  upper(replace(current_stage,' ','')) = 'CLOSED-BOOKED'
 )

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Data Quality Issue that will lead to double counting - Same sales document in multiple closed booked opportunities 
-- MAGIC
-- MAGIC There is a huge data quality issue with this entire approach, I raised this in the ticket 4447, no actions taken so far
-- MAGIC
-- MAGIC One sales order can exist in multiple bookings - this is obviously incorrect but it will cause to the same invoice being counted multiple times. This is due to dodgy data in salesforce. 
-- MAGIC Perhaps some proposed approach could be to make sure you only use each sales order once (forcing them to be in the opportnity with the highest Deal Reg ID or something)
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,show those sales documents that exist in multiple invoices
SELECT sales_order_number_cleaned, count(distinct full_opty_id) as no_of_opps
FROM b2b_tmp.b2b_pipeline_opportunity_order_lookup
GROUP BY sales_order_number_cleaned
HAVING count(distinct full_opty_id) > 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### VIP (Pivot)

-- COMMAND ----------

-- DBTITLE 1,Refresh metadata for pivot4all
REFRESH TABLE CSMB_APP.fact_csmb_subscription_detail;
REFRESH TABLE CSMB_APP.exchange_rate_type_qtrly;
REFRESH TABLE CSMB_APP.subscription_params;
REFRESH TABLE CSMB_APP.acct_segment_activity_cutoff;
REFRESH TABLE CSMB_APP.acct_segment_realign_hist;
REFRESH TABLE CSMB_APP.dim_gtm_acct_hierarchy;
REFRESH TABLE CSMB_APP.gtm_projected_segmentation;
REFRESH TABLE CSMB_APP.dim_subscription;
REFRESH TABLE CSMB_APP.dim_gtm_acct_segment;
REFRESH csmb.vw_ccm_pivot4_all;

-- COMMAND ----------

-- DBTITLE 1,Extract Pivot base date for all the sales orders I am interested in (Closed Booked in Core)
DROP TABLE IF EXISTS b2b_tmp.pivot_base;
CREATE TABLE b2b_tmp.pivot_base AS 
SELECT  p.ecc_customer_id,
        p.end_user_name,
        CASE WHEN Trim(Upper(p.product_name)) IN ('SBST', 'SRC', 'SBTX' ) 
              THEN 'Substance'
              ELSE p.prod_group_hier_description 
        END AS product_group,
        p.sales_document,
        p.net_new_arr_cfx,
        p.net_purchases_arr_cfx,
        p.net_cancelled_arr_cfx,
        p.migrated_to_arr_cfx,
        p.migrated_from_arr_cfx,
        p.gross_new_arr_cfx,
        p.renewal_to_arr_cfx,
        p.gross_new_subs,
        opps.full_opty_id
FROM csmb.vw_ccm_pivot4_all p
INNER JOIN (  SELECT DISTINCT full_opty_id, 
                              REGEXP_REPLACE(sales_order_number_cleaned, '^0+', '') AS sales_order_number_cleaned
              FROM  b2b_tmp.b2b_pipeline_opportunity_order_lookup
) opps
ON REGEXP_REPLACE(opps.sales_order_number_cleaned, '^0+', '') = REGEXP_REPLACE(p.sales_document, '^0+', '')
WHERE p.event_source = 'EVENT'
AND p.date_key >= '20210101' -- this is the earliest date in core (this is just to speed up this query)


-- COMMAND ----------

-- DBTITLE 1,Create Standardized ECC ID 
-- For some reason we have multiple distinct ECC ID's for one opportunity - this causes issues when connecting to the line items table - as we have multiple rows and will sum the ASV multiples times
-- to prevent this I am going to standardize the ECC ID where this happens 

DROP TABLE IF EXISTS b2b_tmp.standardize_ecc_id;
CREATE TABLE b2b_tmp.standardize_ecc_id AS 
SELECT  full_opty_id,
        ecc_customer_id,
        end_user_name
FROM ( 
  SELECT  full_opty_id,
          ecc_customer_id,
          end_user_name,
          ROW_NUMBER() OVER(PARTITION BY full_opty_id ORDER BY ecc_customer_id DESC) as ranking 
  FROM ( 
          SELECT DISTINCT full_opty_id, 
                          ecc_customer_id, 
                          end_user_name
          FROM b2b_tmp.pivot_base
  )
) 
WHERE ranking = 1;

-- COMMAND ----------

-- DBTITLE 1,Aggregate Pivot Base Data
DROP TABLE IF EXISTS b2b_tmp.pivot_base_aggregated;
CREATE TABLE b2b_tmp.pivot_base_aggregated AS 
SELECT  ecc.ecc_customer_id,
        ecc.end_user_name,
        pb.product_group,
        pb.full_opty_id,
        sum(net_new_arr_cfx) AS total_net_new_arr_cfx,
        sum(net_purchases_arr_cfx) AS total_net_purchases_arr_cfx,
        sum(net_cancelled_arr_cfx) AS total_net_cancelled_arr_cfx,
        sum(migrated_to_arr_cfx) AS total_migrated_to_arr_cfx,
        sum(migrated_from_arr_cfx) AS total_migrated_from_arr_cfx,
        sum(gross_new_arr_cfx) AS total_gross_new_arr_cfx,
        sum(renewal_to_arr_cfx) AS total_renewal_to_arr_cfx,
        sum(gross_new_subs) AS total_gross_new_subs
FROM b2b_tmp.pivot_base pb
LEFT JOIN b2b_tmp.standardize_ecc_id ecc 
  ON pb.full_opty_id = ecc.full_opty_id
GROUP BY  ecc.ecc_customer_id,
          ecc.end_user_name,
          pb.product_group,
          pb.full_opty_id


-- COMMAND ----------

-- DBTITLE 1,Connect Salesforce Data to Pivot
DROP TABLE IF EXISTS b2b_tmp.pivot_opp_bookings;
CREATE TABLE b2b_tmp.pivot_opp_bookings AS 
SELECT  c.opportunity_id, 
        c.full_opty_id,
        c.deal_reg_id,
        a.standardizedparentid AS parent_id,
        a.standardizedparent AS parent_name, 
        a.standardizedsubid AS sub_id,
        a.standardizedsub AS sub_name,
        c.geo,
        c.acct_dme_acct_group,
        'VIP' AS licensing_program,
        c.current_stage,
        c.sales_order_number AS sales_order_numbers,
        p.ecc_customer_id AS end_user_id,
        p.end_user_name AS end_user_name,
        p.product_group,
        li_agg.total_reportable_new_asv_fx_neutral, 
        c.acct_addr_country,
        c.current_close_date,
        'Forecasted Product Group Sales' AS purchase_type,
        p.total_net_new_arr_cfx,
        p.total_net_purchases_arr_cfx,
        p.total_net_cancelled_arr_cfx,
        p.total_migrated_to_arr_cfx,
        p.total_migrated_from_arr_cfx,
        p.total_gross_new_arr_cfx,
        p.total_renewal_to_arr_cfx,
        p.total_gross_new_subs
FROM b2b.l2_sa_sfdc_pipeline_core c
INNER JOIN (  
            -- get the total new asv by each product group for every opportunity in scope
            SELECT li.full_opty_id, li.product_group, sum(li.ori_reportable_new_asv_fx_neutral) AS total_reportable_new_asv_fx_neutral
            FROM ( 
                    SELECT li.full_opty_id,
                            CASE  WHEN li.product_code_1 IN ('SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                                  WHEN li.prod_majorolpg1 IN ('ACROBAT','DCE') THEN 'Acrobat DC'
                                  WHEN li.prod_majorolpg1 IN ('SIGN','DCE TRANSACTION') THEN 'Adobe Sign'
                                  WHEN li.prod_majorolpg1 IN ('CREATIVE') THEN 'Creative - Professio'
                                  WHEN li.prod_majorolpg1 IN ('CCE STOCK', 'STOCK') THEN 'Stock Photography'
                                  ELSE 'Other'
                            END AS product_group,
                      ori_reportable_new_asv_fx_neutral
                      FROM b2b.l2_sa_sfdc_pipeline_line_item li
            ) li
            GROUP BY li.full_opty_id, li.product_group
) li_agg
ON c.full_opty_id = li_agg.full_opty_id
INNER JOIN b2b_tmp.pivot_base_aggregated p
ON p.full_opty_id = c.full_opty_id AND p.product_group = li_agg.product_group -- If you join on opportunity & product - you are a forecasted purchase
INNER JOIN (  SELECT id, 
                     standardizedparentid,
                     standardizedparent,
                     standardizedsubid,
                     standardizedsub
              FROM b2b.uda_replicn_sf_corp_uda_vw_account
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_account) ) a 
ON c.account_id = a.id
WHERE upper(replace(c.current_stage,' ','')) = 'CLOSED-BOOKED'


UNION ALL 

SELECT  c.opportunity_id, 
        c.full_opty_id,
        c.deal_reg_id,
        a.standardizedparentid AS parent_id,
        a.standardizedparent AS parent_name, 
        a.standardizedsubid AS sub_id,
        a.standardizedsub AS sub_name,
        c.geo,
        c.acct_dme_acct_group,
        'VIP' AS licensing_program,
        c.current_stage,
        c.sales_order_number AS sales_order_numbers,
        p.ecc_customer_id AS end_user_id,
        p.end_user_name AS end_user_name,
        p.product_group,
        NULL AS total_reportable_new_asv_fx_neutral, --Unforecasted purchases have no ASV value - as no sale was expected in salesforce
        c.acct_addr_country,
        c.current_close_date,
        'Unforecasted Product Group Sales' AS purchase_type,
        p.total_net_new_arr_cfx,
        p.total_net_purchases_arr_cfx,
        p.total_net_cancelled_arr_cfx,
        p.total_migrated_to_arr_cfx,
        p.total_migrated_from_arr_cfx,
        p.total_gross_new_arr_cfx,
        p.total_renewal_to_arr_cfx,
        p.total_gross_new_subs
FROM b2b.l2_sa_sfdc_pipeline_core c
INNER JOIN b2b_tmp.pivot_base_aggregated p
ON p.full_opty_id = c.full_opty_id 
LEFT JOIN (  
            -- get the opportunity product group combinations from the line item tables (expected purchases)
            SELECT DISTINCT concat(full_opty_id,'-',li.product_group) as li_key
            FROM ( 
                    SELECT li.full_opty_id,
                            CASE  WHEN li.product_code_1 IN ('SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                                  WHEN li.prod_majorolpg1 IN ('ACROBAT','DCE') THEN 'Acrobat DC'
                                  WHEN li.prod_majorolpg1 IN ('SIGN','DCE TRANSACTION') THEN 'Adobe Sign'
                                  WHEN li.prod_majorolpg1 IN ('CREATIVE') THEN 'Creative - Professio'
                                  WHEN li.prod_majorolpg1 IN ('CCE STOCK', 'STOCK') THEN 'Stock Photography'
                                  ELSE 'Other'
                            END AS product_group
                      FROM b2b.l2_sa_sfdc_pipeline_line_item li
            ) li
            
) li_key
ON concat(c.full_opty_id,'-',p.product_group) = li_key.li_key
INNER JOIN (  SELECT id, 
                     standardizedparentid,
                     standardizedparent,
                     standardizedsubid,
                     standardizedsub
              FROM b2b.uda_replicn_sf_corp_uda_vw_account
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_account) ) a 
ON c.account_id = a.id
WHERE upper(replace(c.current_stage,' ','')) = 'CLOSED-BOOKED'
AND li_key.li_key IS NULL -- the opportunity product combination from pivot did not exist in line items and therefore this is an unforecasted purchase



-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Ent Arr
-- MAGIC
-- MAGIC This query was provided to me from Jai

-- COMMAND ----------

-- Code to standardize user id and user name - to force it to have one user per opprorunity - based on the highest ID 
DROP TABLE IF EXISTS b2b_tmp.standardized_user;
CREATE TABLE b2b_tmp.standardized_user AS 
SELECT sfdcopportunityid AS full_opty_id, 
       enduser AS end_user_id, 
       endusername AS end_user_name
FROM ( 
      SELECT  enduser,
              endusername, 
              sfdcopportunityid,
              ROW_NUMBER() OVER(PARTITION BY sfdcopportunityid ORDER BY enduser DESC, len(enduser) DESC) as ranking 
      FROM ( 
      SELECT DISTINCT enduser, 
                      endusername,
                      sfdcopportunityid
      FROM b2b.uda_uda_finance_arr_vw_entarr 
      WHERE sfdcopportunityid IN ( SELECT full_opty_id  FROM b2b.l2_sa_sfdc_pipeline_core
                                WHERE  upper(replace(current_stage,' ','')) = 'CLOSED-BOOKED') 
      )
) 
WHERE ranking = 1

-- COMMAND ----------

-- DBTITLE 1,Entprise ARR - Arr Movements

DROP TABLE IF EXISTS b2b_tmp.ent_arr_bookings_arr_movements;
CREATE TABLE b2b_tmp.ent_arr_bookings_arr_movements AS 
SELECT DISTINCT licensing_program_group,
                product_group,     
                Main.enduserid,
                sfdcopportunityid,   
                sum( main.current_week_ending_arr-Main.previous_week_ending_arr) as gross_new_arr                  
FROM  ( SELECT    base.licensing_program_group,
                  base.product_group,
                  base.current_week_ending_arr,
                  base.enduserid,
                  base.sfdcopportunityid,
                  base.datedate,
                  coalesce(lag(current_week_ending_arr) OVER (PARTITION BY licensing_program_group,enduserid,sfdcopportunityid, product_group ORDER BY datedate),0) AS previous_week_ending_arr
FROM (
        -- Base Table
        SELECT DISTINCT 'ETLA' AS licensing_program_group,         
                        username.end_user_id AS enduserid,
                        entarr01.sfdcopportunityid,
                        entarr01.datedate,
                CASE WHEN entarr01.productname IN ( 'SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                WHEN entarr01.olpg IN ( 'ACROBAT') THEN 'Acrobat DC'
                WHEN entarr01.olpg IN ( 'SIGN', 'DCE TRANSACTION','DCE' ) THEN 'Adobe Sign'
                WHEN entarr01.olpg IN ( 'CREATIVE' ) THEN 'Creative - Professio'
                WHEN entarr01.olpg IN ( 'CCE STOCK', 'STOCK' ) THEN 'Stock Photography'
                ELSE 'Unmapped'
              END AS product_group,
              Sum(Cast(coalesce(entarr01.totalendingarr,0) AS DOUBLE)) AS current_week_ending_arr
        FROM  b2b.uda_uda_finance_arr_vw_entarr entarr01
        INNER JOIN b2b_tmp.hana_ccmusage_dim_date dimdate
          ON dimdate.date_key = replace(entarr01.DateDate,'-','')
        LEFT JOIN b2b_tmp.standardized_user username 
            ON entarr01.sfdcopportunityid = username.full_opty_id
        WHERE entarr01.SnapshotType = 'W' 
        AND entarr01.sfdcopportunityid IN ( SELECT full_opty_id  FROM b2b.l2_sa_sfdc_pipeline_core
                           WHERE  upper(replace(current_stage,' ','')) = 'CLOSED-BOOKED') -- if the opportunity isnt in core it wont join regardless so we dont care about it
        AND entarr01.DateDate >='2020-12-01'
        AND entarr01.arrstatus='ACTIVE'
        AND ( entarr01.productgrouphier != 'IS17' -- non adobe sign product groups
        AND businesstype!='PPBU'
        OR ( --  ETLA data with SIGN Legacy
                  entarr01.productgrouphier = 'IS17'
                  AND Upper(entarr01.etlaseattype) IN ('ETLA- STANDARD', 'ETLA- HYBRID','ETLA- ACCESS' ) 
            )
        )
        GROUP  BY  datedate,
                  username.end_user_id,
                  entarr01.contractquantity,
                  entarr01.sfdcopportunityid,
                  CASE
                    WHEN entarr01.productname IN ( 'SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                    WHEN entarr01.olpg IN ( 'ACROBAT') THEN 'Acrobat DC'
                    WHEN entarr01.olpg IN ( 'SIGN', 'DCE TRANSACTION','DCE' ) THEN 'Adobe Sign'
                    WHEN entarr01.olpg IN ( 'CREATIVE' ) THEN 'Creative - Professio'
                    WHEN entarr01.olpg IN ( 'CCE STOCK', 'STOCK' ) THEN 'Stock Photography'
                    ELSE 'Unmapped'
                  END          
                  
  ) base 
) Main 
WHERE coalesce(Main.previous_week_ending_arr,0)!=Main.current_week_ending_arr 
GROUP BY 
         licensing_program_group,
         product_group,                
         Main.enduserid,
         sfdcopportunityid
HAVING sum( main.current_week_ending_arr-Main.previous_week_ending_arr) >=0 -- remove negatives as requsted by Jai


-- COMMAND ----------

-- DBTITLE 1,Entprise ARR - Quantity Movements
-- You can change ARR amounts without changing quantity - because of this you cannot use the ARR movements to sum quantity for subs (current week quantity  = 45, previous weeks = 45 would therefore equal 0 subs) - a separate query has to be written for this, pretty much the same query but looking at quantity movements
-- not ARR 

DROP TABLE IF EXISTS b2b_tmp.ent_arr_bookings_quantity_movements;
CREATE TABLE b2b_tmp.ent_arr_bookings_quantity_movements AS 
SELECT DISTINCT licensing_program_group,
                product_group,     
                Main.enduserid,
                sfdcopportunityid,   
                sum( main.current_week_ending_quantity-Main.previous_week_ending_quantity) as quantity_movement                 
FROM  ( SELECT    base.licensing_program_group,
                  base.product_group,
                  base.enduserid,
                  base.current_week_ending_quantity,
                  base.sfdcopportunityid,
                  base.datedate,
                  coalesce(lag(current_week_ending_quantity) OVER (PARTITION BY licensing_program_group,enduserid,sfdcopportunityid, product_group ORDER BY datedate),0) AS previous_week_ending_quantity
FROM (
        -- Base Table
        SELECT DISTINCT 'ETLA' AS licensing_program_group,         
                        username.end_user_id AS enduserid,
                        entarr01.sfdcopportunityid,
                        entarr01.datedate,
                CASE WHEN entarr01.productname IN ( 'SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                WHEN entarr01.olpg IN ( 'ACROBAT') THEN 'Acrobat DC'
                WHEN entarr01.olpg IN ( 'SIGN', 'DCE TRANSACTION','DCE' ) THEN 'Adobe Sign'
                WHEN entarr01.olpg IN ( 'CREATIVE' ) THEN 'Creative - Professio'
                WHEN entarr01.olpg IN ( 'CCE STOCK', 'STOCK' ) THEN 'Stock Photography'
                ELSE 'Unmapped'
              END AS product_group,
              Sum(Cast(coalesce(entarr01.contractquantity,0) AS DOUBLE)) AS current_week_ending_quantity
        FROM  b2b.uda_uda_finance_arr_vw_entarr entarr01
        INNER JOIN b2b_tmp.hana_ccmusage_dim_date dimdate
          ON dimdate.date_key = replace(entarr01.DateDate,'-','')
        LEFT JOIN b2b_tmp.standardized_user username 
            ON entarr01.sfdcopportunityid = username.full_opty_id
        WHERE entarr01.SnapshotType = 'W' 
        AND entarr01.sfdcopportunityid IN ( SELECT full_opty_id  FROM b2b.l2_sa_sfdc_pipeline_core
                           WHERE  upper(replace(current_stage,' ','')) = 'CLOSED-BOOKED') -- if the opportunity isnt in core it wont join regardless so we dont care about it
        AND entarr01.DateDate >='2020-12-01'
        AND entarr01.arrstatus='ACTIVE'
        AND ( entarr01.productgrouphier != 'IS17' -- non adobe sign product groups
        AND businesstype!='PPBU'
        OR ( --  ETLA data with SIGN Legacy
                  entarr01.productgrouphier = 'IS17'
                  AND Upper(entarr01.etlaseattype) IN ('ETLA- STANDARD', 'ETLA- HYBRID','ETLA- ACCESS' ) 
            )
        )
        GROUP  BY  datedate,
                  username.end_user_id,
                  entarr01.contractquantity,
                  entarr01.sfdcopportunityid,
                  CASE
                    WHEN entarr01.productname IN ( 'SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                    WHEN entarr01.olpg IN ( 'ACROBAT') THEN 'Acrobat DC'
                    WHEN entarr01.olpg IN ( 'SIGN', 'DCE TRANSACTION','DCE' ) THEN 'Adobe Sign'
                    WHEN entarr01.olpg IN ( 'CREATIVE' ) THEN 'Creative - Professio'
                    WHEN entarr01.olpg IN ( 'CCE STOCK', 'STOCK' ) THEN 'Stock Photography'
                    ELSE 'Unmapped'
                  END          
                  
  ) base 
) Main 
WHERE coalesce(Main.previous_week_ending_quantity,0)!=Main.current_week_ending_quantity 
GROUP BY 
         licensing_program_group,
         product_group,                
         Main.enduserid,
         sfdcopportunityid



-- COMMAND ----------

-- DBTITLE 1,Combine Quantity Movements With ARR Movements
DROP TABLE IF EXISTS b2b_tmp.combined_etla;
CREATE TABLE b2b_tmp.combined_etla AS 
SELECT  arr.licensing_program_group,
        arr.product_group,     
        arr.enduserid,
        arr.sfdcopportunityid,
        arr.gross_new_arr,
        q.quantity_movement AS contractquantity
FROM b2b_tmp.ent_arr_bookings_arr_movements arr 
LEFT JOIN b2b_tmp.ent_arr_bookings_quantity_movements q
ON arr.sfdcopportunityid = q.sfdcopportunityid 
AND arr.product_group = q.product_group 
AND arr.enduserid = q.enduserid 

-- COMMAND ----------

-- DBTITLE 1,Create ETLA Bookings Table
DROP TABLE IF EXISTS b2b_tmp.etla_opp_bookings;
CREATE TABLE b2b_tmp.etla_opp_bookings AS 

-- Forecasted Sales - Where the line item product Group is actually what is booked 
SELECT  c.opportunity_id, 
        c.full_opty_id,
        c.deal_reg_id,
        a.standardizedparentid AS parent_id,
        a.standardizedparent AS parent_name, 
        a.standardizedsubid AS sub_id,
        a.standardizedsub AS sub_name,
        c.geo,
        c.acct_dme_acct_group,
        entarr.licensing_program_group,
        c.current_stage,
        c.sales_order_number as sales_order_numbers,
        username.end_user_id AS end_user_id,
        username.end_user_name AS end_user_name,
        entarr.product_group, 
        li_agg.total_reportable_new_asv_fx_neutral,
        c.acct_addr_country,
        c.current_close_date,
         'Forecasted Product Group Sales' AS purchase_type,
        CAST(NULL AS STRING) AS total_net_new_arr_cfx,
        CAST(NULL AS STRING)  AS total_net_purchases_arr_cfx,
        CAST(NULL AS STRING) AS total_net_cancelled_arr_cfx,
        CAST(NULL AS STRING)  AS total_migrated_to_arr_cfx,
        CAST(NULL AS STRING)  AS total_migrated_from_arr_cfx,
        entarr.gross_new_arr AS total_gross_new_arr_cfx,
        CAST(NULL AS STRING)  AS total_renewal_to_arr_cfx,
        entarr.contractquantity AS total_gross_new_subs
FROM b2b.l2_sa_sfdc_pipeline_core c
INNER JOIN (  
            -- get the total new asv by each product group for every opportunity in scope
            SELECT li.full_opty_id, li.product_group, sum(li.ori_reportable_new_asv_fx_neutral) AS total_reportable_new_asv_fx_neutral
            FROM ( 
                    SELECT li.full_opty_id,
                            CASE  WHEN li.product_code_1 IN ('SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                                  WHEN li.prod_majorolpg1 IN ('ACROBAT','DCE') THEN 'Acrobat DC'
                                  WHEN li.prod_majorolpg1 IN ('SIGN','DCE TRANSACTION') THEN 'Adobe Sign'
                                  WHEN li.prod_majorolpg1 IN ('CREATIVE') THEN 'Creative - Professio'
                                  WHEN li.prod_majorolpg1 IN ('CCE STOCK', 'STOCK') THEN 'Stock Photography'
                                  ELSE 'Other'
                            END AS product_group,
                      ori_reportable_new_asv_fx_neutral
                      FROM b2b.l2_sa_sfdc_pipeline_line_item li
            ) li
            GROUP BY li.full_opty_id, li.product_group
) li_agg
ON c.full_opty_id = li_agg.full_opty_id
INNER JOIN b2b_tmp.combined_etla entarr
ON entarr.sfdcopportunityid = c.full_opty_id AND entarr.product_group = li_agg.product_group --  If you join on opportunity & product - you are a forecasted purchase
INNER JOIN (  SELECT id, 
                     standardizedparentid,
                     standardizedparent,
                     standardizedsubid,
                     standardizedsub
              FROM b2b.uda_replicn_sf_corp_uda_vw_account
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_account) ) a 
ON c.account_id = a.id
LEFT JOIN b2b_tmp.standardized_user username 
    ON c.full_opty_id = username.full_opty_id
WHERE upper(replace(c.current_stage,' ','')) = 'CLOSED-BOOKED'

UNION ALL 

SELECT  c.opportunity_id, 
        c.full_opty_id,
        c.deal_reg_id,
        a.standardizedparentid AS parent_id,
        a.standardizedparent AS parent_name, 
        a.standardizedsubid AS sub_id,
        a.standardizedsub AS sub_name,
        c.geo,
        c.acct_dme_acct_group,
        entarr.licensing_program_group,
        c.current_stage,
        c.sales_order_number as sales_order_numbers,
        username.end_user_id AS end_user_id,
        username.end_user_name AS end_user_name,
        entarr.product_group, 
        NULL AS total_reportable_new_asv_fx_neutral, -- if you arent forecasted in salesforce you dont have a asv 
        c.acct_addr_country,
        c.current_close_date,
        'Unforecasted Product Group Sales' AS purchase_type,
        CAST(NULL AS STRING) AS total_net_new_arr_cfx,
        CAST(NULL AS STRING)  AS total_net_purchases_arr_cfx,
        CAST(NULL AS STRING) AS total_net_cancelled_arr_cfx,
        CAST(NULL AS STRING)  AS total_migrated_to_arr_cfx,
        CAST(NULL AS STRING)  AS total_migrated_from_arr_cfx,
        entarr.gross_new_arr AS total_gross_new_arr_cfx,
        CAST(NULL AS STRING)  AS total_renewal_to_arr_cfx,
        entarr.contractquantity AS total_gross_new_subs
FROM b2b.l2_sa_sfdc_pipeline_core c
INNER JOIN b2b_tmp.combined_etla entarr
ON entarr.sfdcopportunityid = c.full_opty_id 
LEFT JOIN (  
            -- get the opportunity product group combinations from the line item tables (expected purchases)
            SELECT DISTINCT concat(full_opty_id,'-',li.product_group) as li_key
            FROM ( 
                    SELECT li.full_opty_id,
                            CASE  WHEN li.product_code_1 IN ('SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                                  WHEN li.prod_majorolpg1 IN ('ACROBAT','DCE') THEN 'Acrobat DC'
                                  WHEN li.prod_majorolpg1 IN ('SIGN','DCE TRANSACTION') THEN 'Adobe Sign'
                                  WHEN li.prod_majorolpg1 IN ('CREATIVE') THEN 'Creative - Professio'
                                  WHEN li.prod_majorolpg1 IN ('CCE STOCK', 'STOCK') THEN 'Stock Photography'
                                  ELSE 'Other'
                            END AS product_group
                      FROM b2b.l2_sa_sfdc_pipeline_line_item li
            ) li        
) li_key
ON concat(c.full_opty_id,'-',entarr.product_group) = li_key.li_key
INNER JOIN (  SELECT id, 
                     standardizedparentid,
                     standardizedparent,
                     standardizedsubid,
                     standardizedsub
              FROM b2b.uda_replicn_sf_corp_uda_vw_account
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_account) ) a 
ON c.account_id = a.id
LEFT JOIN b2b_tmp.standardized_user username 
    ON c.full_opty_id = username.full_opty_id
WHERE upper(replace(c.current_stage,' ','')) = 'CLOSED-BOOKED'
AND li_key.li_key IS NULL -- the opportunity product combination from entarr did not exist in line items and therefore this is an unforecasted purchase




-- COMMAND ----------

DROP TABLE IF EXISTS b2b.l2_sa_sfdc_pipeline_bookings;
CREATE TABLE b2b.l2_sa_sfdc_pipeline_bookings AS  
SELECT  opportunity_id, 
        full_opty_id,
        deal_reg_id,
        parent_id,
        parent_name, 
        sub_id,
        sub_name,
        geo,
        acct_dme_acct_group,
        licensing_program,
        current_stage,
        sales_order_numbers,
        end_user_id,
        end_user_name,
        product_group, 
        total_reportable_new_asv_fx_neutral,
        acct_addr_country,
        current_close_date,
        purchase_type,
        cast(total_net_new_arr_cfx AS DECIMAL(20,2)) AS total_net_new_arr_cfx,
        cast(total_net_purchases_arr_cfx AS DECIMAL(20,2)) AS total_net_purchases_arr_cfx,
        cast(total_net_cancelled_arr_cfx AS DECIMAL(20,2)) AS total_net_cancelled_arr_cfx,
        cast(total_migrated_to_arr_cfx  AS DECIMAL(20,2)) AS total_migrated_to_arr_cfx,
        cast(total_migrated_from_arr_cfx  AS DECIMAL(20,2)) AS total_migrated_from_arr_cfx,
        cast(total_gross_new_arr_cfx  AS DECIMAL(20,2)) AS total_gross_new_arr_cfx,
        cast(total_renewal_to_arr_cfx  AS DECIMAL(20,2)) AS total_renewal_to_arr_cfx,
        cast(total_gross_new_subs AS BIGINT) AS total_gross_new_subs
FROM b2b_tmp.pivot_opp_bookings
UNION ALL 
SELECT  opportunity_id, 
        full_opty_id,
        deal_reg_id,
        parent_id,
        parent_name, 
        sub_id,
        sub_name,
        geo,
        acct_dme_acct_group,
        licensing_program_group,
        current_stage,
        sales_order_numbers,
        end_user_id,
        end_user_name,
        product_group, 
        total_reportable_new_asv_fx_neutral,
        acct_addr_country,
        current_close_date,
        purchase_type,
        cast(total_net_new_arr_cfx AS DECIMAL(20,2)) AS total_net_new_arr_cfx,
        cast(total_net_purchases_arr_cfx AS DECIMAL(20,2)) AS total_net_purchases_arr_cfx,
        cast(total_net_cancelled_arr_cfx AS DECIMAL(20,2)) AS total_net_cancelled_arr_cfx,
        cast(total_migrated_to_arr_cfx  AS DECIMAL(20,2)) AS total_migrated_to_arr_cfx,
        cast(total_migrated_from_arr_cfx  AS DECIMAL(20,2)) AS total_migrated_from_arr_cfx,
        cast(total_gross_new_arr_cfx  AS DECIMAL(20,2)) AS total_gross_new_arr_cfx,
        cast(total_renewal_to_arr_cfx  AS DECIMAL(20,2)) AS total_renewal_to_arr_cfx,
        cast(total_gross_new_subs AS BIGINT) AS total_gross_new_subs
FROM b2b_tmp.etla_opp_bookings

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Remaining Opportunities
-- MAGIC For some reason there is a requirement to put opportunities in this table which do not join to either pivot or enterprise ARR - I'm too sure I understand why non existance doesnt show you this - but there you go - Insert all the opportunties in a closed booked state which are not in the table;

-- COMMAND ----------

-- DBTITLE 1,Opportunities That Dont Join
INSERT INTO b2b.l2_sa_sfdc_pipeline_bookings (opportunity_id,
                                                    full_opty_id,
                                                    deal_reg_id,
                                                    parent_id,
                                                    parent_name,
                                                    sub_id,
                                                    sub_name,
                                                    geo,
                                                    acct_dme_acct_group,
                                                    licensing_program,
                                                    current_stage,
                                                    sales_order_numbers,
                                                    end_user_id,
                                                    end_user_name,
                                                    product_group,
                                                    total_reportable_new_asv_fx_neutral,
                                                    acct_addr_country,
                                                    current_close_date,
                                                    purchase_type,
                                                    total_net_new_arr_cfx,
                                                    total_net_purchases_arr_cfx,
                                                    total_net_cancelled_arr_cfx,
                                                    total_migrated_to_arr_cfx,
                                                    total_migrated_from_arr_cfx,
                                                    total_gross_new_arr_cfx,
                                                    total_renewal_to_arr_cfx,
                                                    total_gross_new_subs)
SELECT  c.opportunity_id,
        c.full_opty_id,
        c.deal_reg_id,
        a.standardizedparentid AS parent_id,
        a.standardizedparent AS parent_name, 
        a.standardizedsubid AS sub_id,
        a.standardizedsub AS sub_name,
        c.geo,
        c.acct_dme_acct_group,
        c.licensing_program,
        c.current_stage,
        c.sales_order_number as sales_order_numbers,
        CAST(NULL AS STRING) AS end_user_id,
        CAST(NULL AS STRING) AS end_user_name,
        li_agg.product_group, 
        li_agg.total_reportable_new_asv_fx_neutral,
        c.acct_addr_country,
        c.current_close_date,
        'No Purchase Found' AS purchase_type,
        CAST(NULL AS DECIMAL(20,2)) AS total_net_new_arr_cfx,
        CAST(NULL AS DECIMAL(20,2))  AS total_net_purchases_arr_cfx,
        CAST(NULL AS DECIMAL(20,2)) AS total_net_cancelled_arr_cfx,
        CAST(NULL AS DECIMAL(20,2))  AS total_migrated_to_arr_cfx,
        CAST(NULL AS DECIMAL(20,2))  AS total_migrated_from_arr_cfx,
        CAST(NULL AS DECIMAL(20,2))  AS total_gross_new_arr_cfx,
        CAST(NULL AS DECIMAL(20,2))  AS total_renewal_to_arr_cfx,
        CAST(NULL AS DECIMAL(20,2))  AS total_gross_new_subs
FROM b2b.l2_sa_sfdc_pipeline_core c
INNER JOIN (  
            -- get the total new asv by each product group for every opportunity in scope
            SELECT li.full_opty_id, li.product_group, sum(li.ori_reportable_new_asv_fx_neutral) AS total_reportable_new_asv_fx_neutral
            FROM ( 
                    SELECT li.full_opty_id,
                            CASE  WHEN li.product_code_1 IN ('SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                                  WHEN li.prod_majorolpg1 IN ('ACROBAT','DCE') THEN 'Acrobat DC'
                                  WHEN li.prod_majorolpg1 IN ('SIGN','DCE TRANSACTION') THEN 'Adobe Sign'
                                  WHEN li.prod_majorolpg1 IN ('CREATIVE') THEN 'Creative - Professio'
                                  WHEN li.prod_majorolpg1 IN ('CCE STOCK', 'STOCK') THEN 'Stock Photography'
                                  ELSE 'Other'
                            END AS product_group,
                      ori_reportable_new_asv_fx_neutral
                      FROM b2b.l2_sa_sfdc_pipeline_line_item li
            ) li
            GROUP BY li.full_opty_id, li.product_group
) li_agg
ON c.full_opty_id = li_agg.full_opty_id
INNER JOIN (  SELECT id, 
                     standardizedparentid,
                     standardizedparent,
                     standardizedsubid,
                     standardizedsub
              FROM b2b.uda_replicn_sf_corp_uda_vw_account
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_account) ) a 
ON c.account_id = a.id
WHERE upper(replace(c.current_stage,' ','')) = 'CLOSED-BOOKED'
AND c.full_opty_id NOT IN ( SELECT full_opty_id FROM b2b.l2_sa_sfdc_pipeline_bookings )


-- COMMAND ----------

-- DBTITLE 1,Tidy Up TMP Tables - Disable this if you want to debug
DROP TABLE IF EXISTS b2b_tmp.b2b_pipeline_opportunity_order_lookup;
DROP TABLE IF EXISTS b2b_tmp.pivot_base;
DROP TABLE IF EXISTS b2b_tmp.standardize_ecc_id;
DROP TABLE IF EXISTS b2b_tmp.pivot_base_aggregated;
DROP TABLE IF EXISTS b2b_tmp.pivot_opp_bookings;
DROP TABLE IF EXISTS b2b_tmp.standardized_endusername;
DROP TABLE IF EXISTS b2b_tmp.ent_arr_bookings_arr_movements;
DROP TABLE IF EXISTS b2b_tmp.ent_arr_bookings_quantity_movements;
DROP TABLE IF EXISTS b2b_tmp.combined_etla;
DROP TABLE IF EXISTS b2b_tmp.etla_opp_bookings;

