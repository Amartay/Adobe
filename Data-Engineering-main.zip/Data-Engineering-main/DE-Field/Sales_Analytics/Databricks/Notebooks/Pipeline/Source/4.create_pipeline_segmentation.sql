-- Databricks notebook source
-- MAGIC %md
-- MAGIC #Sales Pipeline - Segmentation
-- MAGIC Wiki Page: https://wiki.corp.adobe.com/display/CCM/Sales+Pipeline+L2+-+Segmentation
-- MAGIC
-- MAGIC *Note: I strongly recommend reading this page before looking at the code (in particular PSS) - however I have put the relevant requirements as comments in this notebook to aid the reader*
-- MAGIC
-- MAGIC Tasks Performed in Notebook:
-- MAGIC
-- MAGIC - Create Temporary Tables (so if a sub query has to be run multiple times we can access its result set with one run)
-- MAGIC - Select opportunities associated with the AMER GBD Team - Write these opportunity IDs into a lookup table with an AMER GBD tag
-- MAGIC - Select opportunities associated with the AMER MM 22 Team - Write these opportunity IDs into a lookup table with an AMER MM 22 tag
-- MAGIC - Select opportunities associated with the AMER MM 23 Team - Write these opportunity IDs into a lookup table with an AMER MM 23 tag
-- MAGIC - Select opportunities associated with the AMER EDU Team - Write these opportunity IDs into a lookup table with an AMER EDU tag
-- MAGIC - Select opportunities associated with the LATAM ENTERPRISE Team - Write these opportunity IDs into a lookup table with an LATAM ENTERPRISE tag
-- MAGIC - Select opportunities associated with the EMEA CNX Team - Write these opportunity IDs into a lookup table with an EMEA CNX  tag
-- MAGIC - Select opportunities associated with the EMEA PSS 2022 Q3 Team - Write these opportunity IDs into a lookup table with an EMEA PSS 2022 Q3 tag
-- MAGIC - Select opportunities associated with the EMEA PSS 2022 Q4 Team - Write these opportunity IDs into a lookup table with an EMEA PSS 2022 Q4  tag
-- MAGIC - Select opportunities associated with the EMEA PSS 2023 Team - Write these opportunity IDs into a lookup table with an EMEA PSS 2023 tag
-- MAGIC - Select opportunities associated with the EMEA EDU Team - Write these opportunity IDs into a lookup table with an EMEA EDU tag
-- MAGIC - Select opportunities associated with the EMEA ENT/SMB Operations - Write these opportunity IDs into a lookup table with an ENT or SMB Flag where appropriate
-- MAGIC - Pivot the lookup table populated in the previous stages to produce the output report. One row per opportunity, one column per team.
-- MAGIC - Remove temporary tables
-- MAGIC

-- COMMAND ----------

REFRESH TABLE b2b.uda_replicn_sf_corp_uda_vw_product2;
REFRESH TABLE b2b.uda_replicn_sf_corp_uda_vw_adoberole;

-- COMMAND ----------

-- DBTITLE 1,Create Temporary Object - Current dates for underlying tables
-- in various sub queries we will want to know the max(as_of_date) in order to fetch the current records. To save my having to fetch this by scanning the whole table each time, I perform this query once and write them to a table - this way a tiny table is fetched when we need them.

DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_assignment_variables;
CREATE TABLE b2b_tmp.b2b_tmp_assignment_variables (key string, value string);

INSERT INTO b2b_tmp.b2b_tmp_assignment_variables(key,value)
SELECT  'Opp - Max as of Date',
        max(as_of_date) 
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity
UNION ALL
SELECT 'Acc - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_account
UNION ALL
SELECT  'User - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_user 
UNION ALL
SELECT  'Sales Team Assignment - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment 
UNION ALL
SELECT  'Line Item - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
UNION ALL 
SELECT 'Product - Max as of Date',
        max(as_of_date)
FROM b2b.uda_replicn_sf_corp_uda_vw_product2;


-- COMMAND ----------

-- DBTITLE 1,Create Temporary Object - Sales Team Usernames
-- These subsets (the sales team users and created by users) are referenced in numerous places
-- these tables mean we can run the query for these once and reference the results multiple times

-- Sales Team User Names
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_sales_team_usernames;
CREATE TABLE b2b_tmp.b2b_tmp_sales_team_usernames (opportunity string,FullName1 string) ;

INSERT INTO b2b_tmp.b2b_tmp_sales_team_usernames (opportunity,FullName1) 
SELECT DISTINCT opportunity, lower(FullName1) as FullName1
FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment prodSalesAss
INNER JOIN b2b.uda_replicn_sf_corp_uda_vw_user user 
    ON user.UserID = prodSalesAss.SalesTeamMember
WHERE user.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='User - Max as of Date')
AND prodSalesAss.as_of_date = ( SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Sales Team Assignment - Max as of Date');


-- COMMAND ----------

-- DBTITLE 1,Create Temporary Object - Created by Usernames
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_created_by_usernames;
CREATE TABLE b2b_tmp.b2b_tmp_created_by_usernames (opportunity string,FullName1 string) ;

INSERT INTO b2b_tmp.b2b_tmp_created_by_usernames (opportunity,FullName1) 
SELECT DISTINCT opp.fulloptyid, lower(FullName1) as FullName1
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN (    SELECT userid, FullName1 
                FROM b2b.uda_replicn_sf_corp_uda_vw_user
                WHERE as_of_date = (    SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='User - Max as of Date')
            ) createdBy 
ON createdBy.UserID = opp.createdbyid
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE) ;

-- COMMAND ----------

-- DBTITLE 1,Create Temporary Object - Line Items with Reportable ASV Growth FX Neutral >= 0
DROP TABLE IF EXISTS b2b_tmp.asv_by_opportunity;
CREATE TABLE b2b_tmp.asv_by_opportunity AS

SELECT  OpportunityID,
        sum(CASE WHEN ReportableASV_GrowthFX_Neutral IS NULL THEN NULL
                 ELSE round(cast(ReportableASV_GrowthFX_Neutral AS double), 0)
                  END) AS ReportableASV_GrowthFX_Neutral
FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
INNER JOIN  ( SELECT  ProductID 
              FROM b2b.uda_replicn_sf_corp_uda_vw_product2
              WHERE as_of_date IN (SELECT max(as_of_date) 
                                  FROM b2b.uda_replicn_sf_corp_uda_vw_product2)
              AND upper(BusinessUnit) = 'DIGITAL MEDIA'
              AND upper(majorolpg2) = 'DIGITAL MEDIA'
) prod 
ON li.ProductID = prod.ProductID
WHERE li.as_of_date = (SELECT MAX(as_of_date) FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem)
GROUP BY OpportunityID
HAVING  sum(CASE WHEN ReportableASV_GrowthFX_Neutral IS NULL THEN NULL
                 ELSE round(cast(ReportableASV_GrowthFX_Neutral AS double), 0)
                  END) >= 0



-- COMMAND ----------

-- DBTITLE 1,Create a Table that will hold the Opportunity to Team mappings
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_assignment_team_mapping;
CREATE TABLE b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id string, team string, date_period string);

-- COMMAND ----------

-- DBTITLE 1,AMER GBD FLAG
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT  full_opp_id,
        'AMER GBD',
        'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN    (SELECT full_opp_id, ARRAY_JOIN(array_distinct(ARRAY_AGG(team)),' | ') AS gbd_team
                FROM b2b.manual_file_amer_gbd
                GROUP BY full_opp_id
               
               UNION 
              
              SELECT full_opp_id, ARRAY_JOIN(array_distinct(ARRAY_AGG(team)),' | ') AS gbd_team
                FROM b2b.manual_file_amer_gbd_2023_q1
                GROUP BY full_opp_id

              UNION 

              SELECT full_opp_id, ARRAY_JOIN(array_distinct(ARRAY_AGG(team)),' | ') AS gbd_team
                FROM b2b.manual_file_amer_gbd_2023_q2
                GROUP BY full_opp_id

                ) gbd
ON gbd.full_opp_id = opp.fulloptyid
WHERE gbd.gbd_team IS NOT NULL
AND opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE) ;

-- COMMAND ----------

-- DBTITLE 1,AMER MM FLAG
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT opp.fulloptyid,
       'AMER MM',
       '2023'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN  (
            SELECT DISTINCT id, 
                    standardizedsubid 
            FROM b2b.uda_replicn_sf_corp_uda_vw_account 
            WHERE as_of_date = (SELECT value
                                 FROM b2b_tmp.b2b_tmp_assignment_variables
                                 WHERE key='Acc - Max as of Date')
            AND upper(country) IN ('US','CA')
        ) acc
ON acc.id = opp.AccountID
INNER JOIN  (    
            SELECT DISTINCT sub_id as mm_coverage_subid
            FROM b2b.agodah_mmcoverage 
            WHERE parent_id <> 'Parent ID'
                AND sub_id IS NOT NULL
        )  mmCov
ON  acc.standardizedsubid = mmCov.mm_coverage_subid 
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')

AND (opp.reason IS NULL OR upper(opp.reason) NOT IN ('COMBINED WITH OTHER OPP','DEAL REG DUPLICATE',
                                                     'DIRECT SALES DUPLICATE','DUPLICATE','DUPLICATE OPPORTUNITY'))
AND upper(opp.stage) IN ('01 - PRE CALL PLAN','02 - PROSPECT','03 - OPPORTUNITY QUALIFICATION','04 - CIRCLE OF INFLUENCE','05 - SOLUTION DEFINITION','05 - SOLUTION DEFINITION AND VALIDATION',
                        '06 - CUSTOMER COMMIT','07 - EXECUTE TO CLOSE','CLOSED - CLEAN UP','CLOSED - LOST','CLOSED - BOOKED')
-- sum of line item asv >=0 & digital media
AND opp.fulloptyid IN (SELECT OpportunityID FROM b2b_tmp.asv_by_opportunity)
-- exists in FY2023 
AND ( 
        (opp.closedate >= cast('2022-12-03' AS DATE) AND opp.closedate <= cast('2023-12-01' AS DATE)) OR
        (opp.createddate >= cast('2022-12-03' AS DATE) AND opp.createddate <= cast('2023-12-01' AS DATE))
)


UNION ALL 

-- 2022;
SELECT opp.fulloptyid,
       'AMER MM',
       '2022'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN  (
            SELECT DISTINCT id, 
                    standardizedsubid 
            FROM b2b.uda_replicn_sf_corp_uda_vw_account 
            WHERE as_of_date = (SELECT value
                                 FROM b2b_tmp.b2b_tmp_assignment_variables
                                 WHERE key='Acc - Max as of Date')
            AND upper(country) IN ('US','CA')
        ) acc
ON acc.id = opp.AccountID
INNER JOIN ( SELECT DISTINCT prntid AS parent_id 
             FROM b2b_tmp.agodah_mmcoverage_2022
             WHERE prntid IS NOT NULL
        ) mmCovArchive
ON opp.standardizedparentid = mmCovArchive.parent_id 
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')

-- sum of line item asv >=0 & digital media
AND opp.fulloptyid IN (SELECT OpportunityID FROM b2b_tmp.asv_by_opportunity)
AND ( 
        (opp.closedate >= cast('2021-12-04' AS DATE) AND opp.closedate <= cast('2022-12-02' AS DATE)) OR
        (opp.createddate >= cast('2021-12-04' AS DATE) AND opp.createddate <= cast('2022-12-02' AS DATE))
)
AND upper(opp.stage) IN ('01 - PRE CALL PLAN','02 - PROSPECT','03 - OPPORTUNITY QUALIFICATION','04 - CIRCLE OF INFLUENCE','05 - SOLUTION DEFINITION','05 - SOLUTION DEFINITION AND VALIDATION',
                        '06 - CUSTOMER COMMIT','07 - EXECUTE TO CLOSE','CLOSED - CLEAN UP','CLOSED - LOST','CLOSED - BOOKED')
AND (opp.reason IS NULL OR upper(opp.reason) NOT IN ('COMBINED WITH OTHER OPP','DEAL REG DUPLICATE',
                                                     'DIRECT SALES DUPLICATE','DUPLICATE','DUPLICATE OPPORTUNITY'))




-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####AMER EDU FLAG 2023 - Filters (jira ticket 4072)
-- MAGIC
-- MAGIC - Adobe Role Name contains 2023 - ACCOUNT MANAGER
-- MAGIC - Major Revenue Type contains Subscription
-- MAGIC - Oppurtunity Sequence ! = SECONDARY
-- MAGIC - Territory - NEW = C&B EDU AMERICAS
-- MAGIC - closed date = 2023
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,AMER EDU FLAG

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
                'AMER EDU' as team,
                '2023' as date_period
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN ( SELECT opportunity, 
                    adoberole
             FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment 
             WHERE 
              -- this seems to be what is shown as territory in the salesforce report
              subregion = 'C&B EDU AMERICAS'
             AND as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment)
             ) prodass
ON prodass.opportunity = opp.fulloptyid
INNER JOIN (  SELECT opportunityid,
                     productid,
                     majorrevenuetype
              FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
              WHERE as_of_date =  ( SELECT max(as_of_date)
                                   FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem )
              AND lower(majorrevenuetype) like '%subscription%' 
               
) li 
ON opp.id = li.opportunityid
INNER JOIN ( SELECT  recordid,
                     adoberoletype
              FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole ) 
              AND replace(replace(upper(name),' ',''),'-','') LIKE '%2023ACCOUNTMANAGER%'
 ) rt
ON rt.recordid = prodass.adoberole
WHERE opp.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)
AND lower(coalesce(opp.opportunitysequence,'NULL')) <> 'secondary'
AND opp.closedate >= CAST('2022-12-03' AS DATE) 



-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####LATAM Enterprise - Filters
-- MAGIC
-- MAGIC 1. Opportunity's product to sales team assignment sub territory contains LATAM AND
-- MAGIC 2. Opportunity's product to sales team assignment's adobe role type is one of the following: ACCOUNT MANAGER,PRODUCT SPECIALIST AND
-- MAGIC 3. Opportunity's product to sales team assignment's major revenue type is SUBSCRIPTION

-- COMMAND ----------

-- DBTITLE 1,LATAM Enterprise
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT prodSalesAss.opportunity,
                'LATAM ENTERPRISE',
                'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment prodSalesAss
INNER JOIN b2b.uda_replicn_sf_corp_uda_vw_user user 
    ON user.UserID = prodSalesAss.SalesTeamMember
INNER JOIN  b2b.uda_replicn_sf_corp_uda_vw_opportunity opp 
    ON prodSalesAss.opportunity = opp.fulloptyid
WHERE user.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='User - Max as of Date')
AND prodSalesAss.as_of_date = ( SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Sales Team Assignment - Max as of Date') 
AND opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND upper(prodSalesAss.subterritory) LIKE '%LATAM%'
AND upper(user.adoberoletype) IN ('ACCOUNT MANAGER','PRODUCT SPECIALIST') 
AND upper(prodSalesAss.majorrevenuetype)='SUBSCRIPTION'
AND upper(opp.stage) IN ('01 - PRE CALL PLAN','02 - PROSPECT','03 - OPPORTUNITY QUALIFICATION','04 - CIRCLE OF INFLUENCE','05 - SOLUTION DEFINITION','05 - SOLUTION DEFINITION AND VALIDATION',
                        '06 - CUSTOMER COMMIT','07 - EXECUTE TO CLOSE','CLOSED - CLEAN UP','CLOSED - LOST','CLOSED - BOOKED')
-- sum of line item asv >=0 & digital media 
AND opp.fulloptyid IN (SELECT OpportunityID FROM b2b_tmp.asv_by_opportunity)
AND user.FullName1 <> 'SG SF' 
AND opp.closedate >= CAST('2022-12-03' AS DATE) 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####EMEA CNX - Filters
-- MAGIC
-- MAGIC 1. opportunity geo = EMEA  AND
-- MAGIC 2. record owner alias like con[0-9].* 

-- COMMAND ----------

-- DBTITLE 1,EMEA CNX (Previously known as PHONES)
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT opp.fulloptyid,
       'EMEA CNX',
       'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN ( 
        SELECT UserID, alias
        FROM b2b.uda_replicn_sf_corp_uda_vw_user
        WHERE regexp_like(alias , '^con[0-9]|^ttec[0-9]')
        AND as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='User - Max as of Date')
) user 
ON user.UserId = opp.RecordOwner
WHERE opp.Geo = 'EMEA'
AND opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE) ;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####EMEA PSS 2022 Q3 - Filters
-- MAGIC 1. opportunity geo = EMEA  AND
-- MAGIC 2. opportunity close date <= '2022-09-02' AND 
-- MAGIC 3. opportunity record type <> 'SMB Opportunity' or is null 
-- MAGIC 4. You meet at least one of the following sets of conditions;
-- MAGIC
-- MAGIC                 Group A 
-- MAGIC                 ----------
-- MAGIC                 - your sales team user is in a specific list AND 
-- MAGIC 				PipelineAcceptedRejectedBy is not in a specific list of users 
-- MAGIC         OR      
-- MAGIC         
-- MAGIC                 Group B
-- MAGIC                 ----------
-- MAGIC                 - your sales team user is in a different specific list AND 
-- MAGIC 				PipelineAcceptedRejectedBy is not in a different specific list of users AND
-- MAGIC 				your product group IN (STOCK, CCE STOCK) AND 
-- MAGIC 				your opportunity Name isnt like '%overage% or %payg%' AND 
-- MAGIC 				your opportunity industry <> 'Education - Higher Ed'
-- MAGIC         OR
-- MAGIC 		    
-- MAGIC                 Group C
-- MAGIC                 ----------
-- MAGIC                   your opportunity name is like '%3D%' or '%SUBSTANCE%' AND
-- MAGIC 				  your opportunity is accepted into the sales pipeline AND 
-- MAGIC 				  one of the following conditions is true;
-- MAGIC 					  1. the created by user is from a specific list
-- MAGIC 					  2. the salesteam user is in a specific list
-- MAGIC 					  3.  the accepted rejected user is in a specific list
-- MAGIC
-- MAGIC 		AND you meet one of the following 2 sets of conditions;
-- MAGIC                 Group D
-- MAGIC                 --------
-- MAGIC                 - Deal Regisration = Y AND
-- MAGIC                   your pipeline was accepted / rejected by specific set of users
-- MAGIC 				  Accepted into pipeline = Accepted
-- MAGIC         OR 
-- MAGIC 	
-- MAGIC                 Deal Regisration = N
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,EMEA PSS FLAG - 2022 Q3
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT in_scope_opportunities.fulloptyid,
                in_scope_opportunities.team,
                in_scope_opportunities.date_period
FROM 
(
        SELECT opp.fulloptyid,
        'EMEA PSS' AS team,
        '2022 Q3' AS date_period
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        WHERE opp.Geo = 'EMEA'
        AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
        AND opp.CloseDate IS NOT NULL
        AND opp.CloseDate >= cast('2022-06-04' AS DATE) 
        AND opp.CloseDate <= cast('2022-09-02' AS DATE)
        AND (opp.OpportunityRecordType <> 'SMB Opportunity' OR opp.OpportunityRecordType IS NULL)
) in_scope_opportunities
INNER JOIN   ( 
        
SELECT DISTINCT FullOptyId 
FROM (
                -- Group A 
                SELECT  'A' AS condition_group, 
                        opp.FullOptyId
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN  b2b_tmp.b2b_tmp_sales_team_usernames salesTeam
                ON opp.FullOptyId = salesTeam.opportunity
                INNER JOIN (
                        SELECT lower(user_name) AS user_name
                        FROM b2b.b2b_pipeline_assignment_user_list
                        WHERE condition_alias = 'A'
                        AND user_role = 'Sales Team'
                ) filterA1 ON lower(salesTeam.FullName1) = filterA1.user_name
                WHERE lower(opp.PipelineAcceptedRejectedBy) NOT IN (   SELECT lower(user_name)
                                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                                WHERE condition_alias = 'A'
                                                                AND user_role = 'Pipeline Accepted / Rejected by' )
                AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')

                UNION ALL

                -- Group B
                SELECT  'B' AS condition_group, 
                        opp.FullOptyId
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN  b2b_tmp.b2b_tmp_sales_team_usernames salesTeam
                ON opp.FullOptyId = salesTeam.opportunity
                INNER JOIN (
                        SELECT lower(user_name) AS user_name
                        FROM b2b.b2b_pipeline_assignment_user_list
                        WHERE condition_alias = 'B'
                        AND user_role = 'Sales Team'
                ) filterB ON lower(salesTeam.FullName1) = filterB.user_name
                INNER JOIN (SELECT DISTINCT OpportunityID
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                        WHERE OutlookProductGroup in ('CCE STOCK', 'STOCK')
                        AND as_of_date = (SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Line Item - Max as of Date')
                ) li ON li.OpportunityID = opp.FullOptyId
                WHERE lower(opp.PipelineAcceptedRejectedBy) NOT IN (    SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias = 'B'
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
                AND (lower(opp.Name) not like '%overage%' or lower(opp.Name) not like '%payg%') 
                AND opp.Industry <> 'Education - Higher Ed'
                AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
                UNION ALL 

                -- Group C 
                SELECT  'C',
                        opp.FullOptyId
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                LEFT JOIN ( SELECT opportunity, 
                                FullName1
                        FROM b2b_tmp.b2b_tmp_created_by_usernames  
                        WHERE lower(FullName1) IN (SELECT lower(user_name)
                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                        WHERE condition_alias='C' 
                                                        AND user_role = 'Created by'
                                                )
                ) createdBy 
                ON opp.FullOptyId = createdBy.opportunity
                LEFT JOIN (SELECT opportunity, 
                                FullName1
                        FROM b2b_tmp.b2b_tmp_sales_team_usernames  
                        WHERE lower(FullName1) IN (SELECT lower(user_name)
                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                WHERE condition_alias='C' 
                                                AND user_role = 'Sales Team')
                ) salesTeam
                ON opp.FullOptyId = salesTeam.opportunity
                WHERE (upper(opp.Name) like '%3D%' or upper(opp.Name) like '%SUBSTANCE%') 
                AND opp.AcceptintoSalesPipeline = 'Accepted'
                AND (       createdBy.opportunity IS NOT NULL 
                        OR  salesTeam.opportunity IS NOT NULL  
                        OR  lower(opp.PipelineAcceptedRejectedBy) IN (  SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias='C' 
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
                )

        ) abc_records
) ABC_Opps
ON ABC_Opps.FullOptyId=in_scope_opportunities.fulloptyid
INNER JOIN  ( 
                SELECT  'D' as condition_group,
                        opp.FullOptyId 
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                WHERE opp.DealRegistration='N'
                UNION  
                SELECT  'D' as condition_group,
                        opp.FullOptyId 
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                WHERE opp.DealRegistration='Y'
                AND lower(opp.PipelineAcceptedRejectedBy) IN (  SELECT lower(user_name)
                                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                                WHERE condition_alias='D' 
                                                                AND user_role = 'Pipeline Accepted / Rejected by' )
                AND opp.AcceptintoSalesPipeline = ' Accepted' 
) condition_D
ON condition_D.FullOptyId = in_scope_opportunities.FullOptyId;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####EMEA PSS 2022 Q4 - Filters
-- MAGIC         1. opportunity geo = EMEA  AND
-- MAGIC         2. opportunity close date <= '2022-12-02 AND 
-- MAGIC         3. DmeAccountGroup is NULL or <> 'Enterprise' AND
-- MAGIC         4. Pipeline accepted rejected in a specific list of users (group E) AND
-- MAGIC         5. OutlookProductGroup in ('SUBSTANCE', 'DCE', 'DCE TRANSACTION', 'ACROBAT', 'SIGN', 'CCE STOCK', 'STOCK', 'CREATIVE')	AND
-- MAGIC         6. opp01.OpportunityRecordType <> 'SMB Opportunity' AND
-- MAGIC         7. AND You meet one of the following 2 conditions; 
-- MAGIC                 
-- MAGIC                 --- Group F
-- MAGIC                 OutlookProductGroup in ('CCE STOCK', 'STOCK') AND
-- MAGIC                 opportunity name not like '%overage%' or '%payg%'
-- MAGIC                 OR
-- MAGIC                 OutlookProductGroup not in ('CCE STOCK', 'STOCK') 
-- MAGIC
-- MAGIC         9. AND you need to meet one of the following 2 conditions;
-- MAGIC                 
-- MAGIC                 -- GROUP G
-- MAGIC                 PipelineAcceptedRejectedBy in a specific list of users (G1) AND
-- MAGIC                 ProductName like '%3D%' or  like '%SUBSTANCE%'
-- MAGIC                 OR
-- MAGIC                 PipelineAcceptedRejectedBy not in a specific list of users (G2)
-- MAGIC         
-- MAGIC         10. AND you need to meet one of the following 2 conditions;
-- MAGIC
-- MAGIC                 -- Group H
-- MAGIC                 OutlookProductGroup like '%CREATIVE% AND 
-- MAGIC                 ProductName like '%3D%' or ProductName like '%SUBSTANCE%'
-- MAGIC                 OR
-- MAGIC                 OutlookProductGroup not like '%CREATIVE% 
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,EMEA PSS FLAG - 2022 Q4
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT in_scope_opportunities.fulloptyid,
                in_scope_opportunities.team,
                in_scope_opportunities.date_period
FROM 
(
        SELECT opp.fulloptyid,
        'EMEA PSS' AS team,
        '2022 Q4' AS date_period
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        INNER JOIN (    SELECT DISTINCT dmeaccountgroup,id
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                        AND (dmeaccountgroup IS NULL OR dmeaccountgroup <> 'Enterprise') 
                ) acc
        ON opp.AccountID = acc.Id 
        INNER JOIN (    SELECT DISTINCT OpportunityID,
                                        OutlookProductGroup
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Line Item - Max as of Date')
                        AND OutlookProductGroup IN ('SUBSTANCE', 'DCE', 'DCE TRANSACTION', 'ACROBAT', 'SIGN', 'CCE STOCK', 'STOCK', 'CREATIVE')	
                )prod
        ON prod.OpportunityID = opp.fulloptyid
        WHERE opp.Geo = 'EMEA'
        AND opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
        AND opp.CloseDate IS NOT NULL
        AND opp.CloseDate >= cast('2022-09-03' AS DATE) 
        AND opp.CloseDate <= cast('2022-12-02' AS DATE)
        AND (opp.OpportunityRecordType <> 'SMB Opportunity' OR opp.OpportunityRecordType IS NULL)
        AND (lower(opp.PipelineAcceptedRejectedBy) IN ( SELECT lower(user_name)
                                                FROM b2b.b2b_pipeline_assignment_user_list
                                                WHERE condition_alias='E' 
                                                AND user_role = 'Pipeline Accepted / Rejected by' )
                                                OR lower(opp.PipelineAcceptedRejectedBy) LIKE 'dorota g__wka')
) in_scope_opportunities
INNER JOIN (    -- group F
                SELECT DISTINCT fulloptyid
                FROM (
                        SELECT opp.fulloptyid
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                        INNER JOIN (SELECT DISTINCT OpportunityID,
                                                OutlookProductGroup
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                        WHERE as_of_date = (    SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Line Item - Max as of Date') 
                                        AND OutlookProductGroup IN ('CCE STOCK', 'STOCK')
                                ) prod ON opp.fulloptyid=prod.OpportunityID
                        WHERE (lower(opp.Name) NOT LIKE '%overage%' or lower(opp.Name) NOT LIKE '%payg%') 
                        AND opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                        UNION ALL

                        SELECT opp.fulloptyid
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                        INNER JOIN (SELECT DISTINCT OpportunityID,
                                                OutlookProductGroup
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                        WHERE as_of_date = (    SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Line Item - Max as of Date') 
                                        AND OutlookProductGroup NOT IN ('CCE STOCK', 'STOCK')
                                ) prod
                        ON prod.OpportunityID = opp.fulloptyid
                        WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                ) GroupFAll
) GroupF
ON GroupF.fulloptyid=in_scope_opportunities.fulloptyid
INNER JOIN (
        -- group G
        SELECT DISTINCT fulloptyid
        FROM (
                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (    SELECT DISTINCT OpportunityID
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                                INNER JOIN ( SELECT ProductName, 
                                                ProductID
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                        WHERE as_of_date = (   SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Product - Max as of Date')
                                        AND  (upper(ProductName) LIKE '%3D%' OR upper(ProductName) LIKE '%SUBSTANCE%') 
                                        ) prod
                                ON li.ProductID = prod.ProductID 
                                WHERE li.as_of_date = ( SELECT value    
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date')
                        ) oppProd
                        ON oppProd.OpportunityID=opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                AND lower(opp.PipelineAcceptedRejectedBy) IN (
                                                        SELECT lower(user_name)
                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                        WHERE condition_alias='G1' 
                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
                UNION ALL

                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                AND lower(opp.PipelineAcceptedRejectedBy) NOT IN (     SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias='G2' 
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )

        ) GroupGAll

) GroupG
ON GroupG.fulloptyid=in_scope_opportunities.fulloptyid
INNER JOIN (
        -- group H
        SELECT DISTINCT fulloptyid
        FROM (  
                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (    SELECT DISTINCT OpportunityID
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                                INNER JOIN ( SELECT     ProductName, 
                                                        ProductID
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                        WHERE as_of_date = (   SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Product - Max as of Date')
                                        AND  (upper(ProductName) LIKE '%3D%' OR upper(ProductName) LIKE '%SUBSTANCE%') 
                                        ) prod
                                ON li.ProductID = prod.ProductID 
                                WHERE li.as_of_date = ( SELECT value    
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date')
                                AND li.OutlookProductGroup LIKE '%CREATIVE%'
                                AND (upper(prod.ProductName) LIKE '%3D%' OR upper(prod.ProductName) LIKE '%SUBSTANCE%') 
                ) oppProd
                ON oppProd.OpportunityID = opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                UNION ALL 

                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (SELECT DISTINCT OpportunityID,
                                        OutlookProductGroup
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                WHERE as_of_date = (    SELECT value
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date') 
                                AND OutlookProductGroup NOT LIKE '%CREATIVE%'
                ) prod
                ON prod.OpportunityID = opp.fulloptyid
                WHERE opp.as_of_date = (SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
        ) GroupHAll

) GroupH
ON GroupH.fulloptyid=in_scope_opportunities.fulloptyid;

-- COMMAND ----------

-- DBTITLE 1,EMEA PSS FLAG - 2023 Q1 to Q3
-- MAGIC %md
-- MAGIC ###EMEA PSS FLAG - 2023 Q1 to Q3 - Filters
-- MAGIC
-- MAGIC The logic for this is taken from the PSS Full Pipeline salesforce report - a report which can seemingly be updated at any point in time. 
-- MAGIC At the time of writing this the report has 17 conditions, with the following logic of applying them;
-- MAGIC
-- MAGIC (1 AND 2 AND ((3 AND 4) OR 5) AND 6 AND ((7 AND 8) OR 9) AND 10 AND 11 AND ((12 AND (13 OR 14)) OR 15) AND 17) OR 16
-- MAGIC
-- MAGIC the conditions (1,2,3 etc) are as follows;
-- MAGIC
-- MAGIC 1. DME Major Segment != Enterprise
-- MAGIC 2. Pipeline Accepted / Rejected by is in a specific set of users
-- MAGIC 3. Outlook Product Group Contains CCE STOCK, STOCK, CCE PRO PLUS
-- MAGIC 4. Opportunity Name does not contain Overage,PAYG
-- MAGIC 5. Outlook Product Group does not Contain CCE STOCK, STOCK
-- MAGIC 6. Outlook Product Group contains EXPRESS,CCE PRO PLUS,Frame,SUBSTANCE,DCE,DCE TRANSACTION,ACROBAT,SIGN,CCE STOCK,STOCK,CREATIVE
-- MAGIC 7. Pipeline Accepted Rejected by is in a set of users
-- MAGIC 8. Product Name Contains 3D, Substance
-- MAGIC 9. Pipeline Accepted Reject By not Equal to a set of Users
-- MAGIC 10. Stage is in 03 - Opportunity Qualification, 04 - Cirle of Influence, 05 - Solution Definition and Validation, 06 - Customer Commit, 07 - Execute to Close - This is removed in pipeline as we care about all stages
-- MAGIC 11. Opportunity Record Type != SMB Opportunity
-- MAGIC 12. Outlook Product Group Contains CREATIVE
-- MAGIC 13. Product Name Contains 3D, Substance
-- MAGIC 14. Pipeline Accepted/Rejected is in a specific set of users
-- MAGIC 15. Outlook Product Group does not contain CREATIVE
-- MAGIC 16. DEAL Registration Is IN A Specific list
-- MAGIC 17. CSAM is in a specific set of users or is null
-- MAGIC
-- MAGIC We can try to simplify this as follows;
-- MAGIC
-- MAGIC You must have 
-- MAGIC
-- MAGIC -- Mandatory (1,2,6,10,11,17)
-- MAGIC
-- MAGIC - DME Major Segment != Enterprise
-- MAGIC - Pipeline Accepted / Rejected by is in a specific set of users (Group H - Check this list)
-- MAGIC - Outlook Product Group contains EXPRESS,CCE PRO PLUS,Frame,SUBSTANCE,DCE,DCE TRANSACTION,ACROBAT,SIGN,CCE STOCK,STOCK,CREATIVE
-- MAGIC - Stage is in 03 - Opportunity Qualification, 04 - Cirle of Influence, 05 - Solution Definition and Validation, 06 - Customer Commit, 07 - Execute to Close
-- MAGIC - Opportunity Record Type != SMB Opportunity
-- MAGIC - CSAM is in a specific set of users 
-- MAGIC
-- MAGIC
-- MAGIC --Conditionals 
-- MAGIC
-- MAGIC _Group J_ (3 AND 4) OR 5) 
-- MAGIC  Outlook Product Group Contains CCE STOCK, STOCK, CCE PRO PLUS AND Opportunity Name does not contain Overage,PAYG OR
-- MAGIC  Outlook Product Group does not Contain CCE STOCK, STOCK
-- MAGIC
-- MAGIC AND 
-- MAGIC
-- MAGIC _Group K_ ((7 AND 8) OR 9) 
-- MAGIC Pipeline Accepted Rejected by is in a set of users AND Product Name Contains 3D, Substance OR 
-- MAGIC Pipeline Accepted Reject By not Equal to a set of Users
-- MAGIC
-- MAGIC AND 
-- MAGIC
-- MAGIC _Group L_ ((12 AND (13 OR 14)) OR 15)
-- MAGIC Outlook Product Group Contains CREATIVE AND 
-- MAGIC
-- MAGIC EITHER Product Name Contains 3D, Substance 
-- MAGIC        OR Pipeline Accepted/Rejected is in a specific set of users 
-- MAGIC
-- MAGIC OR 
-- MAGIC
-- MAGIC Outlook Product Group does not contain CREATIVE
-- MAGIC
-- MAGIC
-- MAGIC OR you ignore these previous conditionals but you are in a handful of opportunities someone has dug out. (16)
-- MAGIC
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Code for 2023 PSS  Q1 to Q3 
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
                'EMEA PSS' AS team,
                '2023 Q1 to Q3' AS date_period
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
LEFT JOIN (    SELECT DISTINCT dmeaccountgroup,
                                id,
                                coalesce(csam,'Unknown') as csam
                FROM b2b.uda_replicn_sf_corp_uda_vw_account
                WHERE as_of_date = (    SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Acc - Max as of Date')
                -- Condition 1 
                AND (dmeaccountgroup IS NULL OR dmeaccountgroup <> 'Enterprise') 
        ) acc
ON opp.AccountID = acc.Id 
LEFT JOIN  ( SELECT DISTINCT    userid, 
                                lower(FullName1) AS FullName1 
                FROM b2b.uda_replicn_sf_corp_uda_vw_user
                WHERE as_of_date = (      SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='User - Max as of Date')
) csam 
ON csam.UserID = acc.csam 
INNER JOIN (    SELECT DISTINCT OpportunityID,
                                        OutlookProductGroup
                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Line Item - Max as of Date')
                        -- Condition 6 
                        AND upper(OutlookProductGroup) RLIKE('EXPRESS|FIREFLY|CCE PRO PLUS|FRAME|SUBSTANCE|DCE|DCE TRANSACTION|ACROBAT|SIGN|CCE STOCK|STOCK|CREATIVE')
                        
                )prod
        ON prod.OpportunityID = opp.fulloptyid
---------------------------
-- Group J  (3 AND 4) OR 5)
----------------------------
INNER JOIN (
                SELECT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                INNER JOIN (    SELECT DISTINCT OpportunityID,
                                                OutlookProductGroup
                                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                                WHERE as_of_date = (    SELECT value
                                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                        WHERE key='Line Item - Max as of Date')
                                                -- Condition 6 
                                                AND upper(OutlookProductGroup) rlike('EXPRESS|FIREFLY|CCE PRO PLUS|FRAME|SUBSTANCE|DCE|DCE TRANSACTION|ACROBAT|SIGN|CCE STOCK|STOCK|CREATIVE')
                                                
                                        )prod
                                ON prod.OpportunityID = opp.fulloptyid

                WHERE (
                        -- condition 4
                        upper(opp.name) NOT RLIKE('OVERAGE|PAYG') AND 
                        -- Condition 3
                        upper(prod.OutlookProductGroup) RLIKE ('STOCK|CCE STOCK|CCE PRO PLUS')
                ) 
                OR
                -- Condition 5
                upper(prod.OutlookProductGroup) NOT RLIKE ('STOCK|CCE STOCK')
                AND opp.as_of_date = (SELECT value
                                 FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')

) J
ON J.fulloptyid = opp.fulloptyid
---------------------------
-- Group K  ((7 AND 8) OR 9) 
----------------------------
INNER JOIN (
        SELECT DISTINCT opp.fulloptyid
        FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        LEFT JOIN (    SELECT           OpportunityID,
                                        ProductName
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                                        LEFT JOIN ( SELECT     ProductName, 
                                                                ProductID
                                                FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                                WHERE as_of_date = (    SELECT value
                                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                        WHERE key='Product - Max as of Date')
                                                ) prod
                                        ON li.ProductID = prod.ProductID 
                                        WHERE li.as_of_date = ( SELECT value    
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Line Item - Max as of Date')
        ) oppProd
        ON opp.fulloptyid = oppProd.OpportunityID
        WHERE  (
        -- Condition 7
        coalesce(lower(opp.pipelineacceptedrejectedby),'None') IN  (    SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias='K1' 
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
        AND
        -- Condition 8 
        upper(oppProd.ProductName) RLIKE('3D|SUBSTANCE|FIREFLY|EXPRESS')
        )
        OR
        -- Condition 9 
        coalesce(lower(opp.pipelineacceptedrejectedby),'None') NOT IN (    SELECT lower(user_name)
                                                                        FROM b2b.b2b_pipeline_assignment_user_list
                                                                        WHERE condition_alias='K2' 
                                                                        AND user_role = 'Pipeline Accepted / Rejected by' )
        AND  opp.as_of_date = (      SELECT value
                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                WHERE key='Opp - Max as of Date')
) K 
ON J.fulloptyid = opp.fulloptyid

---------------------------
-- Group L  ((12 AND (13 OR 14)) OR 15)
----------------------------

INNER JOIN (    SELECT DISTINCT opp.fulloptyid
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
                LEFT JOIN (    SELECT OpportunityID,
                                ProductName,
                                li.outlookproductgroup
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem li
                                LEFT JOIN ( SELECT     ProductName, 
                                                        ProductID
                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                        WHERE as_of_date = (    SELECT value
                                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                WHERE key='Product - Max as of Date')
                                        ) prod
                                ON li.ProductID = prod.ProductID 
                                WHERE li.as_of_date = ( SELECT value    
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date')
                        ) oppProd
                ON opp.fulloptyid = oppProd.OpportunityID
                LEFT JOIN (    SELECT lower(user_name) as user_name
                                FROM b2b.b2b_pipeline_assignment_user_list
                                WHERE condition_alias='L1' 
                                AND user_role = 'Pipeline Accepted / Rejected by' ) cond14
                ON lower(opp.PipelineAcceptedRejectedBy) RLIKE(cond14.user_name)

                WHERE opp.as_of_date = (      SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Opp - Max as of Date')
                AND (
                -- Condition 12
                oppProd.OutlookProductGroup RLIKE('CREATIVE')
                AND 
                ( -- Condition 13
                        upper(oppProd.ProductName) RLIKE('3D|SUBSTANCE')
                        OR
                        -- Condition 14 - this condition is done on "LIKE in salesforce thus this odd join approach"
                        cond14.user_name IS NOT NULL
                        
                )

                )
                OR
                -- Condition 15
                upper(oppProd.outlookproductgroup) NOT RLIKE('CREATIVE')
) L
ON L.fulloptyid = opp.fulloptyid
LEFT JOIN (SELECT lower(user_name) AS user_name
                FROM b2b.b2b_pipeline_assignment_user_list
                WHERE condition_alias='M' 
                AND user_role = 'Pipeline Accepted / Rejected by') cond2
ON lower(opp.PipelineAcceptedRejectedBy) RLIKE(cond2.user_name)
WHERE

-- limit this to Q1-Q3 2023
opp.CloseDate >= cast('2022-12-03' AS DATE)  -- start of Q1
AND opp.CloseDate <= cast('2023-09-01' AS DATE) -- end of Q3

-- Condition 2 (I have to hard code this as I cant join or subquery on "LIKE")
AND cond2.user_name IS NOT NULL

-- Condition 10 (intentionally commented out)
--AND opp.stage IN ('03 - Opportunity Qualification','04 - Circle of Influence','05 - Solution Definition and Validation','06 - Customer Commit','07 - Execute to Close')


-- Condition 11 
AND upper(opp.opportunityrecordtype) <> 'SMB OPPORTUNITY'

-- Condition 17
AND (
lower(csam.FullName1) IN ( SELECT lower(user_name)
                        FROM b2b.b2b_pipeline_assignment_user_list
                        WHERE condition_alias='N' 
                        AND user_role = 'CSAM' )
OR csam.fullName1 IS NULL
)


AND  

opp.as_of_date = (SELECT value
                FROM b2b_tmp.b2b_tmp_assignment_variables
                WHERE key='Opp - Max as of Date')

UNION ALL 

-- Condition 16 - Opportunities that dont fall into PSS after all this criteria, but are PSS 2023
SELECT  fulloptyid,
        'EMEA PSS' AS team,
        '2023 Q1 to Q3' AS date_period
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity 
WHERE upper(dealregistrationid) IN ('DR3469845','DR3517727','DR3110870','DR3392250','DR3544008','DR3486473','DR3539283','DR3539212','DR3574595')
AND as_of_date = (      SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
-- limit this to Q1-Q3 2023
AND CloseDate >= cast('2022-12-03' AS DATE)  -- start of Q1
AND CloseDate <= cast('2023-09-01' AS DATE) -- end of Q3


-- COMMAND ----------

-- DBTITLE 1,PSS 2023 Q4
-- MAGIC %md
-- MAGIC
-- MAGIC As ridiculous as it is - they've changed it again.
-- MAGIC
-- MAGIC
-- MAGIC 1. DMe Major Segment 'NOT EQUAL TO' Enterprise
-- MAGIC 2. Pipeline Accepted/Rejected By 'CONTAINS' Alissa Maier,Paolo Motta,Timo Labrenz,Dorota Główka,Charlotte Bogaert,Karine Couvreur,Vincenzo Vollaro,Malte Istel,KAtharina Reeck,Moises Crispim,Sebastien Belliere,Trigun Soni,Chris Alchin,Laura Toth,Marisa Bogumil,Dan Gonzalez,Kagan Orhan,Gilles Senee,Loic Perhirin,Peter Musumeci,James Taylor,Oliver Corbett,Oliver Heath,Scarlet Barber,Leonie Lacaille,Julian Arthur,Magdalena Boerger,Bethan Keane,Dennis Waberowski,Alice Woods, Aaron Akisanya
-- MAGIC 3. Outlook Product Group 'CONTAINS' CCE STOCK,STOCK,CCE PRO PLUS
-- MAGIC 4. Opportunity Name 'DOES NOT CONTAIN' Overage, PAYG
-- MAGIC 5. Outlook Product Group 'DOES NOT CONTAIN' CCE STOCK,STOCK,CCE PRO PLUS
-- MAGIC 6. Outlook Product Group 'CONTAINS' FRAME, SUBSTANCE, DCE, DCE TRANSACTION, ACROBAT, SIGN, CCE STOCK, STOCK,CREATIVE, CCE PRO PLUS, EXPRESS, FIREFLY
-- MAGIC 8. Opportunity Record Type 'NOT EQUAL TO' SMB Opportunity
-- MAGIC 9. Deal Registration ID 'EQUALS' DR3469845,DR3517727,DR3110870,DR3392250,DR3544008,DR3486473,DR3539283,DR3539212,DR3574595
-- MAGIC 10. CSAM 'EQUALS' "",Robyn Eames,Robin Dousa,Charlotte Bogaert,Andrea Bolognese,Kagan Orhan,Trigun Soni,Jorge Nadel Ciordia,Gilles Senee,Ruth Weiss,Marianna Sala,Thor Magne Engerbakk,Dan Gonzalez,Doreen Paltawitz,Timo Labrenz,Dorota Główka,Karine Couvreur,Vincenzo Vollaro,Malte Istel,Katharina Reeck,Moises Crispim,Sebastien Belliere,Chris Alchin,Laura Toth,Marisa Bogumil,Loic Perhirin,Peter Musumeci,James Taylor,Oliver Corbett,Oliver Heath,Scarlet Barber,Leonie Lacaille,Julian Arthur,Magdalena Boerger,Bethan Keane,Dennis Waberowski,Alice Woods
-- MAGIC
-- MAGIC Filter Logic is
-- MAGIC
-- MAGIC (1 AND 2 AND ((3 AND 4) OR 5) AND 6 AND 7 AND 8 AND 10) OR 9
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,PSS 2023 - Q4
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
                'EMEA PSS' AS team,
                '2023 Q4' AS date_period
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
LEFT JOIN (    SELECT DISTINCT dmeaccountgroup,
                                id,
                                coalesce(csam,'Unknown') as csam
                FROM b2b.uda_replicn_sf_corp_uda_vw_account
                WHERE as_of_date = (    SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='Acc - Max as of Date')
                -- Condition 1 
                AND (dmeaccountgroup IS NULL OR lower(dmeaccountgroup) <> 'enterprise') 
) acc
ON acc.id = opp.id
INNER JOIN (SELECT user_name 
            FROM b2b.b2b_pipeline_assignment_user_list 
            WHERE condition_alias='P' AND user_role='Pipeline Accepted / Rejected by') acceptReject
ON lower(opp.PipelineAcceptedRejectedBy) RLIKE lower(acceptReject.user_name) -- condition 2 (Rlike used as "Contains")

-- Sub Query for conditions 3,4 and 5
INNER JOIN ( 
              SELECT opp.fulloptyid
              FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
              INNER JOIN (    SELECT DISTINCT OpportunityID,
                                              OutlookProductGroup
                                              FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                              WHERE as_of_date = (    SELECT value
                                                                      FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                      WHERE key='Line Item - Max as of Date')
                                              -- Condition 3
                                              AND upper(OutlookProductGroup) RLIKE('CCE STOCK|STOCK|CCE PRO PLUS')
                                              
              ) prod
              ON prod.OpportunityID = opp.fulloptyid
              -- Condition 4
              WHERE upper(opp.name) NOT RLIKE 'OVERAGE|PAYG'
              AND opp.as_of_date =  (      SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')

              UNION ALL 

              -- OR condition 5
              SELECT opp.fulloptyid
              FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
              INNER JOIN (    SELECT DISTINCT OpportunityID,
                                              OutlookProductGroup
                                              FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                              WHERE as_of_date = (    SELECT value
                                                                      FROM b2b_tmp.b2b_tmp_assignment_variables
                                                                      WHERE key='Line Item - Max as of Date')
                                              -- Condition 5
                                              AND upper(OutlookProductGroup) NOT RLIKE('CCE STOCK|STOCK|CCE PRO PLUS')
                                              
              ) prod
              ON prod.OpportunityID = opp.fulloptyid
              WHERE opp.as_of_date = (      SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
) cond345
ON cond345.fulloptyid = opp.fulloptyid
INNER JOIN (    SELECT DISTINCT OpportunityID,
                                OutlookProductGroup
                                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                                WHERE as_of_date = (    SELECT value
                                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                                        WHERE key='Line Item - Max as of Date')
                                -- Condition 6
                                AND upper(OutlookProductGroup) RLIKE('FRAME|SUBSTANCE|DCE|DCE TRANSACTION|ACROBAT|SIGN|CCE STOCK|STOCK|CREATIVE|CCE PRO PLUS|EXPRESS|FIREFLY')
                                            
            ) prod
ON prod.OpportunityID = opp.fulloptyid
LEFT JOIN  ( SELECT DISTINCT    userid, 
                                lower(FullName1) AS FullName1 
                FROM b2b.uda_replicn_sf_corp_uda_vw_user
                WHERE as_of_date = (      SELECT value
                                        FROM b2b_tmp.b2b_tmp_assignment_variables
                                        WHERE key='User - Max as of Date')
) csam 
ON csam.UserID = acc.csam 

WHERE upper(opp.opportunityrecordtype) <> 'SMB OPPORTUNITY' -- condition 8
AND opp.as_of_date = (      SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND (
lower(csam.FullName1) IN ( SELECT lower(user_name)
                        FROM b2b.b2b_pipeline_assignment_user_list
                        WHERE condition_alias='Q' 
                        AND user_role = 'CSAM' )
OR csam.fullName1 IS NULL
)
AND opp.CloseDate > cast('2023-09-01' AS DATE) -- end of Q3

UNION ALL 
-- Condition 9 - Opportunities that dont fall into PSS after all this criteria, but are PSS 2023 Q4
SELECT  fulloptyid,
        'EMEA PSS' AS team,
        '2023 Q1 to Q3' AS date_period
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity 
WHERE upper(dealregistrationid) IN ('DR3469845','DR3517727','DR3110870','DR3392250','DR3544008','DR3486473','DR3539283','DR3539212','DR3574595')
AND as_of_date = (      SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND CloseDate > cast('2023-09-01' AS DATE) -- end of Q3



-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####EMEA EDU - Filters
-- MAGIC  1. opportunity geo = EMEA
-- MAGIC  2. account industry in (Education – Higher Ed, Education – K12, Non-Profit)
-- MAGIC  3. Adobe Sales Team: Adobe Role Type = 'Account Manager'

-- COMMAND ----------

-- DBTITLE 1,EMEA EDU FLAG
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
       'EMEA EDU',
       'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN  (
            SELECT DISTINCT     id, 
                                industry 
            FROM b2b.uda_replicn_sf_corp_uda_vw_account 
            WHERE as_of_date = (SELECT value
                                 FROM b2b_tmp.b2b_tmp_assignment_variables
                                 WHERE key='Acc - Max as of Date')
            AND industry IN ('Education - Higher Ed','Education - K12','Non-Profit')
        ) acc
ON acc.id = opp.AccountID
INNER JOIN b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment sta 
 ON sta.opportunity  = opp.fulloptyid
INNER JOIN (SELECT UserID,
                   fullname1,
                   adoberoletype
            FROM b2b.uda_replicn_sf_corp_uda_vw_user
            WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_user)
            AND lower(adoberoletype) = 'account manager' ) u 
ON u.UserID = sta.SalesTeamMember
WHERE sta.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment)
AND opp.Geo='EMEA' 
AND opp.fulloptyid NOT IN ( 
    -- Ticket 4730 - EDU and PSS are not mutually exclusive - prefer PSS
    SELECT full_opty_id
    FROM b2b_tmp.b2b_tmp_assignment_team_mapping
    WHERE team like '%PSS%'
)


-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### EMEA RESELLER - Filters
-- MAGIC
-- MAGIC 1. opportunity geo = EMEA
-- MAGIC 2. dmeaccountgroup in Mid-Market,SMB or NULL
-- MAGIC 3. route to market = 'Partners Involved'
-- MAGIC 4. olpg2 = 'DIGITAL MEDIA'

-- COMMAND ----------

-- DBTITLE 1,EMEA RESELLER

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT   resell.fulloptyid,
        'EMEA RESELLER',
        'ALL'
FROM (

        SELECT DISTINCT opp.fulloptyid
        FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
        INNER JOIN ( 
                SELECT           OpportunityID,
                                 ProductID,
                                 OutlookProductGroup,
                                 coalesce(round(cast(ReportableASV_GrowthFX_Neutral as double), 0),0) AS ReportableASV_GrowthFX_Neutral
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                WHERE as_of_date = ( SELECT value
                                     FROM b2b_tmp.b2b_tmp_assignment_variables
                                     WHERE key='Line Item - Max as of Date')

                ) lineItems
        ON lineItems.OpportunityID = opp.FullOptyId
        INNER JOIN (    
                SELECT  ProductID,
                        majorolpg2
                FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                WHERE as_of_date = (SELECT value
                                           FROM b2b_tmp.b2b_tmp_assignment_variables
                                           WHERE key='Product - Max as of Date')
                ) prod
        ON lineItems.ProductID = prod.ProductID
        INNER JOIN (    SELECT Id,
                               dmeaccountgroup
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account 
                        WHERE as_of_date IN (SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                        AND (upper(dmeaccountgroup) IN ('MID-MARKET','SMB') OR dmeaccountgroup IS NULL)
        ) acc
        ON acc.Id = opp.AccountID

        WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
        AND opp.CloseDate IS NOT NULL
        AND opp.CloseDate >= cast('2021-01-01' AS DATE)
        AND upper(opp.geo)='EMEA'
        AND upper(prod.majorolpg2) = 'DIGITAL MEDIA'
        AND upper(opp.routetomarket) = 'PARTNERS INVOLVED'
) resell


-- COMMAND ----------

-- DBTITLE 1,APAC - ENT and SMB
-- MAGIC %md
-- MAGIC logical conditions are;
-- MAGIC
-- MAGIC - UPPER(p2s.GlobalRegion) LIKE '%APAC%'
-- MAGIC - AND TRIM(opp.Stage) NOT IN ('Closed - Clean Up','Closed - Lost')
-- MAGIC - AND UPPER(p2.MajorOLPG2) IN ('DIGITAL MEDIA', 'PUBLISHING')
-- MAGIC - AND (UPPER(ar.adoberoletype) LIKE '%ACCOUNT MANAGER%' OR UPPER(ar.adoberoletype) LIKE '%ACCOUNT MGR%')
-- MAGIC - AND UPPER(ar.adoberoletype) NOT LIKE '%POST SALES ACCOUNT MANAGER - OBU%'
-- MAGIC - AND UPPER(p2.OutlookProductGroup) NOT IN ('CAPTIVATE PRIME ADD-ON','PRIMETIME')
-- MAGIC - AND UPPER(p2s.SubTerritory) NOT LIKE '%DX%'
-- MAGIC - AND opp.dmeineligible != 'true'
-- MAGIC - AND Major Account Segment = 'Enterprise'/'SMB' -- depending on the segment
-- MAGIC
-- MAGIC Ticket: https://jira.corp.adobe.com/browse/B2BDME-3949
-- MAGIC
-- MAGIC
-- MAGIC Note: I believe Major Account Segment is a renamed version of account.DMeAccountGroup - this can separate SMB / ENTERPRISE. No similar field named Major Account Segment could be found in databricks / UDA info schema
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,APAC - ENT
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
                'APAC ENT',
                'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN ( SELECT opportunity, 
                    adoberole
             FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment 
             WHERE upper(globalregion) LIKE '%APAC%'
             AND upper(subterritory) NOT LIKE '%DX%'
             AND as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Sales Team Assignment - Max as of Date')
            ) prodass
ON prodass.opportunity = opp.fulloptyid
INNER JOIN ( 
            SELECT           OpportunityID,
                             ProductID,
                             OutlookProductGroup
            FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
            WHERE as_of_date =  ( SELECT value
                                   FROM b2b_tmp.b2b_tmp_assignment_variables
                                   WHERE key='Line Item - Max as of Date')
            AND upper(OutlookProductGroup) NOT IN ('CAPTIVATE PRIME ADD-ON','PRIMETIME')

) lineItems
ON lineItems.OpportunityID = opp.FullOptyId
INNER JOIN (    SELECT DISTINCT dmeaccountgroup,id
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account
                         WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                        -- I assume this is the "Major Account Segment " quoted in the ticket
                        AND lower(dmeaccountgroup) = 'enterprise'
                ) acc
ON opp.AccountID = acc.Id 
INNER JOIN (    
        SELECT  ProductID,
                majorolpg2
        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
        WHERE as_of_date = ( SELECT value
                                   FROM b2b_tmp.b2b_tmp_assignment_variables
                                   WHERE key='Product - Max as of Date')
        AND upper(majorolpg2) IN ('DIGITAL MEDIA','PUBLISHING')
) prod
ON lineItems.ProductID = prod.ProductID
INNER JOIN ( SELECT  recordid,
                     adoberoletype
              FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole ) 
              AND upper(adoberoletype) RLIKE 'ACCOUNT MANAGER|ACCOUNT MGR'
              AND upper(adoberoletype) NOT RLIKE 'POST SALES ACCOUNT MANAGER - OBU'
 ) rt
ON rt.recordid = prodass.adoberole
WHERE opp.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)



-- COMMAND ----------

-- DBTITLE 1,APAC - SMB
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
                'APAC SMB',
                'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN ( SELECT opportunity, 
                    adoberole
             FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment 
             WHERE upper(globalregion) LIKE '%APAC%'
             AND upper(subterritory) NOT LIKE '%DX%'
             AND as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Sales Team Assignment - Max as of Date')
             ) prodass
ON prodass.opportunity = opp.fulloptyid
INNER JOIN ( 
            SELECT           OpportunityID,
                              ProductID,
                              OutlookProductGroup
            FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
            WHERE as_of_date =  ( SELECT value
                                   FROM b2b_tmp.b2b_tmp_assignment_variables
                                   WHERE key='Line Item - Max as of Date')
            AND upper(OutlookProductGroup) NOT IN ('CAPTIVATE PRIME ADD-ON','PRIMETIME')

) lineItems
ON lineItems.OpportunityID = opp.FullOptyId
INNER JOIN (    SELECT DISTINCT dmeaccountgroup,id
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account
                         WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                        -- I assume this is the "Major Account Segment " quoted in the ticket
                        AND lower(dmeaccountgroup) = 'smb'
                ) acc
ON opp.AccountID = acc.Id 
INNER JOIN (    
        SELECT  ProductID,
                majorolpg2
        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
        WHERE as_of_date = ( SELECT value
                                   FROM b2b_tmp.b2b_tmp_assignment_variables
                                   WHERE key='Product - Max as of Date')
        AND upper(majorolpg2) IN ('DIGITAL MEDIA','PUBLISHING')
) prod
ON lineItems.ProductID = prod.ProductID
INNER JOIN ( SELECT  recordid,
                     adoberoletype
              FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole ) 
              AND upper(adoberoletype) RLIKE 'ACCOUNT MANAGER|ACCOUNT MGR'
              AND upper(adoberoletype) NOT RLIKE 'POST SALES ACCOUNT MANAGER - OBU'
 ) rt
ON rt.recordid = prodass.adoberole
WHERE opp.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)




-- COMMAND ----------

-- DBTITLE 1,Japan ENT
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid, 
                'JAPAN ENT',
                'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN (  SELECT opportunityid,
                     productid,
                     majorrevenuetype
              FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
              WHERE as_of_date =  ( SELECT value
                                   FROM b2b_tmp.b2b_tmp_assignment_variables
                                   WHERE key='Line Item - Max as of Date')
              AND lower(majorrevenuetype) = 'subscription' 
               
) li 
ON opp.id = li.opportunityid
INNER JOIN  ( SELECT productname,
                     MajorOLPG2,
                     productid
              FROM b2b.uda_replicn_sf_corp_uda_vw_product2
              WHERE as_of_date = ( SELECT value
                                   FROM b2b_tmp.b2b_tmp_assignment_variables
                                   WHERE key='Product - Max as of Date')
              AND upper(coalesce(productname,'NULL')) NOT IN ('TRAVEL:SOFTWARE CONSULTING','TRAVEL:SAAS CONSULTING') 
              AND upper(MajorOLPG2) IN ('DIGITAL MEDIA') 
) prod
ON li.productid  = prod.productid 
INNER JOIN (  SELECT opportunity, 
                    subterritory,
                    adoberole
             FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment
             WHERE as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Sales Team Assignment - Max as of Date')
             AND upper(subterritory) IN ( 'JAPAN DME ENT STRAT 1', 
                                              'JAPAN DME ENT CORP 2 A',
                                              'JAPAN DME ENT CORP 2 B', 
                                              'JAPAN DME ENT CORP 3 A', 
                                              'JAPAN DME ENT CORP 3 B') 
) prodAss 
ON opp.id = prodAss.opportunity
INNER JOIN ( SELECT  recordid,
                     adoberoletype
              FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole ) 
              AND upper(adoberoletype) LIKE '%ACCOUNT MANAGER%' 
 ) rt
ON rt.recordid = prodAss.adoberole
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND upper(opp.geo) LIKE '%JAPAN%'
AND upper(coalesce(opp.OpportunitySequence,'NULL')) <> 'SECONDARY' 
AND upper(coalesce(opp.opportunityrecordtype,'NULL')) <> 'SMB OPPORTUNITY' 


-- COMMAND ----------

-- DBTITLE 1,EMEA GOV ENT SMB FLAG

INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
       CASE WHEN (opp.AccountAddressCountry IN ('UK', 'DE') AND lower(opp.Industry) LIKE 'government%') THEN 'ENT'
            WHEN lower(opp.Industry) IN ('government - federal', 'government - military')
            THEN 'ENT'
            WHEN lower(opp.Industry) IN ('government - local', 'government - state') 
            THEN 'CSMB'
            WHEN (acc.DMeAccountGroup = 'SMB')
            THEN 'SMB'
            ELSE 'ENT'
        END AS team,
       'ALL'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
LEFT JOIN (    SELECT DISTINCT dmeaccountgroup,id
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account
                        WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                ) acc
        ON opp.AccountID = acc.Id 
WHERE opp.as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Opp - Max as of Date')
AND opp.CloseDate IS NOT NULL
AND opp.CloseDate >= cast('2021-01-01' AS DATE)
AND opp.Geo='EMEA' ;


-- COMMAND ----------

-- DBTITLE 1,APAC TAM 24 (See ticket 5636)
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id,team,date_period)
SELECT DISTINCT opp.fulloptyid,
                'APAC TAM',
                '2024'
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN ( SELECT opportunity, 
                    adoberole
             FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment 
             WHERE upper(globalregion) LIKE '%APAC%'
             AND upper(subterritory) NOT LIKE '%DX%'
             AND as_of_date = (SELECT value
                        FROM b2b_tmp.b2b_tmp_assignment_variables
                        WHERE key='Sales Team Assignment - Max as of Date')
             ) prodass
ON prodass.opportunity = opp.fulloptyid
INNER JOIN ( 
            SELECT           OpportunityID,
                              ProductID,
                              OutlookProductGroup
            FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
            WHERE as_of_date =  ( SELECT value
                                   FROM b2b_tmp.b2b_tmp_assignment_variables
                                   WHERE key='Line Item - Max as of Date')
            AND upper(OutlookProductGroup) NOT IN ('CAPTIVATE PRIME ADD-ON','PRIMETIME')

) lineItems
ON lineItems.OpportunityID = opp.FullOptyId
INNER JOIN (    SELECT DISTINCT dmeaccountgroup,id
                        FROM b2b.uda_replicn_sf_corp_uda_vw_account
                         WHERE as_of_date = (    SELECT value
                                                FROM b2b_tmp.b2b_tmp_assignment_variables
                                                WHERE key='Acc - Max as of Date')
                        -- I assume this is the "Major Account Segment " quoted in the ticket
                        AND upper(dmeaccountgroup)IN ('SMB','CSMB')
                ) acc
ON opp.AccountID = acc.Id 
INNER JOIN (    
        SELECT  productID,
                majorolpg2,
                outlookproductgroup
        FROM b2b.uda_replicn_sf_corp_uda_vw_product2
        WHERE as_of_date = ( SELECT value
                                   FROM b2b_tmp.b2b_tmp_assignment_variables
                                   WHERE key='Product - Max as of Date')
        AND upper(majorolpg2) IN ('DIGITAL MEDIA','PUBLISHING')
        AND upper(outlookproductgroup) NOT IN ('CAPTIVATE PRIME ADD-ON','PRIMETIME')
) prod
ON lineItems.ProductID = prod.ProductID
INNER JOIN ( SELECT  recordid,
                     adoberoletype
              FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole
              WHERE as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_adoberole ) 
              AND upper(adoberoletype) RLIKE 'ACCOUNT MANAGER|ACCOUNT MGR'
              AND upper(adoberoletype) NOT RLIKE 'POST SALES ACCOUNT MANAGER - OBU'
 ) rt
ON rt.recordid = prodass.adoberole
WHERE opp.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)




-- COMMAND ----------

-- MAGIC %md
-- MAGIC # FY24 Logic

-- COMMAND ----------

-- DBTITLE 1,Create Fy 24 Segment Lookup Table
DROP TABLE IF EXISTS b2b_tmp.fy24_named_acounts_segment_lu; 
CREATE TABLE b2b_tmp.fy24_named_acounts_segment_lu (full_opty_id STRING, account_id STRING, sub_id STRING, sales_district STRING, named_flag INT, fy24_proposal_segment_flag STRING);
INSERT INTO b2b_tmp.fy24_named_acounts_segment_lu (full_opty_id, account_id, sub_id, sales_district, named_flag, fy24_proposal_segment_flag)
SELECT core.full_opty_id,
       acc.account_id,
       dme.ech_sub_id,
       dme.sales_district,
       dme.named_flag,
       dme.fy24_proposal_segment_flag
FROM ( 
        SELECT DISTINCT ech_sub_id,
                        sales_district,
                        CASE WHEN upper(fy24_proposal_segment_flag) = 'EDU' AND  geo = 'EMEA' THEN 'EMEA EDU'
                             WHEN upper(fy24_proposal_segment_flag) = 'EDU' AND  geo = 'AMER' THEN 'AMER EDU'
                             ELSE upper(fy24_proposal_segment_flag)
                        END AS fy24_proposal_segment_flag,
                        named_flag
        FROM b2b.dme_customer_profile
        WHERE named_flag=1  -- If its not a named account we default to FY23 Logic 
)  dme 
INNER JOIN (  SELECT  id AS account_id,
                      standardizedsubid,
                      salesdistrict
            FROM b2b.uda_replicn_sf_corp_uda_vw_account a
            WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_account)
) acc
ON dme.sales_district = acc.salesdistrict AND acc.standardizedsubid = dme.ech_sub_id
INNER JOIN b2b.l2_sa_sfdc_pipeline_core core 
ON  core.account_id = acc.account_id 

-- COMMAND ----------

-- DBTITLE 1,Archive Fy 24 Segment Lookup Table - This should actually be done by whoever loads this table 
INSERT INTO b2b.dme_customer_profile_snapshot (
  as_of_date,
  geo,
  fy24_proposal_segment_flag,
  ech_sub_id,
  ech_sub_name,
  ech_sub_country_code,
  domain,
  ech_parent_name,
  ech_parent_id,
  ech_parent_country_code,
  contract_key,
  end_user_id,
  org_key,
  std_sub_id_mapped,
  ech_sub_tot_emp_cont_enriched,
  ech_sub_annual_sales_usd_enriched,
  ech_sub_industry_enriched,
  ech_sub_annual_sales_band,
  ech_sub_employee_count_band,
  employee_count_proxy,
  ech_parent_annual_sales_usd,
  ech_parent_industry,
  ech_parent_tot_emp_cont,
  market_segment,
  sops_market_segment,
  sales_district,
  city,
  f_tv_market,
  division,
  region_group,
  state_code,
  group,
  region,
  state_region,
  postal_code,
  market_area,
  route_to_market_derived,
  cc_phone_vs_web,
  product_group,
  contract_end_date,
  contract_type,
  reseller,
  distributor,
  partner_level,
  ending_seats_band,
  Offering,
  pro_version_flag,
  subs_offer,
  renewal_date,
  renewal_wk,
  renewal_qtr,
  up_for_renewal_seats,
  up_for_renewal_arr,
  fiscal_yr_desc,
  year_end_date,
  ending_arr_total,
  ending_seats_total,
  net_new_arr_total,
  net_new_subs_total,
  upsell_rsam,
  expand_rsam,
  greenfield_rsam,
  total_rsam,
  acrobat_cc_cross_sell_propensity_bucket,
  frame_upsell_cross_sell_propensity_bucket,
  sign_upsell_cross_sell_propensity_bucket,
  substance_cc_cross_sell_propensity_bucket,
  substance_upsell_propensity_bucket,
  growth_asv,
  opportunity_count,
  fy23_segment_flag,
  financial_segment,
  named_flag )

SELECT 
  core.as_of_date,
  dme.geo,
  dme.fy24_proposal_segment_flag,
  dme.ech_sub_id,
  dme.ech_sub_name,
  dme.ech_sub_country_code,
  dme.domain,
  dme.ech_parent_name,
  dme.ech_parent_id,
  dme.ech_parent_country_code,
  dme.contract_key,
  dme.end_user_id,
  dme.org_key,
  dme.std_sub_id_mapped,
  dme.ech_sub_tot_emp_cont_enriched,
  dme.ech_sub_annual_sales_usd_enriched,
  dme.ech_sub_industry_enriched,
  dme.ech_sub_annual_sales_band,
  dme.ech_sub_employee_count_band,
  dme.employee_count_proxy,
  dme.ech_parent_annual_sales_usd,
  dme.ech_parent_industry,
  dme.ech_parent_tot_emp_cont,
  dme.market_segment,
  dme.sops_market_segment,
  dme.sales_district,
  dme.city,
  dme.f_tv_market,
  dme.division,
  dme.region_group,
  dme.state_code,
  dme.group,
  dme.region,
  dme.state_region,
  dme.postal_code,
  dme.market_area,
  dme.route_to_market_derived,
  dme.cc_phone_vs_web,
  dme.product_group,
  dme.contract_end_date,
  dme.contract_type,
  dme.reseller,
  dme.distributor,
  dme.partner_level,
  dme.ending_seats_band,
  dme.Offering,
  dme.pro_version_flag,
  dme.subs_offer,
  dme.renewal_date,
  dme.renewal_wk,
  dme.renewal_qtr,
  dme.up_for_renewal_seats,
  dme.up_for_renewal_arr,
  dme.fiscal_yr_desc,
  dme.year_end_date,
  dme.ending_arr_total,
  dme.ending_seats_total,
  dme.net_new_arr_total,
  dme.net_new_subs_total,
  dme.upsell_rsam,
  dme.expand_rsam,
  dme.greenfield_rsam,
  dme.total_rsam,
  dme.acrobat_cc_cross_sell_propensity_bucket,
  dme.frame_upsell_cross_sell_propensity_bucket,
  dme.sign_upsell_cross_sell_propensity_bucket,
  dme.substance_cc_cross_sell_propensity_bucket,
  dme.substance_upsell_propensity_bucket,
  NULL AS growth_asv, -- on 23-01-24 these 2 columns were removed from the table.
  NULL AS opportunity_count,
  dme.opportunity_count,
  dme.fy23_segment_flag,
  dme.financial_segment,
  dme.named_flag 
FROM b2b.dme_customer_profile dme
CROSS JOIN ( SELECT MAX(as_of_date) AS as_of_date FROM b2b.l2_sa_sfdc_pipeline_core ) core  -- I am just applying the core AS of date to this table

-- COMMAND ----------

-- DBTITLE 1,FY24 Segmentation - We use this if we have it otherwise default to FY23 Rules
-- Delete any FY23 Segmentation from b2b_tmp.b2b_tmp_assignment_team_mapping where things opportunity has Fy24 Segmentation
DELETE FROM b2b_tmp.b2b_tmp_assignment_team_mapping 
WHERE full_opty_id IN (SELECT full_opty_id FROM b2b_tmp.fy24_named_acounts_segment_lu);

-- Add the FY24  records in;
INSERT INTO b2b_tmp.b2b_tmp_assignment_team_mapping (full_opty_id, team, date_period)
SELECT DISTINCT full_opty_id, fy24_proposal_segment_flag, 'FY24'
FROM b2b_tmp.fy24_named_acounts_segment_lu;

-- COMMAND ----------

OPTIMIZE b2b_tmp.b2b_tmp_assignment_team_mapping

-- COMMAND ----------

-- DBTITLE 1,Create Segmentation L2 Report
DROP TABLE IF EXISTS b2b.l2_sa_sfdc_pipeline_segmentation;
CREATE TABLE b2b.l2_sa_sfdc_pipeline_segmentation  AS
SELECT DISTINCT core.full_opty_id,
                core.deal_reg_id,
                acc.account_id,
                acc.parent_id,
                acc.subsidiary_id,
                acc.sales_district,
                dme.geo AS cust_profile_geo,

                -- FY 24
                coalesce(teamlu.corp1_24,'-') AS corp1_24,
                coalesce(teamlu.corp2_24,'-') AS corp2_24,
                coalesce(teamlu.csmb_24,'-') AS csmb_24,
                coalesce(teamlu.ent_24,'-') AS ent_24,
                coalesce(teamlu.amer_edu_named_24,'-') AS amer_edu_named_24,
                coalesce(teamlu.emea_edu_named_24,'-') AS emea_edu_named_24,
                coalesce(teamlu.latam_named_24,'-') AS latam_named_24,
                coalesce(teamlu.apac_tam_24,'-') AS apac_tam_24,
                coalesce(teamlu.emea_edu_non_named_24,'-') AS emea_edu_non_named_24,
                coalesce(teamlu.latam_non_named_24,'-') AS latam_non_named_24,
                coalesce(teamlu.abd_named_24,'-') AS abd_named_24,

                -- FY 23 Fields
                coalesce(teamlu.amer_gbd,'-') AS amer_gbd,
                coalesce(teamlu.amer_mm_22,'-') AS amer_mm_22,
                coalesce(teamlu.amer_mm_23,'-') AS amer_mm_23,
                coalesce(teamlu.amer_edu,'-') AS amer_edu,
                coalesce(teamlu.latam_ent,'-') AS latam_ent,
                coalesce(teamlu.emea_cnx,'-') AS emea_cnx,
                coalesce(teamlu.emea_pss_22_q3,'-') AS emea_pss_22_q3,
                coalesce(teamlu.emea_pss_22_q4,'-') AS emea_pss_22_q4,
                coalesce(teamlu.emea_pss_23_q1_to_q3,'-') AS emea_pss_23_q1_to_q3,
                coalesce(teamlu.emea_pss_23_q4,'-') AS emea_pss_23_q4,
                coalesce(teamlu.emea_pss_23,'-') AS emea_pss_23,
                coalesce(teamlu.emea_edu,'-') AS emea_edu,
                coalesce(teamlu.emea_reseller,'-') AS emea_reseller,
                coalesce(teamlu.apac_ent,'-') AS apac_ent,
                coalesce(teamlu.apac_smb,'-') AS apac_smb,
                coalesce(teamlu.japan_ent,'-') AS japan_ent,
                coalesce(teamlu.emea_gov_ent_smb,'-') AS emea_gov_ent_smb,
                cast(current_timestamp() as string) AS executed_on
FROM b2b.l2_sa_sfdc_pipeline_core core
INNER JOIN (    SELECT     fulloptyid,
                           accountID
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp 
                WHERE opp.as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity )
        ) udaOpp
ON udaOpp.fulloptyid = core.full_opty_id
LEFT JOIN (SELECT        Id AS account_id
                        , standardizedparentid AS parent_id
                        , standardizedsubid AS subsidiary_id
                        , salesdistrict AS sales_district
                FROM b2b.uda_replicn_sf_corp_uda_vw_account
                WHERE as_of_date IN ( SELECT max(as_of_date) 
                                FROM b2b.uda_replicn_sf_corp_uda_vw_account)
        ) acc  
ON udaOpp.accountID = acc.account_id
LEFT JOIN (     SELECT  DISTINCT ech_sub_id,sales_district,geo
                FROM b2b.dme_customer_profile
                WHERE named_flag=1 ) dme -- they want to see the geo in this table for some reason
ON dme.ech_sub_id = acc.subsidiary_id 
        AND acc.sales_district = dme.sales_district 
LEFT JOIN (
        
-- this works as Y is alphabetically bigger than -
SELECT full_opty_id, 
       MAX(amer_gbd) AS amer_gbd,
       MAX(amer_mm_22) AS amer_mm_22,
       MAX(amer_mm_23) AS amer_mm_23,
       MAX(amer_edu) AS amer_edu,
       MAX(latam_ent) AS latam_ent,
       MAX(emea_cnx) AS emea_cnx,
       MAX(emea_pss_22_q3) AS emea_pss_22_q3,
       MAX(emea_pss_22_q4) AS emea_pss_22_q4,
       MAX(emea_pss_23_q1_to_q3) AS emea_pss_23_q1_to_q3,
       MAX(emea_pss_23_q4) AS emea_pss_23_q4,
       MAX(emea_pss_23) AS emea_pss_23,
       MAX(emea_edu) AS emea_edu,
       MAX(emea_reseller) AS emea_reseller,
       MAX(apac_ent) AS apac_ent,
       MAX(apac_smb) AS apac_smb,
       MAX(japan_ent) AS japan_ent,
       MAX(emea_gov_ent_smb) AS emea_gov_ent_smb,
       MAX(corp2_24) AS corp2_24,
       MAX(corp1_24) AS corp1_24,
       MAX(csmb_24) AS csmb_24,
       MAX(ent_24) AS ent_24,
       MAX(amer_edu_named_24) AS amer_edu_named_24,
       MAX(emea_edu_named_24) AS emea_edu_named_24,
       MAX(latam_named_24) AS latam_named_24,
       MAX(apac_tam_24) AS apac_tam_24,
       MAX(emea_edu_non_named_24) AS emea_edu_non_named_24,
       MAX(latam_non_named_24) AS latam_non_named_24,
       MAX(abd_named_24) AS  abd_named_24
FROM ( 
            SELECT  full_opty_id,
                    CASE WHEN team = 'AMER GBD' THEN 'Y' ELSE '-' END AS amer_gbd,
                    CASE WHEN team = 'AMER MM' AND date_period='2022' THEN 'Y' ELSE '-' END AS amer_mm_22,
                    CASE WHEN team = 'AMER MM' AND date_period='2023' THEN 'Y' ELSE '-' END AS amer_mm_23,
                    CASE WHEN team = 'AMER EDU' AND date_period='2023' THEN 'Y' ELSE '-' END AS amer_edu,
                    CASE WHEN team = 'LATAM ENTERPRISE' THEN 'Y' ELSE '-' END AS latam_ent,
                    CASE WHEN team = 'EMEA CNX' THEN 'Y' ELSE '-' END AS emea_cnx,
                    CASE WHEN team = 'EMEA PSS' AND date_period='2022 Q3' THEN 'Y' ELSE '-' END AS emea_pss_22_q3,
                    CASE WHEN team = 'EMEA PSS' AND date_period='2022 Q4' THEN 'Y' ELSE '-' END AS emea_pss_22_q4,
                    CASE WHEN team = 'EMEA PSS' AND date_period='2023 Q1 to Q3' THEN 'Y' ELSE '-' END AS emea_pss_23_q1_to_q3,
                    CASE WHEN team = 'EMEA PSS' AND date_period='2023 Q4' THEN 'Y' ELSE '-' END AS emea_pss_23_q4,
                    CASE WHEN team = 'EMEA PSS' AND date_period IN ('2023 Q4','2023 Q1 to Q3') THEN 'Y' ELSE '-' END AS emea_pss_23,
                    CASE WHEN team = 'EMEA EDU' THEN 'Y' ELSE '-' END AS emea_edu,
                    CASE WHEN team = 'EMEA RESELLER' THEN 'Y' ELSE '-' END AS emea_reseller,
                    CASE WHEN team = 'APAC ENT' THEN 'Y' ELSE '-' END AS apac_ent,
                    CASE WHEN team = 'APAC SMB' THEN 'Y' ELSE '-' END AS apac_smb,
                    CASE WHEN team = 'JAPAN ENT' THEN 'Y' ELSE '-' END as japan_ent,
                    CASE WHEN team = 'ENT' THEN 'ENT'
                        WHEN team = 'SMB' THEN 'SMB'
                        WHEN team = 'CSMB' THEN 'CSMB' ELSE '-' END AS emea_gov_ent_smb,
                    -- Get the names confirmed on these - currently they dont exist in the DME Segmentation Table
                    CASE WHEN team = 'CORP T1' AND date_period = 'FY24' THEN 'Y' ELSE '-' END AS corp1_24,
                    CASE WHEN team = 'CORP T2' AND date_period = 'FY24' THEN 'Y' ELSE '-' END AS corp2_24,
                    CASE WHEN team = 'CSMB' AND date_period = 'FY24' THEN 'Y' ELSE '-' END AS csmb_24,
                    CASE WHEN team = 'ENTERPRISE' AND date_period = 'FY24' THEN 'Y' ELSE '-' END AS ent_24,
                    CASE WHEN team = 'AMER EDU' AND date_period = 'FY24' THEN 'Y' ELSE '-' END AS amer_edu_named_24,
                    CASE WHEN team = 'EMEA EDU' AND date_period = 'FY24' THEN 'Y' ELSE '-' END AS emea_edu_named_24,
                    CASE WHEN team = 'LATAM' AND date_period = 'FY24' THEN 'Y' ELSE '-' END AS latam_named_24,
                    CASE WHEN team = 'ABD NAMED' AND date_period = 'FY24' THEN 'Y' ELSE '-' END AS abd_named_24,
                    CASE WHEN team = 'APAC TAM' AND date_period = '2024' THEN 'Y' ELSE '-' END AS apac_tam_24, 
                    CASE WHEN team = 'EMEA EDU' THEN 'Y' ELSE '-' END AS emea_edu_non_named_24,  -- pointless - the same as the FY23 stuff - but I got told to add it as they "need a new column"
                    CASE WHEN team = 'LATAM ENTERPRISE' THEN 'Y' ELSE '-' END AS latam_non_named_24   -- pointless - the same as the FY23 stuff - but I got told to add it as they "need a new column"
            FROM b2b_tmp.b2b_tmp_assignment_team_mapping
        )
GROUP BY full_opty_id      
) teamlu
ON teamlu.full_opty_id = core.full_opty_id

-- COMMAND ----------

-- DBTITLE 1,Delete Todays Data From Snapshot Table (shouldn't exist at this point - but just incase you need to re-run this code a few times you wont insert the same data multiple times)
DELETE FROM  b2b.l2_sa_sfdc_pipeline_segmentation_snapshot
WHERE as_of_date = ( SELECT MAX(as_of_date) AS as_of_date FROM b2b.l2_sa_sfdc_pipeline_core )

-- COMMAND ----------

-- DBTITLE 1,Insert into Snapshot (History Table) - Table is partitioned on as_of_date
INSERT INTO b2b.l2_sa_sfdc_pipeline_segmentation_snapshot (as_of_date,full_opty_id,deal_reg_id,account_id,parent_id,subsidiary_id,sales_district,cust_profile_geo,
                                                                    corp1_24,corp2_24,csmb_24,ent_24,amer_edu_named_24,emea_edu_named_24,latam_named_24,apac_tam_24,latam_non_named_24,abd_named_24,
                                                                    amer_gbd,amer_mm_22,amer_mm_23,amer_edu,
                                                                    latam_ent,emea_cnx,emea_pss_22_q3,emea_pss_22_q4,emea_pss_23_q1_to_q3,emea_pss_23_q4,emea_pss_23,emea_edu,emea_reseller,apac_ent,apac_smb,
                                                                    japan_ent,emea_gov_ent_smb,executed_on)


SELECT  c.as_of_date AS as_of_date,
        full_opty_id,
        deal_reg_id,
        account_id,
        parent_id,
        subsidiary_id,
        sales_district,
        cust_profile_geo,
        corp1_24,
        corp2_24,
        csmb_24,
        ent_24,
        amer_edu_named_24,
        emea_edu_named_24,
        latam_named_24,
        apac_tam_24,
        latam_non_named_24,
        abd_named_24,
        amer_gbd,
        amer_mm_22,
        amer_mm_23,
        amer_edu,
        latam_ent,
        emea_cnx,
        emea_pss_22_q3,
        emea_pss_22_q4,
        emea_pss_23_q1_to_q3,
        emea_pss_23_q4,
        emea_pss_23,
        emea_edu,
        emea_reseller,
        apac_ent,
        apac_smb,
        japan_ent,
        emea_gov_ent_smb,
        CAST(current_timestamp() AS STRING) as executed_on
FROM  b2b.l2_sa_sfdc_pipeline_segmentation
CROSS JOIN ( SELECT MAX(as_of_date) AS as_of_date FROM b2b.l2_sa_sfdc_pipeline_core ) c -- I am just applying the core AS of date to this table


-- COMMAND ----------

-- DBTITLE 1,Clean Up Temporary Objects
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_assignment_variables;
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_sales_team_usernames;
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_created_by_usernames;
DROP TABLE IF EXISTS b2b_tmp.b2b_tmp_assignment_team_mapping;
DROP TABLE IF EXISTS b2b_tmp.asv_by_opportunity;
DROP TABLE IF EXISTS b2b_tmp.fy24_named_acounts_segment_lu; 

