-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Sales Pipeline - Line Item
-- MAGIC
-- MAGIC Wiki Page: https://wiki.corp.adobe.com/display/CCM/Sales+Pipeline+L2+-+Line+Item
-- MAGIC
-- MAGIC Tasks Performed in Notebook:
-- MAGIC
-- MAGIC   - Select current records from opportunity line items
-- MAGIC   - Collapse down product groups to key values
-- MAGIC   - Sum numeric values by opportunity, product and key groups
-- MAGIC   - Produce output table (b2b.l2_sa_sfdc_pipeline_line_item)
-- MAGIC   - Insert into Snapshot Table (b2b.l2_sa_sfdc_pipeline_line_item_snapshot)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # This is some nonsense with the source parquet files having decimal values in them
-- MAGIC # https://learn.microsoft.com/en-us/answers/questions/853861/parquet-column-cannot-be-converted
-- MAGIC # https://community.databricks.com/t5/data-engineering/vectorized-reading-of-parquet-file-containing-decimal-type/m-p/6075
-- MAGIC
-- MAGIC spark.conf.set("spark.sql.parquet.enableVectorizedReader","false")  

-- COMMAND ----------

-- DBTITLE 1,Drop Line Details Table If Exists
DROP TABLE IF EXISTS b2b.l2_sa_sfdc_pipeline_line_item;

-- COMMAND ----------

-- DBTITLE 1,Create Line Details Table 
CREATE TABLE IF NOT EXISTS b2b.l2_sa_sfdc_pipeline_line_item (
                                                            full_opty_id string
                                                            , as_of_date date
                                                            , adobe_sku string
                                                            , om_pmbu string
                                                            , opportunity_product_name string
                                                            , outlook_product_group string
                                                            , product_outlook_product_group string
                                                            , booking_product_group string
                                                            , product_code_1 string
                                                            , product_id string
                                                            , prod_majorolpg1 string
                                                            , prod_business_unit string
                                                            , product_profit_center_name string
                                                            , business_prod_group string
                                                            , business_prod_group_growth string
                                                            , ori_total_price double
                                                            , ori_reportable_new_asv_fx_neutral double
                                                            , ori_reportable_asv_growth_fx_neutral double
                                                            , assigned_asv_growth_fx_neutral double
                                                            , ori_quantity double
                                                            , reportable_renewal_asv double 
                                                            , reportable_amount double
                                                            , total_growth_asv double
                                                            , sign_growth_asv double
                                                            , sign_growth_asv_1 double
                                                            , acrobat_growth_asv double
                                                            , acrobat_growth_asv_1 double
                                                            , stock_growth_asv double
                                                            , stock_growth_asv_1 double
                                                            , substance_growth_asv double
                                                            , substance_growth_asv_1 double
                                                            , frame_growth_asv double
                                                            , frame_growth_asv_1 double
                                                            , express_growth_asv double
                                                            , express_growth_asv_1 double
                                                            , creative_growth_asv double
                                                            , creative_growth_asv_1 double
                                                            , firefly_growth_asv double 
                                                            , firefly_growth_asv_1 double 
                                                            , total_quantity double
                                                            , sign_quantity double
                                                            , acrobat_quantity double
                                                            , stock_quantity double
                                                            , substance_quantity double
                                                            , frame_quantity double
                                                            , express_quantity double
                                                            , creative_quantity double
                                                            , firefly_quantity double
                                                            , executed_on string
);


-- COMMAND ----------

-- DBTITLE 1,Insert Into Line Item 

INSERT INTO b2b.l2_sa_sfdc_pipeline_line_item (
    full_opty_id 
    , as_of_date 
    , adobe_sku 
    , om_pmbu 
    , outlook_product_group
    , opportunity_product_name 
    , product_outlook_product_group 
    , booking_product_group 
    , product_code_1 
    , product_id 
    , prod_majorolpg1 
    , prod_business_unit 
    , product_profit_center_name 
    , business_prod_group 
    , business_prod_group_growth 
    , ori_total_price 
    , ori_reportable_new_asv_fx_neutral 
    , ori_reportable_asv_growth_fx_neutral 
    , assigned_asv_growth_fx_neutral 
    , reportable_renewal_asv
    , ori_quantity 
    , reportable_amount 
    , total_growth_asv 
    , sign_growth_asv 
    , sign_growth_asv_1 
    , acrobat_growth_asv 
    , acrobat_growth_asv_1 
    , stock_growth_asv 
    , stock_growth_asv_1 
    , substance_growth_asv 
    , substance_growth_asv_1 
    , frame_growth_asv 
    , frame_growth_asv_1 
    , express_growth_asv 
    , express_growth_asv_1 
    , creative_growth_asv 
    , creative_growth_asv_1 
    , firefly_growth_asv  
    , firefly_growth_asv_1  
    , total_quantity 
    , sign_quantity 
    , acrobat_quantity 
    , stock_quantity 
    , substance_quantity 
    , frame_quantity 
    , express_quantity 
    , creative_quantity 
    , firefly_quantity 
    , executed_on 
)
SELECT  core01.OpportunityID
        , core01.as_of_date
        , core01.AdobeSKU
        , core01.OM_PMBU
        , core01.OutlookProductGroup
        , core01.OpportunityProductName
        , core01.prod_outlook_prod_group
        , core01.booking_product_group
        , core01.ProductCode1
        , core01.ProductID
        , core01.prod_majorolpg1
        , core01.prod_business_unit
        , core01.ProductProfitCenterName
        , core01.business_prod_group
        , core01.business_prod_group_growth
        , core01.ori_TotalPrice
        , sum(CASE WHEN core01.ori_ReportableNewASV_FX_Neutral IS NULL THEN 0 ELSE core01.ori_ReportableNewASV_FX_Neutral END) AS ReportableNewASV_FX_Neutral
        , sum(CASE  WHEN ORI_ReportableASV_GrowthFX_Neutral IS NULL THEN NULL
                    ELSE core01.ORI_ReportableASV_GrowthFX_Neutral
            END) AS ORI_ReportableASV_GrowthFX_Neutral
        , sum(CASE WHEN core01.assignedasv_growthfx_neutral IS NULL THEN 0 ELSE core01.assignedasv_growthfx_neutral END) AS assigned_asv_growth_fx_neutral
        , sum(core01.reportable_renewal_asv) AS reportable_renewal_asv
        , sum(core01.quantity) AS ori_quantity
        , cast(sum(cast(core01.reportable_amount as DOUBLE)) as double) AS reportable_amount
        -- ASV;
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth IN ('SIGN','ACROBAT','STOCK','SUBSTANCE','FRAME','EXPRESS','CREATIVE','FIREFLY') THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS Total_Growth_ASV

        -- Sign 
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SIGN' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS sign_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SIGN' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS sign_growth_asv_1
        
        -- Acrobat
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'ACROBAT' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS acrobat_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'ACROBAT' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS acrobat_growth_asv_1

        -- Stock
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'STOCK' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS stock_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'STOCK' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS stock_growth_asv_1
       
       -- Substance
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SUBSTANCE' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS substance_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SUBSTANCE' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS substance_growth_asv_1
       
    
        -- Frame
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FRAME' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS frame_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FRAME' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS frame_growth_asv_1

        -- Express
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'EXPRESS' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS express_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'EXPRESS' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS express_growth_asv_1

        -- Creative
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'CREATIVE' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS creative_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'CREATIVE' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS creative_growth_asv_1

        -- Firefly
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FIREFLY' AND core01.CLEAN_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.CLEAN_ReportableASV_GrowthFX_Neutral ELSE 0 END),0) AS firefly_growth_asv
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FIREFLY' AND core01.ORI_ReportableASV_GrowthFX_Neutral >= 0 THEN core01.ORI_ReportableASV_GrowthFX_Neutral ELSE NULL END),0) AS firefly_growth_asv_1

        -- Quantity;
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth IN ('SIGN','ACROBAT','STOCK','SUBSTANCE','FRAME','EXPRESS','CREATIVE','FIREFLY') THEN core01.quantity ELSE 0 END),0) AS total_quantity

        -- Sign 
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SIGN' THEN core01.quantity END),0) AS sign_quantity
        -- Acrobat
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'ACROBAT' THEN core01.quantity END),0) AS acrobat_quantity
        -- Stock
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'STOCK' THEN core01.quantity END),0) AS stock_quantity
       -- Substance
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'SUBSTANCE' THEN core01.quantity END),0) AS substance_quantity
        -- Frame
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FRAME' THEN core01.quantity END),0) AS frame_quantity
        -- Express
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'EXPRESS' THEN core01.quantity END),0) AS express_quantity
        -- Creative
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'CREATIVE' THEN core01.quantity END),0) AS creative_quantity
        -- Firefly 
        , coalesce(sum(CASE WHEN core01.business_prod_group_growth = 'FIREFLY' THEN core01.quantity END),0) AS firefly_quantity
        , CAST(current_timestamp() as string) AS executed_on

FROM (  
        -- Business Logic to collapse down Product Group into key values which are easy to search for
        -- This logic is in this subquery so if it changes - it only need be updated here
        SELECT CASE WHEN core01_no_tag.OutlookProductGroup IN ('ACROBAT','DCE','DOCUMENT SERVICES') THEN 'ACROBAT'
                    WHEN (core01_no_tag.OutlookProductGroup IN ('CREATIVE','CCE STOCK') 
                                                            AND (core01_no_tag.ProductCode1 NOT IN ('FRAM','SBST','SRC','SBTX','3DAR') 
                                                            OR core01_no_tag.ProductCode1 IS NULL)) THEN 'CREATIVE'                           
                    WHEN (core01_no_tag.OutlookProductGroup = 'FRAME.IO' 
                                                        OR core01_no_tag.ProductCode1 = 'FRAM') THEN 'FRAME'
                    WHEN core01_no_tag.OutlookProductGroup IN ('SIGN','DCE TRANSACTION') THEN 'SIGN'
                    WHEN core01_no_tag.OutlookProductGroup = 'STOCK' THEN 'STOCK'
                    WHEN (core01_no_tag.OutlookProductGroup = 'CREATIVE'
                                                    AND core01_no_tag.ProductCode1 IN ('SBST','SRC','SBTX','3DAR'))
                                                    OR core01_no_tag.ProductProfitCenterName = '3DNI'
                                                    OR lower(core01_no_tag.OpportunityProductName) LIKE '%substance%'
                                                    OR lower(core01_no_tag.OpportunityProductName) LIKE '%3d%' THEN 'SUBSTANCE'
                    WHEN core01_no_tag.OutlookProductGroup LIKE '%FIREFLY%' THEN 'FIREFLY'
                    ELSE core01_no_tag.OutlookProductGroup 
                    END AS business_prod_group,

                    CASE  WHEN core01_no_tag.ProductCode1 IN ('SBTX', 'SBST', 'SRC' ) THEN 'Substance'
                                  WHEN core01_no_tag.prod_majorolpg1 IN ('ACROBAT','DCE') THEN 'Acrobat DC'
                                  WHEN core01_no_tag.prod_majorolpg1 IN ('SIGN','DCE TRANSACTION') THEN 'Adobe Sign'
                                  WHEN core01_no_tag.prod_majorolpg1 IN ('CREATIVE') THEN 'Creative - Professio'
                                  WHEN core01_no_tag.prod_majorolpg1 IN ('CCE STOCK', 'STOCK') THEN 'Stock Photography'
                                  ELSE 'Other'
                            END AS booking_product_group,
                
                -- Grouping for Growth Products
                top_product_group AS business_prod_group_growth,
                core01_no_tag.OpportunityID,
                core01_no_tag.as_of_date,
                core01_no_tag.AdobeSKU,
                core01_no_tag.OM_PMBU,
                core01_no_tag.OpportunityProductName,
                core01_no_tag.OutlookProductGroup,
                core01_no_tag.prod_outlook_prod_group,
                core01_no_tag.ProductCode1,
                core01_no_tag.ProductID,
                core01_no_tag.ProductProfitCenterName,
                core01_no_tag.ori_TotalPrice,
                core01_no_tag.ori_ReportableNewASV_FX_Neutral,
                core01_no_tag.ORI_ReportableASV_GrowthFX_Neutral,
                core01_no_tag.CLEAN_ReportableASV_GrowthFX_Neutral,
                core01_no_tag.quantity,
                cast(core01_no_tag.reportable_amount as double) AS reportable_amount,
                core01_no_tag.reportable_renewal_asv,-- Added in ticket 5693
                core01_no_tag.assignedasv_growthfx_neutral, 
                core01_no_tag.prod_majorolpg1,
                core01_no_tag.prod_business_unit
        FROM
        ( 
        SELECT  OpportunityID
                    , cast(li.as_of_date AS DATE) AS as_of_date
                    , case 
                        WHEN AdobeSKU = '\N' THEN NULL 
                        ELSE AdobeSKU 
                        END AS AdobeSKU
                    , case
                        WHEN OM_PMBU = '\N' THEN NULL 
                        ELSE OM_PMBU
                        END AS OM_PMBU
                    , OpportunityProductName
                    , CASE WHEN OutlookProductGroup = '\N' THEN NULL 
                        ELSE OutlookProductGroup
                        END AS OutlookProductGroup
                    , prod.prod_outlook_prod_group 
                    , CASE WHEN ProductCode1 = '\N' THEN NULL
                        ELSE ProductCode1
                        END AS ProductCode1
                    , li.ProductID
                    , prod.prod_majorolpg1
                    , prod.prod_business_unit
                    , CASE WHEN ProductProfitCenterName = '\N' THEN NULL 
                        ELSE ProductProfitCenterName 
                        END AS ProductProfitCenterName
                    , prod.prod_majorolpg2
                    , prod.top_product_group
                    , sum(round(cast(TotalPrice AS double), 2)) AS ori_TotalPrice
                    , sum(CASE WHEN ReportableNewASV_FX_Neutral IS NULL THEN 0
                        ELSE round(cast(ReportableNewASV_FX_Neutral AS double), 0)
                        END) AS ori_ReportableNewASV_FX_Neutral
                    , sum(CASE WHEN ReportableASV_GrowthFX_Neutral IS NULL THEN NULL
                        ELSE round(cast(ReportableASV_GrowthFX_Neutral AS double), 0)
                        END) AS ORI_ReportableASV_GrowthFX_Neutral
                    , sum(CASE WHEN ReportableASV_GrowthFX_Neutral IS NULL THEN 0
                        WHEN cast(ReportableASV_GrowthFX_Neutral AS double) < 0 THEN 0
                        ELSE round(cast(ReportableASV_GrowthFX_Neutral AS double), 0)
                        END) AS CLEAN_ReportableASV_GrowthFX_Neutral
                    , sum(cast(quantity AS double)) AS quantity
                    , cast(sum(cast( li.reportableamount as double)) as double) AS reportable_amount
                    , sum(round(prodass.assignedasv_growthfx_neutral,2))  AS assignedasv_growthfx_neutral
                    , sum(round(cast(li.reportablerenewalasv_fx_neutral as double),2)) AS reportable_renewal_asv -- Added 
                    FROM  (SELECT * 
                            FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem 
                            WHERE as_of_date = (SELECT Max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunitylineitem)
                            AND flag='D'
                    ) li
                    LEFT JOIN  ( SELECT     MajorOLPG1 AS prod_majorolpg1
                                            ,majorolpg2 AS prod_majorolpg2
                                            ,OutlookProductGroup AS prod_outlook_prod_group
                                            ,BusinessUnit AS prod_business_unit
                                            ,ProductID 
                                            ,CASE   WHEN OutlookProductGroup LIKE '%FIREFLY%' THEN 'FIREFLY'
                                                    WHEN OutlookProductGroup = 'SUBSTANCE' THEN 'SUBSTANCE'
                                                    WHEN OutlookProductGroup = 'FRAME.IO' THEN 'FRAME'
                                                    WHEN OutlookProductGroup = 'EXPRESS' THEN 'EXPRESS'
                                                    ELSE MajorOLPG1
                                                    END AS top_product_group
                                    FROM b2b.uda_replicn_sf_corp_uda_vw_product2
                                    WHERE as_of_date IN (SELECT max(as_of_date) 
                                                        FROM b2b.uda_replicn_sf_corp_uda_vw_product2)
                    ) prod 
                    ON li.ProductID = prod.ProductID
                    -- limit to just those records filtered in CORE
                    INNER JOIN b2b.l2_sa_sfdc_pipeline_core core
                    ON li.OpportunityID = core.full_opty_id

                    -- Ticket 4202 - add  assignedasv_growthfx_neutral
                    LEFT JOIN (
                        SELECT productlineitemid, 
                                sum(assignedasv_growthfx_neutral) AS assignedasv_growthfx_neutral -- it looks like sometimes users enter 0 as well as a value - I need to force this to have 1 row per line item id
                        FROM ( 
                            SELECT DISTINCT productlineitemid, 
                                            assignedasv_growthfx_neutral -- you have the same total multiple times - per sales team member - making the set distinct is correct for the line item
                            FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment
                            WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment)
                        ) x 
                        GROUP BY productlineitemid
                    ) prodass
                    ON li.lineitemid = prodass.productlineitemid
                    GROUP BY AdobeSKU
                            , li.OM_PMBU
                            , li.OpportunityProductName
                            , li.OutlookProductGroup
                            , prod.prod_outlook_prod_group
                            , li.ProductCode1
                            , li.ProductID
                            , prod.prod_majorolpg1
                            , prod_majorolpg2
                            , top_product_group
                            , prod.prod_business_unit
                            , li.ProductProfitCenterName
                            , li.OpportunityID
                            , li.as_of_date
                ) core01_no_tag
) core01

GROUP BY core01.OpportunityID
        , core01.business_prod_group
        , core01.business_prod_group_growth
        , core01.as_of_date
        , core01.AdobeSKU
        , core01.OM_PMBU
        , core01.OpportunityProductName
        , core01.OutlookProductGroup
        , core01.booking_product_group
        , core01.prod_outlook_prod_group
        , core01.ProductCode1
        , core01.ProductID
        , core01.ProductProfitCenterName
        , core01.ori_TotalPrice
        , prod_majorolpg1
        , prod_business_unit

-- COMMAND ----------

-- DBTITLE 1,Delete Todays Data From Snapshot Table (shouldn't exist at this point - but just incase you need to re-run this code a few times you wont insert the same data multiple times)
DELETE FROM b2b.l2_sa_sfdc_pipeline_line_item_snapshot
WHERE as_of_date = (SELECT max(as_of_date) FROM b2b.l2_sa_sfdc_pipeline_line_item);

-- COMMAND ----------

-- DBTITLE 1,Insert into Snapshot (History Table) - Table is partitioned on as_of_date
INSERT INTO b2b.l2_sa_sfdc_pipeline_line_item_snapshot (  

full_opty_id,
adobe_sku,
om_pmbu,
opportunity_product_name,
outlook_product_group,
product_outlook_product_group,
booking_product_group,
product_code_1,
product_id,
prod_majorolpg1,
prod_business_unit,
product_profit_center_name,
business_prod_group,
business_prod_group_growth,
ori_total_price,
ori_reportable_new_asv_fx_neutral,
ori_reportable_asv_growth_fx_neutral,
assigned_asv_growth_fx_neutral,
ori_quantity,
reportable_renewal_asv,
reportable_amount,
total_growth_asv,
sign_growth_asv,
sign_growth_asv_1,
acrobat_growth_asv,
acrobat_growth_asv_1,
stock_growth_asv,
stock_growth_asv_1,
substance_growth_asv,
substance_growth_asv_1,
frame_growth_asv,
frame_growth_asv_1,
express_growth_asv,
express_growth_asv_1,
creative_growth_asv,
creative_growth_asv_1,
firefly_growth_asv,
firefly_growth_asv_1,
total_quantity,
sign_quantity,
acrobat_quantity,
stock_quantity,
substance_quantity,
frame_quantity,
express_quantity,
creative_quantity,
firefly_quantity,
executed_on,
as_of_date)

SELECT full_opty_id
, adobe_sku
, om_pmbu
, opportunity_product_name
, outlook_product_group
, product_outlook_product_group
, booking_product_group
, product_code_1
, product_id
, prod_majorolpg1
, prod_business_unit
, product_profit_center_name
, business_prod_group
, business_prod_group_growth
, ori_total_price 
, ori_reportable_new_asv_fx_neutral 
, ori_reportable_asv_growth_fx_neutral
, assigned_asv_growth_fx_neutral
, ori_quantity 
, reportable_renewal_asv
, reportable_amount
, total_growth_asv 
, sign_growth_asv 
, sign_growth_asv_1 
, acrobat_growth_asv 
, acrobat_growth_asv_1 
, stock_growth_asv 
, stock_growth_asv_1 
, substance_growth_asv 
, substance_growth_asv_1 
, frame_growth_asv 
, frame_growth_asv_1 
, express_growth_asv 
, express_growth_asv_1 
, creative_growth_asv 
, creative_growth_asv_1 
, firefly_growth_asv
, firefly_growth_asv_1
, total_quantity 
, sign_quantity 
, acrobat_quantity 
, stock_quantity 
, substance_quantity 
, frame_quantity 
, express_quantity 
, creative_quantity 
, firefly_quantity
, executed_on
, as_of_date

FROM b2b.l2_sa_sfdc_pipeline_line_item

-- COMMAND ----------

-- MAGIC %md DEBUG
