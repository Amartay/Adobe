-- Databricks notebook source
CREATE OR REPLACE VIEW b2b.l2_sa_license_management_domain_lookup (
  vip_contract,
  jem_contract_id,
  subscription_account_guid,
  domain)
AS SELECT DISTINCT vip_contract, 
                jem_contract_id,
                subscription_account_guid,
                explode(array_distinct(member_email_domains)) as domain
FROM dmefinext.bdong_omega_prime
WHERE trim(lower(email_domain)) NOT IN  ('no email','unknown') 
AND ( contract_end_date_bp >= current_date OR contract_end_date_veda >= current_date )
AND fqtr_to_date_end_arr > 0 

UNION 

SELECT DISTINCT vip_contract, 
                jem_contract_id,
                subscription_account_guid,
                lower(email_domain) as domain
FROM dmefinext.bdong_omega_prime
WHERE trim(lower(email_domain)) NOT IN  ('no email','unknown') 
AND ( contract_end_date_bp >= current_date OR contract_end_date_veda >= current_date )
AND fqtr_to_date_end_arr > 0

