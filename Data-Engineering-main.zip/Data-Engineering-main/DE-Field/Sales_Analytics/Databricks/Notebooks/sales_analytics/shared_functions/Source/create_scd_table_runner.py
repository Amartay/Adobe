# Databricks notebook source
# DBTITLE 1,Create Class to Encapsulate SCD Logic
# MAGIC %python
# MAGIC class scdTableRunner:
# MAGIC     def __init__(self, sourceView, destTbl, rowId, debugMode, removeChangeLog):
# MAGIC         self.sourceView = sourceView
# MAGIC         self.destTbl = destTbl
# MAGIC         self.rowId = rowId
# MAGIC         self.debug = debugMode
# MAGIC         self.removeChangeLog = removeChangeLog
# MAGIC         self.changeLogDest = self.destTbl + "_change_log"
# MAGIC     
# MAGIC     ####################
# MAGIC     # Private Methods
# MAGIC     ####################
# MAGIC     
# MAGIC     # Change Log table Methods;
# MAGIC     def _get_new_records_sql(self):
# MAGIC
# MAGIC         new_records_sql = ( f" SELECT {self.rowId} AS PK_Value,"
# MAGIC                             f" 'NEW' AS status"
# MAGIC                             f" FROM {self.sourceView}"
# MAGIC                             f" WHERE {self.rowId} NOT IN (SELECT {self.rowId} FROM {self.destTbl})"
# MAGIC         )
# MAGIC         return new_records_sql
# MAGIC     
# MAGIC     def _get_records_to_delete_sql(self):
# MAGIC
# MAGIC         records_to_delete_sql = ( f" SELECT {self.rowId} AS PK_Value,"
# MAGIC                               f" 'DELETE' AS status"
# MAGIC                               f" FROM {self.destTbl}"
# MAGIC                               f" WHERE {self.rowId} NOT IN (SELECT {self.rowId} FROM {self.sourceView})"
# MAGIC                               f" AND date_to IS NULL"
# MAGIC         )
# MAGIC
# MAGIC         return records_to_delete_sql
# MAGIC     
# MAGIC     def _get_all_field_names(self,tbl):
# MAGIC         df = sqlContext.sql(f"SELECT * FROM {tbl}")
# MAGIC         return ','.join(df.columns)
# MAGIC
# MAGIC     def _get_records_to_ignore_sql(self):
# MAGIC
# MAGIC         all_field_names = self._get_all_field_names(self.sourceView)
# MAGIC         records_to_ignore_sql = ( f" SELECT {self.rowId} AS PK_Value,"
# MAGIC                                   f" 'IGNORE' AS status"
# MAGIC                                   f" FROM ("
# MAGIC                                   f" SELECT {all_field_names}"
# MAGIC                                   f" FROM {self.sourceView}"
# MAGIC                                   f" INTERSECT ("
# MAGIC                                   f" SELECT {all_field_names}"
# MAGIC                                   f" FROM {self.destTbl}"
# MAGIC                                   f"))"
# MAGIC         )
# MAGIC         return records_to_ignore_sql
# MAGIC
# MAGIC
# MAGIC     def _get_records_to_update_sql(self):
# MAGIC
# MAGIC         # if you arent new, deleted or ignored - you are updated
# MAGIC         new_records_sql = self._get_new_records_sql()
# MAGIC         ignored_records_sql = self._get_records_to_ignore_sql()
# MAGIC         
# MAGIC         records_to_update_sql = ( f" WITH  new_records  AS ({new_records_sql}),"
# MAGIC                                   f" records_to_ignore  AS ({ignored_records_sql})"
# MAGIC                                   f" SELECT {self.rowId} AS PK_Value,"
# MAGIC                                   f" 'UPDATE' AS status"
# MAGIC                                   f" FROM {self.sourceView}"
# MAGIC                                   f" WHERE {self.rowId} NOT IN ("
# MAGIC                                   f" SELECT PK_Value FROM new_records"
# MAGIC                                   f" UNION ALL"
# MAGIC                                   f" SELECT PK_Value FROM records_to_ignore)"
# MAGIC
# MAGIC         )
# MAGIC
# MAGIC         return records_to_update_sql
# MAGIC     
# MAGIC
# MAGIC     def _get_execute_scd_new_sql(self):
# MAGIC         # New Records Get inserted (start date/9999 end date)
# MAGIC         dest_field_names = self._get_all_field_names(self.destTbl)
# MAGIC         source_field_names = self._get_all_field_names(self.sourceView)
# MAGIC
# MAGIC         # Add SCD Fields to the source Fields string 
# MAGIC         insert_into_fields = source_field_names + ",date_from, date_to, is_current"
# MAGIC         select_values = source_field_names + " ,current_date(),CAST('9999-12-31' AS DATE),TRUE "
# MAGIC
# MAGIC         execute_scd_new_sql = ( f" INSERT INTO {self.destTbl} ({insert_into_fields})"
# MAGIC                                 f" SELECT {select_values} FROM {self.sourceView} sv"
# MAGIC                                 f" INNER JOIN {self.changeLogDest} cl"
# MAGIC                                 f" ON sv.{self.rowId} = cl.PK_value"
# MAGIC                                 f" AND cl.status = 'NEW'"
# MAGIC         
# MAGIC         )
# MAGIC
# MAGIC         return execute_scd_new_sql
# MAGIC
# MAGIC     def _get_execute_scd_delete_sql(self):
# MAGIC         # Deleted Records Get End dated 
# MAGIC         execute_scd_del_sql = ( f" UPDATE {self.destTbl}"
# MAGIC                                 f" SET date_to = current_date(),"
# MAGIC                                 f" is_current = FALSE"
# MAGIC                                 f" WHERE {self.rowId} IN (SELECT PK_value FROM {self.changeLogDest} WHERE status = 'DELETE')"
# MAGIC                                 f" AND date_to IS NULL"
# MAGIC
# MAGIC         )
# MAGIC
# MAGIC         return execute_scd_del_sql
# MAGIC
# MAGIC     def _get_execute_scd_update_sql(self):
# MAGIC         # Update = delete old record then insert new record 
# MAGIC         del_updated_record_sql = self._get_execute_scd_delete_sql()
# MAGIC         del_updated_record_sql = del_updated_record_sql.replace("status = 'DELETE'","status = 'UPDATE'")
# MAGIC
# MAGIC         add_new_sql = self._get_execute_scd_new_sql()
# MAGIC         add_new_sql = add_new_sql.replace("status = 'NEW'","status = 'UPDATE'")
# MAGIC
# MAGIC         # These statements have to run one at a time in the sqlcontext method in pyspark - so i return an array
# MAGIC         combined_sql = [del_updated_record_sql,add_new_sql]
# MAGIC         return combined_sql
# MAGIC     
# MAGIC     def _execute_scd_changes(self):
# MAGIC
# MAGIC         # Get dynamic sql Statements
# MAGIC         execute_scd_new_sql = self._get_execute_scd_new_sql()
# MAGIC         execute_scd_del_sql = self._get_execute_scd_delete_sql()
# MAGIC         execute_scd_update_sql = self._get_execute_scd_update_sql()
# MAGIC
# MAGIC         # Write log if debug mode is on - Dont Execute any Code
# MAGIC         if (self.debug):
# MAGIC              debug_str = (f"---------------------------------------- \n "
# MAGIC                          f" {self.sourceView} - Applying  SCD \n"
# MAGIC                          f"---------------------------------------- \n\n "
# MAGIC                          f" New Records \n"
# MAGIC                          f" {execute_scd_new_sql} \n\n"
# MAGIC                          f" Deleted Records \n"
# MAGIC                          f" {execute_scd_del_sql} \n\n"
# MAGIC                          f" Updated Records \n"
# MAGIC                          f" {execute_scd_update_sql} \n\n"
# MAGIC             )
# MAGIC              print(debug_str)
# MAGIC         else:
# MAGIC             # Execute them 
# MAGIC             sqlContext.sql(execute_scd_new_sql)
# MAGIC             sqlContext.sql(execute_scd_del_sql)
# MAGIC             sqlContext.sql(execute_scd_update_sql[0])
# MAGIC             sqlContext.sql(execute_scd_update_sql[1])
# MAGIC
# MAGIC             print(f"SCD Changes Applied to {self.destTbl}")
# MAGIC
# MAGIC     ####################
# MAGIC     # Public Methods
# MAGIC     ####################
# MAGIC
# MAGIC     def create_scd_change_log_table(self):
# MAGIC         
# MAGIC         # Get the SQL Commands
# MAGIC         new_records_sql = self._get_new_records_sql()
# MAGIC         records_to_delete_sql = self._get_records_to_delete_sql()
# MAGIC         records_to_ignore_sql = self._get_records_to_ignore_sql()
# MAGIC         records_to_update_sql = self._get_records_to_update_sql()
# MAGIC
# MAGIC         # Get Data from this SQL
# MAGIC         df_new = sqlContext.sql(new_records_sql)
# MAGIC         df_delete = sqlContext.sql(records_to_delete_sql)
# MAGIC         df_ignore =  sqlContext.sql(records_to_ignore_sql)
# MAGIC         df_update =  sqlContext.sql(records_to_update_sql)
# MAGIC         
# MAGIC         # Write log if debug mode is on - Dont Execute any Code
# MAGIC         if (self.debug):
# MAGIC             debug_str = (f"---------------------------------------- \n "
# MAGIC                          f" {self.sourceView} - Change Log SQL \n"
# MAGIC                          f"---------------------------------------- \n\n "
# MAGIC                          f" New Records \n"
# MAGIC                          f" {new_records_sql} \n\n"
# MAGIC                          f" Ignored Records \n"
# MAGIC                          f" {records_to_ignore_sql} \n\n"
# MAGIC                          f" Deleted Records \n"
# MAGIC                          f" {records_to_delete_sql} \n\n"
# MAGIC                          f" Updated Records \n"
# MAGIC                          f" {records_to_update_sql} \n\n"
# MAGIC             )
# MAGIC             print(debug_str)
# MAGIC
# MAGIC         else: 
# MAGIC             # Put the results in 1 Table
# MAGIC             df_combined = df_new.union(df_delete).union(df_ignore).union(df_update)
# MAGIC             
# MAGIC             # Write the change log to the storage
# MAGIC             
# MAGIC             df_combined.write.mode("overwrite").saveAsTable(self.changeLogDest)
# MAGIC
# MAGIC             print(f"{self.changeLogDest} Created")
# MAGIC     
# MAGIC     def perform_scd_update(self):
# MAGIC         self.create_scd_change_log_table()
# MAGIC         self._execute_scd_changes()
# MAGIC
# MAGIC         if (self.removeChangeLog):
# MAGIC             drop_change_log_sql = f"DROP TABLE IF EXISTS {self.changeLogDest};"
# MAGIC             sqlContext.sql(drop_change_log_sql)
# MAGIC         
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC     
# MAGIC
