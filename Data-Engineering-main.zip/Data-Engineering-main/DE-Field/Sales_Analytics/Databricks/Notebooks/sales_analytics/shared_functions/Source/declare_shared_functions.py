# Databricks notebook source
# MAGIC %md
# MAGIC This notebook stores functions which can be used by other notebooks - the advantage is this is these functions are only coded / updated in one place and can be reused in many. 
# MAGIC To use these functions in another notebook - call this notebook and the functions will be declared and in scope for the calling notebook.

# COMMAND ----------

# DBTITLE 1,Import Libraries
import datetime
import uuid

# COMMAND ----------

# DBTITLE 1,Declare Function to Log Job Start
def LogJobStart(job_id,job_name, start_time, logging_table):

    # Create Dataframe to write
    data = [{"job_id": job_id, 
            "job_name": job_name, 
            "start_time": start_time, 
            "end_time": '', 
            "status": '',
            "duration_minutes": int(0),
            "error_msg": '',}
    ]

    # Convert to spark DF and insert into log table
    df = spark.createDataFrame(data)
    format_df = df.withColumn("duration_minutes",df.duration_minutes.cast('int')) 
    df_ordered = format_df.select("job_id","job_name","start_time","end_time","status","duration_minutes","error_msg")
    df_ordered.write.mode("append").saveAsTable(logging_table)

# COMMAND ----------

# DBTITLE 1,Declare Function to Log Job End (Update a Job Start Record)
def LogJobEnd(job_id,job_name,start_time,status,err_msg,logging_table): 

    # Calculate end date and duration
    end_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    end_time_dt = datetime.datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')
    start_time_dt = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')

    time_delta = end_time_dt - start_time_dt
    duration = round(time_delta.total_seconds() / 60,0)

    # Build SQL Update Statement
    sql_update=f"UPDATE {logging_table} \
    SET end_time = '{end_time}', status = '{status}', duration_minutes = CAST({duration} AS INT), error_msg = '{err_msg}' \
    WHERE job_id = '{job_id}'"
    
    # Execute Sql
    sqlContext.sql(sql_update)