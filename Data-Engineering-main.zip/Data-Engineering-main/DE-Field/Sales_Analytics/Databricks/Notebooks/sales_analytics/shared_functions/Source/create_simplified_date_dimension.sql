-- Databricks notebook source
REFRESH TABLE Ids_coredata.dim_date;

-- COMMAND ----------


DROP VIEW IF EXISTS b2b.l2_sa_sfdc_dim_date;
CREATE VIEW b2b.l2_sa_sfdc_dim_date AS
SELECT      date_key,
            calendar_date,
            calendar_yr,
            calendar_yr_and_mo,
            calendar_yr_and_mo_desc,
            calendar_yr_and_wk,
            calendar_yr_and_wk_desc,
            fiscal_yr,
            previous_fiscal_yr,
            fiscal_yr_and_per,
            previous_fiscal_yr_and_per,
            fiscal_yr_and_per_desc,
            fiscal_yr_and_qtr,
            previous_fiscal_yr_and_qtr,
            fiscal_yr_and_qtr_desc,
            fiscal_qtr_id,
            fiscal_yr_and_qtr_start_date,
            fiscal_yr_and_qtr_end_date,
            fiscal_yr_and_wk,
            previous_fiscal_yr_week,
            fiscal_yr_and_wk_desc,
            fiscal_wk_in_qtr,
            fiscal_wk_in_qtr_numeric,
            fiscal_wk_in_yr,
            fiscal_wk_in_yr_numeric,
            day_name,
            fiscal_day_in_qtr,
            fiscal_yr_and_qtr_year_ago,
            fiscal_yr_and_qtr_desc_year_ago,
            previous_fiscal_yr_and_qtr_desc,
            next_fiscal_yr_and_qtr,
            next_fiscal_yr_and_qtr_desc,
            is_current_date

FROM ( 
      SELECT  d.date_key,
            cast(d.calendar_date as date) as calendar_date,
            d.calendar_yr,
            d.calendar_yr_and_mo,
            d.calendar_yr_and_mo_desc,
            d.calendar_yr_and_wk,
            d.calendar_yr_and_wk_desc,
            d.fiscal_yr,
            prvyr.previous_fiscal_yr,
            d.fiscal_yr_and_per,
            prvper.previous_fiscal_yr_and_per,
            d.fiscal_yr_and_per_desc,
            d.fiscal_yr_and_qtr,
            prvqtr.previous_fiscal_yr_and_qtr,
            d.fiscal_yr_and_qtr_desc,
            cast(d.fiscal_qtr_id as int) AS fiscal_qtr_id,
            cast(startQtr.fiscal_yr_and_qtr_end_date AS date) AS fiscal_yr_and_qtr_start_date,
            cast(endQtr.fiscal_yr_and_qtr_end_date AS date) AS fiscal_yr_and_qtr_end_date,
            d.fiscal_yr_and_wk, 
            prvweek.previous_fiscal_yr_week,
            d.fiscal_yr_and_wk_desc,
            d.fiscal_wk_in_qtr,
            d.fiscal_day_in_qtr,
            CAST(d.fiscal_wk_in_qtr AS int) AS fiscal_wk_in_qtr_numeric,
            d.fiscal_wk_in_yr,
            CAST(d.fiscal_wk_in_yr AS int) AS fiscal_wk_in_yr_numeric,
            d.day_name,
            d.fiscal_day_in_qtr,
            yearAgo.fiscal_yr_and_qtr As fiscal_yr_and_qtr_year_ago,
            yearAgo.fiscal_yr_and_qtr_desc As fiscal_yr_and_qtr_desc_year_ago,
            CASE WHEN cdate.today IS NOT NULL THEN 'Y' ELSE 'N' END as is_current_date,
            nxtqtr.next_fiscal_yr_and_qtr,
            nxtqtrDesc.next_fiscal_yr_and_qtr_desc,
            prvqtrDesc.previous_fiscal_yr_and_qtr_desc,
            -- THIS IS SOME NONSENSE ABOUT LEAP YEARS - the interval -1 year on a leap year returns the previous date causing me a duplication of rows every 4 years for one day...  
            row_number() OVER (PARTITION BY date_key ORDER BY date_key ) as row_num
      FROM Ids_coredata.dim_date d 
      -- get previous quarter 
      INNER JOIN ( SELECT qtr_key, 
                        lag(qtr_key) over (ORDER BY qtr_key) as previous_fiscal_yr_and_qtr
                  FROM ( 
                        SELECT DISTINCT fiscal_yr_and_qtr as qtr_key
                        FROM  Ids_coredata.dim_date
                        )
      )prvqtr
      ON prvqtr.qtr_key = d.fiscal_yr_and_qtr

      -- get previous quarter Desc
      INNER JOIN ( SELECT qtr_key, 
                          lag(qtr_key) over (ORDER BY qtr_key) as previous_fiscal_yr_and_qtr_desc
                  FROM ( 
                        SELECT DISTINCT fiscal_yr_and_qtr_desc as qtr_key
                        FROM  Ids_coredata.dim_date
                        )
      ) prvqtrDesc
      ON prvqtrDesc.qtr_key = d.fiscal_yr_and_qtr_desc
      
      -- get next quarter 
      INNER JOIN ( SELECT qtr_key, 
                        lead(qtr_key) over (ORDER BY qtr_key) as next_fiscal_yr_and_qtr
                  FROM ( 
                        SELECT DISTINCT fiscal_yr_and_qtr as qtr_key
                        FROM  Ids_coredata.dim_date
                        )
      )nxtqtr
      ON nxtqtr.qtr_key = d.fiscal_yr_and_qtr

      -- get next quarter Desc
      INNER JOIN ( SELECT qtr_key, 
                          lead(qtr_key) over (ORDER BY qtr_key) as next_fiscal_yr_and_qtr_desc
                  FROM ( 
                        SELECT DISTINCT fiscal_yr_and_qtr_desc as qtr_key
                        FROM  Ids_coredata.dim_date
                        )
      ) nxtqtrDesc
      ON nxtqtrDesc.qtr_key = d.fiscal_yr_and_qtr_desc

      -- Get previous fiscial yr and period
      INNER JOIN (
      SELECT period_key, 
            lag(period_key) over (ORDER BY period_key) as previous_fiscal_yr_and_per
      FROM ( 
            SELECT DISTINCT fiscal_yr_and_per as period_key
            FROM  Ids_coredata.dim_date
      )
      ) prvper
      ON d.fiscal_yr_and_per = prvper.period_key
      -- get previous year
      INNER JOIN  (
      SELECT yr_key, 
            lag(yr_key) over (ORDER BY yr_key) as previous_fiscal_yr
      FROM ( 
            SELECT DISTINCT fiscal_yr as yr_key
            FROM  Ids_coredata.dim_date
            )
      ) prvyr
      ON d.fiscal_yr = prvyr.yr_key
      -- Get previous Week 
      INNER JOIN (
            SELECT yr_week_key, 
            lag(yr_week_key) over (ORDER BY yr_week_key) as previous_fiscal_yr_week
      FROM ( 
            SELECT DISTINCT fiscal_yr_and_wk as yr_week_key
            FROM  Ids_coredata.dim_date
            )
      ) prvweek
      ON d.fiscal_yr_and_wk = prvweek.yr_week_key
      -- Get values from a year ago 
      LEFT JOIN  ( SELECT DISTINCT calendar_date, fiscal_yr_and_qtr,fiscal_yr_and_qtr_desc
                  FROM         Ids_coredata.dim_date )yearAgo
            ON cast(d.calendar_date as date) = (cast(yearAgo.calendar_date as date) + INTERVAL '1' YEAR)
      -- get yr_qtr_end_date
      LEFT JOIN ( SELECT fiscal_yr_and_qtr, 
                  MAX(calendar_date) as fiscal_yr_and_qtr_end_date
                  FROM Ids_coredata.dim_date
                  GROUP BY fiscal_yr_and_qtr ) endQtr
      ON endQtr.fiscal_yr_and_qtr = d.fiscal_yr_and_qtr
      -- get yr_qtr_start_date
      LEFT JOIN ( SELECT fiscal_yr_and_qtr, 
                  MIN(calendar_date) as fiscal_yr_and_qtr_end_date
                  FROM Ids_coredata.dim_date
                  GROUP BY fiscal_yr_and_qtr ) startQtr
      ON startQtr.fiscal_yr_and_qtr = d.fiscal_yr_and_qtr
      -- sused for current Date flag
      LEFT JOIN ( SELECT current_date() AS today) cdate 
      ON cdate.today = cast(d.calendar_date as date) 
      -- THERE are 2 rogue dates way out in the future that breaks the sequence
      WHERE d.date_key < 20300101
) 
WHERE row_num = 1
