-- Databricks notebook source
-- Refer to tickets: 
--https://jira.corp.adobe.com/browse/B2BDME-6067
--https://jira.corp.adobe.com/browse/B2BDME-6120

-- Note: The opportunity ID / Deal Reg ID (and because of this Rep Assignment) are really poorly populated when joining to sales force circa 80% of closed booked opportunities have no records in here 
-- I would advise no one to use this field to produce metrics - alas I was told "we need to add this so people can see that it is wrong" - that is why it exists here. See ticket 6120. 


-- COMMAND ----------

REFRESH TABLE CSMB_APP.fact_csmb_subscription_detail;
REFRESH TABLE CSMB_APP.exchange_rate_type_qtrly;
REFRESH TABLE CSMB_APP.subscription_params;
REFRESH TABLE CSMB_APP.acct_segment_activity_cutoff;
REFRESH TABLE CSMB_APP.acct_segment_realign_hist;
REFRESH TABLE CSMB_APP.dim_gtm_acct_hierarchy;
REFRESH TABLE CSMB_APP.gtm_projected_segmentation;
REFRESH TABLE CSMB_APP.dim_subscription;
REFRESH TABLE CSMB_APP.dim_gtm_acct_segment;
REFRESH csmb.vw_ccm_pivot4_all;
REFRESH TABLE Ids_coredata.dim_date;

-- COMMAND ----------

-- DBTITLE 1,Create Sops Segmentation Lookups (5839)
-- one sub / sales district can appear to have multiple distinct segments - So I am going to roll them into one string;
-- ENT ARR Uses this level 
CREATE OR REPLACE TABLE b2b_tmp.sops_segment_mapping_sub_distict AS 
SELECT  ech_sub_id, 
        sales_district,
        array_join(array_agg( DISTINCT fy24_proposal_segment_flag),'|') AS fy24_proposal_segment_flag
FROM b2b.dme_customer_profile
WHERE coalesce(ech_sub_id,'') <> ''
AND   coalesce(sales_district,'') <> '' -- we cant rely on null/blank strings
GROUP BY ech_sub_id, sales_district;

-- Pivot uses this grain 
CREATE OR REPLACE TABLE b2b_tmp.sops_segment_mapping_sub_distict_contract AS 
SELECT  ech_sub_id, 
        sales_district,
        contract_key,
        array_join(array_agg( DISTINCT fy24_proposal_segment_flag),'|') AS fy24_proposal_segment_flag
FROM b2b.dme_customer_profile
WHERE coalesce(ech_sub_id,'') <> ''
AND   coalesce(sales_district,'') <> '' -- we cant rely on null/blank strings
AND   coalesce(contract_key,'') <> ''
GROUP BY ech_sub_id, sales_district,contract_key

-- COMMAND ----------

-- DBTITLE 1,Create Pivot Product -> OLPG & Major OLPG Lookup (Ticket 5838)
-- Code provided in Ticket 5838 - converted to lookup table to simplify code
CREATE OR REPLACE TABLE b2b_tmp.pivot_product_to_olpg_mapping AS 
SELECT DISTINCT product_name,
                product_name_description,
                olpg,
                major_olpg 
FROM ( 
    SELECT product_name,
          a.product_name_description,
    CASE WHEN a.product_name IN ('ACRO', 'APAP') THEN 'ACROBAT'
         WHEN a.product_name IN ('CCLE') THEN 'CREATIVE'
         WHEN a.product_name IN ('CTSK') THEN 'STOCK'
         WHEN upper(a.product_name_description) LIKE '%SPARK%' THEN 'EXPRESS'
         WHEN a.product_name_description LIKE '%- Pro%' THEN 'CCE STOCK'
         WHEN upper(a.product_name_description) LIKE '%ACRO%SIGN%' OR upper(a.product_name_description) LIKE '%ADOBE%SIGN%' THEN 'SIGN'
         ELSE olpg
    END AS olpg,
    CASE WHEN a.product_name IN ('ACRO', 'APAP') THEN 'ACROBAT'
         WHEN a.product_name IN (' CCLE') THEN 'CREATIVE'
         WHEN a.product_name IN ('CTSK') THEN 'STOCK'
         WHEN upper(a.product_name_description) LIKE '%SPARK%' THEN 'CREATIVE'
         WHEN a.product_name_description LIKE '%- Pro%' THEN 'CREATIVE'
         WHEN upper(a.product_name_description) LIKE '%ACRO%SIGN%' OR upper(a.product_name_description) LIKE '%ADOBE%SIGN%' THEN 'SIGN'
         ELSE majorolpg
         END AS major_olpg
  FROM  (
     SELECT  product_name, 
             product_name_description FROM (
                    SELECT DISTINCT p.product_name,
                                   p.product_name_description,
                                   ROW_NUMBER() OVER (PARTITION BY product_name ORDER BY date_key DESC) as rowNum
                    FROM csmb.vw_ccm_pivot4_all p
                    WHERE p.event_source = 'SNAPSHOT'
                    AND p.date_key >= (SELECT min(date_key) FROM Ids_coredata.dim_date
                                        WHERE fiscal_yr >= 2021) -- fiscal year 21
             ) 
             WHERE rowNum = 1 -- Over time it seems the description of these products has changed - I will force it to pick one
  ) a
  LEFT JOIN (SELECT DISTINCT  CASE WHEN productcode = 'CPDF' THEN 'ACROBAT' ELSE outlookproductgroup END AS olpg, -- see ticket 6467 - for some reason this same code has 2 olpg - im forcing it to be one  
                              majorolpg1 as majorolpg,
                              productcode
          FROM b2b.uda_replicn_sf_corp_uda_vw_product2
  ) b 
  ON a.product_name = b.productcode
) 



-- COMMAND ----------

-- DBTITLE 1,Get the snapshots - Week Beginning
CREATE OR REPLACE TABLE b2b_tmp.arr_walk_pivot_weekly_balance AS 
SELECT  p.vip_contract,
        p.route_to_market,
        CASE WHEN coalesce(p.vip_contract,'')=''
             THEN p.subscription_account_guid
             ELSE p.vip_contract
        END AS contract_key, -- taken from b2b_arr 
        CASE WHEN p.STYPE = 'TM' AND p.vip_contract != '' AND UPPER(p.product_config) LIKE '%E' THEN 'EVIP'
            WHEN p.STYPE = 'TM' AND p.cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market= 'RESELLER' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market = 'ADOBE.COM/CC.COM' AND p.cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
            ELSE 'UNKNOWN'
        END AS contract_type,
        p.geo,
        p.ech_sub_id,
        p.ech_sub_name,
        p.ecc_customer_id,
        p.product_name,
        p.product_name_description,
        olpg.olpg,
        olpg.major_olpg,
        p.market_area,
        p.sales_district,
        p.market_segment,
        p.sales_document,
        p.fiscal_yr_desc,
        p.fiscal_yr_and_qtr_desc,
        p.fiscal_yr_and_per_desc,
        p.fiscal_yr_and_wk_desc,
        CAST(replace(p.contract_start_date_veda,'.','-') AS DATE) AS contract_start_date, 
        CAST(replace(p.contract_end_date_veda,'.','-') AS DATE) AS contract_end_date, 
        sum(p.fwk_begin_arr_cfx) AS fweek_beg_arr,
        sum(p.fwk_begin_active) AS fweek_beg_units,
        p.gtm_acct_segment AS dme_acct_segment,
        sops.fy24_proposal_segment_flag AS sops_segment
FROM csmb.vw_ccm_pivot4_all p 
LEFT JOIN b2b_tmp.pivot_product_to_olpg_mapping olpg
    ON p.product_name = olpg.product_name 
LEFT JOIN b2b_tmp.sops_segment_mapping_sub_distict_contract  sops 
    ON p.ech_sub_id = sops.ech_sub_id
    AND p.sales_district = sops.sales_district
    AND p.vip_contract = sops.contract_key
WHERE p.date_key >= (SELECT min(date_key) FROM Ids_coredata.dim_date
                     WHERE fiscal_yr >= 2021) -- fiscal year 21
AND p.event_source='SNAPSHOT'
AND p.cc_phone_vs_web <> 'WEB'
AND p.fwk_begin_arr_cfx <> 0 
AND coalesce(p.vip_contract,'') <> ''
GROUP BY ALL
ORDER BY p.fiscal_yr_and_wk_desc

-- COMMAND ----------

-- DBTITLE 1,Week Ending
-- Refresh underlying tables
REFRESH TABLE Ids_coredata.dim_date;
REFRESH TABLE CSMB_APP.fact_csmb_subscription_detail;
REFRESH TABLE CSMB_APP.exchange_rate_type_qtrly;
REFRESH TABLE CSMB_APP.subscription_params;
REFRESH TABLE CSMB_APP.acct_segment_activity_cutoff;
REFRESH TABLE CSMB_APP.acct_segment_realign_hist;
REFRESH TABLE CSMB_APP.dim_gtm_acct_hierarchy;
REFRESH TABLE CSMB_APP.gtm_projected_segmentation;
REFRESH TABLE CSMB_APP.dim_subscription;
REFRESH TABLE CSMB_APP.dim_gtm_acct_segment;
REFRESH csmb.vw_ccm_pivot4_all;

CREATE OR REPLACE TABLE b2b_tmp.arr_walk_pivot_ending_balance AS 
SELECT  p.vip_contract,
        p.route_to_market,
        CASE WHEN coalesce(p.vip_contract,'')=''
             THEN p.subscription_account_guid
             ELSE p.vip_contract
        END AS contract_key, -- taken from b2b_arr 
        CASE WHEN p.STYPE = 'TM' AND p.vip_contract != '' AND UPPER(p.product_config) LIKE '%E' THEN 'EVIP'
            WHEN p.STYPE = 'TM' AND p.cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market= 'RESELLER' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market = 'ADOBE.COM/CC.COM' AND p.cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
            ELSE 'UNKNOWN'
        END AS contract_type,
        p.geo,
        p.ech_sub_id,
        p.ecc_customer_id,
        p.product_name,
        p.product_name_description,
        p.sales_district,
        p.market_segment,
        p.sales_document,
        p.fiscal_yr_desc,
        p.fiscal_yr_and_qtr_desc,
        p.fiscal_yr_and_per_desc,
        p.fiscal_yr_and_wk_desc,
        CAST(replace(p.contract_start_date_veda,'.','-') AS DATE) AS contract_start_date, 
        CAST(replace(p.contract_end_date_veda,'.','-') AS DATE) AS contract_end_date, 
        sum(p.fwk_end_arr_cfx) AS fweek_end_arr,
        sum(fwk_end_active) AS fweek_end_units
FROM csmb.vw_ccm_pivot4_all p 
LEFT JOIN b2b_tmp.pivot_product_to_olpg_mapping olpg
    ON p.product_name = olpg.product_name 
WHERE p.date_key >= (SELECT min(date_key) FROM Ids_coredata.dim_date
                     WHERE fiscal_yr>= 2021) -- fiscal year 21
AND p.event_source='SNAPSHOT'
AND p.cc_phone_vs_web <> 'WEB'
AND p.fwk_end_arr_cfx <> 0 
AND coalesce(p.vip_contract,'') <> ''
GROUP BY ALL
ORDER BY p.fiscal_yr_and_wk_desc

-- COMMAND ----------

-- DBTITLE 1,Get the Events
-- Refresh underlying tables
REFRESH TABLE Ids_coredata.dim_date;
REFRESH TABLE CSMB_APP.fact_csmb_subscription_detail;
REFRESH TABLE CSMB_APP.exchange_rate_type_qtrly;
REFRESH TABLE CSMB_APP.subscription_params;
REFRESH TABLE CSMB_APP.acct_segment_activity_cutoff;
REFRESH TABLE CSMB_APP.acct_segment_realign_hist;
REFRESH TABLE CSMB_APP.dim_gtm_acct_hierarchy;
REFRESH TABLE CSMB_APP.gtm_projected_segmentation;
REFRESH TABLE CSMB_APP.dim_subscription;
REFRESH TABLE CSMB_APP.dim_gtm_acct_segment;
REFRESH csmb.vw_ccm_pivot4_all;

CREATE OR REPLACE TABLE b2b_tmp.arr_walk_pivot_weekly_events AS 
SELECT  p.vip_contract,
        p.route_to_market,
        CASE WHEN coalesce(p.vip_contract,'')=''
             THEN p.subscription_account_guid
             ELSE p.vip_contract
        END AS contract_key, -- taken from b2b_arr 
        CASE WHEN p.STYPE = 'TM' AND p.vip_contract != '' AND UPPER(p.product_config) LIKE '%E' THEN 'EVIP'
            WHEN p.STYPE = 'TM' AND p.cc_phone_vs_web = 'VIP-PHONE' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market= 'RESELLER' THEN 'VIP'
            WHEN p.STYPE = 'TM' AND p.route_to_market = 'ADOBE.COM/CC.COM' AND p.cc_phone_vs_web IN ('PHONE','WEB') THEN 'TEAM_DIRECT'
            ELSE 'UNKNOWN'
        END AS contract_type,
        p.geo,
        p.ech_sub_id,
        p.ech_sub_name,
        p.ecc_customer_id,
        p.product_name,
        p.product_name_description,
        p.sales_district,
        CAST(replace(p.contract_start_date_veda,'.','-') AS DATE) AS contract_start_date, 
        CAST(replace(p.contract_end_date_veda,'.','-') AS DATE) AS contract_end_date,
        p.market_area,
        p.market_segment,
        p.sales_document,
        p.fiscal_yr_desc,
        p.fiscal_yr_and_qtr_desc,
        p.fiscal_yr_and_per_desc,
        p.fiscal_yr_and_wk_desc,
        olpg.olpg,
        olpg.major_olpg,
        p.gtm_acct_segment AS dme_acct_segment,
        -- ARR Values
        sum(p.net_purchases_arr_cfx) AS net_purchases_arr_cfx,
        sum(p.gross_new_arr_cfx) AS gross_new_arr_cfx,
        sum(p.net_new_arr_cfx) AS net_new_arr_cfx,
        sum(p.migrated_from_arr_cfx) AS migrated_from_arr_cfx, 
        sum(p.migrated_to_arr_cfx) AS migrated_to_arr_cfx, 
        sum(p.gross_cancel_arr_cfx) AS gross_cancel_arr_cfx, 
        sum(p.net_cancelled_arr_cfx) AS net_cancelled_arr_cfx,
        sum(p.renewal_from_arr_cfx) AS renewal_from_arr_cfx, 
        sum(p.renewal_to_arr_cfx) AS renewal_to_arr_cfx,

        -- Units 
        sum(p.gross_cancellations) AS gross_cancellations_units,
        sum(p.gross_new_subs) AS gross_new_subs_units,
        sum(p.migrated_from) AS migrated_from_units,
        sum(p.migrated_to) AS migrated_to_units,
        sum(p.net_cancelled_subs) AS net_cancelled_subs_units,
        sum(p.net_new_subs) AS net_new_subs_units,
        sum(p.net_purchases) AS net_purchases_units,
        sum(p.renewal_from) AS renewal_from_units,
        sum(p.renewal_to) AS renewal_to_units

FROM csmb.vw_ccm_pivot4_all p 
LEFT JOIN b2b_tmp.pivot_product_to_olpg_mapping olpg
    ON p.product_name = olpg.product_name 
WHERE p.date_key >= (SELECT min(date_key) FROM Ids_coredata.dim_date
                     WHERE fiscal_yr>= 2021) -- fiscal year 21
AND p.event_source='EVENT'
AND p.cc_phone_vs_web <> 'WEB'
AND coalesce(p.vip_contract,'') <> ''
GROUP BY ALL
ORDER BY p.fiscal_yr_and_wk_desc


-- COMMAND ----------

-- DBTITLE 1,Combine into a report
CREATE OR REPLACE TABLE b2b_tmp.arr_walk_vip AS 
SELECT  date_add(current_date(),-1) AS as_of_date, -- confirm they want date -1
        bal.vip_contract, 
        bal.route_to_market, 
        bal.contract_key,
        bal.contract_type,
        bal.geo,
        bal.ech_sub_id,
        bal.ech_sub_name,
        bal.ecc_customer_id,
        bal.product_name,
        bal.product_name_description,
        bal.sales_district, 
        bal.market_area,
        bal.market_segment, 
        bal.sales_document,
        bal.fiscal_yr_desc,
        bal.fiscal_yr_and_qtr_desc, 
        bal.fiscal_yr_and_per_desc,
        bal.fiscal_yr_and_wk_desc,
        bal.olpg AS outlook_product_group,
        bal.major_olpg,
        bal.contract_start_date,
        bal.contract_end_date,
        bal.dme_acct_segment,
        bal.sops_segment,
        -- ARR 
        round(bal.fweek_beg_arr,2) AS fweek_begin_arr,
        round(endbal.fweek_end_arr,2) AS fweek_end_arr,
        round(coalesce((ev.gross_new_arr_cfx + ev.migrated_to_arr_cfx + ev.renewal_to_arr_cfx) - (ev.migrated_from_arr_cfx + ev.gross_cancel_arr_cfx + ev.renewal_from_arr_cfx) + bal.fweek_beg_arr,bal.fweek_beg_arr),2) AS current_week_arr,
        round(ev.gross_new_arr_cfx,2) AS gross_new_arr_cfx,
        round(ev.net_new_arr_cfx,2) AS net_new_arr_cfx,
        round(ev.net_purchases_arr_cfx) AS net_purchases_arr_cfx,
        round(ev.migrated_from_arr_cfx,2) AS migrated_from_arr_cfx, 
        round(ev.migrated_to_arr_cfx,2) AS migrated_to_arr_cfx, 
        round(ev.gross_cancel_arr_cfx,2) AS  gross_cancel_arr_cfx, 
        round(ev.net_cancelled_arr_cfx,2) AS net_cancelled_arr_cfx,
        round(ev.renewal_from_arr_cfx,2) AS renewal_from_arr_cfx, 
        round(ev.renewal_to_arr_cfx,2) AS renewal_to_arr_cfx,

        -- Quantity 
        round(bal.fweek_beg_units,2) AS fweek_beg_units,
        round(endbal.fweek_end_units,2) AS fweek_end_units,
        round(ev.gross_cancellations_units,2) AS gross_cancellations_units,
        round(ev.gross_cancellations_units,2) AS gross_new_subs_units,
        round(ev.migrated_from_units) AS migrated_from_units,
        round(ev.migrated_to_units) AS migrated_to_units,
        round(ev.net_cancelled_subs_units) AS net_cancelled_subs_units,
        round(ev.net_new_subs_units) AS net_new_subs_units,
        round(ev.net_purchases_units) AS net_purchases_units,
        round(ev.renewal_from_units) AS renewal_from_units,
        round(ev.renewal_to_units) AS renewal_to_units
FROM b2b_tmp.arr_walk_pivot_weekly_balance bal
LEFT JOIN b2b_tmp.arr_walk_pivot_ending_balance endbal
  ON bal.contract_key = endbal.contract_key 
  AND bal.fiscal_yr_and_wk_desc = endbal.fiscal_yr_and_wk_desc
  AND bal.ecc_customer_id = endbal.ecc_customer_id
  AND bal.sales_document = endbal.sales_document
  AND bal.product_name = endbal.product_name
  AND bal.contract_type = endbal.contract_type -- for some reason you can have the same product, sales document, customer, week but two different contract types
  AND bal.contract_start_date = endbal.contract_start_date
  AND bal.contract_end_date = endbal.contract_end_date
LEFT JOIN b2b_tmp.arr_walk_pivot_weekly_events ev
ON bal.contract_key = ev.contract_key 
  AND bal.fiscal_yr_and_wk_desc = ev.fiscal_yr_and_wk_desc
  AND bal.ecc_customer_id = ev.ecc_customer_id
  AND bal.sales_document = ev.sales_document
  AND bal.product_name = ev.product_name
  AND bal.contract_type = ev.contract_type
  AND bal.contract_start_date = ev.contract_start_date
  AND bal.contract_end_date = ev.contract_end_date
ORDER BY bal.contract_key,bal.fiscal_yr_and_wk_desc


-- COMMAND ----------

-- DBTITLE 1,Append New sales document events that happen within a week
-- So far we have taken all the sales documents that were there at the start of the week - and appended their closing balances / events 
-- but it is possible to have a sales document be new within a week - we need to capture these events too - they will always have an opening balance of 0 for that week 
-- as they never existed at the start of the week. 

-- note: See ticket: 6505 - it seems a sales document can be modified rather than any new sale having a new sales document - because of this i need to include products in the statement that identifies if something exists or not

INSERT INTO b2b_tmp.arr_walk_vip (
  as_of_date,
  vip_contract,
  route_to_market,
  contract_key,
  contract_type,
  geo,
  ech_sub_id,
  ech_sub_name,
  ecc_customer_id,
  product_name,
  product_name_description,
  sales_district,
  market_area,
  market_segment,
  sales_document,
  fiscal_yr_desc,
  fiscal_yr_and_qtr_desc,
  fiscal_yr_and_per_desc,
  fiscal_yr_and_wk_desc,
  outlook_product_group,
  major_olpg,
  contract_start_date,
  contract_end_date,
  dme_acct_segment,
  sops_segment,
  fweek_begin_arr,
  fweek_end_arr,
  current_week_arr,
  gross_new_arr_cfx,
  net_new_arr_cfx,
  net_purchases_arr_cfx,
  migrated_from_arr_cfx,
  migrated_to_arr_cfx,
  gross_cancel_arr_cfx,
  net_cancelled_arr_cfx,
  renewal_from_arr_cfx,
  renewal_to_arr_cfx,
  fweek_beg_units,
  fweek_end_units,
  gross_cancellations_units,
  gross_new_subs_units,
  migrated_from_units,
  migrated_to_units,
  net_cancelled_subs_units,
  net_new_subs_units,
  net_purchases_units,
  renewal_from_units,
  renewal_to_units
)
SELECT  date_add(current_date(),-1) AS as_of_date,
        e.vip_contract,
        e.route_to_market,
        e.contract_key,
        e.contract_type,
        e.geo,
        e.ech_sub_id,
        e.ech_sub_name,
        e.ecc_customer_id,
        e.product_name,
        e.product_name_description,
        e.sales_district,
        e.market_area,
        e.market_segment,
        e.sales_document,
        e.fiscal_yr_desc,
        e.fiscal_yr_and_qtr_desc,
        e.fiscal_yr_and_per_desc,
        e.fiscal_yr_and_wk_desc,
        olpg.olpg AS outlook_product_group,
        olpg.major_olpg,
        endbal.contract_start_date,
        endbal.contract_end_date,
        e.dme_acct_segment,
        sops.fy24_proposal_segment_flag,
        0 AS fweek_begin_arr,
        endbal.fweek_end_arr,
        round(coalesce((e.gross_new_arr_cfx + e.migrated_to_arr_cfx + e.renewal_to_arr_cfx) - (e.migrated_from_arr_cfx + e.gross_cancel_arr_cfx + e.renewal_from_arr_cfx),0),2) AS current_week_arr,
        e.gross_new_arr_cfx,
        e.net_new_arr_cfx,
        e.net_purchases_arr_cfx,
        e.migrated_from_arr_cfx,
        e.migrated_to_arr_cfx,
        e.gross_cancel_arr_cfx,
        e.net_cancelled_arr_cfx,
        e.renewal_from_arr_cfx,
        e.renewal_to_arr_cfx,
        0 AS fweek_beg_units,
        endbal.fweek_end_units,
        e.gross_cancellations_units,
        e.gross_new_subs_units,
        e.migrated_from_units,
        e.migrated_to_units,
        e.net_cancelled_subs_units,
        e.net_new_subs_units,
        e.net_purchases_units,
        e.renewal_from_units,
        e.renewal_to_units
FROM b2b_tmp.arr_walk_pivot_weekly_events e 
LEFT JOIN b2b_tmp.pivot_product_to_olpg_mapping olpg
    ON e.product_name = olpg.product_name 
LEFT JOIN b2b_tmp.arr_walk_pivot_ending_balance endbal
   ON e.contract_key = endbal.contract_key 
  AND e.fiscal_yr_and_wk_desc = endbal.fiscal_yr_and_wk_desc
  AND e.ecc_customer_id = endbal.ecc_customer_id
  AND e.sales_document = endbal.sales_document
  AND e.product_name = endbal.product_name
  AND e.contract_start_date = endbal.contract_start_date
  AND e.contract_end_date = endbal.contract_end_date
LEFT JOIN b2b_tmp.sops_segment_mapping_sub_distict_contract sops 
    ON e.ech_sub_id = sops.ech_sub_id
    AND e.sales_district = sops.sales_district
    AND e.vip_contract = sops.contract_key
-- I only want sales order numbers for a given week where they dont exist at the start of the week
-- this means they are new sales orders that took place in that week
WHERE concat(coalesce(e.sales_document,''),'|',coalesce(e.product_name,''),'|',coalesce(e.contract_start_date,''),'|',coalesce(e.contract_end_date,''),'|',coalesce(e.fiscal_yr_and_wk_desc,''))
NOT IN ( 
  SELECT concat(coalesce(sales_document,''),'|',coalesce(product_name,''),'|',coalesce(contract_start_date,''),'|',coalesce(contract_end_date,''),'|',coalesce(fiscal_yr_and_wk_desc,'') ) 
  FROM b2b_tmp.arr_walk_pivot_weekly_balance 
)


-- COMMAND ----------

-- MAGIC %md
-- MAGIC #ETLA 

-- COMMAND ----------

CREATE OR REPLACE TABLE b2b_tmp.etla_opening_balances AS 
SELECT  e.vipcontract,
        e.sellinchanneldesc AS route_to_market,
        regexp_replace(e.enduser,'^0+(?!$)','') AS contract_key, -- from b2b.arr
        CASE WHEN e.olpg = 'SIGN' AND e.businesstype != 'ETLA' AND e.etlaseattype LIKE '%ETLA%' THEN 'ETLA'
        WHEN e.olpg = 'SIGN' AND e.businesstype = 'SIGN' THEN 'SIGN_SAP_SA'
        ELSE businesstype
        END AS contract_type,
        e.geo,
        e.echsubid,
        e.echsubname,
        e.productname,
        e.productnamedescription,
        e.salesdistrict,
        e.marketarea,
        e.marketsegment,
        e.salesdocument,
        e.dealregistrationid,
        d.fiscal_yr,
        d.fiscal_yr_and_qtr_desc,
        d.fiscal_yr_and_per_desc,
        d.fiscal_yr_and_wk_desc,
        CASE WHEN coalesce(upper(e.olpg),'')  = '' THEN 'UNKNOWN' ELSE upper(e.olpg) END  AS outlook_product_group,
        CASE WHEN upper(olpg) LIKE '%ACROBAT%' THEN 'ACROBAT'
             WHEN upper(olpg) IN (  'CREATIVE',
                                    'CCE PRO PLUS',
                                    'CCE STOCK',
                                    'EXPRESS',
                                    'EXPRESS FIREFLY',
                                    'SUBSTANCE',
                                    'CCE PRO FIREFLY',
                                    'SUPPORT PLAN CC',
                                    'FRAME.IO') then 'CREATIVE'
            WHEN upper(olpg) IN ('PPBU','COLDFUSION','CONNECT','CAPTIVATE PRIME') THEN'PPBU'
            ELSE upper(olpg)
        END AS  major_olpg,
        e.contractstartdate,
        e.contractenddate,
        e.maxcontractenddatekey,
        e.dmegtmsegment AS dme_acct_segment,
        sops.fy24_proposal_segment_flag  AS sops_segment,
        SUM(e.arr) AS fweek_begin_arr, -- Ticket 6020 - use ARR as the field to show both opening and closing
        SUM(e.contractquantity) AS fweek_begin_quantity
FROM b2b.uda_uda_finance_arr_vw_entarr e -- get ETLA balances for each financial period
LEFT JOIN b2b_tmp.sops_segment_mapping_sub_distict  sops 
    ON e.echsubid = sops.ech_sub_id
    AND e.salesdistrict = sops.sales_district
INNER JOIN ( 
              SELECT DISTINCT date_key,
                              date_date,
                              fiscal_yr,
                              fiscal_yr_and_qtr_desc,
                              fiscal_yr_and_per_desc,
                              fiscal_yr_and_wk_desc
              FROM Ids_coredata.dim_date
              WHERE fiscal_yr >= 2021
              AND fiscal_day_in_wk = 1 
) d
ON d.date_date = e.DateDate
WHERE e.SnapshotType = 'D' -- I will take the daily snapshot for the first day in each fiscal wk
GROUP BY  e.vipcontract,
          e.sellinchanneldesc,
          regexp_replace(e.enduser,'^0+(?!$)',''),
          CASE  WHEN e.olpg = 'SIGN' AND e.businesstype != 'ETLA' AND e.etlaseattype LIKE '%ETLA%' THEN 'ETLA'
                WHEN e.olpg = 'SIGN' AND e.businesstype = 'SIGN' THEN 'SIGN_SAP_SA'
                ELSE businesstype END,
          e.geo,
          e.echsubid,
          e.echsubname,
          e.productname,
          e.productnamedescription,
          e.salesdistrict,
          e.marketsegment,
          e.marketarea,
          e.salesdocument,
          e.dealregistrationid,
          d.fiscal_yr,
          d.fiscal_yr_and_qtr_desc,
          d.fiscal_yr_and_per_desc, 
          d.fiscal_yr_and_wk_desc,
          e.maxcontractenddatekey,
          upper(e.olpg),
          CASE WHEN upper(olpg) LIKE '%ACROBAT%' THEN 'ACROBAT'
             WHEN upper(olpg) IN (  'CREATIVE',
                                    'CCE PRO PLUS',
                                    'CCE STOCK',
                                    'EXPRESS',
                                    'EXPRESS FIREFLY',
                                    'SUBSTANCE',
                                    'CCE PRO FIREFLY',
                                    'SUPPORT PLAN CC',
                                    'FRAME.IO') then 'CREATIVE'
            WHEN upper(olpg) IN ('PPBU','COLDFUSION','CONNECT','CAPTIVATE PRIME') THEN'PPBU'
            ELSE upper(olpg)
            END,
          e.contractstartdate,
          e.contractenddate,
          e.dmegtmsegment,
          sops.fy24_proposal_segment_flag                       
ORDER BY d.fiscal_yr_and_wk_desc 



-- COMMAND ----------

-- DBTITLE 1,Ticket 6020 - Use ARR column to provide the ending week balance (rather than the following weeks opening)
CREATE OR REPLACE TABLE b2b_tmp.etla_ending_balances AS 
SELECT  e.vipcontract,
        e.sellinchanneldesc AS route_to_market,
        regexp_replace(e.enduser,'^0+(?!$)','') AS contract_key, -- from b2b.arr
        CASE WHEN e.olpg = 'SIGN' AND e.businesstype != 'ETLA' AND e.etlaseattype LIKE '%ETLA%' THEN 'ETLA'
        WHEN e.olpg = 'SIGN' AND e.businesstype = 'SIGN' THEN 'SIGN_SAP_SA'
        ELSE businesstype
        END AS contract_type,
        e.geo,
        e.echsubid,
        e.echsubname,
        e.productname,
        e.productnamedescription,
        e.salesdistrict,
        e.marketarea,
        e.marketsegment,
        e.salesdocument,
        e.dealregistrationid,
        d.fiscal_yr,
        d.fiscal_yr_and_qtr_desc,
        d.fiscal_yr_and_per_desc,
        d.fiscal_yr_and_wk_desc,
        CASE WHEN coalesce(upper(e.olpg),'')  = '' THEN 'UNKNOWN' ELSE upper(e.olpg) END  AS outlook_product_group,
        CASE WHEN upper(olpg) LIKE '%ACROBAT%' THEN 'ACROBAT'
             WHEN upper(olpg) IN (  'CREATIVE',
                                    'CCE PRO PLUS',
                                    'CCE STOCK',
                                    'EXPRESS',
                                    'EXPRESS FIREFLY',
                                    'SUBSTANCE',
                                    'CCE PRO FIREFLY',
                                    'SUPPORT PLAN CC',
                                    'FRAME.IO') then 'CREATIVE'
            WHEN upper(olpg) IN ('PPBU','COLDFUSION','CONNECT','CAPTIVATE PRIME') THEN'PPBU'
            ELSE upper(olpg)
        END AS  major_olpg,
        e.contractstartdate,
        e.contractenddate,
        e.maxcontractenddatekey,
        e.dmegtmsegment AS dme_acct_segment,
        sops.fy24_proposal_segment_flag  AS sops_segment,
        SUM(e.arr) AS fweek_end_arr, -- Ticket 6020 - use ARR as the field to show both opening and closing
        SUM(e.contractquantity) AS fweek_end_quantity
FROM b2b.uda_uda_finance_arr_vw_entarr e -- get ETLA balances for each financial period
LEFT JOIN b2b_tmp.sops_segment_mapping_sub_distict  sops 
    ON e.echsubid = sops.ech_sub_id
    AND e.salesdistrict = sops.sales_district
INNER JOIN ( 
              SELECT DISTINCT date_key,
                              date_date,
                              fiscal_yr,
                              fiscal_yr_and_qtr_desc,
                              fiscal_yr_and_per_desc,
                              fiscal_yr_and_wk_desc
              FROM Ids_coredata.dim_date
              WHERE fiscal_yr >= 2021
              AND fiscal_day_in_wk = 7 -- End of fiscal week 
) d
ON d.date_date = e.DateDate
WHERE e.SnapshotType = 'D' -- I will take the daily snapshot for the last day in each fiscal wk
GROUP BY ALL                      
ORDER BY d.fiscal_yr_and_wk_desc 



-- COMMAND ----------

-- DBTITLE 1,Create tmp etla arr walk
CREATE OR REPLACE TABLE b2b_tmp.arr_walk_etla AS 
SELECT  date_add(current_date(),-1) AS as_of_date,  -- confirm they want date -1
        o.vipcontract AS vip_contract,
        o.route_to_market,
        o.contract_key,
        o.contract_type,
        o.geo,
        o.echsubid AS ech_sub_id,
        o.echsubname AS ech_sub_name,
        o.productname AS product_name,
        o.productnamedescription AS product_name_description,
        o.salesdistrict AS sales_district, 
        o.marketarea AS market_area,
        o.marketsegment AS market_segment,
        o.salesdocument AS sales_document,
        o.dealregistrationid AS deal_registration_id, 
        o.fiscal_yr,
        o.fiscal_yr_and_qtr_desc,
        o.fiscal_yr_and_per_desc,
        o.fiscal_yr_and_wk_desc,
        o.outlook_product_group,
        o.major_olpg,
        o.contractstartdate AS contract_start_date, 
        o.contractenddate AS contract_end_date,
        o.maxcontractenddatekey AS max_contract_end_date_key,
        o.dme_acct_segment,
        o.sops_segment,
        o.fweek_begin_arr,
        o.fweek_begin_quantity,
        e.fweek_end_quantity,
        e.fweek_end_arr
FROM  b2b_tmp.etla_opening_balances o
LEFT JOIN b2b_tmp.etla_ending_balances e
 ON o.contract_key = e.contract_key 
 AND o.productname = e.productname 
 AND o.salesdocument = e.salesdocument
 AND o.fiscal_yr_and_wk_desc = e.fiscal_yr_and_wk_desc
 AND o.contractstartdate = e.contractstartdate
 AND o.contractenddate = e.contractenddate
 AND o.outlook_product_group = e.outlook_product_group -- There are cases where the same product code in ent arr has 2 distinct product groups - must be data quality, but this could lead to a 1-many join and over-inflated ARR
ORDER BY o.fiscal_yr_and_per_desc

-- COMMAND ----------

-- DBTITLE 1,Insert and mid week new sales order numbers
-- If you were to make a new sale within a week - it wouldnt have its sales order number present at the start of the week opening
-- thefore it would arrive a week later 

INSERT INTO b2b_tmp.arr_walk_etla (
as_of_date,
vip_contract,
route_to_market,
contract_key,
contract_type,
geo,
ech_sub_id,
ech_sub_name,
product_name,
product_name_description,
sales_district,
market_area,
market_segment,
sales_document,
deal_registration_id,
fiscal_yr,
fiscal_yr_and_qtr_desc,
fiscal_yr_and_per_desc,
fiscal_yr_and_wk_desc,
outlook_product_group,
major_olpg,
contract_start_date,
contract_end_date,
max_contract_end_date_key,
dme_acct_segment,
sops_segment,
fweek_begin_arr,
fweek_begin_quantity,
fweek_end_quantity,
fweek_end_arr
)

SELECT date_add(current_date(),-1) AS as_of_date,
       e.vipcontract AS vip_contract,
      e.route_to_market,
      e.contract_key,
      e.contract_type,
      e.geo,
      e.echsubid AS ech_sub_id,
      e.echsubname AS ech_sub_name,
      e.productname AS product_name,
      e.productnamedescription AS product_name_description,
      e.salesdistrict AS sales_district,
      e.marketarea AS market_area,
      e.marketsegment AS market_segment,
      e.salesdocument AS sales_document,
      e.dealregistrationid AS deal_registration_id, 
      e.fiscal_yr,
      e.fiscal_yr_and_qtr_desc,
      e.fiscal_yr_and_per_desc,
      e.fiscal_yr_and_wk_desc,
      e.outlook_product_group,
      e.major_olpg,
      e.contractstartdate AS contract_start_date,
      e.contractenddate AS contract_end_date,
      e.maxcontractenddatekey ASmax_contract_end_date_key,
      e.dme_acct_segment,
      e.sops_segment,
      0 AS fweek_begin_arr, -- They never existed at the start of the week so they have to be 0
      0 AS fweek_begin_quantity, -- They never existed at the start of the week so they have to be 0
      e.fweek_end_quantity,
      e.fweek_end_arr
FROM b2b_tmp.etla_ending_balances e 
WHERE concat(coalesce(e.salesdocument,''),'|',coalesce(e.productname,''),'|',coalesce(e.contractstartdate,''),'|',coalesce(e.contractenddate,''),'|',coalesce(e.fiscal_yr_and_wk_desc,'')) NOT IN ( 
  SELECT concat(coalesce(salesdocument,''),'|',coalesce(productname,''),'|',coalesce(contractstartdate,''),'|',coalesce(contractenddate,''),'|',coalesce(fiscal_yr_and_wk_desc,'')) 
  FROM b2b_tmp.etla_opening_balances) -- you have a sales document/product/week combination that wasnt present at the start in the opening balances ( It seems changes to terms / quantities etc.. DOES NOT always result in a new sales order) - see ticket 6505

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Ticket 6120 - Adding Opportunity IDs to ARR walk
-- MAGIC - Please read this ticket - the completeness of this data is woeful - but I was told "it needs to be done" - any figures using these value are going to be massively incomplete. 
-- MAGIC - The view is by publishing this in reports people will correct it... rather than just losing trust in the reporting (interesting strategy)

-- COMMAND ----------

-- Create a VIP lookup table - contract, quarter - its possible to have multiple opportunities within the same contract in the same quarter so I rank them; 
-- Note: I can see multiple contracts within the vip_ea_clp_agreementnumber field - Stephen wills said not to attempt to parse them though
CREATE OR REPLACE TEMPORARY VIEW contract_to_opp_mapping AS 
SELECT DISTINCT opp.dealregistrationid AS deal_registration_id, 
                opp.fulloptyid AS full_opty_id, 
                opp.closedate,
                d.fiscal_yr_and_qtr_desc AS opportunity_closing_qtr,
                opp.vip_ea_clp_agreementnumber, 
                ROW_NUMBER() OVER( PARTITION BY opp.vip_ea_clp_agreementnumber, d.fiscal_yr_and_qtr_desc ORDER BY opp.closedate DESC, opp.dealregistrationid DESC ) as ranking
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
INNER JOIN Ids_coredata.dim_date d 
  ON opp.closedate = d.date_date
WHERE opp.as_of_date  = (SELECT max(as_of_date) FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunity )
AND lower(opp.stage) LIKE '%booked%'
AND opp.CloseDate >= cast('2021-01-01' AS DATE)
AND salesopsreconciled = TRUE AND opp.dmeineligible = FALSE
AND coalesce(replace(opp.vip_ea_clp_agreementnumber,'-',''),'') <> '' -- No point to include those which cant join (this is the vast majority) see the ticket 6120


-- COMMAND ----------

-- DBTITLE 1,If you do want to try and parse this field - look at this example - you can change it from Markdown to SQL 
-- MAGIC %md
-- MAGIC  SELECT DISTINCT  fulloptyid,
-- MAGIC                   vip_contract_original,
-- MAGIC                   explode(array_remove(contracts,'')) as contracts_cleaned
-- MAGIC  FROM (
-- MAGIC  SELECT DISTINCT opp.fulloptyid,
-- MAGIC                  opp.dealregistrationid,
-- MAGIC                  opp.vip_ea_clp_agreementnumber as vip_contract_original,
-- MAGIC                      split(
-- MAGIC                      regexp_replace(
-- MAGIC                              
-- MAGIC                                  trim(CASE WHEN substring(opp.vip_ea_clp_agreementnumber,-1) IN ('|',',','+','#',';',':','-','\\','/','.')
-- MAGIC                                                           THEN substring(opp.vip_ea_clp_agreementnumber,1,(length(opp.vip_ea_clp_agreementnumber)-1))
-- MAGIC                                                           ELSE opp.vip_ea_clp_agreementnumber END),
-- MAGIC                                  '[,]{2,}',','),
-- MAGIC                          ',') as contracts          
-- MAGIC          FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity opp
-- MAGIC          WHERE opp.as_of_date  = (SELECT max(as_of_date) FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunity )
-- MAGIC           AND lower(opp.stage) LIKE '%booked%'
-- MAGIC           AND opp.CloseDate >= cast('2021-01-01' AS DATE)
-- MAGIC           AND salesopsreconciled = TRUE AND opp.dmeineligible = FALSE
-- MAGIC           AND coalesce(replace(opp.vip_ea_clp_agreementnumber,'-',''),'') <> '' -- No point to include those which cant join (this is the vast majority) see the ticket 6120
-- MAGIC  )
-- MAGIC  WHERE fulloptyid='0065Y00001UlETiQAN'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Combine ETLA And Pivot ARR walk

-- COMMAND ----------


DROP TABLE IF EXISTS b2b.b2b_arr_walk;
CREATE TABLE  b2b.b2b_arr_walk AS 
SELECT  v.as_of_date,
        v.vip_contract,
        v.route_to_market,
        v.contract_key,
        v.contract_type,
        v.geo,
        v.ech_sub_id,
        v.ech_sub_name,
        v.ecc_customer_id,
        v.product_name,
        v.product_name_description,
        v.sales_district,
        v.market_area,
        v.market_segment,
        v.sales_document,
        distinct_opps.deal_registration_id AS deal_registration_id,
        distinct_opps.full_opty_id AS full_opty_id,
        CASE WHEN duplicate_opps.vip_ea_clp_agreementnumber IS NOT NULL THEN 'Y'
             WHEN distinct_opps.full_opty_id IS NOT NULL AND duplicate_opps.vip_ea_clp_agreementnumber IS NULL THEN 'N'
             ELSE '-' END AS multiple_opp_flag,
        CASE WHEN distinct_opps.deal_registration_id IS NOT NULL THEN 1 ELSE 0 END AS rep_driven_flag,  
        v.fiscal_yr_desc,
        v.fiscal_yr_and_qtr_desc,
        v.fiscal_yr_and_per_desc,
        v.fiscal_yr_and_wk_desc,
        v.outlook_product_group,
        v.major_olpg,
        v.dme_acct_segment,
        v.sops_segment,
        v.contract_start_date,
        v.contract_end_date,
        NULL AS max_contract_end_date_key,
        coalesce(round(v.fweek_begin_arr,2),0) AS fweek_begin_arr,
        coalesce(round(v.fweek_end_arr,2),0) AS fweek_end_arr,
        round(v.gross_new_arr_cfx,2) AS gross_new_arr_cfx,
        round(v.net_new_arr_cfx,2) AS net_new_arr_cfx,
        round(v.net_purchases_arr_cfx,2) AS net_purchases_arr_cfx,
        round(v.migrated_from_arr_cfx,2) AS migrated_from_arr_cfx,
        round(v.migrated_to_arr_cfx,2) AS migrated_to_arr_cfx,
        round(v.gross_cancel_arr_cfx,2) AS gross_cancel_arr_cfx,
        round(v.net_cancelled_arr_cfx,2) AS net_cancelled_arr_cfx,
        round(v.renewal_from_arr_cfx,2) AS renewal_from_arr_cfx,
        round(v.renewal_to_arr_cfx,2) AS renewal_to_arr_cfx,

         -- Quantity 
        coalesce(v.fweek_beg_units,0) AS fweek_beg_units,
        coalesce(v.fweek_end_units,0) AS fweek_end_units,
        v.gross_cancellations_units,
        v.gross_new_subs_units,
        v.migrated_from_units,
        v.migrated_to_units,
        v.net_cancelled_subs_units,
        v.net_new_subs_units,
        v.net_purchases_units,
        v.renewal_from_units,
        v.renewal_to_units
FROM b2b_tmp.arr_walk_vip v
-- ticket 6120 
LEFT JOIN ( SELECT opportunity_closing_qtr,
                   vip_ea_clp_agreementnumber,
                   deal_registration_id,
                   full_opty_id
            FROM contract_to_opp_mapping 
            WHERE ranking = 1 -- I dont want duplicates

        )  distinct_opps -- ticket 6120 -- get the opportunitiies 
ON v.contract_key = distinct_opps.vip_ea_clp_agreementnumber
AND v.fiscal_yr_and_qtr_desc = distinct_opps.opportunity_closing_qtr
AND v.sops_segment IN ('CORP T1','CORP T2') -- God only knows why but they want to limit this pile to CORP
LEFT JOIN ( SELECT DISTINCT opportunity_closing_qtr, vip_ea_clp_agreementnumber
            FROM contract_to_opp_mapping 
            WHERE ranking > 1 -- These are all the contracts which contain multiple opportunities 
        ) duplicate_opps
ON v.contract_key = duplicate_opps.vip_ea_clp_agreementnumber
AND v.fiscal_yr_and_qtr_desc = duplicate_opps.opportunity_closing_qtr
AND v.sops_segment IN ('CORP T1','CORP T2') -- God only knows why but they want to limit this pile to CORP
WHERE upper(outlook_product_group) NOT IN ('PPBU','CAPTIVATE PRIME','OTHER','DPS','CONNECT','DALP','UNMAPPED','UNKNOWN') -- requested in ticket 5789
UNION ALL 
SELECT  e.as_of_date,
        NULL AS vip_contract, -- Abhijeet Gupta said he doesnt want this field populating to ETLAS 19/12/2023
        e.route_to_market,
        e.contract_key,
        e.contract_type,
        e.geo,
        e.ech_sub_id,
        e.ech_sub_name,
        NULL AS ecc_customer_id, -- Awaiting confirmation as to what they want populated here
        e.product_name,
        e.product_name_description,
        e.sales_district,
        e.market_area,
        e.market_segment,
        e.sales_document,
        e.deal_registration_id,
        sfdc.fulloptyid AS full_opty_id,
        'N' AS multiple_opp_flag,
        1 AS rep_driven_flag,
        e.fiscal_yr,
        e.fiscal_yr_and_qtr_desc,
        e.fiscal_yr_and_per_desc,
        e.fiscal_yr_and_wk_desc,
        e.outlook_product_group,
        e.major_olpg,
        e.dme_acct_segment,
        e.sops_segment,
        e.contract_start_date,
        e.contract_end_date,
        e.max_contract_end_date_key,
        coalesce(round(e.fweek_begin_arr,2),0) AS fweek_begin_arr,
        coalesce(round(e.fweek_end_arr,2),0) AS fweek_end_arr,
        NULL AS gross_new_arr_cfx,
        NULL AS net_new_arr_cfx,
        NULL AS net_purchases_arr_cfx,
        NULL AS migrated_from_arr_cfx,
        NULL AS migrated_to_arr_cfx,
        NULL AS gross_cancel_arr_cfx,
        NULL AS net_cancelled_arr_cfx,
        NULL AS renewal_from_arr_cfx,
        NULL AS renewal_to_arr_cfx,
        coalesce(e.fweek_begin_quantity,0) AS fweek_begin_quantity,
        coalesce(e.fweek_end_quantity,0) AS fweek_end_quantity,
        NULL AS gross_cancellations_units,
        NULL AS gross_new_subs_units,
        NULL AS migrated_from_units,
        NULL AS migrated_to_units,
        NULL AS net_cancelled_subs_units,
        NULL AS net_new_subs_units,
        NULL AS net_purchases_units,
        NULL AS renewal_from_units,
        NULL AS renewal_to_units
FROM  b2b_tmp.arr_walk_etla e 
LEFT JOIN  ( SELECT dealregistrationid,
                    fulloptyid 
             FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity
             WHERE as_of_date = (SELECT max(as_of_date) FROM  b2b.uda_replicn_sf_corp_uda_vw_opportunity )) sfdc
ON sfdc.dealregistrationid = e.deal_registration_id
WHERE upper(outlook_product_group) NOT IN ('PPBU','CAPTIVATE PRIME','OTHER','DPS','CONNECT','DALP','UNMAPPED','UNKNOWN') -- requested in ticket 5789

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #DEBUG
