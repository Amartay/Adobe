-- Databricks notebook source
-- DBTITLE 1,DEDUPE MEETINGS EVENT DATA
/*
MEETINGS EVENT DATA - DEDUPE

Collapses the VW_EVENT data into single meeting instances per activityid. Should also collapse rows if the same meeting has been pushed back
as there will be 2 instances of the meeting existing in the system with the same SUBJECT details

https://adobe.lightning.force.com/lightning/r/Opportunity/0065Y00001jReeoQAC/view
*/
refresh table b2b.uda_replicn_sf_corp_uda_vw_event;
refresh table b2b.l2_sa_sfdc_pipeline_core;

drop table if exists b2b_tmp.l2_sa_meetings_dedupe;
create table b2b_tmp.l2_sa_meetings_dedupe as 
 select relatedtoid as full_opty_id, max(meetingchangedtimepeopleai) as dedupeFilter, startdatetime as meetingTime01, upper(`subject`) as subject01, activityid as meeting_id, upper(meetingstatuspeopleai) as meetingstatuspeopleai
  from b2b.uda_replicn_sf_corp_uda_vw_event
  where 
  upper(meetingstatuspeopleai) = 'COMPLETED'
  and relatedtoid in (select distinct full_opty_id from b2b.l2_sa_sfdc_pipeline_core)
  and as_of_date in (select max(as_of_date) from b2b.uda_replicn_sf_corp_uda_vw_event)
  group by relatedtoid, upper(`subject`), activityid, meetingstatuspeopleai, startdatetime

UNION all

 select relatedtoid as full_opty_id, max(meetingchangedtimepeopleai) as dedupeFilter, startdatetime as meetingTime01, upper(`subject`) as subject01, activityid as meeting_id, upper(meetingstatuspeopleai) as meetingstatuspeopleai
  from b2b.uda_replicn_sf_corp_uda_vw_event
  where 
  upper(meetingstatuspeopleai) = 'SCHEDULED'
  and relatedtoid in (select distinct full_opty_id from b2b.l2_sa_sfdc_pipeline_core)
  and as_of_date in (select max(as_of_date) from b2b.uda_replicn_sf_corp_uda_vw_event)
  group by relatedtoid, upper(`subject`), activityid, meetingstatuspeopleai, startdatetime

UNION ALL

 select relatedtoid as full_opty_id, max(meetingchangedtimepeopleai) as dedupeFilter, startdatetime as meetingTime01, upper(`subject`) as subject01, activityid as meeting_id, upper(meetingstatuspeopleai) as meetingstatuspeopleai
  from b2b.uda_replicn_sf_corp_uda_vw_event
  where 
  upper(meetingstatuspeopleai) = 'RESCHEDULED'
  and relatedtoid in (select distinct full_opty_id from b2b.l2_sa_sfdc_pipeline_core)
  and as_of_date in (select max(as_of_date) from b2b.uda_replicn_sf_corp_uda_vw_event)
  group by relatedtoid, upper(`subject`), activityid, meetingstatuspeopleai, startdatetime
  ;

-- COMMAND ----------

-- DBTITLE 1,FLATTEN REP DATA
refresh table b2b.l2_sub_id_opp_rep_map;
refresh table b2b.dme_customer_profile;

drop table if exists b2b_tmp.l2_sa_rep_segments_dcp_flat;
create table b2b_tmp.l2_sa_rep_segments_dcp_flat as 
  select 
  source01.coverage_sales_rep_id as sales_rep_id
  , source01.coverage_sales_rep_name as sales_rep_name
  , source01.coverage_sales_rep_ldap as sales_rep_ldap
  , case when sum(source01.rep_segment_dcp_abd_named) > 0 then 'Y' else 'N' end as rep_segment_dcp_abd_named
  , case when sum(source01.rep_segment_dcp_corp_t1) > 0 then 'Y' else 'N' end as rep_segment_dcp_corp_t1
  , case when sum(source01.rep_segment_dcp_corp_t2) > 0 then 'Y' else 'N' end as rep_segment_dcp_corp_t2
  , case when sum(source01.rep_segment_dcp_csmb) > 0 then 'Y' else 'N' end as rep_segment_dcp_csmb
  , case when sum(source01.rep_segment_dcp_edu) > 0 then 'Y' else 'N' end as rep_segment_dcp_edu
  , case when sum(source01.rep_segment_dcp_enterprise) > 0 then 'Y' else 'N' end as rep_segment_dcp_enterprise
  , case when sum(source01.rep_segment_dcp_latam) > 0 then 'Y' else 'N' end as rep_segment_dcp_latam

  from (
    select 
    rep01.*
    , dcp01.*

    /* As there are cases where a single person has been assigned to different Sub_ID / Sales Districts under different
      segments, this bit of logic allows us to transpose and collapse the data into 1 row per person

      It will show a single line output with Y/N flags for each person and each segment */
    , case when dcp01.fy24_proposal_segment_flag = 'ABD Named' then 1 else 0 end as rep_segment_dcp_abd_named
    , case when dcp01.fy24_proposal_segment_flag = 'CORP T1' then 1 else 0 end as rep_segment_dcp_corp_t1
    , case when dcp01.fy24_proposal_segment_flag = 'CORP T2' then 1 else 0 end as rep_segment_dcp_corp_t2
    , case when dcp01.fy24_proposal_segment_flag = 'CSMB' then 1 else 0 end as rep_segment_dcp_csmb
    , case when dcp01.fy24_proposal_segment_flag = 'EDU' then 1 else 0 end as rep_segment_dcp_edu
    , case when dcp01.fy24_proposal_segment_flag = 'Enterprise' then 1 else 0 end as rep_segment_dcp_enterprise
    , case when dcp01.fy24_proposal_segment_flag = 'LATAM' then 1 else 0 end as rep_segment_dcp_latam


    /* Get list of people from L2 Rep Mapping table */
    from (
      select distinct main01.ech_sub_id, main01.sales_district, main01.coverage_sales_rep_id, main01.coverage_sales_rep_name, 
      main01.coverage_sales_rep_ldap, main01.named_flag
      from b2b.l2_sub_id_opp_rep_map main01
      where main01.assignment_source = 'DCP_Coverage' 
    ) rep01


    /* Pull in the FY24 Segmentation according to DCP source table */
    left outer join (
      select fy24_proposal_segment_flag, ech_sub_id, sales_district 
      from b2b.dme_customer_profile 
      where ech_sub_id is not null and sales_district is not null group by all
    ) dcp01 on dcp01.ech_sub_id = rep01.ech_sub_id and dcp01.sales_district = rep01.sales_district
  ) source01

  group by all
  order by source01.coverage_sales_rep_name
  ;

-- COMMAND ----------

-- DBTITLE 1,L2 MEETINGS MAIN CODE
refresh table Ids_coredata.dim_date;
refresh table b2b.uda_replicn_sf_corp_uda_vw_event;
refresh table b2b.l2_sa_sfdc_pipeline_core;
refresh table b2b.uda_replicn_sf_corp_uda_vw_user;
refresh table b2b.uda_replicn_sf_corp_uda_vw_account;
refresh table b2b_tmp.l2_sa_meetings_dedupe;


drop table if exists b2b.l2_sa_meetings;
create table b2b.l2_sa_meetings as

select distinct * from (
select 
date01.fiscal_yr_and_qtr_desc
, date01.fiscal_wk_and_qtr_desc
, date01.fiscal_qtr_name 
, date01.fiscal_weeks_in_yr 
, date01.fiscal_wk_in_qtr
, opp01.geo
, dcp01.fy24_proposal_segment_flag as acct_segmentation
, repflat01.rep_segment_dcp_abd_named
, repflat01.rep_segment_dcp_corp_t1
, repflat01.rep_segment_dcp_corp_t2
, repflat01.rep_segment_dcp_csmb
, repflat01.rep_segment_dcp_edu
, repflat01.rep_segment_dcp_enterprise
, repflat01.rep_segment_dcp_latam
, dcp01.named_flag as acct_named_flag
, cast(event01.meetingtime01 as date) as meeting_date
, event01.subject01 as meeting_subject
, event02.duration
, event02.activitytype
, opp01.accountname as acc_name
, opp01.acc_id
, event02.activityid as meeting_id
, event02.meetingstatuspeopleai as meeting_status
, event02.participantspeopleai as participants_peopleai
, event01.full_opty_id
, opp01.deal_reg_id
, opp01.current_stage
, opp01.current_close_year_qtr
, rep01.coverage_role_type
, case when upper(rep01.coverage_role_type) = 'ACCOUNT MANAGER' then 'ACCOUNT MANAGER'
    when upper(rep01.coverage_role_type) = 'PRODUCT SPECIALIST' 
      and upper(rep01.anaplan_product_group) like '%ACROBAT%SIGN%' then 'DC PRODUCT SPECIALIST'
    when upper(rep01.coverage_role_type) = 'PRODUCT SPECIALIST' 
      and upper(rep01.anaplan_product_group) like '%CREATIVE%' then 'CC PRODUCT SPECIALIST'
    else rep01.coverage_role_type
    end as cloud_specialists
, rep01.coverage_sales_rep_id
, rep01.coverage_sales_rep_ldap
, rep01.coverage_sales_rep_name
, user01.user_email
, rep01.emp_level2_mgr_name as flm_name -- level 2, manager name above individual
, rep01.emp_level3_mgr_name as slm_name -- level 3, manager name above individual
, rep01.emp_level4_mgr_name as segment_leader -- level 4, manager name above individual
, chorus01.ENGAGEMENT_TYPE
, chorus01.duration_mins as chorus_duration_minutes
, case when chorus01.ENGAGEMENT_TYPE is null then 'N' else 'Y' end as present_in_chorus
, case when upper(event02.meetingstatuspeopleai) = 'COMPLETED'
    and chorus01.ENGAGEMENT_TYPE is null then 'Y'
    else 'N'
    end as check_with_rep_flag
, case when upper(event02.meetingstatuspeopleai) in ('SCHEDULED','RESCHEDULED')
    and cast(event01.meetingtime01 as date) > current_date()
    then 'Y' else 'N' 
    end as upcoming_meeting_flag
, case when chorus01.ENGAGEMENT_TYPE is not null and chorus01.duration > 10 then 'Y'
    else 'N' end as completed_flag


/*
Main code to filter VW_EVENT data to only data where Opportunity exists in Pipeline Core, meetings are Completed and aggregation
has been done to reduce row duplication
*/
from b2b_tmp.l2_sa_meetings_dedupe event01

/* Pulls in more details for the aggregated dataset from VW_EVENT source */
left outer join (
  select activityid, assignedtoid, meetingstatuspeopleai
  , case when `subject` like '[People.ai | Meeting]%' then substr(`subject`, 23, len(`subject`))
      when `subject` like '[People.ai | R Meeting]%' then substr(`subject`, 25, len(`subject`))
      else `subject`
      end as subject_trimmed
  , date_trunc('HOUR', meetingchangedtimepeopleai) as trimmed_meeting
  , duration, activitytype, participantspeopleai
  from b2b.uda_replicn_sf_corp_uda_vw_event
  where as_of_date in (select max(as_of_date) from b2b.uda_replicn_sf_corp_uda_vw_event)
) event02 on event01.meeting_id = event02.activityid

/* Add User related data for Rep Name - need to bounce from EVENT to USER to REP_MAP to get Anaplan Rep Details */
left outer join (
  select userid, fullname1 as full_name, alias as ldap, employeenumber, trim(email) as user_email
  from b2b.uda_replicn_sf_corp_uda_vw_user 
  where as_of_date in (select max(as_of_date) from b2b.uda_replicn_sf_corp_uda_vw_user)
  ) user01 on user01.userid = event02.assignedtoid

left outer join (
  select coverage_sales_rep_id, coverage_sales_rep_name, coverage_sales_rep_ldap, coverage_role_type, emp_level2_mgr_name
  , emp_level3_mgr_name, emp_level4_mgr_name, anaplan_product_group
  from b2b.l2_sub_id_opp_rep_map group by all
  ) rep01 on rep01.coverage_sales_rep_id = user01.employeenumber


/* Add Opportunity level data */
left outer join (
  select core01.full_opty_id, core01.deal_reg_id, core01.account_id, acc01.accountname, acc01.id as acc_id, core01.geo
  , core01.acct_dme_acct_group, acc01.standardizedsubid, acc01.salesdistrict, core01.current_stage, core01.current_close_year_qtr
  from b2b.l2_sa_sfdc_pipeline_core core01
  left outer join (select * from b2b.uda_replicn_sf_corp_uda_vw_account where as_of_date in (select max(as_of_date) from b2b.uda_replicn_sf_corp_uda_vw_account)) acc01 on core01.account_id = acc01.id
) opp01 on opp01.full_opty_id = event01.full_opty_id

left outer join (select * from Ids_coredata.dim_date) date01 on cast(date01.calendar_date as date) = cast(event01.meetingtime01 as date)

/* Pull in the FY24 Segmentation according to DCP source table */
left outer join (
  select fy24_proposal_segment_flag, ech_sub_id, sales_district, named_flag from b2b.dme_customer_profile 
  where ech_sub_id is not null and sales_district is not null group by all
) dcp01 on dcp01.ech_sub_id = opp01.standardizedsubid and dcp01.sales_district = opp01.salesdistrict


/* Connect in Chorus data where possible 
Chorus overlap with SFDC Event is not great, so this JOIN is just to show where a matching record can be found.
The connection uses SUBJECT, DATETIME of Meeting,  SFDC ACCOUNT_ID and the email match between both tables for staff member
 - there was a request to use the "assignedto" field which is present in VW_EVENT, but a matching field in CHORUS is not available.

This was discussed and agreed with FHH BI Team
*/
left outer join (
  select distinct date_trunc('HOUR', dateadd(hour,-7,cast(cast(start_time as float) as timestamp))) as trimmed_startdatetime
  , START_DATE, SUBJECT, ENGAGEMENT_TYPE, CALL_ID, DURATION, round(duration/60, 2) as duration_mins, EXTERNAL_ID, cp01.participant_email
  from b2b_phones.chorus_calls cc01
  left outer join (select call_id as cp_call_id, trim(PARTICIPANT_EMAIL) as participant_email from b2b_phones.chorus_calls_participants where PARTICIPANT_EMAIL like '%adobe.com') 
    cp01 on cp01.cp_call_id = cc01.CALL_ID
  ) chorus01 on chorus01.SUBJECT = event02.subject_trimmed
      and chorus01.trimmed_startdatetime = event02.trimmed_meeting
      and chorus01.PARTICIPANT_EMAIL = user01.user_email
      and chorus01.EXTERNAL_ID = opp01.acc_id


/* Pulls in flattened Rep Segmentation data - this is because although a Rep can be assigned to CORP T1, they may also
  be connected to meetings with non-CORP T1 clients.
  This is a flattened view of Rep-to-Segment as there are multiple instances where a Rep is assigned to multiple segments
  EG Rep ID = 211724 who is assigned to 4 different segments.
 */
left outer join (select * from b2b_tmp.l2_sa_rep_segments_dcp_flat) repflat01 
  on repflat01.sales_rep_id = user01.employeenumber

)

group by all
