-- Databricks notebook source
-- MAGIC %md
-- MAGIC Code Provided by Jai Bhatraju with the instruction to run this daily. 

-- COMMAND ----------

DROP TABLE IF EXISTS b2b.l2_sa_sales_capacity;

-- COMMAND ----------

-- DBTITLE 1,Create Table
CREATE TABLE b2b.l2_sa_sales_capacity AS 
SELECT
  employee_name,
  case
    when employee_name like '% PH User%'
    or employee_name like '% PH USER%' then 'TBH'
    When employee_name like '%EMEA% POOL%' then 'TBH'
    When employee_name like '%, POOL%' then 'TBH'
    When employee_name like 'GHOST %' then 'TBH'
    else employee_name
  end as employee,
  employee_id,
  employee_ldap,
  position_id,
  c.emp_geo as Geo,
  b.geo_group,
  c.hire_date,
  b.position_creation_date,
  b.position_type,
  b.has_coverage_flag,
  COALESCE(c.mgr_name, b.mgr_employee_name) as mgr_name,
  c.level3_mgr_name,
  c.level4_mgr_name,
  c.level5_mgr_name,
  c.level6_mgr_name,
  c.level7_mgr_name,
  c.termination_date,
  case
    when c.termination_date is not null then '0'
    else '1'
  end as Is_Active,
  DATE_DIFF(
    CAST(c.hire_date AS date),
    date '2023-03-04'
  ) as Q1_Days_in_Role,
  case
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-03-04'
    ) between 0
    and 90 then '25%'
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-03-04'
    ) between 90
    and 180 then '50%'
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-03-04'
    ) between 180
    and 270 then '75%'
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-03-04'
    ) > 270 then '100%'
    else null
  end as Q1_Ramp_Level,
  DATE_DIFF(
    CAST(c.hire_date AS date),
    date '2023-06-03'
  ) as Q2_Days_in_Role,
  case
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-06-03'
    ) between 0
    and 90 then '25%'
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-06-03'
    ) between 90
    and 180 then '50%'
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-06-03'
    ) between 180
    and 270 then '75%'
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-06-03'
    ) > 270 then '100%'
    else null
  end as Q2_Ramp_Level,
  DATE_DIFF(
    CAST(c.hire_date AS date),
    date '2023-09-02'
  ) as Q3_Days_in_Role,
  case
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-09-02'
    ) between 0
    and 90 then '25%'
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-09-02'
    ) between 90
    and 180 then '50%'
    when DATE_DIFF(
      CAST(c.hire_date AS date),
      date '2023-09-02'
    ) between 180
    and 270 then '75%'
    when DATE_DIFF(
      
      CAST(c.hire_date AS date),
      date '2023-09-02'
    ) > 270 then '100%'
    else null
  end as Q3_Ramp_Level,
  DATE_DIFF(
    
    CAST(c.hire_date AS date),
    date '2023-12-02'
  ) as Q4_Days_in_Role,
  case
    when DATE_DIFF(
      
      CAST(c.hire_date AS date),
      date '2023-12-02'
    ) between 0
    and 90 then '25%'
    when DATE_DIFF(
      
      CAST(c.hire_date AS date),
      date '2023-12-02'
    ) between 90
    and 180 then '50%'
    when DATE_DIFF(
      
      CAST(c.hire_date AS date),
      date '2023-12-02'
    ) between 180
    and 270 then '75%'
    when DATE_DIFF(
      
      CAST(c.hire_date AS date),
      date '2023-12-02'
    ) > 270 then '100%'
    else null
  end as Q4_Ramp_Level,
  case
    when sub_territory like 'C&B EMEA FIELD SALES PSS%' then 'Mid-Market' --Q
    when sub_territory like 'C&B EMEA FIELD SALES%' then 'Mid-Market'
    when sub_territory like 'C&B AMERICAS FIELD SALES LATAM%' then 'Mid-Market' -- Q
    when sub_territory like '%C&B DME GROWTH FRAME AMER ENT&CORP AM%'
    and Role_type = 'SAM' then 'Legacy MM'
    when sub_territory like '% EDU %' then 'Education'
    when sub_territory like '% CORP %' then 'Corporate'
    when sub_territory like '%ENTERPRISE %'
    or sub_territory like '% ENT%' then 'Enterprise'
    when sub_territory like 'C&B AMERICAS DME GROWTH%' then 'Mid-Market'
    when sub_territory like '%MM %' then 'SMB'
    when sub_territory like '%DOC CLOUD %' then 'Mid-Market'
    else sub_territory
  end as SOPS_Segment,
  case
    when sub_territory like '%C&B DME GROWTH FRAME AMER ENT&CORP AM%' then 'Account Manager' -- SAM in Frame are Account managers
    when sub_territory like '%C&B AMERICAS DME GROWTH FRAME ENTERPRISE AM%' then 'Account Manager'
    when sub_territory like 'C&B AMERICAS DME GROWTH DOC CLOUD PSM%' then 'DC PSM'
    when sub_territory like 'C&B EDU AMERICAS%'
    and role_type = 'ACCOUNT MANAGER' then 'Account Executive'
    when sub_territory like 'C&B EMEA FIELD SALES%'
    and role_type = 'ACCOUNT MANAGER' then 'Account Executive(PSS)'
    when sub_territory like 'C&B EDU AMERICAS%'
    and role_type = 'PRODUCT SPECIALIST' then 'DC Specialist'
    when sub_territory like 'C&B EMEA FIELD SALES PSS%' then 'Account Executive(PSS)' --Q
    when sub_territory like 'C&B AMERICAS FIELD SALES LATAM%' then 'Account Manager'
    when sub_territory like 'C&B AMERICAS DME GROWTH 3D PSM%' then '3D PSM' --Q  C&B AMERICAS  DME GROWTH 3D AE , ALL Product specilists are AE
    when sub_territory like 'C&B AMERICAS DME GROWTH 3D ENT PS' then 'Account Executive'
    when sub_territory like '% AE%'
    or sub_territory like '%CORP AE'
    or sub_territory like '%3D AE' then 'Account Executive'
    else Role_type
  end as SOPS_Role,
  b.sub_territory,
  role_type,
  b.product_group,
  region,
  sub_region,
  b.territory
from
  b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing b
  INNER JOIN (
    select
      max(as_of_date) as_of_date
    from
      b2b.sops_tap_prod_eu_dbo_vw_report_ta_staffing
  ) a ON b.as_of_date = a.as_of_date
  Left join b2b.sops_tap_prod_eu_dbo_vw_td_employee c on b.employee_id = c.emp_id -- left join (select * from  b2b.sops_tap_prod_eu_dbo_vw_td_employee where termination_date >'2022-12-04') t on t.mgr_name = b.mgr_employee_name
where
  --b.region ='C&B DME GROWTH'
  area = 'DME'
  and b.role_type <> 'SALES MANAGER'
  and (
    b.sub_territory like '% AE%'
    or b.sub_territory like '% AM %'
    or sub_territory like 'C&B EDU %'
    or sub_territory like 'C&B EMEA FIELD SALES%'
    or sub_territory like 'C&B AMERICAS FIELD SALES%'
    or sub_territory like 'C&B AMERICAS DME GROWTH%'
    or sub_territory like 'C&B DME GROWTH FRAME AMER%'
    or (
      sub_territory like 'SEA DME CSMB - TAM%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'SEA DME CSMB - EDU%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'INDIA DME CSMB%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'ANZ DME MM / SMB` / CAM%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'KOREA DME CSMB MIDMARKET - COMM%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'KOREA DME CSMB CHANNEL & MIDMARKET PUB SEC%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'KOREA DME ENT%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'GREATER CHINA - CHINA DME - SOUTH CSMB%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'GREATER CHINA - CHINA DME - EAST CSMB%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'GREATER CHINA - CHINA DME - NORTH & WEST CSMB%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'GREATER CHINA - HKT DME CSMB%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'GREATER CHINA - HKT DME ENT%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
    or (
      sub_territory like 'INDIA DME ENT%'
      and b.role_type = 'ACCOUNT MANAGER'
    )
  )