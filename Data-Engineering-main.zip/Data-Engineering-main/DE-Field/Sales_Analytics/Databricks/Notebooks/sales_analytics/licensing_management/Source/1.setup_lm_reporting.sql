-- Databricks notebook source
-- MAGIC %md
-- MAGIC This notebook performs the set up tasks for LM reporting based on the spreadsheets uploaded, which are provided by LM  
-- MAGIC
-- MAGIC This makes a clear distinction between the pulling together and enrichment of data provided from the LM team to the report generation itself 
-- MAGIC
-- MAGIC
-- MAGIC - Creation of a Product Mapping Table
-- MAGIC - Combine spreadsheets uploaded to DBX for Small and Medium Companies
-- MAGIC - Enrich the uploaded spreadsheets with contracts LM have "forgotten to Add" to the spreadsheets (also known as 'discovered contracts')
-- MAGIC - Create Merged version of the spreadsheets (discovered contracts + provided ones)
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Refresh Metadata for tables we will use
-- MAGIC %sql
-- MAGIC REFRESH TABLE ocf_analytics.dim_contract_jem;
-- MAGIC REFRESH TABLE ocf_analytics.dim_user_lvt_profile;
-- MAGIC REFRESH TABLE ocf.dim_contract;
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Create ETLA Product -> Segment Mapping Table
DROP TABLE IF EXISTS b2b_tmp.etla_dccc_prod_segment_mapping;
CREATE TABLE b2b_tmp.etla_dccc_prod_segment_mapping (product_code string, product_desc string, segment string);
INSERT INTO b2b_tmp.etla_dccc_prod_segment_mapping (product_code, product_desc, segment)
VALUES ('ACRO','Acrobat','ACROBAT DC'),
('AEFT','After Effects','TEAM'),
('AICY','Adobe InCopy','TEAM'),
('AIS','InDesign Server','TEAM'),
('APAP','ACROBAT PRO SUBSCRPT','ACROBAT DC'),
('APAS','Acrobat PRO SF','ACROBAT DC'),
('APSF','Acrobat Pro Adv PDF','ACROBAT DC'),
('ASIG','Acrobat Pro Adv SF','ACROBAT DC'),
('ASPK','Adobe Spark','TEAM'),
('AUDT','Audition','TEAM'),
('CAUS','CC All Apps - Pro','TEAM'),
('CCEX','Adobe Express','TEAM'),
('CCLE','Creative Cloud','TEAM'),
('CCSB','CC Desktop Apps','TEAM'),
('CSAD','Audition - Pro','TEAM'),
('CSAE','After Effects - Pro','TEAM'),
('CSAM','Animate - Pro','TEAM'),
('CSDM','Dimension - Pro','TEAM'),
('CSDW','Dreamweaver - Pro','TEAM'),
('CSIC','InCopy - Pro','TEAM'),
('CSID','InDesign - Pro','TEAM'),
('CSIL','Illustrator - Pro','TEAM'),
('CSLR','Lightroom - Pro','TEAM'),
('CSPH','Photoshop - Pro','TEAM'),
('CSPM','Premiere Rush - Pro','TEAM'),
('CSPP','Premiere Pro - Pro','TEAM'),
('CSXD','Adobe XD - Pro','TEAM'),
('CTSK','CCT & Stock','TEAM'),
('DRWV','Dreamweaver','TEAM'),
('EDGE','Edge Animate','TEAM'),
('ESHR','Adobe Dimension CC','TEAM'),
('FLPR','Animate / Flash Pro','TEAM'),
('FRSC','Adobe Fresco','TEAM'),
('IDSN','InDesign','TEAM'),
('ILST','Illustrator','TEAM'),
('LCCC','Lightroom w Classic','TEAM'),
('LPES','Lightroom CC','TEAM'),
('MUSE','Adobe Muse','TEAM'),
('PHSP','Photoshop','TEAM'),
('PPRO','Adobe Premiere Pro','TEAM'),
('PRLD','Adobe Prelude','TEAM'),
('RUSH','Adobe Premiere RUSH','TEAM'),
('SBST','Substance 3D','TEAM'),
('SHDW','Adobe Edge Inspect','TEAM'),
('SPGD','Adobe SpeedGrade','TEAM'),
('SPRK','Adobe XD','TEAM'),
('SRC','Substance 3D Assets','TEAM'),
('STAM','Master Collection','TEAM'),
('ECHE','Acrobat Sign for bus','SIGN'),
('ECHG','Acrobat Sign for ent','SIGN'),
('ECHP','Acrobat Sign','SIGN')
;



-- COMMAND ----------

-- DBTITLE 1,Combine EMEA and USA files for Small Companies
CREATE OR REPLACE VIEW emea_and_usa_small_Companies AS

SELECT  'EMEA' as originating_spreadsheet,
        'BSA' as originating_tab,
        'SMALL' AS lm_program,
         Country,
         CASE WHEN VIP = '' THEN NULL ELSE VIP END AS VIP,
         CASE WHEN Domain='' THEN NULL ELSE Domain END AS Domain,
         CASE WHEN Subscription_Account_GUID='' THEN NULL ELSE Subscription_Account_GUID END AS Subscription_Account_GUID,
         Company_Name,
         Notified_Date,
         Notified_Date_Plus_90_Days,
         Opportunity
FROM b2b.l1_sa_manual_lm_notified_list_small_companies

UNION ALL 

SELECT  'AMER' as originating_spreadsheet,
         'BSA' as originating_tab,
         'SMALL' AS lm_program,
         Country,
         CASE WHEN VIP = '' THEN NULL ELSE VIP END AS VIP,
         CASE WHEN Domain='' THEN NULL ELSE Domain END AS Domain,
         CASE WHEN Subscription_Account_GUID='' THEN NULL ELSE Subscription_Account_GUID END AS Subscription_Account_GUID,
         Company_Name,
         Notified_Date,
         Notified_Date_Plus_90_Days,
         Opportunity
FROM b2b.l1_sa_manual_lm_notified_list_small_companies_usa

UNION ALL 

-- Added in ticket 4109
SELECT  'EMEA' as originating_spreadsheet,
         'INTERNAL SCALE' AS originating_tab,
         'INTERNAL SCALE' AS lm_program,
         Country,
         CASE WHEN VIP = '' THEN NULL ELSE VIP END AS VIP,
         CASE WHEN Domain='' THEN NULL ELSE Domain END AS Domain,
         CASE WHEN Subscription_Account_GUID='' THEN NULL ELSE Subscription_Account_GUID END AS Subscription_Account_GUID,
         Company_Name,
         Notified_Date,
         Notified_Date_Plus_90_Days,
         Opportunity
FROM b2b.l1_sa_manual_lm_notified_list_internal_scale

UNION ALL 

SELECT  'AMER' as originating_spreadsheet,
         'INTERNAL SCALE' AS originating_tab,
         'INTERNAL SCALE' AS lm_program,
         Country,
         CASE WHEN VIP = '' THEN NULL ELSE VIP END AS VIP,
         CASE WHEN Domain='' THEN NULL ELSE Domain END AS Domain,
         CASE WHEN Subscription_Account_GUID='' THEN NULL ELSE Subscription_Account_GUID END AS Subscription_Account_GUID,
         Company_Name,
         Notified_Date,
         Notified_Date_Plus_90_Days,
         Opportunity
FROM b2b.l1_sa_manual_lm_notified_list_internal_scale_usa


-- COMMAND ----------

-- DBTITLE 1,Combine EMEA and USA files for Medium Companies
CREATE OR REPLACE VIEW emea_and_usa_medium_Companies AS

SELECT  'EMEA' as originating_spreadsheet,
        'DELOITTE' as originating_tab,
        upper(LM_Program) AS LM_Program,
        upper(LM_Engagement_Name) AS LM_Engagement_Name,
        Account_Name,
        CASE WHEN Contract_ID = '' THEN NULL ELSE Contract_ID END AS Contract_ID,
        CASE WHEN Domain = '' THEN NULL ELSE Domain END AS Domain,
        CASE WHEN Subscription_Account_GUID = '' THEN NULL ELSE Subscription_Account_GUID END AS Subscription_Account_GUID,
        Notified_Date,
        Notified_Date_Plus_90_Days,
        On_Hold_Start_Date,
        -- Those on hold dates with a start and no end are ongoing - we need to use todays date 
        CASE WHEN On_Hold_Start_Date IS NOT NULL AND On_Hold_End_Date IS NULL THEN current_date() ELSE On_Hold_End_Date END AS On_Hold_End_Date,
        CASE WHEN On_Hold_Start_Date IS NOT NULL AND On_Hold_End_Date IS NULL THEN datediff(current_date(), On_Hold_Start_Date) ELSE On_Hold_Duration END AS On_Hold_Duration,
        coalesce(upper(Renewal_Health_Check),'NO') AS Renewal_Health_Check,
        coalesce(upper(Opportunity_Only_Review),'NO') AS Opportunity_Only_Review
FROM b2b.l1_sa_manual_lm_notified_list_medium_companies
WHERE LM_Engagement_Name IS NOT NULL -- snaplogic appears to import some null rows

UNION ALL 

SELECT 'AMER' as originating_spreadsheet,
        'DELOITTE' as originating_tab,
        upper(LM_Program) AS LM_Program,
        upper(LM_Engagement_Name) AS LM_Engagement_Name,
        Account_Name,
        CASE WHEN Contract_ID = '' THEN NULL ELSE Contract_ID END AS Contract_ID,
        CASE WHEN Domain = '' THEN NULL ELSE Domain END AS Domain,
        CASE WHEN Subscription_Account_GUID = '' THEN NULL ELSE Subscription_Account_GUID END AS Subscription_Account_GUID,
        Notified_Date,
        Notified_Date_Plus_90_Days,
        On_Hold_Start_Date,
        CASE WHEN On_Hold_Start_Date IS NOT NULL AND On_Hold_End_Date IS NULL THEN current_date() ELSE On_Hold_End_Date END AS On_Hold_End_Date,
        CASE WHEN On_Hold_Start_Date IS NOT NULL AND On_Hold_End_Date IS NULL THEN datediff(current_date(), On_Hold_Start_Date) ELSE On_Hold_Duration END AS On_Hold_Duration,
        coalesce(upper(Renewal_Health_Check),'NO') AS Renewal_Health_Check,
        coalesce(upper(Opportunity_Only_Review),'NO') AS Opportunity_Only_Review
FROM b2b.l1_sa_manual_lm_notified_list_medium_companies_usa
WHERE LM_Engagement_Name IS NOT NULL -- snaplogic appears to import some null rows

-- COMMAND ----------



-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Explanation of why I do this contract mapping to domains 
-- MAGIC
-- MAGIC The way this business process works is a bit strange;
-- MAGIC
-- MAGIC There is a spreadsheet provided from licence mangagement with 2 tabs (small and medium companies) This spreadsheet contains contract Ids and domain names for companies under LM engagement.
-- MAGIC However it is possible there are contracts LM do not know about related to the domains - the issue here is pivot4all doesnt populate the domains properly - because of this a process needs to take place in this notebook
-- MAGIC whereby domain / contract mapping is identified - any historic contracts for a domain are appended to the input spreadsheets so the evaluation takes place on any contract associated to the domains and any contract on the input sheets
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Find Additional Contracts that Need to be Added to LM Spreadsheets due to their domain
-- MAGIC %sql
-- MAGIC DROP TABLE IF EXISTS b2b_tmp.contracts_not_on_input_spreadsheet;
-- MAGIC CREATE TABLE b2b_tmp.contracts_not_on_input_spreadsheet AS 
-- MAGIC SELECT DISTINCT lower(split(lvt.pers_email, '@')[1]) AS domain,
-- MAGIC                 coalesce(jem.contract_id, c.contract_id) AS contract_id,
-- MAGIC                 upper(file.originating_spreadsheet) AS originating_spreadsheet
-- MAGIC FROM ocf_analytics.dim_user_lvt_profile lvt
-- MAGIC INNER JOIN (
-- MAGIC             -- I only want domains that are given to us from Paul
-- MAGIC             SELECT lower(domain) AS domain, 
-- MAGIC                   lower(originating_spreadsheet) AS originating_spreadsheet
-- MAGIC             FROM  emea_and_usa_medium_Companies
-- MAGIC             WHERE lower(Domain) NOT IN (SELECT lower(email_domain) FROM b2b_tmp.domain_exclusion_list)
-- MAGIC             UNION 
-- MAGIC             SELECT lower(domain), 
-- MAGIC                    lower(originating_spreadsheet) AS originating_spreadsheet
-- MAGIC             FROM  emea_and_usa_small_Companies
-- MAGIC             WHERE lower(domain) NOT IN (SELECT lower(email_domain) FROM b2b_tmp.domain_exclusion_list)
-- MAGIC ) file 
-- MAGIC ON lower(file.domain) = lower(split(lvt.pers_email, '@')[1]) 
-- MAGIC LEFT JOIN ocf_analytics.dim_contract_jem jem
-- MAGIC       ON jem.enrollee_id = lvt.user_guid
-- MAGIC       -- Added for EMEA / USA Split
-- MAGIC       AND lower(file.originating_spreadsheet) = lower(jem.geo)
-- MAGIC
-- MAGIC LEFT JOIN ocf.dim_contract c
-- MAGIC       ON c.enrollee_id = lvt.user_guid
-- MAGIC       -- Added for EMEA / USA Split
-- MAGIC       AND lower(file.originating_spreadsheet) = lower(c.geo)
-- MAGIC
-- MAGIC -- We only need to add contract IDs where they do not exist in pauls spreadsheets
-- MAGIC LEFT JOIN ( 
-- MAGIC             SELECT contract_id AS contract_id
-- MAGIC             FROM  emea_and_usa_medium_Companies
-- MAGIC             UNION 
-- MAGIC             SELECT vip AS contract_id
-- MAGIC             FROM  emea_and_usa_small_Companies
-- MAGIC ) initialContracts
-- MAGIC ON initialContracts.contract_id = coalesce(jem.contract_id, c.contract_id)
-- MAGIC
-- MAGIC WHERE lower(jem.contract_type) <> 'direct_individual'
-- MAGIC AND  length(lvt.pers_email) > 0
-- MAGIC AND  lvt.pers_email not in('<UNKNOWN>','UNKNOWN','UNASSIGNED','NOT ASSIGNED','N/A','BLANK','MISSING','NULL','DELETED-ORG','DELETED ORG','DELETED','')
-- MAGIC AND initialContracts.contract_id IS NULL 
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Medium Companies - Create Merged Version of the Input Spreadsheet - combining discovered contracts with those provided 
-- MAGIC %sql
-- MAGIC DROP TABLE IF EXISTS b2b_tmp.medium_companies_combined;
-- MAGIC CREATE TABLE b2b_tmp.medium_companies_combined AS
-- MAGIC
-- MAGIC SELECT DISTINCT   upper(originating_spreadsheet) AS originating_spreadsheet,
-- MAGIC                   upper(originating_tab) AS originating_tab,
-- MAGIC                   'Provided by LM' AS record_type,
-- MAGIC                   LM_Program,
-- MAGIC                   LM_engagement_name,
-- MAGIC                   upper(account_name) AS account_name,
-- MAGIC                   contract_id, 
-- MAGIC                   upper(domain) AS domain,
-- MAGIC                   upper(Subscription_Account_GUID) AS  subscription_account_guid,
-- MAGIC                   Notified_Date,
-- MAGIC                   Notified_Date_Plus_90_Days,
-- MAGIC                   On_Hold_Start_Date,
-- MAGIC                   On_Hold_End_Date,
-- MAGIC                   On_Hold_Duration,
-- MAGIC                   Renewal_Health_Check,
-- MAGIC                   Opportunity_Only_Review
-- MAGIC FROM emea_and_usa_medium_Companies
-- MAGIC WHERE lower(coalesce(Domain,'')) NOT IN (SELECT lower(email_domain) FROM b2b_tmp.domain_exclusion_list)
-- MAGIC
-- MAGIC UNION
-- MAGIC
-- MAGIC -- Discovered Contracts
-- MAGIC SELECT DISTINCT   upper(new.originating_spreadsheet) AS originating_spreadsheet,
-- MAGIC                   upper(med.originating_tab) AS originating_tab,
-- MAGIC                   'Discovered Contract' AS record_type,
-- MAGIC                   med.LM_Program,
-- MAGIC                   med.LM_engagement_name,
-- MAGIC                   upper(med.account_name) AS account_name,
-- MAGIC                   new.contract_id, 
-- MAGIC                   upper(new.domain) AS domain,
-- MAGIC                   upper(med.Subscription_Account_GUID) AS subscription_account_guid,
-- MAGIC                   med.Notified_Date,
-- MAGIC                   med.Notified_Date_Plus_90_Days,
-- MAGIC                   med.On_Hold_Start_Date,
-- MAGIC                   med.On_Hold_End_Date,
-- MAGIC                   med.On_Hold_Duration,
-- MAGIC                   med.Renewal_Health_Check,
-- MAGIC                   med.Opportunity_Only_Review
-- MAGIC FROM b2b_tmp.contracts_not_on_input_spreadsheet new 
-- MAGIC INNER JOIN emea_and_usa_medium_Companies med
-- MAGIC   ON lower(med.Domain) = lower(new.domain)
-- MAGIC   AND lower(med.originating_spreadsheet) = lower(new.originating_spreadsheet)

-- COMMAND ----------

-- DBTITLE 1,Small Companies - Create Merged Version of the Input Spreadsheet - combining discovered contracts with those provided 
-- MAGIC %sql
-- MAGIC DROP TABLE IF EXISTS b2b_tmp.small_companies_combined;
-- MAGIC CREATE TABLE b2b_tmp.small_companies_combined AS
-- MAGIC
-- MAGIC SELECT DISTINCT   upper(originating_spreadsheet) AS originating_spreadsheet,
-- MAGIC                   upper(originating_tab) AS originating_tab,
-- MAGIC                   upper(LM_Program) AS lm_program,
-- MAGIC                   'Provided by LM' AS record_type,
-- MAGIC                   country,
-- MAGIC                   VIP, 
-- MAGIC                   upper(Domain) AS domain,
-- MAGIC                   upper(Company_Name) AS Company_Name,
-- MAGIC                   upper(Subscription_Account_GUID) AS subscription_account_guid,
-- MAGIC                   Notified_Date,
-- MAGIC                   Notified_Date_Plus_90_Days,
-- MAGIC                   Opportunity
-- MAGIC FROM emea_and_usa_small_Companies
-- MAGIC WHERE lower(coalesce(Domain,'')) NOT IN (SELECT lower(email_domain) FROM b2b_tmp.domain_exclusion_list)
-- MAGIC
-- MAGIC UNION
-- MAGIC
-- MAGIC -- Discovered Contracts
-- MAGIC SELECT DISTINCT   upper(new.originating_spreadsheet) AS originating_spreadsheet,
-- MAGIC                   upper(sm.originating_tab) AS originating_tab,
-- MAGIC                   upper(LM_Program) AS lm_program,
-- MAGIC                   'Discovered Contract' AS record_type,
-- MAGIC                   sm.country,
-- MAGIC                   new.contract_id,
-- MAGIC                   upper(new.domain) as domain, 
-- MAGIC                   upper(sm.Company_Name) AS Company_Name,
-- MAGIC                   upper(sm.Subscription_Account_GUID) AS subscription_account_guid,
-- MAGIC                   sm.Notified_Date,
-- MAGIC                   sm.Notified_Date_Plus_90_Days,
-- MAGIC                   sm.Opportunity
-- MAGIC FROM b2b_tmp.contracts_not_on_input_spreadsheet new 
-- MAGIC INNER JOIN emea_and_usa_small_Companies sm
-- MAGIC   ON lower(sm.Domain) = lower(new.domain)
-- MAGIC   AND lower(sm.originating_spreadsheet) = lower(new.originating_spreadsheet)