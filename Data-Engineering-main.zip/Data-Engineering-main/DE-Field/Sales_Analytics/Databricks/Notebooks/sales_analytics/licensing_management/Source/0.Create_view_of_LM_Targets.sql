-- Databricks notebook source
-- MAGIC %md
-- MAGIC There are two excel files that contain the sales targets for EMEA / AMER LM. To make life easier for the Power BI developers I make a view that combines them. It only needs to be run once as is not part of the job

-- COMMAND ----------

-- DBTITLE 1,Create View of Combined LM Targets
DROP VIEW IF EXISTS b2b.l1_sa_manual_lm_fact_targets;
CREATE VIEW b2b.l1_sa_manual_lm_fact_targets AS 
SELECT 'EMEA' as source_spreadsheet, 
        fw,
        first_day_of_fw,
        weekly_phasing,
        gross_new_arr_qrf,
        `nn_arr_(cc/dc_commerical_field)` AS `nn_arr_(cc/dc_commerical_field)` ,
        `nn_arr_(cc_commerical_field)` AS `nn_arr_(cc_commerical_field)`,
        `nn_arr_(dc_commerical_field)` AS `nn_arr_(dc_commerical_field)`,
        `nn_arr_(cc/dc)_commerical_field_layer` AS `nn_arr_(cc/dc)_commerical_field_layer`,
        `nn_arr_(cc)_commerical_field_layer` AS `nn_arr_(cc)_commerical_field_layer`,
        `nn_arr_(dc)_commerical_field_layer` AS `nn_arr_(dc)_commerical_field_layer`
FROM b2b.l1_sa_manual_lm_targets_by_week
UNION ALL 
SELECT 'AMER' as source_spreadsheet, 
        fw,
        first_day_of_fw,
        weekly_phasing,
        gross_new_arr_qrf,
        `nn_arr_(cc/dc_commerical_field)` AS nn_arr_cc_dc_commerical_field,
        `nn_arr_(cc_commerical_field)` AS nn_arr_cc_commerical_field,
        `nn_arr_(dc_commerical_field)` AS nn_arr_dc_commerical_field,
        `nn_arr_(cc/dc)_commerical_field_layer` AS nn_arr_cc_dc_commerical_field_layer,
        `nn_arr_(cc)_commerical_field_layer` AS nn_arr_cc_commerical_field_layer,
        `nn_arr_(dc)_commerical_field_layer` AS nn_arr_dc_commerical_field_layer
FROM b2b.l1_sa_manual_lm_targets_by_week_usa