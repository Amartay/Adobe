-- Databricks notebook source
-- MAGIC %md
-- MAGIC ####Setup

-- COMMAND ----------

-- DBTITLE 1,Refresh metadata of tables we will use
REFRESH TABLE CSMB_APP.fact_csmb_subscription_detail;
REFRESH TABLE CSMB_APP.exchange_rate_type_qtrly;
REFRESH TABLE CSMB_APP.subscription_params;
REFRESH TABLE CSMB_APP.acct_segment_activity_cutoff;
REFRESH TABLE CSMB_APP.acct_segment_realign_hist;
REFRESH TABLE CSMB_APP.dim_gtm_acct_hierarchy;
REFRESH TABLE CSMB_APP.gtm_projected_segmentation;
REFRESH TABLE CSMB_APP.dim_subscription;
REFRESH TABLE CSMB_APP.dim_gtm_acct_segment;
REFRESH csmb.vw_ccm_pivot4_all;

-- COMMAND ----------

-- DBTITLE 1,Create Table  (Not view)  of Medium Companies of pivot4all records of Interest - This is mainly for performance reasons but also aggregates any 0 records / nulls out of the data
DROP TABLE IF EXISTS b2b_analyst_tmp.jc_medium_selection;
CREATE TABLE b2b_analyst_tmp.jc_medium_selection AS
SELECT
  'Medium Companies' as type,
  p.date_key,
  p.geo,
  p.vip_contract,
  p.customer_email_domain,
  p.sales_document,
  p.route_to_market,
  p.product_name,
  p.sales_document_item,
  p.fiscal_yr_and_qtr_desc,
  p.fiscal_yr_and_wk_desc,
  p.market_segment,
  p.sales_district_description,
  p.market_area_description,
  p.geo_description,
  p.product_name_description,
  p.cc_phone_vs_web,
  p.subscription_account_guid,
  p.ecc_customer_id,
  p.cc_segment,
  p.cc_segment_offer,
  p.gtm_acct_segment,
  p.ech_sub_id,
  p.ech_parent_id,
  p.ech_sub_name,
  p.ech_parent_name,
  p.live_dme_gtm_segment,
  sum(p.first_purchase_arr_cfx) AS first_purchase_arr_cfx,
  sum(p.gross_new_arr_cfx) AS gross_new_arr_cfx,
  sum(p.init_purchase_arr_cfx) AS init_purchase_arr_cfx,
  sum(p.net_purchases_arr_cfx) AS net_purchases_arr_cfx,
  sum(p.renewal_from_arr_cfx) AS renewal_from_arr_cfx,
  sum(p.renewal_to_arr_cfx) AS renewal_to_arr_cfx,
  sum(p.migrated_from_arr_cfx) AS migrated_from_arr_cfx,
  sum(p.migrated_to_arr_cfx) AS migrated_to_arr_cfx,
  sum(p.net_cancelled_arr_cfx) AS net_cancelled_arr_cfx,
  sum(p.net_new_arr_cfx) AS net_new_arr_cfx
FROM
  csmb.vw_ccm_pivot4_all p
WHERE
  p.event_source = 'EVENT'
  AND p.geo IN ('EMEA','AMER')
  AND p.cc_phone_vs_web IN ('N/A','PHONE','VIP-PHONE','WEB')
  AND p.date_key >= 20211204 -- Q1 2022
  AND (
    p.vip_contract IN (
      SELECT DISTINCT contract_id
      FROM  b2b_analyst_tmp.medium_companies_combined
    )
    OR lower(p.customer_email_domain) IN (
      SELECT DISTINCT lower(domain) 
        FROM  b2b_analyst_tmp.medium_companies_combined
    )
    OR upper(p.subscription_account_guid) IN (SELECT DISTINCT upper(subscription_account_guid) 
                                              FROM  b2b_analyst_tmp.medium_companies_combined )
  )
  
GROUP BY 
  p.date_key,
    p.geo,
    p.vip_contract,
    p.customer_email_domain,
    p.sales_document,
    p.route_to_market,
    p.product_name,
    p.sales_document_item,
    p.fiscal_yr_and_qtr_desc,
    p.fiscal_yr_and_wk_desc,
    p.market_segment,
    p.sales_district_description,
    p.market_area_description,
    p.geo_description,
    p.product_name_description,
    p.cc_phone_vs_web,
    p.subscription_account_guid,
    p.ecc_customer_id,
    p.cc_segment,
    p.cc_segment_offer,
    p.gtm_acct_segment,
    p.ech_sub_id,
    p.ech_parent_id,
    p.ech_sub_name,
    p.ech_parent_name,
    p.live_dme_gtm_segment

-- COMMAND ----------

REFRESH TABLE CSMB_APP.fact_csmb_subscription_detail;
REFRESH TABLE CSMB_APP.exchange_rate_type_qtrly;
REFRESH TABLE CSMB_APP.subscription_params;
REFRESH TABLE CSMB_APP.acct_segment_activity_cutoff;
REFRESH TABLE CSMB_APP.acct_segment_realign_hist;
REFRESH TABLE CSMB_APP.dim_gtm_acct_hierarchy;
REFRESH TABLE CSMB_APP.gtm_projected_segmentation;
REFRESH TABLE CSMB_APP.dim_subscription;
REFRESH TABLE CSMB_APP.dim_gtm_acct_segment;
REFRESH csmb.vw_ccm_pivot4_all;

-- COMMAND ----------

-- DBTITLE 1,Create Table  (Not view)  of Small Companies of pivot4all records of Interest - This is mainly for performance reasons
DROP TABLE IF EXISTS b2b_analyst_tmp.jc_small_selection;
CREATE TABLE b2b_analyst_tmp.jc_small_selection AS
SELECT
  'Small Companies' as type,
  p.date_key,
  p.geo,
  p.vip_contract,
  p.customer_email_domain,
  p.sales_document,
  p.route_to_market,
  p.product_name,
  p.sales_document_item,
  p.fiscal_yr_and_qtr_desc,
  p.fiscal_yr_and_wk_desc,
  p.market_segment,
  p.sales_district_description,
  p.market_area_description,
  p.geo_description,
  p.product_name_description,
  p.cc_phone_vs_web,
  p.subscription_account_guid,
  p.ecc_customer_id,
  p.cc_segment,
  p.cc_segment_offer,
  p.gtm_acct_segment,
  p.ech_sub_id,
  p.ech_parent_id,
  p.ech_sub_name,
  p.ech_parent_name,
  p.live_dme_gtm_segment,
  sum(p.first_purchase_arr_cfx) AS first_purchase_arr_cfx,
  sum(p.gross_new_arr_cfx) AS gross_new_arr_cfx,
  sum(p.init_purchase_arr_cfx) AS init_purchase_arr_cfx,
  sum(p.net_purchases_arr_cfx) AS net_purchases_arr_cfx,
  sum(p.renewal_from_arr_cfx) AS renewal_from_arr_cfx,
  sum(p.renewal_to_arr_cfx) AS renewal_to_arr_cfx,
  sum(p.migrated_from_arr_cfx) AS migrated_from_arr_cfx,
  sum(p.migrated_to_arr_cfx) AS migrated_to_arr_cfx,
  sum(p.net_cancelled_arr_cfx) AS net_cancelled_arr_cfx,
  sum(p.net_new_arr_cfx) AS net_new_arr_cfx
FROM
  csmb.vw_ccm_pivot4_all p
WHERE
  p.event_source = 'EVENT'
  AND p.geo IN ('EMEA','AMER')
  AND p.cc_phone_vs_web IN ('N/A','PHONE','VIP-PHONE','WEB')
  AND p.date_key >= 20211204 -- Q1 2022
  AND (
    p.vip_contract IN (
      SELECT DISTINCT vip
      FROM b2b_analyst_tmp.small_companies_combined
    )
    OR lower(p.customer_email_domain) IN (
      SELECT DISTINCT lower(domain)
      FROM b2b_analyst_tmp.small_companies_combined
    )
      OR upper(p.subscription_account_guid) IN (SELECT DISTINCT upper(subscription_account_guid) 
                                              FROM  b2b_analyst_tmp.small_companies_combined )
  )
GROUP BY p.date_key,
  p.geo,
  p.vip_contract,
  p.customer_email_domain,
  p.sales_document,
  p.route_to_market,
  p.product_name,
  p.sales_document_item,
  p.fiscal_yr_and_qtr_desc,
  p.fiscal_yr_and_wk_desc,
  p.market_segment,
  p.sales_district_description,
  p.market_area_description,
  p.geo_description,
  p.product_name_description,
  p.cc_phone_vs_web,
  p.subscription_account_guid,
  p.ecc_customer_id,
  p.cc_segment,
  p.cc_segment_offer,
  p.gtm_acct_segment,
  p.ech_sub_id,
  p.ech_parent_id,
  p.ech_sub_name,
  p.ech_parent_name,
  p.live_dme_gtm_segment

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create a Lookup Table for opportunities based on the deal Reg ID - Get all cleaned order numbers for a given opportunity. 
-- MAGIC
-- MAGIC the opportunity field in salesforce is free text and has literally zero standards - its just various numbers separated perhaps by delimiters or spaces or anything really - this is the best thing I could think of to try and parse them and give you a list for each opportunity

-- COMMAND ----------

-- DBTITLE 1,Make one row per order Number in the Opportunity Table (its a free text field and they use a variety of delimeters)
--Sort out the Order Numbers in the Opportunity Table before joining to look at any LM engaged booked Opportunities beyond 90 days

DROP TABLE IF EXISTS  b2b_analyst_tmp.lm_opportunity_order_lookup;
CREATE TABLE b2b_analyst_tmp.lm_opportunity_order_lookup (      dealregistrationid  string,
                                                        lm_engagement string, 
                                                        sales_order_number_original string,
                                                        sales_order_number_cleaned string,
                                                        as_of_date string
                                                ); 

INSERT INTO  b2b_analyst_tmp.lm_opportunity_order_lookup (dealregistrationid,lm_engagement,sales_order_number_original,sales_order_number_cleaned,as_of_date)

-- this ranking stuff is necessary because some people in salesforce key the same sales order number into multiple opportunities (see sales_order_number_cleaned = '150821876' )

SELECT dealregistrationid,
       lm_engagement,
       sales_order_number_original,
       sales_order_number_cleaned,
       as_of_date
FROM ( 
SELECT dealregistrationid,
       lm_engagement,
       sales_order_number_original,
       sales_order_number_cleaned,
       as_of_date,
       ROW_NUMBER() OVER (PARTITION BY sales_order_number_cleaned ORDER BY dealregistrationid DESC) AS ranking -- this is necessary as ive seen case 
FROM ( 
  SELECT DISTINCT  dealregistrationid,
                  'Y' AS lm_engagement,
                  sales_order_number_original,
                  explode(array_remove(orders,'')) as sales_order_number_cleaned,
                  as_of_date
  FROM (
  SELECT DISTINCT dealregistrationid,
                  sales_order_num as sales_order_number_original,
                  lm_engagement,
                  stage,
                  as_of_date,
                  split(
                  regexp_replace(
                          regexp_replace(
                          trim(regexp_replace(CASE WHEN substring(sales_order_num,-1) IN ('|',',','+','#',';',':','-','\\','/','.')
                                                          THEN substring(sales_order_num,1,(length(sales_order_num)-1))
                                                          ELSE sales_order_num END,
                          '[A-za-z]','')),
                          '[^0-9]',','),
                          '[,]{2,}',','),
                  ',') as orders
  
          FROM (
                SELECT  dealregistrationid, 
                        concat(coalesce(adobesalesordernumber,''),',',coalesce(ecc_salesordernumber,'')) AS sales_order_num,
                        lm_engagement,
                        stage,
                        as_of_date
                FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity
                WHERE  upper(replace(stage,' ','')) = 'CLOSED-BOOKED'
                AND lm_engagement IS NOT NULL
                AND as_of_date = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity )
          ) orders 
  )
)
) 
WHERE ranking = 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###Small Companies
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Drop table IF Exists
DROP TABLE IF EXISTS b2b_analyst_tmp.LM_Report_Small_Companies;

-- COMMAND ----------

-- DBTITLE 1,Run the Report - Small Companies
CREATE TABLE b2b_analyst_tmp.LM_Report_Small_Companies AS
SELECT DISTINCT
  -- there isnt a engagement name in the small companies file
  upper(coalesce(sc_contract.originating_spreadsheet,sc_domain.originating_spreadsheet,sc_acc_guid.originating_spreadsheet, opps.originating_spreadsheet)) AS originating_spreadsheet,
  upper(coalesce(sc_contract.originating_tab,sc_domain.originating_tab,sc_acc_guid.originating_tab, opps.originating_tab)) AS originating_tab,
  upper(coalesce(sc_contract.LM_Program,sc_domain.LM_Program,sc_acc_guid.LM_Program, opps.LM_Program)) AS lm_program,
  'N/A' AS lm_engagement_name,
  CASE WHEN opps.company_name IS NOT NULL THEN 'Opportunity' ELSE 'In Window Payment' END AS type,
  p.geo,
  p.date_key,
  coalesce(sc_contract.company_name,sc_domain.company_name,sc_acc_guid.company_name,opps.company_name) AS account_name,
  p.vip_contract,
  p.customer_email_domain,
  p.sales_document,
  p.route_to_market,
  p.product_name,
  p.sales_document_item,
  p.fiscal_yr_and_qtr_desc,
  p.fiscal_yr_and_wk_desc,
  p.market_segment,
  p.sales_district_description,
  p.market_area_description,
  p.geo_description,
  p.product_name_description,
  p.cc_phone_vs_web,
  p.subscription_account_guid,
  p.ecc_customer_id,
  p.cc_segment,
  p.cc_segment_offer,
  p.gtm_acct_segment,
  p.ech_sub_id,
  p.ech_parent_id,
  p.ech_sub_name,
  p.ech_parent_name,
  p.live_dme_gtm_segment,
  p.first_purchase_arr_cfx,
  p.gross_new_arr_cfx,
  p.init_purchase_arr_cfx,
  p.net_purchases_arr_cfx,
  p.renewal_from_arr_cfx,
  p.renewal_to_arr_cfx,
  p.migrated_from_arr_cfx,
  p.migrated_to_arr_cfx,
  p.net_cancelled_arr_cfx,
  p.net_new_arr_cfx
FROM b2b_analyst_tmp.jc_small_selection p
-- contracts
LEFT JOIN (
  SELECT DISTINCT company_name,
                  originating_spreadsheet,
                  LM_Program,
                  originating_tab,
                  vip, 
                  replace(notified_date,'-','') as notified_date,
                  replace(cast((notified_date + interval '90' day) as string),'-','') as end_date
  FROM b2b_analyst_tmp.small_companies_combined
) sc_contract
ON p.vip_contract = sc_contract.vip
AND p.date_key BETWEEN sc_contract.notified_date AND sc_contract.end_date
AND lower(p.geo) = lower(sc_contract.originating_spreadsheet)

-- domains
LEFT JOIN (
  SELECT DISTINCT company_name,
                  originating_spreadsheet,
                  LM_Program,
                  originating_tab,
                  lower(domain) as domain,
                  replace(notified_date,'-','') as notified_date,
                  replace(cast((notified_date + interval '90' day) as string),'-','') as end_date
  FROM b2b_analyst_tmp.small_companies_combined
) sc_domain
ON lower(p.customer_email_domain) = lower(sc_domain.domain)
AND p.date_key BETWEEN sc_domain.notified_date AND sc_domain.end_date
AND lower(p.geo) = lower(sc_domain.originating_spreadsheet)

-- subscription_account_guid
LEFT JOIN (
  SELECT DISTINCT company_name,
                  originating_spreadsheet,
                  LM_Program,
                  originating_tab,
                  upper(subscription_account_guid) as subscription_account_guid,
                  replace(notified_date,'-','') as notified_date,
                  replace(cast((notified_date + interval '90' day) as string),'-','') as end_date
  FROM b2b_analyst_tmp.small_companies_combined
) sc_acc_guid
ON upper(p.subscription_account_guid) = upper(sc_acc_guid.subscription_account_guid)
AND p.date_key BETWEEN sc_acc_guid.notified_date AND sc_acc_guid.end_date
AND lower(p.geo) = lower(sc_acc_guid.originating_spreadsheet)

-- Closed booked LM opportunities - these can happen after the engagement window closes
LEFT JOIN ( 
          SELECT DISTINCT   company_name,
                            originating_spreadsheet,
                            LM_Program,
                            originating_tab,
                            opp.sales_order_number_cleaned 
          FROM  b2b_analyst_tmp.small_companies_combined s
          INNER JOIN b2b_analyst_tmp.lm_opportunity_order_lookup opp
            ON s.Opportunity = opp.dealregistrationid
          WHERE s.Opportunity IS NOT NULL
) opps
ON REGEXP_REPLACE(p.sales_document, '^0+', '')  = REGEXP_REPLACE(opps.sales_order_number_cleaned, '^0+', '') -- replace any leading 0's on both sides of the join
AND p.date_key >=sc_acc_guid.notified_date  -- opportunities can be in the engagement and beyond

-- either contract,domain, subscription_account_guid matches or opportunity matches
WHERE sc_contract.company_name IS NOT NULL 
OR sc_domain.company_name IS NOT NULL
OR sc_acc_guid.company_name IS NOT NULL
OR opps.company_name IS NOT NULL

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###Medium Companies

-- COMMAND ----------

-- DBTITLE 1,Drop medium companies output table if exists
DROP TABLE IF EXISTS b2b_analyst_tmp.LM_Report_medium_Companies;

-- COMMAND ----------

-- DBTITLE 1,Run the Report - Stage 1 (Medium Companies)
CREATE TABLE b2b_analyst_tmp.LM_Report_medium_Companies AS -- Section 1 - Those bookings made within the 90 day window
SELECT
  upper(coalesce(mc_contract.originating_spreadsheet,mc_domain.originating_spreadsheet,sc_acc_guid.originating_spreadsheet)) AS originating_spreadsheet,
  upper(coalesce(mc_contract.originating_tab,mc_domain.originating_tab,sc_acc_guid.originating_tab)) AS originating_tab,
  coalesce(mc_contract.lm_engagement_name,mc_domain.lm_engagement_name,sc_acc_guid.lm_engagement_name) AS lm_engagement_name,
  upper(coalesce(mc_contract.LM_Program,mc_domain.LM_Program,sc_acc_guid.LM_Program)) AS lm_program,
  'In Window Payment' AS type,
  NULL AS opp_dr_id,
  NULL AS opp_as_of_date,
  p.date_key,
  p.geo,
  coalesce(mc_contract.account_name,mc_domain.account_name,sc_acc_guid.account_name) AS account_name,
  coalesce(mc_contract.Renewal_Health_Check,mc_domain.Renewal_health_check,sc_acc_guid.Renewal_health_check) AS renewal_health_check,
  coalesce(mc_contract.Opportunity_Only_Review,mc_domain.Opportunity_Only_Review,sc_acc_guid.Opportunity_Only_Review) AS opportunity_only_review,
  p.vip_contract,
  p.customer_email_domain,
  p.sales_document,
  p.route_to_market,
  p.product_name,
  p.sales_document_item,
  p.fiscal_yr_and_qtr_desc,
  p.fiscal_yr_and_wk_desc,
  p.market_segment,
  p.sales_district_description,
  p.market_area_description,
  p.geo_description,
  p.product_name_description,
  p.cc_phone_vs_web,
  p.subscription_account_guid,
  p.ecc_customer_id,
  p.cc_segment,
  p.cc_segment_offer,
  p.gtm_acct_segment,
  p.ech_sub_id,
  p.ech_parent_id,
  p.ech_sub_name,
  p.ech_parent_name,
  p.live_dme_gtm_segment,
  p.first_purchase_arr_cfx,
  p.gross_new_arr_cfx,
  p.init_purchase_arr_cfx,
  p.net_purchases_arr_cfx,
  p.renewal_from_arr_cfx,
  p.renewal_to_arr_cfx,
  p.migrated_from_arr_cfx,
  p.migrated_to_arr_cfx,
  p.net_cancelled_arr_cfx,
  p.net_new_arr_cfx
FROM b2b_analyst_tmp.jc_medium_selection p
-- contracts
LEFT JOIN (
  SELECT DISTINCT lm_engagement_name, 
                account_name,
                originating_spreadsheet,
                LM_Program,
                originating_tab,
                contract_id, 
                Renewal_Health_Check,
                Opportunity_Only_Review,
                replace(notified_date,'-','') as notified_date,
                -- 90 days + any on hold time
                replace(date_add(notified_date, cast(coalesce(on_hold_duration,0)+90 as int)),'-','')as end_date
  FROM b2b_analyst_tmp.medium_companies_combined
  WHERE (upper(Renewal_Health_Check) = 'NO' AND upper(Opportunity_Only_Review) = 'NO') -- the records flagged Yes for these only care for opportunities
) mc_contract
ON p.vip_contract = mc_contract.contract_id
AND p.date_key BETWEEN mc_contract.notified_date AND mc_contract.end_date -- within 90 days
AND lower(p.geo) = lower(mc_contract.originating_spreadsheet)

-- domains
LEFT JOIN (
  SELECT DISTINCT lm_engagement_name, 
                account_name,
                originating_spreadsheet,
                LM_Program,
                originating_tab,
                lower(domain) as domain,
                Renewal_Health_Check,
                Opportunity_Only_Review,
                replace(notified_date,'-','') as notified_date,
                -- 90 days + any on hold time
                replace(date_add(notified_date, cast(coalesce(on_hold_duration,0)+90 as int)),'-','') as end_date
  FROM b2b_analyst_tmp.medium_companies_combined
  WHERE (upper(Renewal_Health_Check) = 'NO'  AND  upper(Opportunity_Only_Review) = 'NO') -- the records flagged yes do not care about payments within the 90 day window
) mc_domain
ON lower(p.customer_email_domain) = lower(mc_domain.domain)
AND p.date_key BETWEEN mc_domain.notified_date AND mc_domain.end_date -- within 90 days
AND lower(p.geo) = lower(mc_domain.originating_spreadsheet)

-- subscription_account_guid
LEFT JOIN (
  SELECT DISTINCT lm_engagement_name,
                  account_name,
                  originating_spreadsheet,
                  LM_Program,
                  originating_tab,
                  upper(subscription_account_guid) as subscription_account_guid,
                  Renewal_Health_Check,
                  Opportunity_Only_Review,
                  replace(notified_date,'-','') as notified_date,
                  replace(date_add(notified_date, cast(coalesce(on_hold_duration,0)+90 as int)),'-','') as end_date
  FROM b2b_analyst_tmp.medium_companies_combined
  WHERE (upper(Renewal_Health_Check) = 'NO'  AND upper(Opportunity_Only_Review) = 'NO')  -- the records flagged yes do not care about payments within the 90 day window
) sc_acc_guid
ON upper(p.subscription_account_guid) = upper(sc_acc_guid.subscription_account_guid)
AND p.date_key BETWEEN sc_acc_guid.notified_date AND sc_acc_guid.end_date
AND lower(p.geo) = lower(sc_acc_guid.originating_spreadsheet)


-- either a match on domain or contract
WHERE mc_contract.lm_engagement_name IS NOT NULL 
OR mc_domain.lm_engagement_name IS NOT NULL
OR sc_acc_guid.lm_engagement_name IS NOT NULL


UNION ALL

-- Section 2 - Opportunities 
-- No Health Check: Those opportunities linked to LM made after 90 days (their opportunities payments will already be selected within the 90 day window)
-- Health Check / Opps Only: All Opportunities in 90 days or beyond

SELECT
  upper(coalesce(mc_contract.originating_spreadsheet,mc_domain.originating_spreadsheet,sc_acc_guid.originating_spreadsheet)) AS originating_spreadsheet,
  upper(coalesce(mc_contract.originating_tab,mc_domain.originating_tab,sc_acc_guid.originating_tab)) AS originating_tab,
  coalesce(mc_contract.lm_engagement_name,mc_domain.lm_engagement_name,sc_acc_guid.lm_engagement_name) AS lm_engagement_name,
  upper(coalesce(mc_contract.LM_Program,mc_domain.LM_Program,sc_acc_guid.LM_Program)) AS lm_program,
  'Opportunity' AS type,
  opp.dealregistrationid as opp_dr_id,
  max(opp.as_of_date) as opp_as_of_date,
  max(p.date_key) as pivot_date_key,
  p.geo,
  coalesce(mc_contract.account_name,mc_domain.account_name,sc_acc_guid.account_name) AS account_name,
  coalesce(mc_contract.Renewal_Health_Check,mc_domain.Renewal_health_check,sc_acc_guid.Renewal_health_check) AS renewal_health_check,
  coalesce(mc_contract.Opportunity_Only_Review,mc_domain.Opportunity_Only_Review,sc_acc_guid.Opportunity_Only_Review) AS Opportunity_Only_Review,
  p.vip_contract,
  p.customer_email_domain,
  p.sales_document,
  p.route_to_market,
  p.product_name,
  p.sales_document_item,
  p.fiscal_yr_and_qtr_desc,
  p.fiscal_yr_and_wk_desc,
  p.market_segment,
  p.sales_district_description,
  p.market_area_description,
  p.geo_description,
  p.product_name_description,
  p.cc_phone_vs_web,
  p.subscription_account_guid,
  p.ecc_customer_id,
  p.cc_segment,
  p.cc_segment_offer,
  p.gtm_acct_segment,
  p.ech_sub_id,
  p.ech_parent_id,
  p.ech_sub_name,
  p.ech_parent_name,
  p.live_dme_gtm_segment,
  p.first_purchase_arr_cfx,
  p.gross_new_arr_cfx,
  p.init_purchase_arr_cfx,
  p.net_purchases_arr_cfx,
  p.renewal_from_arr_cfx,
  p.renewal_to_arr_cfx,
  p.migrated_from_arr_cfx,
  p.migrated_to_arr_cfx,
  p.net_cancelled_arr_cfx,
  p.net_new_arr_cfx
FROM b2b_analyst_tmp.jc_medium_selection p
INNER JOIN b2b_analyst_tmp.lm_opportunity_order_lookup opp ON REGEXP_REPLACE(p.sales_document, '^0+', '') = REGEXP_REPLACE(opp.sales_order_number_cleaned, '^0+', '')
LEFT JOIN (
  SELECT DISTINCT lm_engagement_name, 
                originating_spreadsheet,
                LM_Program,
                originating_tab,
                account_name,
                contract_id, 
                Renewal_Health_Check,
                Opportunity_Only_Review,
                replace(notified_date,'-','') as notified_date,
                replace(cast((notified_date + interval '90' day) as string),'-','') as end_date
  FROM b2b_analyst_tmp.medium_companies_combined
) mc_contract
ON p.vip_contract = mc_contract.contract_id
AND ( 
      -- if you have no health check or opportunities only flags - you only care about opportunities post the engagment end - as any opportunities associated to that domain/contracts will already be reported on
      (upper(mc_contract.Renewal_Health_Check) = 'NO' AND upper(mc_contract.Opportunity_Only_Review) = 'NO'  AND  p.date_key > mc_contract.end_date) 
  OR
     ((upper(mc_contract.Renewal_Health_Check) = 'YES' OR upper(mc_contract.Opportunity_Only_Review) = 'YES' ) AND p.date_key >= mc_contract.notified_date ) -- if you are health check you are interested in all opportunities after the engagement start date
)

AND lower(p.geo) = lower(mc_contract.originating_spreadsheet)

-- domains
LEFT JOIN (
  SELECT DISTINCT lm_engagement_name, 
                originating_spreadsheet,
                LM_Program,
                originating_tab,
                account_name,
                Renewal_Health_Check,
                Opportunity_Only_Review,
                lower(domain) as domain,
                replace(notified_date,'-','') as notified_date,
                replace(cast((notified_date + interval '90' day) as string),'-','') as end_date
  FROM b2b_analyst_tmp.medium_companies_combined
) mc_domain
ON lower(p.customer_email_domain) = lower(mc_domain.domain)
AND ( 
      -- if you have no health check or opportunities only flags - you only care about opportunities post the engagment end - as any opportunities associated to that domain/contracts will already be reported on
      (upper(mc_domain.Renewal_Health_Check) = 'NO' AND upper(mc_domain.Opportunity_Only_Review) = 'NO'  AND  p.date_key > mc_domain.end_date) 
  OR
     ((upper(mc_domain.Renewal_Health_Check) = 'YES' OR upper(mc_domain.Opportunity_Only_Review) = 'YES' ) AND p.date_key >= mc_domain.notified_date ) -- if you are health check you are interested in all opportunities after the engagement start date
)
AND lower(p.geo) = lower(mc_domain.originating_spreadsheet)

-- subscription_account_guid
LEFT JOIN (
  SELECT DISTINCT lm_engagement_name,
                  account_name,
                  originating_spreadsheet,
                  LM_Program,
                  originating_tab,
                  upper(subscription_account_guid) as subscription_account_guid,
                  Renewal_Health_Check,
                  Opportunity_Only_Review,
                  replace(notified_date,'-','') as notified_date,
                  replace(date_add(notified_date, cast(coalesce(on_hold_duration,0)+90 as int)),'-','') as end_date
  FROM b2b_analyst_tmp.medium_companies_combined
) sc_acc_guid
ON upper(p.subscription_account_guid) = upper(sc_acc_guid.subscription_account_guid)
AND ( 
      -- if you have no health check or opportunities only flags - you only care about opportunities post the engagment end - as any opportunities associated to that domain/contracts will already be reported on
      (upper(sc_acc_guid.Renewal_Health_Check) = 'NO' AND upper(sc_acc_guid.Opportunity_Only_Review) = 'NO'  AND  p.date_key > sc_acc_guid.end_date) 
  OR
     ((upper(sc_acc_guid.Renewal_Health_Check) = 'YES' OR upper(sc_acc_guid.Opportunity_Only_Review) = 'YES' ) AND p.date_key >= sc_acc_guid.notified_date ) -- if you are health check you are interested in all opportunities after the engagement start date
)
AND lower(p.geo) = lower(sc_acc_guid.originating_spreadsheet)



-- either a match on domain or contract
WHERE mc_contract.lm_engagement_name IS NOT NULL 
OR mc_domain.lm_engagement_name IS NOT NULL
OR sc_acc_guid.lm_engagement_name IS NOT NULL

GROUP BY
  coalesce(mc_contract.originating_spreadsheet,mc_domain.originating_spreadsheet,sc_acc_guid.originating_spreadsheet),
  upper(coalesce(mc_contract.originating_tab,mc_domain.originating_tab,sc_acc_guid.originating_tab)),
  coalesce(mc_contract.lm_engagement_name,mc_domain.lm_engagement_name,sc_acc_guid.lm_engagement_name),
  upper(coalesce(mc_contract.LM_Program,mc_domain.LM_Program,sc_acc_guid.LM_Program)),
  opp.dealregistrationid,
  coalesce(mc_contract.account_name,mc_domain.account_name,sc_acc_guid.account_name),
  coalesce(mc_contract.Renewal_Health_Check,mc_domain.Renewal_health_check,sc_acc_guid.Renewal_health_check),
  coalesce(mc_contract.Opportunity_Only_Review,mc_domain.Opportunity_Only_Review,sc_acc_guid.Opportunity_Only_Review),
  p.vip_contract,
  p.geo,
  p.customer_email_domain,
  p.sales_document,
  p.route_to_market,
  p.product_name,
  p.sales_document_item,
  p.fiscal_yr_and_qtr_desc,
  p.fiscal_yr_and_wk_desc,
  p.market_segment,
  p.sales_district_description,
  p.market_area_description,
  p.geo_description,
  p.product_name_description,
  p.cc_phone_vs_web,
  p.subscription_account_guid,
  p.ecc_customer_id,
  p.cc_segment,
  p.cc_segment_offer,
  p.gtm_acct_segment,
  p.ech_sub_id,
  p.ech_parent_id,
  p.ech_sub_name,
  p.ech_parent_name,
  p.live_dme_gtm_segment,
  p.first_purchase_arr_cfx,
  p.gross_new_arr_cfx,
  p.init_purchase_arr_cfx,
  p.net_purchases_arr_cfx,
  p.renewal_from_arr_cfx,
  p.renewal_to_arr_cfx,
  p.migrated_from_arr_cfx,
  p.migrated_to_arr_cfx,
  p.net_cancelled_arr_cfx,
  p.net_new_arr_cfx

HAVING 
-- Remove Cancellations (Ticket 4337)
coalesce(p.net_cancelled_arr_cfx,0) <=0

ORDER BY account_name

-- COMMAND ----------

DROP TABLE IF EXISTS b2b_analyst_tmp.l3_sa_license_management_report_pre_deduplication;

-- COMMAND ----------

-- DBTITLE 1,Run the report Stage 2 - Combine Small companies with Medium Companies
CREATE TABLE b2b_analyst_tmp.l3_sa_license_management_report_pre_deduplication AS
SELECT 
  originating_spreadsheet,
  sc.LM_Program AS originating_file,
  sc.originating_tab,
  lm_engagement_name,
  sc.type,
  NULL AS opportunity_only_review,
  NULL AS renewal_health_check,
  'Pivot' as financial_source,
  NULL as opp_dr_id,
  NULL as opp_as_of_date,
  date_key,
  account_name,
  sc.geo,
  vip_contract,
  customer_email_domain as domain,
  sc.sales_document,
  route_to_market,
  product_name,
  sales_document_item,
  fiscal_yr_and_qtr_desc,
  fiscal_yr_and_wk_desc,
  market_segment,
  sales_district_description,
  market_area_description,
  geo_description,
  product_name_description,
  cc_phone_vs_web,
  subscription_account_guid,
  ecc_customer_id,
  cc_segment,
  cc_segment_offer,
  gtm_acct_segment,
  ech_sub_id,
  ech_parent_id,
  ech_sub_name,
  ech_parent_name,
  live_dme_gtm_segment,
  CASE WHEN bigDeal.sales_document IS NOT NULL THEN 'Y' ELSE 'N' END AS big_deal,
  first_purchase_arr_cfx,
  gross_new_arr_cfx,
  init_purchase_arr_cfx,
  net_purchases_arr_cfx,
  renewal_from_arr_cfx,
  renewal_to_arr_cfx,
  migrated_from_arr_cfx,
  migrated_to_arr_cfx,
  net_cancelled_arr_cfx,
  net_new_arr_cfx,
  net_purchases_arr_cfx AS gross_arr,
  net_purchases_arr_cfx  - net_cancelled_arr_cfx + ((migrated_to_arr_cfx - migrated_from_arr_cfx) + (renewal_to_arr_cfx - renewal_from_arr_cfx)) AS net_arr,
  CASE WHEN upper(cc_segment) = 'ACROBAT DC' THEN gross_new_arr_cfx ELSE 0 END AS gross_arr_dc,
  CASE WHEN upper(cc_segment) = 'TEAM' THEN gross_new_arr_cfx ELSE 0 END AS gross_arr_cc,
  CASE WHEN upper(cc_segment) = 'ACROBAT DC' THEN net_purchases_arr_cfx  - net_cancelled_arr_cfx + ((migrated_to_arr_cfx - migrated_from_arr_cfx) + (renewal_to_arr_cfx - renewal_from_arr_cfx)) ELSE 0 END AS net_arr_dc,
  CASE WHEN upper(cc_segment) = 'TEAM' THEN net_purchases_arr_cfx  - net_cancelled_arr_cfx + ((migrated_to_arr_cfx - migrated_from_arr_cfx) + (renewal_to_arr_cfx - renewal_from_arr_cfx)) ELSE 0 END AS net_arr_cc
FROM
  b2b_analyst_tmp.LM_Report_Small_Companies sc
LEFT JOIN (
    SELECT DISTINCT sales_document
    FROM ( 
            SELECT DISTINCT sales_document,
                            CASE WHEN big_deal_group = 'EDU' AND total_net_purchases>= 15000 THEN 'Y' 
                            WHEN big_deal_group = 'DC' AND total_net_purchases>= 10000 THEN 'Y' 
                            WHEN big_deal_group = 'TEAM' AND total_net_purchases>= 20000 THEN 'Y' 
                            WHEN big_deal_group = 'SIGN' AND total_net_purchases>= 5000 THEN 'Y' 
                            ELSE 'N'
                            END AS big_deal_flag
            FROM (
                    SELECT sales_document, big_deal_group, sum(net_purchases_arr_cfx) as total_net_purchases
                    FROM ( 
                            SELECT  sales_document,
                                    CASE WHEN upper(cc_segment) IN ('HED','K12') OR upper(market_segment) like '%EDUCATION%' THEN 'EDU'
                                    WHEN upper(cc_segment) = 'ACROBAT DC' THEN 'DC'
                                    WHEN upper(cc_segment) = 'TEAM' THEN 'TEAM'
                                    WHEN  upper(cc_segment) = 'SIGN' THEN 'SIGN' 
                                    END AS big_deal_group,
                                    net_purchases_arr_cfx
                            FROM b2b_analyst_tmp.jc_small_selection

                    )
                    GROUP BY  sales_document, big_deal_group
            )
    )
    WHERE big_deal_flag ='Y'
) bigDeal 
ON bigDeal.sales_document = sc.sales_document

UNION ALL

SELECT

  originating_spreadsheet,
  mc.LM_Program AS originating_file,
  mc.originating_tab,
  lm_engagement_name,
  type,
  mc.opportunity_only_review,
  mc.renewal_health_check,
  'Pivot' as financial_source,
  opp_dr_id,
  opp_as_of_date,
  date_key,
  account_name,
  mc.geo,
  vip_contract,
  customer_email_domain,
  mc.sales_document,
  route_to_market,
  product_name,
  sales_document_item,
  fiscal_yr_and_qtr_desc,
  fiscal_yr_and_wk_desc,
  market_segment,
  sales_district_description,
  market_area_description,
  geo_description,
  product_name_description,
  cc_phone_vs_web,
  subscription_account_guid,
  ecc_customer_id,
  cc_segment,
  cc_segment_offer,
  gtm_acct_segment,
  ech_sub_id,
  ech_parent_id,
  ech_sub_name,
  ech_parent_name,
  live_dme_gtm_segment,
  CASE WHEN bigDeal.sales_document IS NOT NULL THEN 'Y' ELSE 'N' END AS big_deal,
  first_purchase_arr_cfx,
  gross_new_arr_cfx,
  init_purchase_arr_cfx,
  net_purchases_arr_cfx,
  renewal_from_arr_cfx,
  renewal_to_arr_cfx,
  migrated_from_arr_cfx,
  migrated_to_arr_cfx,
  net_cancelled_arr_cfx,
  net_new_arr_cfx,
  net_purchases_arr_cfx AS gross_arr,
  net_purchases_arr_cfx  - net_cancelled_arr_cfx + ((migrated_to_arr_cfx - migrated_from_arr_cfx) + (renewal_to_arr_cfx - renewal_from_arr_cfx)) AS net_arr,
  CASE WHEN upper(cc_segment) = 'ACROBAT DC' THEN gross_new_arr_cfx ELSE 0 END AS gross_arr_dc,
  CASE WHEN upper(cc_segment) = 'TEAM' THEN gross_new_arr_cfx ELSE 0 END AS gross_arr_cc,
  CASE WHEN upper(cc_segment) = 'ACROBAT DC' THEN net_purchases_arr_cfx  - net_cancelled_arr_cfx + ((migrated_to_arr_cfx - migrated_from_arr_cfx) + (renewal_to_arr_cfx - renewal_from_arr_cfx)) ELSE 0 END AS net_arr_dc,
  CASE WHEN upper(cc_segment) = 'TEAM' THEN net_purchases_arr_cfx  - net_cancelled_arr_cfx + ((migrated_to_arr_cfx - migrated_from_arr_cfx) + (renewal_to_arr_cfx - renewal_from_arr_cfx)) ELSE 0 END AS net_arr_cc
FROM
  b2b_analyst_tmp.LM_Report_medium_Companies mc
LEFT JOIN (
    SELECT DISTINCT sales_document
    FROM ( 
            SELECT DISTINCT sales_document,
                            CASE WHEN big_deal_group = 'EDU' AND total_net_purchases>= 15000 THEN 'Y' 
                            WHEN big_deal_group = 'DC' AND total_net_purchases>= 10000 THEN 'Y' 
                            WHEN big_deal_group = 'TEAM' AND total_net_purchases>= 20000 THEN 'Y' 
                            WHEN big_deal_group = 'SIGN' AND total_net_purchases>= 5000 THEN 'Y' 
                            ELSE 'N'
                            END AS big_deal_flag
            FROM (
                    SELECT sales_document, big_deal_group, sum(net_purchases_arr_cfx) as total_net_purchases
                    FROM ( 
                            SELECT  sales_document,
                                    CASE WHEN upper(cc_segment) IN ('HED','K12') OR upper(market_segment) like '%EDUCATION%' THEN 'EDU'
                                    WHEN upper(cc_segment) = 'ACROBAT DC' THEN 'DC'
                                    WHEN upper(cc_segment) = 'TEAM' THEN 'TEAM'
                                    WHEN  upper(cc_segment) = 'SIGN' THEN 'SIGN' 
                                    END AS big_deal_group,
                                    net_purchases_arr_cfx
                            FROM b2b_analyst_tmp.jc_medium_selection

                    )
                    GROUP BY  sales_document, big_deal_group
            )
    )
    WHERE big_deal_flag ='Y'
) bigDeal 
ON bigDeal.sales_document = mc.sales_document

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #ETLA
-- MAGIC
-- MAGIC At this point the report consists of VIP records from pivot - LM can also take place on ETLAS - they communicate this by entering the sales order numbers (which always start with 40 (after removing leading zeros)) in their spreadsheet - we find these in enterprise ARR and see what is in scope based on those findings. 

-- COMMAND ----------

-- DBTITLE 1,Create a list of ETLA orders from the source spreadsheets

-- Get ETLA order numbers from the spreadsheet (They always start with 40 or 0040 - and are shorter than contract IDs (which are 20 chars))
CREATE OR REPLACE TEMPORARY VIEW etla_orders AS 

SELECT  upper(originating_spreadsheet) AS originating_spreadsheet,
        originating_tab,
        etla_order_num,
        lm_engagement_name,
        LM_Program,
        account_name,
        opportunity_only_review,
        renewal_health_check
FROM (
  SELECT  originating_spreadsheet,
          originating_tab,
          contract_id AS etla_order_num, 
          lm_engagement_name,
          account_name as account_name,
          LM_Program,
          opportunity_only_review,
          renewal_health_check
  FROM emea_and_usa_medium_Companies
  UNION 
  SELECT  originating_spreadsheet,
          originating_tab,
          vip, 
          'N/A',
          company_name as account_name,
          LM_Program,
          NULL AS opportunity_only_review,
          NULL AS renewal_health_check
  FROM emea_and_usa_small_Companies
) x 
WHERE (regexp_replace(x.etla_order_num, '^0+', '') like '40%' OR regexp_replace(x.etla_order_num, '^0+', '') like '190%') --40 is ETLA, 190 is VIP Custom (who are in the ent arr table for some reason)
AND length(x.etla_order_num) <=20

-- COMMAND ----------

-- DBTITLE 1,Get all the ETLA Transaction from enterprise ARR - use the movement between opening and closing balance to provide a rough net arr figure
CREATE OR REPLACE TEMPORARY VIEW etla_base_data AS 

SELECT  x.*,
        opp.*,
        movement AS gross_arr,
        movement AS net_arr,
        CASE WHEN upper(segment) = 'ACROBAT DC' THEN movement ELSE 0 END AS gross_arr_dc,
        CASE WHEN upper(segment) = 'TEAM' THEN movement ELSE 0 END AS gross_arr_cc,
        CASE WHEN upper(segment) = 'ACROBAT DC' THEN movement ELSE 0 END AS net_arr_dc,
        CASE WHEN upper(segment) = 'TEAM' THEN movement ELSE 0 END AS net_arr_cc,
        CASE WHEN upper(olpg) IN ('CREATIVE','CCE STOCK') THEN 'TEAM' 
                             WHEN upper(olpg) = 'CCE STOCK' THEN 'STOCK'
                             WHEN upper(olpg) = 'ACROBAT' THEN 'ACROBAT DC'
                             ELSE upper(olpg) END AS olpg_cleaned,
        row_number() OVER (PARTITION BY lm_engagement_name,salesdocument,productname,salesdocumentitem   ORDER BY salesdocument,productname,salesdocumentitem  ASC) as transaction_order_number
FROM 
(
        SELECT  *,
                current_week_end_balance - previous_week_end AS movement,
                CASE WHEN opplu.sales_order_number_cleaned IS NULL THEN 'N' ELSE 'Y' END AS Order_Closed_Booked_Salesforce_with_lm_engagement
        FROM  (
        SELECT      -- obtain the previous weeks opening balance
                        *,
                        coalesce(lag(current_week_end_balance) OVER (PARTITION BY x.lm_engagement_name, x.salesdocument, x.productname, x.salesdocumentitem ORDER BY x.fiscalyrandwk),0) as previous_week_end
        FROM (
                -- sum the sales document balances
                SELECT  fiscalyrandwk, 
                        o.originating_spreadsheet,
                        o.originating_tab,
                        o.LM_Program,
                        o.lm_engagement_name,
                        o.account_name,
                        o.opportunity_only_review,
                        o.renewal_health_check,
                        salesdocument,
                        salesdocumentitem,
                        geodescription,
                        salesdistrictdescription,
                        marketsegment,
                        marketareadescription,
                        productname,
                        productnamedescription,
                        fiscalyrandqtr,
                        sm.segment,
                        accountname,
                        echparentmarketareadesc,
                        echparentid,
                        echparentname,
                        echsubid,
                        echsubname,
                        echchildid,
                        vipcontract,
                        subscriptionid,
                        DateDate,
                        entarr.geo,
                        entarr.olpg,
                        case when lm_engagement_name is not null then 'Y' else 'N' End as is_in_spreadsheet,
                        coalesce(sum(totalendingarr),0) As current_week_end_balance
                FROM  b2b.uda_uda_finance_arr_vw_entarr entarr
                -- they need to be in the spreadsheets provided. 
                INNER JOIN etla_orders o
                ON regexp_replace(o.etla_order_num,'^0+','') = regexp_replace(entarr.salesdocument,'^0+','')
                AND lower(entarr.geo) = lower(o.originating_spreadsheet)
                -- map the products to a segment to populate the cc segment table
                LEFT JOIN b2b_analyst_tmp.etla_dccc_prod_segment_mapping sm
                        ON sm.product_code = entarr.productname
                WHERE SnapshotType = 'W'
                GROUP BY fiscalyrandwk,
                         o.LM_Program,
                         salesdocument,
                         entarr.geo,
                         o.account_name,
                         o.originating_spreadsheet,
                         o.originating_tab,
                         o.lm_engagement_name, 
                         o.opportunity_only_review,
                         o.renewal_health_check,
                         case when lm_engagement_name is not null then 'Y' else 'N' end,
                         salesdocumentitem,
                        geodescription,
                        salesdistrictdescription,
                        marketsegment,
                        marketareadescription,
                        productname,
                        productnamedescription,
                        fiscalyrandqtr,
                        accountname,
                        sm.segment,
                        echparentmarketareadesc,
                        echparentid,
                        echparentname,
                        echsubid,
                        echsubname,
                        echchildid,
                        entarr.olpg,
                        vipcontract,
                        subscriptionid,
                        DateDate
        ) x 
        ) prev
        -- they need to be closed booked with LM involvement
        INNER JOIN b2b_analyst_tmp.lm_opportunity_order_lookup opplu
                ON opplu.sales_order_number_cleaned = salesdocument
        AND current_week_end_balance <> previous_week_end
) x 
LEFT JOIN (

-- We need to remove ETLA orders relating to opportunities which are >3 months past the closed date of said opportunity
SELECT DISTINCT  o.fulloptyid,
                 o.dealregistrationid AS deal_reg_id,
                 o.ecc_salesordernumber as sales_order_number,
                 o.closedate,
                 add_months(o.closedate, 3) as end_of_etla_opportunity_window
FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity o 
INNER JOIN etla_orders et
  ON regexp_replace(et.etla_order_num, '^0+', '') = regexp_replace(o.ecc_salesordernumber, '^0+', '') -- you are in the spreadsheets
WHERE o.as_of_date  = (SELECT MAX(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_opportunity)
AND o.lm_engagement IS NOT NULL -- you have LM engagement in salesforce
AND upper(replace(o.stage,' ','')) = 'CLOSED-BOOKED'
) opp
ON regexp_replace(x.salesdocument, '^0+', '') = regexp_replace(opp.sales_order_number, '^0+', '') 

WHERE x.DateDate <= opp.end_of_etla_opportunity_window -- you are a closed booked opportunity and we only care about etla orders within 3 months of the opportunity closing
OR opp.fulloptyid is null -- or we cant find an opportunity for you

-- COMMAND ----------

-- DBTITLE 1,Insert ETLA Records into Report - pre dedupe
INSERT INTO  b2b_analyst_tmp.l3_sa_license_management_report_pre_deduplication
( originating_spreadsheet,
  originating_file ,
  originating_tab,
  lm_engagement_name ,
  type ,
  opportunity_only_review,
  renewal_health_check,
  financial_source,
  opp_dr_id ,
  opp_as_of_date,
  date_key ,
  account_name ,
  geo,
  vip_contract ,
  domain ,
  sales_document ,
  route_to_market ,
  product_name ,
  sales_document_item ,
  fiscal_yr_and_qtr_desc ,
  fiscal_yr_and_wk_desc ,
  market_segment ,
  sales_district_description ,
  market_area_description ,
  geo_description ,
  product_name_description ,
  cc_phone_vs_web ,
  subscription_account_guid ,
  ecc_customer_id ,
  cc_segment ,
  cc_segment_offer ,
  gtm_acct_segment ,
  ech_sub_id ,
  ech_parent_id ,
  ech_sub_name ,
  ech_parent_name ,
  live_dme_gtm_segment ,
  big_deal,
  first_purchase_arr_cfx ,
  gross_new_arr_cfx ,
  init_purchase_arr_cfx ,
  net_purchases_arr_cfx ,
  renewal_from_arr_cfx ,
  renewal_to_arr_cfx ,
  migrated_from_arr_cfx ,
  migrated_to_arr_cfx ,
  net_cancelled_arr_cfx,
  net_new_arr_cfx,
  gross_arr,
  net_arr,
  gross_arr_dc,
  gross_arr_cc,
  net_arr_dc,
  net_arr_cc
 )
SELECT  originating_spreadsheet,
        LM_Program AS originating_file,
        base.originating_tab,
        lm_engagement_name,
        'ETLA Opportunity' AS type,
        opportunity_only_review,
        renewal_health_check,
        'Enterprise Arr' AS financial_source,
        dealregistrationid,
        NULL AS opp_as_of_date,
        cast(replace(datedate,'-','') as int)  AS date_key,
        account_name,
        base.geo,
        vipcontract,
        NULL AS domain,
        base.salesdocument,
        NULL AS route_to_market,
        productname,
        salesdocumentitem,
        concat(substr(fiscalyrandqtr,1,4),'-Q',right(fiscalyrandqtr,1)) AS fiscalyrandqtr,
        concat(substr(fiscalyrandwk,1,4),'-',right(fiscalyrandwk,2)) AS fiscalyrandwk,
        marketsegment,
        salesdistrictdescription,
        marketareadescription,
        geodescription,
        productnamedescription,
        'ETLA' AS cc_phone_vs_web,
        subscriptionid AS subscription_account_guid,
        NULL AS ecc_customer_id,
        olpg_cleaned AS cc_segment,
        NULL AS cc_segment_offer,
        'CSMB' AS gtm_acct_segment, 
        echsubid,
        echparentid,
        echsubname,
        echparentname,
        NULL AS live_dme_gtm_segment,
        CASE WHEN bd.salesdocument IS NOT NULL THEN 'Y' ELSE 'N' END AS big_deal,
        NULL AS   first_purchase_arr_cfx,
        NULL AS   gross_new_arr_cfx,
        NULL AS   init_purchase_arr_cfx,
        NULL AS   net_purchases_arr_cfx,
        NULL AS   renewal_from_arr_cfx,
        NULL AS   renewal_to_arr_cfx,
        NULL AS   migrated_from_arr_cfx,
        NULL AS   migrated_to_arr_cfx,
        NULL AS   net_cancelled_arr_cfx,
        movement AS   net_new_arr_cfx,
        gross_arr,
        net_arr,
        gross_arr_dc,
        gross_arr_cc,
        net_arr_dc,
        net_arr_cc
FROM etla_base_data base
LEFT JOIN (SELECT DISTINCT salesdocument
    FROM ( 
            SELECT DISTINCT salesdocument,
                            CASE WHEN big_deal_group = 'EDU' AND total_net_arr>= 15000 THEN 'Y' 
                            WHEN big_deal_group = 'DC' AND total_net_arr>= 10000 THEN 'Y' 
                            WHEN big_deal_group = 'TEAM' AND total_net_arr>= 20000 THEN 'Y' 
                            WHEN big_deal_group = 'SIGN' AND total_net_arr>= 5000 THEN 'Y' 
                            ELSE 'N'
                            END AS big_deal_flag
            FROM (
                    SELECT salesdocument, big_deal_group, sum(net_arr) as total_net_arr
                    FROM ( 
                      SELECT salesdocument,
                            CASE WHEN upper(marketsegment) like '%EDUCATION%' THEN 'EDU'
                                  WHEN upper(segment)='ACROBAT DC' THEN 'DC'
                                  WHEN upper(segment)='TEAM' THEN 'TEAM'
                                  WHEN upper(segment) = 'SIGN' THEN 'SIGN'
                                  WHEN left(upper(productname),3) = 'ECH' THEN 'SIGN'
                                  END AS big_deal_group,
                                  net_arr
                      FROM etla_base_data
                    )
                    GROUP BY salesdocument, big_deal_group
            )
    )
  WHERE big_deal_flag = 'Y'
) bd
ON bd.salesdocument = base.salesdocument
WHERE transaction_order_number =  1 -- We only want to see the initial transaction that took place

-- COMMAND ----------

-- DBTITLE 1,Removing Double Counted Invoices
-- MAGIC %md
-- MAGIC
-- MAGIC There are a number of issues in the input spreadsheet which can cause the sales sales document to be counted multiple times in this reporting - which is wrong. These were discussed with LM and we were told they dont have time to monitor this spreadsheet effectively.
-- MAGIC The common issues for this double counting on the spreadsheet are;
-- MAGIC
-- MAGIC - The same domain shared across multiple LM Engagements within the same or overlapping time periods
-- MAGIC - Opportunities found after the 90 day window relating to domains that are shared across multiple engagements
-- MAGIC - Overlapping time periods within the spreadsheet
-- MAGIC - Duplicated LM engagements within the spreadsheet
-- MAGIC
-- MAGIC
-- MAGIC to stop this I put a rule in place that simply means the same sales document line item, date and segment combination cannot exist in multiple LM engagements (medium company) or account names (Small Company)

-- COMMAND ----------

DROP TABLE IF EXISTS b2b_analyst.l3_sa_license_management_report;

-- COMMAND ----------

-- DBTITLE 1,Create Final Report Table having removed duplicates caused by poor data entry on the initial spreadsheets provided.

CREATE TABLE b2b_analyst.l3_sa_license_management_report AS 
SELECT  upper(rep.originating_spreadsheet) AS originating_spreadsheet,
        CASE WHEN upper(rep.originating_file) = 'LARGE' THEN 'CORP' ELSE upper(rep.originating_file) END AS originating_file, -- A request from Ravi to name Large as CORP
        upper(rep.originating_tab) AS originating_tab,
        upper(rep.lm_engagement_name) AS  lm_engagement_name,
        upper(coalesce(opportunity_only_review,'NO')) AS opportunity_only_review, -- these dont exist for small companies - just force them to be NO for power BI 
        upper(coalesce(renewal_health_check,'NO')) AS renewal_health_check, -- these dont exist for small companies - just force them to be NO for power BI 
        CASE WHEN opps.dealregistrationid IS NOT NULL THEN 'OPPORTUNITY' ELSE 'IN WINDOW PAYMENT' END AS type,
        financial_source,
        opps.dealregistrationid AS opp_dr_id ,
        opp_as_of_date ,
        date_key ,
        rep.account_name ,
        geo,
        CASE WHEN vip_contract = '' THEN NULL ELSE vip_contract END AS vip_contract,
        CASE WHEN domain = '' THEN NULL ELSE domain END AS domain,
        sales_document ,
        route_to_market ,
        product_name ,
        sales_document_item ,
        fiscal_yr_and_qtr_desc ,
        fiscal_yr_and_wk_desc ,
        market_segment ,
        sales_district_description ,
        market_area_description ,
        geo_description ,
        product_name_description ,
        cc_phone_vs_web ,
        CASE WHEN subscription_account_guid = '' THEN NULL ELSE subscription_account_guid END AS subscription_account_guid,
        ecc_customer_id ,
        cc_segment ,
        cc_segment_offer ,
        gtm_acct_segment ,
        ech_sub_id ,
        ech_parent_id ,
        ech_sub_name ,
        ech_parent_name ,
        live_dme_gtm_segment,
        big_deal,
        CASE WHEN smallBigDeals.account_name IS NOT NULL OR mediumBigDeals.lm_engagement_name IS NOT NULL THEN 'Y' ELSE 'N' END AS engagement_contains_big_deal,
        first_purchase_arr_cfx ,
        gross_new_arr_cfx ,
        init_purchase_arr_cfx ,
        net_purchases_arr_cfx ,
        renewal_from_arr_cfx ,
        renewal_to_arr_cfx ,
        migrated_from_arr_cfx ,
        migrated_to_arr_cfx ,
        net_cancelled_arr_cfx,
        net_new_arr_cfx,
        gross_arr,
        net_arr,
        gross_arr_dc,
        gross_arr_cc,
        net_arr_dc,
        net_arr_cc,
        extractD.extract_date
FROM ( 
  SELECT *,
        row_number() OVER (PARTITION BY  date_key,cc_segment,sales_document,sales_document_item ORDER BY coalesce(Lm_engagement_name,account_name, date_key) DESC ) as ranking
  FROM b2b_analyst_tmp.l3_sa_license_management_report_pre_deduplication
) rep
LEFT JOIN (
   SELECT DISTINCT originating_spreadsheet,
                  originating_file,
                  lm_engagement_name
  FROM b2b_analyst_tmp.l3_sa_license_management_report_pre_deduplication
  WHERE big_deal = 'Y'
  AND originating_file NOT IN ('SMALL','INTERNAL SCALE')
  AND lm_engagement_name <> 'N/A'
) mediumBigDeals
ON mediumBigDeals.lm_engagement_name = rep.lm_engagement_name
AND mediumBigDeals.originating_spreadsheet = rep.originating_spreadsheet
LEFT JOIN (
   SELECT DISTINCT originating_spreadsheet,
                  originating_file,
                  account_name
  FROM b2b_analyst_tmp.l3_sa_license_management_report_pre_deduplication
  WHERE big_deal = 'Y'
  AND originating_file IN ('SMALL','INTERNAL SCALE')
) smallBigDeals
ON smallBigDeals.account_name = rep.account_name
AND smallBigDeals.originating_spreadsheet = rep.originating_spreadsheet

LEFT JOIN ( 
                SELECT  originating_spreadsheet, 
                        originating_tab, 
                        MAX(extract_date) AS extract_date -- I force it to take the most recent one - now this can be many
              FROM emea_and_usa_small_Companies 
              GROUP BY  originating_spreadsheet, 
                        originating_tab
              UNION ALL 
              SELECT    originating_spreadsheet, 
                        originating_tab, 
                        MAX(extract_date) AS extract_date
              FROM emea_and_usa_medium_companies
              GROUP BY  originating_spreadsheet, 
                        originating_tab

) extractD -- get the extract dates of the files to show when the data was last updated
ON upper(extractD.originating_spreadsheet) = upper(rep.originating_spreadsheet)  AND upper(extractD.originating_tab) = upper(rep.originating_tab)

-- Make sure everything which is from an opportunity is flagged as such 
LEFT JOIN ( SELECT DISTINCT sales_order_number_cleaned,
                            dealregistrationid
            FROM b2b_analyst_tmp.lm_opportunity_order_lookup ) opps 
ON regexp_replace(opps.sales_order_number_cleaned,'^0+','') = regexp_replace(sales_document,'^0+','')

WHERE rep.ranking = 1


