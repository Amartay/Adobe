# Databricks notebook source
# DBTITLE 1,Declare Shared Functions (to allow us to log these job events)
# MAGIC %run ../../../sales_analytics_shared_functions/declare_shared_functions

# COMMAND ----------

# DBTITLE 1,Declare function to check snaplogic has loaded the spreadsheets
# Check the logged snapshot upon completition of the last snaplogic load
def check_snaplogic_last_load():

    should_execute = True   
    has_error = False 

    try: 
        sql = "SELECT DISTINCT extractdate, CASE WHEN CAST(extractdate AS DATE) = current_date() THEN TRUE ELSE FALSE END AS is_load_current FROM b2b.tbl_dmeemeacb_licensemgmt_upload_task_monitoring"
        df = sqlContext.sql(sql)
        load_date =  df.head()[0]
        should_execute = df.head()[1]
        print(f"Last Snaplogic Load Time Is: {load_date}")
        print(f"Should Execute Is: {should_execute}")

        if df.count() == 0 or df.count()>1:
            should_execute = False
            print(f"Job Aborted: No Records/More than 1 record found in Snaplogic Load logging table")


    except Exception as e:
        has_error = True
        err_msg = f"Error in LM File Load Validation. Err Msg: " + str(e).replace("'",'')
        if has_error:
            raise Exception("An Error Has occured Checking the load date of Snaplogic Tables - Please Check the Logs")

    return should_execute

# COMMAND ----------

# DBTITLE 1,Run LM Reporting Notebooks 
# MAGIC %python
# MAGIC # Declare Variables 
# MAGIC has_error = False
# MAGIC start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
# MAGIC myid = str(uuid.uuid4())
# MAGIC job_name = "Sales Pipeline"
# MAGIC logging_table = 'b2b.sales_analytics_job_log'
# MAGIC
# MAGIC # Have a list of tables to check - snaplogic fails often in loading these 
# MAGIC tables_to_check = ["b2b.l1_sa_manual_lm_notified_list_small_companies",
# MAGIC                     "b2b.l1_sa_manual_lm_notified_list_small_companies_usa",
# MAGIC                     "b2b.l1_sa_manual_lm_notified_list_internal_scale_usa",
# MAGIC                     "b2b.l1_sa_manual_lm_notified_list_internal_scale",
# MAGIC                     "b2b.l1_sa_manual_lm_notified_list_medium_companies",
# MAGIC                     "b2b.l1_sa_manual_lm_notified_list_medium_companies_usa"
# MAGIC                     ]
# MAGIC
# MAGIC # List what notebooks need to run in the job;
# MAGIC notebooks_to_run = ["../1.setup_lm_reporting",
# MAGIC                     "../2.execute_lm_reporting",
# MAGIC                     ]
# MAGIC
# MAGIC # Evaluate if snaplogic has loaded files 
# MAGIC should_execute = check_snaplogic_last_load()
# MAGIC
# MAGIC if (should_execute):
# MAGIC   # Log Job Start 
# MAGIC   LogJobStart(myid,job_name,start_time,logging_table)
# MAGIC
# MAGIC   # Loop through the jobs list and run
# MAGIC   for n in notebooks_to_run:
# MAGIC
# MAGIC     try:    
# MAGIC       # Excute the current Job
# MAGIC       retValue = dbutils.notebook.run(n,0)
# MAGIC
# MAGIC
# MAGIC     # Catch Exceptions
# MAGIC     except Exception as e:
# MAGIC       has_error = True
# MAGIC       err_msg = f"Error in {n} Err Msg: " + str(e).replace("'",'')
# MAGIC       LogJobEnd(myid,job_name,start_time,"Error",err_msg,logging_table)
# MAGIC       if has_error:
# MAGIC           raise Exception("An Error Has occured - Please Check the Logs")
# MAGIC
# MAGIC   # Log Successful Job End
# MAGIC   LogJobEnd(myid,job_name,start_time,"Success",'',logging_table)
# MAGIC
# MAGIC else: 
# MAGIC   print("Tables Not Loaded by Snaplogic - Process Aborted")