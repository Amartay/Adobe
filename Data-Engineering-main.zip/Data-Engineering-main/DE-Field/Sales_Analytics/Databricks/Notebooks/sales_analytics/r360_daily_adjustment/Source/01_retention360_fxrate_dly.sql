-- Databricks notebook source
/*
JIRA 5874 - B2B L2 Retention360 table - interim solution
--------------------------------------------------------
https://jira.corp.adobe.com/browse/B2BDME-5874

This is an interim solution to solve FX conversion issue that exists in Finance table Retention360.
Logic is to pull in Retention360 table that is owned/maintained by IDS, reverse the FX conversion for
key fields and then re-apply correct FX Rates.

This table is to be kept in B2B_STG for short term as IDS have confirmed that they are working on a fix
their end, making this table redundant in the next short/mid term. No confirmed dates for IDS fix have
been announced, so there is an unknown lifespan for this B2B_STG table.
*/

refresh table csmb.vw_retention_360_team;
drop table if exists b2b_stg.l2_sa_r360_fx_adj;
create table b2b_stg.l2_sa_r360_fx_adj as 

select 
source01.*
, source01.sales_document as sales_doc2
, source01.sales_document_item as sales_doc_item2
, source01.up_for_renewal_arr as ufr_arr_ori

/*
  When there is a value for up_for_renewal_arr (aka UFR ARR), then reverse the historical FX rate applied to re-generate the LC value
  This only works as a single FX Rate per Fiscal Year is held in source table
*/
, case 
    when source01.up_for_renewal_arr is null then 0
    when source01.up_for_renewal_arr = 0 then 0
    else source01.up_for_renewal_arr / correct_fx.exchange_rate 
    end as up_for_renewal_arr_lc
, case 
    when source01.term_end_active_post_reactivation_arr is null then 0
    when source01.term_end_active_post_reactivation_arr = 0 then 0
    else source01.term_end_active_post_reactivation_arr / correct_fx.exchange_rate 
    end as term_end_active_post_reactivation_arr_lc
, case 
    when source01.end_term_cancel_arr is null then 0
    when source01.end_term_cancel_arr = 0 then 0
    else source01.end_term_cancel_arr / correct_fx.exchange_rate 
    end as end_term_cancel_arr_lc
, case 
    when source01.end_term_reactivation_arr is null then 0
    when source01.end_term_reactivation_arr = 0 then 0
    else source01.end_term_reactivation_arr / correct_fx.exchange_rate 
    end as end_term_reactivation_arr_lc
, case 
    when source01.term_end_active_arr is null then 0
    when source01.term_end_active_arr = 0 then 0
    else source01.term_end_active_arr / correct_fx.exchange_rate 
    end as term_end_active_arr_lc

/* 
  When there is a value for up_for_renewal_arr (aka UFR ARR), then reverse the historical FX rate applied before 
  applying the current FX rate.
  This only works as a single FX Rate per Fiscal Year is held in source table
*/
, case 
    when source01.up_for_renewal_arr is null then 0
    when source01.up_for_renewal_arr = 0 then 0
    else source01.up_for_renewal_arr / correct_fx.exchange_rate * correct_fx.current_exchange_rate 
    end as up_for_renewal_arr_cfx
, case 
    when source01.term_end_active_post_reactivation_arr is null then 0
    when source01.term_end_active_post_reactivation_arr = 0 then 0
    else source01.term_end_active_post_reactivation_arr / correct_fx.exchange_rate * correct_fx.current_exchange_rate 
    end as term_end_active_post_reactivation_arr_cfx
, case 
    when source01.end_term_cancel_arr is null then 0
    when source01.end_term_cancel_arr = 0 then 0
    else source01.end_term_cancel_arr / correct_fx.exchange_rate * correct_fx.current_exchange_rate 
    end as end_term_cancel_arr_cfx
, case 
    when source01.end_term_reactivation_arr is null then 0
    when source01.end_term_reactivation_arr = 0 then 0
    else source01.end_term_reactivation_arr / correct_fx.exchange_rate * correct_fx.current_exchange_rate 
    end as end_term_reactivation_arr_cfx
, case 
    when source01.term_end_active_arr is null then 0
    when source01.term_end_active_arr = 0 then 0
    else source01.term_end_active_arr / correct_fx.exchange_rate * correct_fx.current_exchange_rate 
    end as term_end_active_arr_cfx


from 

/* Main data source - this derived table is just using Retention 360 */
csmb.vw_retention_360_team source01
left outer join (select fiscal_year, currency, exchange_rate, current_exchange_rate from csmb_app.exchange_plan_rate ) correct_fx
    on correct_fx.currency = source01.document_currency
    and correct_fx.fiscal_year = source01.fiscal_yr
left outer join (select fiscal_year, currency, exchange_rate from csmb_app.exchange_plan_rate ) renewal_correct_fx
    on renewal_correct_fx.currency = source01.document_currency
    and renewal_correct_fx.fiscal_year = source01.renewal_fiscal_yr
