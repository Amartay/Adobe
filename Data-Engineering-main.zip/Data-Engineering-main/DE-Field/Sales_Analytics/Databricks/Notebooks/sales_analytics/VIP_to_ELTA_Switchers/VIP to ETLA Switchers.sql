-- Databricks notebook source
-- MAGIC %md
-- MAGIC Permissions have changed on the etla view (etla.vw_ent_arr).  I can no longer query it. Jas is dealing with talking to the finance guys about why this is / if we should use it / how we can get access. 
-- MAGIC until then I have set this to run on the previous version (b2b.uda_uda_finance_arr_vw_entarr)

-- COMMAND ----------

-- DBTITLE 1,Refresh tables that make up finance ETLA view
--REFRESH TABLE ETLA_APP.FACT_ENT_CONTRACT_SNAPSHOT;
--REFRESH TABLE ETLA_APP.DIM_SUBSCRIPTION;
--REFRESH TABLE ETLA_APP.FACT_ENT_MANUAL_ADJ_SNAPSHOT;
--REFRESH TABLE ids_coredata.dim_date;
--REFRESH TABLE ids_coredata.dim_product;
--REFRESH TABLE IDS_COREDATA.AT_DIM_MATERIAL_MASTER;
--REFRESH TABLE ETLA_APP.AT_REJECT_REASON;
--REFRESH TABLE csmb_app.exchange_plan_rate;
--REFRESH TABLE csmb_app.exchange_plan_rate;
--REFRESH TABLE ids_coredata.dim_country;
--REFRESH TABLE etla_app.at_snapshot_type_desc ;
--REFRESH TABLE csmb_app.gtm_projected_segmentation;
--REFRESH TABLE csmb_app.dim_gtm_acct_segment;
--REFRESH TABLE csmb_app.dim_gtm_acct_hierarchy;
--REFRESH TABLE etla_app.dme_account_segmentation;
--REFRESH TABLE replicn_sfdc.sfdc_account;
--REFRESH etla.vw_ent_arr;

-- COMMAND ----------

-- DBTITLE 1,Get Population of ETLA who were at some point migrated from vip
DROP TABLE IF EXISTS b2b_tmp.etla_switch;
CREATE TABLE   b2b_tmp.etla_switch AS
SELECT DISTINCT ent.echsubid AS ECH_SUB_STD_NAME_KEY,
                ent.geo,
                ent.marketsegment AS market_segment,
                ent.echsubname AS ech_sub_name, 
                ent.enduser AS end_user, 
                ent.endusername AS end_user_name, 
                CASE  WHEN upper(ent.olpg) IN ('CREATIVE','CCE STOCK') THEN 'TEAM' 
                      WHEN upper(ent.olpg) = 'CCE STOCK' THEN 'STOCK'
                      WHEN upper(ent.olpg) = 'ACROBAT' THEN 'ACROBAT DC'
                      ELSE upper(ent.olpg) END AS olpg_cleaned,
                min(ent.contractstartdate) as moved_to_etla_date
FROM b2b.uda_uda_finance_arr_vw_entarr ent
WHERE ent.sfdcetlatype = 'Migrated from VIP'
AND ent.dmegtmsegment <> 'Enterprise'
GROUP BY  ent.echsubid, 
          ent.geo,
          ent.echsubname, 
          ent.enduser,
          ent.marketsegment,
          ent.endusername,
          CASE  WHEN upper(ent.olpg) IN ('CREATIVE','CCE STOCK') THEN 'TEAM' 
                      WHEN upper(ent.olpg) = 'CCE STOCK' THEN 'STOCK'
                      WHEN upper(ent.olpg) = 'ACROBAT' THEN 'ACROBAT DC'
                      ELSE upper(ent.olpg) END
HAVING min(ent.contractstartdate) >='2022-01-01'

-- COMMAND ----------

-- DBTITLE 1,Refresh tables that make up pivot
 REFRESH TABLE CSMB_APP.exchange_rate_type_qtrly;
 REFRESH TABLE CSMB_APP.subscription_params;
 REFRESH TABLE CSMB_APP.acct_segment_activity_cutoff;
 REFRESH TABLE CSMB_APP.acct_segment_realign_hist;
 REFRESH TABLE CSMB_APP.dim_gtm_acct_hierarchy;
 REFRESH TABLE CSMB_APP.gtm_projected_segmentation;
 REFRESH TABLE CSMB_APP.dim_subscription;
 REFRESH TABLE CSMB_APP.dim_gtm_acct_segment;
 REFRESH csmb.vw_ccm_pivot4_all;

-- COMMAND ----------

-- DBTITLE 1,Get Cancellations for pivots for these IDs ranging from 2022 to current date
DROP TABLE IF EXISTS b2b_tmp.vip_cancellations;
CREATE TABLE b2b_tmp.vip_cancellations AS
SELECT  p.ech_sub_id,
        p.market_segment,
        p.geo,
        p.ech_sub_name,
        p.cc_segment, -- this is olpg apparently 
        sum(p.net_cancelled_arr_cfx) AS total_net_cancelled_arr
FROM csmb.vw_ccm_pivot4_all p
INNER JOIN ( SELECT DISTINCT ECH_SUB_STD_NAME_KEY, 
                            moved_to_etla_date
             FROM b2b_tmp.etla_switch ) e
ON e.ECH_SUB_STD_NAME_KEY = p.ech_sub_id
WHERE p.event_source = 'EVENT'
AND p.date_key >= '20220101' -- we dont care about events pre 2022
AND p.date_date BETWEEN date_add(e.moved_to_etla_date,-30) AND date_add(e.moved_to_etla_date,365) -- we are only interesting in cancelations if they are 30 days prior to the moved to etla date OR up to a year after
GROUP BY  p.ech_sub_id,
          p.ech_sub_name,
          p.cc_segment,
          p.geo,
          p.market_segment
HAVING  sum(p.net_cancelled_arr_cfx) >0 
        

-- COMMAND ----------

REFRESH TABLE Ids_coredata.dim_date;
REFRESH b2b.l2_sa_sfdc_dim_date;

-- COMMAND ----------

-- DBTITLE 1,Get Cancellation Details (event level) 
DROP TABLE IF EXISTS b2b.vip_cancellation_details;
CREATE TABLE b2b.vip_cancellation_details AS
SELECT  d.calendar_date as event_date,
        d.fiscal_yr_and_qtr_desc,
        d.fiscal_yr_and_per_desc,
        d.calendar_yr_and_wk_desc,
        p.ech_sub_id,
        p.market_area,
        p.market_segment,
        p.geo,
        p.ech_sub_name,
        p.cc_phone_vs_web,
        p.gtm_acct_segment,
        p.vip_contract,
        contract_end_date_veda,
        p.cc_segment, -- this is olpg apparently 
        p.net_cancelled_arr_cfx
FROM csmb.vw_ccm_pivot4_all p
INNER JOIN ( SELECT DISTINCT ECH_SUB_STD_NAME_KEY, 
                            moved_to_etla_date
             FROM b2b_tmp.etla_switch ) e
ON e.ECH_SUB_STD_NAME_KEY = p.ech_sub_id
INNER JOIN b2b.l2_sa_sfdc_dim_date d
  ON d.date_key = p.date_key
WHERE p.event_source = 'EVENT'
AND p.date_key >= '20220101' -- we dont care about events pre 2022
AND p.date_date BETWEEN date_add(e.moved_to_etla_date,-30) AND date_add(e.moved_to_etla_date,365) -- we are only interesting in cancelations if they are 30 days prior to the moved to etla date OR up to a year after
AND p.net_cancelled_arr_cfx >0 
        

-- COMMAND ----------

-- DBTITLE 1,Find potential False Switchers
-- Potential False Switchers are identified as those records which have 0 cancellations - but also do not have any active contracts 
DROP TABLE IF EXISTS b2b_tmp.potential_false_switchers;
CREATE TABLE b2b_tmp.potential_false_switchers AS 

SELECT ECH_SUB_STD_NAME_KEY as ech_sub_id, 
      status,
      latest_contract_end,
      total_net_cancelled_arr
FROM ( 
      SELECT DISTINCT ECH_SUB_STD_NAME_KEY,
            CASE WHEN pfs.ech_sub_id IS NULL THEN 'No Record In Pivot 4 All'
                 WHEN pfs.total_net_cancelled_arr = 0 AND latest_contract_end < current_date() THEN '0 Cancellations and all VIP Contracts Ended'
                 END AS status,
                 pfs.latest_contract_end,
                 pfs.total_net_cancelled_arr
      FROM b2b_tmp.etla_switch s
      LEFT JOIN ( SELECT  p.ech_sub_id, 
                          max(CAST(replace(p.contract_end_date_veda,'.','-') AS DATE)) as latest_contract_end, -- for some reason the date format is 2023.12.31
                          sum(p.net_cancelled_arr_cfx) AS total_net_cancelled_arr
                  FROM csmb.vw_ccm_pivot4_all p
                  WHERE p.date_key >= '20220101'
                  AND p.event_source = 'EVENT'
                  GROUP BY p.ech_sub_id
                  
      ) pfs
      ON s.ECH_SUB_STD_NAME_KEY = pfs.ech_sub_id
)
WHERE status IS NOT NULL

-- COMMAND ----------

-- REFRESH TABLE ETLA_APP.FACT_ENT_CONTRACT_SNAPSHOT;
-- REFRESH TABLE ETLA_APP.DIM_SUBSCRIPTION;
-- REFRESH TABLE ETLA_APP.FACT_ENT_MANUAL_ADJ_SNAPSHOT;
-- REFRESH TABLE ids_coredata.dim_date;
-- REFRESH TABLE ids_coredata.dim_product;
-- REFRESH TABLE IDS_COREDATA.AT_DIM_MATERIAL_MASTER;
-- REFRESH TABLE ETLA_APP.AT_REJECT_REASON;
-- REFRESH TABLE csmb_app.exchange_plan_rate;
-- REFRESH TABLE csmb_app.exchange_plan_rate;
-- REFRESH TABLE ids_coredata.dim_country;
-- REFRESH TABLE csmb_app.gtm_projected_segmentation;
-- REFRESH TABLE csmb_app.dim_gtm_acct_segment;
-- REFRESH TABLE csmb_app.dim_gtm_acct_hierarchy;
-- REFRESH TABLE etla_app.dme_account_segmentation;
-- REFRESH TABLE replicn_sfdc.sfdc_account;
-- REFRESH etla.vw_ent_arr;

-- COMMAND ----------

-- DBTITLE 1,Get weekly ETLA ARR Subtotals for these IDs 
DROP TABLE IF EXISTS b2b_tmp.etla_switchers_balances; 
CREATE TABLE b2b_tmp.etla_switchers_balances AS 
SELECT ent.fiscalyrandwk AS fiscal_yr_and_wk,
       ent.echsubid AS ECH_SUB_STD_NAME_KEY,
       ent.geo,
       CASE WHEN upper(ent.olpg) IN ('CREATIVE','CCE STOCK') THEN 'TEAM' 
            WHEN upper(ent.olpg) = 'CCE STOCK' THEN 'STOCK'
            WHEN upper(ent.olpg) = 'ACROBAT' THEN 'ACROBAT DC'
            ELSE upper(ent.olpg) END AS olpg_cleaned,
       sum(ent.TotalEndingARR) AS total_ending_arr
FROM b2b.uda_uda_finance_arr_vw_entarr ent
WHERE SnapshotType = 'W'
AND ent.echsubid IN (SELECT ECH_SUB_STD_NAME_KEY FROM b2b_tmp.etla_switch)
AND ent.DateDate >= '2022-01-01'
GROUP BY  ent.fiscalyrandwk,
       ent.echsubid,
       ent.geo,
       CASE WHEN upper(ent.olpg) IN ('CREATIVE','CCE STOCK') THEN 'TEAM' 
            WHEN upper(ent.olpg) = 'CCE STOCK' THEN 'STOCK'
            WHEN upper(ent.olpg) = 'ACROBAT' THEN 'ACROBAT DC'
            ELSE upper(ent.olpg) END

-- COMMAND ----------

-- DBTITLE 1,Create Report - showing the cancellations Vs ETLA uplift
------------------------------------------------------------------------------------------------------
-- Section One - Where product Groups are cancelled exist in new contracts
------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS b2b.etla_switchers_report; 
CREATE TABLE b2b.etla_switchers_report AS 
SELECT DISTINCT etla.ECH_SUB_STD_NAME_KEY AS ech_sub_id,
                etla.geo,
                etla.market_segment, 
                etla.ech_sub_name, 
                etla.end_user,
                etla.end_user_name,
                etla.olpg_cleaned as olpg,
                etla.moved_to_etla_date,
                d.fiscal_yr_and_qtr_desc AS etla_contract_start_qtr,
                d.fiscal_wk_in_qtr AS etla_contract_start_week_in_qtr,
                d.fiscal_yr_and_per_desc AS etla_contract_start_period, 
                d.fiscal_yr_and_wk_desc AS etla_contract_year_and_week,
                coalesce(vip.total_net_cancelled_arr,0) AS vip_net_cancelled_arr,
                booking_yr_and_wk, 
                coalesce(prevWkArr.total_ending_arr,0) AS total_ending_arr_week_before_etla_contract,
                coalesce(switchBooking.first_booking_on_or_after_contract_start,0) AS first_booking_on_or_after_contract_start,
                coalesce(switchBooking.first_booking_on_or_after_contract_start,0) - coalesce(prevWkArr.total_ending_arr,0) AS etla_arr_uplift,
                coalesce(switchBooking.first_booking_on_or_after_contract_start,0) - coalesce(prevWkArr.total_ending_arr,0) - coalesce(vip.total_net_cancelled_arr,0) AS etla_uplift_less_vip_cancel,
                CASE WHEN pfs.ech_sub_id IS NOT NULL THEN true else false END as potential_false_switcher,
                pfs.status AS potential_false_switcher_reason
FROM b2b_tmp.etla_switch  etla
LEFT JOIN b2b_tmp.vip_cancellations vip
  ON etla.ECH_SUB_STD_NAME_KEY = vip.ech_sub_id
  AND etla.olpg_cleaned = vip.cc_segment
  AND etla.geo=vip.geo
INNER JOIN b2b.l2_sa_sfdc_dim_date d
  ON d.calendar_date = etla.moved_to_etla_date
LEFT JOIN b2b_tmp.etla_switchers_balances prevWkArr 
  ON prevWkArr.ECH_SUB_STD_NAME_KEY = etla.ECH_SUB_STD_NAME_KEY 
  AND prevWkArr.fiscal_yr_and_wk = d.previous_fiscal_yr_week
  AND prevWkArr.olpg_cleaned = etla.olpg_cleaned
  AND prevWkArr.geo=etla.geo
LEFT JOIN (SELECT   ECH_SUB_STD_NAME_KEY,
                    booking_yr_and_wk,
                    olpg_cleaned,
                    total_ending_arr AS first_booking_on_or_after_contract_start 
          FROM ( 
                  SELECT DISTINCT   d.fiscal_yr_and_wk as elta_contract_start_week,
                                    s.fiscal_yr_and_wk as booking_yr_and_wk,
                                    s.ECH_SUB_STD_NAME_KEY,
                                    etla.ech_sub_name,
                                    s.olpg_cleaned,
                                    s.total_ending_arr,
                                    ROW_NUMBER() OVER(PARTITION BY s.ECH_SUB_STD_NAME_KEY, s.olpg_cleaned ORDER BY s.fiscal_yr_and_wk ASC) as ranking
                  FROM b2b_tmp.etla_switch  etla
                  INNER JOIN b2b.l2_sa_sfdc_dim_date d
                    ON d.calendar_date = etla.moved_to_etla_date
                  LEFT JOIN  b2b_tmp.etla_switchers_balances s
                    ON etla.ECH_SUB_STD_NAME_KEY = s.ECH_SUB_STD_NAME_KEY
                    AND etla.olpg_cleaned = s.olpg_cleaned
                    AND s.fiscal_yr_and_wk >= d.fiscal_yr_and_wk -- the week of the booking is on or after the week of the contract start 
                    AND etla.geo = s.geo
          ) 
          where ranking = 1 
) switchBooking
ON switchBooking.ECH_SUB_STD_NAME_KEY = etla.ECH_SUB_STD_NAME_KEY
AND switchBooking.olpg_cleaned = etla.olpg_cleaned
LEFT JOIN b2b_tmp.potential_false_switchers pfs 
  ON etla.ECH_SUB_STD_NAME_KEY = pfs.ech_sub_id




-- COMMAND ----------

-- DBTITLE 1,Cancellations on product Groups that arent in the ETLA 
-------------------------------------------------------------------------------------
-- Step 2 - Add Cancellations from VIP for product groups you no longer have in ETLA
-------------------------------------------------------------------------------------
INSERT INTO b2b.etla_switchers_report   (ech_sub_id, 
                                            geo,
                                            market_segment,
                                            ech_sub_name, 
                                            end_user,
                                            end_user_name, 
                                            olpg, 
                                            moved_to_etla_date, 
                                            etla_contract_start_qtr, 
                                            etla_contract_start_week_in_qtr,
                                            etla_contract_start_period,
                                            etla_contract_year_and_week,
                                            vip_net_cancelled_arr, 
                                            booking_yr_and_wk, 
                                            total_ending_arr_week_before_etla_contract, 
                                            first_booking_on_or_after_contract_start, 
                                            etla_arr_uplift, 
                                            etla_uplift_less_vip_cancel,
                                            potential_false_switcher,
                                            potential_false_switcher_reason)

SELECT DISTINCT etla.ECH_SUB_STD_NAME_KEY AS ech_sub_id,
                vip.geo,
                vip.market_segment,
                etla.ech_sub_name, 
                etla.end_user,
                etla.end_user_name,
                vip.cc_segment as olpg,
                etla.moved_to_etla_date,
                d.fiscal_yr_and_qtr_desc AS etla_contract_start_qtr,
                d.fiscal_wk_in_qtr AS etla_contract_start_week_in_qtr,
                d.fiscal_yr_and_per_desc AS etla_contract_start_period, 
                d.fiscal_yr_and_wk_desc AS etla_contract_year_and_week,
                coalesce(vip.total_net_cancelled_arr,0) AS vip_net_cancelled_arr,
                NULL AS booking_yr_and_wk, 
                0 AS total_ending_arr_week_before_etla_contract,
                0 AS first_booking_on_or_after_contract_start,
                0 AS etla_arr_uplift,
                0 - coalesce(vip.total_net_cancelled_arr,0) AS etla_uplift_less_vip_cancel,
                CASE WHEN pfs.ech_sub_id IS NOT NULL THEN true else false END as potential_false_switcher,
                pfs.status AS potential_false_switcher_reason
FROM b2b_tmp.etla_switch  etla
LEFT JOIN b2b_tmp.vip_cancellations vip
  ON etla.ECH_SUB_STD_NAME_KEY = vip.ech_sub_id
INNER JOIN b2b.l2_sa_sfdc_dim_date d
  ON d.calendar_date = etla.moved_to_etla_date
LEFT JOIN b2b_tmp.potential_false_switchers pfs 
  ON etla.ECH_SUB_STD_NAME_KEY = pfs.ech_sub_id
LEFT JOIN b2b.etla_switchers_report r
  ON concat(r.ech_sub_id,'-',r.olpg) = concat(vip.ech_sub_id,'-',vip.cc_segment)
WHERE r.ech_sub_id IS NULL -- the record doesnt exist in the report but exists in the vip cancellations


-- COMMAND ----------

-- DBTITLE 1,ETLA Details
DROP TABLE IF EXISTS b2b.elta_switcher_details;
CREATE TABLE b2b.elta_switcher_details AS 

SELECT fiscal_yr_and_wk,
        ECH_SUB_STD_NAME_KEY,
        geo,
        olpg_cleaned,
        market_area,
        market_segment,
        DME_GTM_SEGMENT_FINAL,
        total_wk_ending_arr
FROM 
(
  SELECT fiscal_yr_and_wk,
        ECH_SUB_STD_NAME_KEY,
        geo,
        olpg_cleaned,
        market_area,
        market_segment,
        DME_GTM_SEGMENT_FINAL,
        total_wk_ending_arr,
        ROW_NUMBER() OVER(PARTITION BY ranking.ECH_SUB_STD_NAME_KEY, ranking.olpg_cleaned ORDER BY ranking.fiscal_yr_and_wk ASC) as ranking
  FROM ( 
          SELECT ent.fiscalyrandwk AS fiscal_yr_and_wk,
                ent.echsubid AS ECH_SUB_STD_NAME_KEY,
                ent.echsubname AS ech_sub_name,
                ent.geo,
                CASE WHEN upper(ent.olpg) IN ('CREATIVE','CCE STOCK') THEN 'TEAM' 
                      WHEN upper(ent.olpg) = 'CCE STOCK' THEN 'STOCK'
                      WHEN upper(ent.olpg) = 'ACROBAT' THEN 'ACROBAT DC'
                      ELSE upper(ent.olpg) END AS olpg_cleaned,
                ent.marketarea AS market_area,
                ent.marketsegment AS market_segment,
                ent.dmegtmsegment AS DME_GTM_SEGMENT_FINAL,
                ent.TotalEndingARR AS total_wk_ending_arr
          FROM b2b.uda_uda_finance_arr_vw_entarr ent 
          INNER JOIN (
                SELECT DISTINCT s.ECH_SUB_STD_NAME_KEY, d.fiscal_yr_and_wk
                FROM b2b_tmp.etla_switch s 
                INNER JOIN b2b.l2_sa_sfdc_dim_date d
                  ON d.calendar_date = s.moved_to_etla_date
          )  s 
          ON s.ECH_SUB_STD_NAME_KEY = ent.echsubid
          AND ent.fiscalyrandwk >= s.fiscal_yr_and_wk -- the week of the etla balance is on or after the week of the contract start 
          WHERE SnapshotType = 'W'
          AND ent.DateDate >= '2022-01-01'
  ) ranking
) switchers
WHERE ranking = 1 

-- COMMAND ----------

--Tidy up
DROP TABLE IF EXISTS b2b_tmp.etla_switchers_balances;
DROP TABLE IF EXISTS b2b_tmp.vip_cancellations;
DROP TABLE IF EXISTS b2b_tmp.etla_switch;
DROP TABLE IF EXISTS b2b_tmp.potential_false_switchers;

