-- Databricks notebook source
------------------------------------------------------------NEW QUERY-------------------------------------------------------------------

drop table b2b_tmp.rep_subid_dcp_mapping;
create table if not exists b2b_tmp.rep_subid_dcp_mapping AS
select 
distinct  
'DCP_Coverage' as assignment_source,
'' as opportunity_stage,
base.ech_sub_id,
case when base.ech_sub_name is null then coverage.subsidiary_name else base.ech_sub_name end as ech_sub_name,
base.ech_parent_id,
case when base.ech_parent_name is null then coverage.parent_name else base.ech_parent_name end as ech_parent_name,
base.sales_district,
base.named_flag,
base.geo_group, 
base.geo_group_id,
coverage.rep_territory,
coverage.sales_rep_id as coverage_sales_rep_id,
coverage.sales_rep_name as coverage_sales_rep_name,
coverage.sales_rep_ldap as coverage_sales_rep_ldap,
coverage.sales_manager_id as coverage_sales_manager_id,
coverage.sales_manager_name as coverage_sales_manager_name,
coverage.sales_manager_ldap as coverage_sales_manager_ldap,
coverage.coverage_role_type,
employee.emp_id,
employee.emp_ldap,
employee.mgr_id as emp_mgr_id,
employee.mgr_name as emp_mgr_name,
employee.mgr_ldap as emp_mgr_ldap,
employee.title as emp_title,
employee.hire_date as emp_hire_date,
employee.orig_hire_date as emp_orig_hire_date,
employee.termination_date as emp_termination_date ,
employee.level1_mgr_id as emp_level1_mgr_id,
employee.level1_mgr_name as emp_level1_mgr_name,
employee.level1_mgr_ldap as emp_level1_mgr_ldap,
employee.level2_mgr_id as emp_level2_mgr_id,
employee.level2_mgr_name as emp_level2_mgr_name,
employee.level2_mgr_ldap as emp_level2_mgr_ldap,
employee.level3_mgr_id as emp_level3_mgr_id,
employee.level3_mgr_name as emp_level3_mgr_name,
employee.level3_mgr_ldap as emp_level3_mgr_ldap,
employee.level4_mgr_id as emp_level4_mgr_id,
employee.level4_mgr_name as emp_level4_mgr_name,
employee.level4_mgr_ldap as emp_level4_mgr_ldap,
employee.level5_mgr_id as emp_level5_mgr_id,
employee.level5_mgr_name as emp_level5_mgr_name,
employee.level5_mgr_ldap as emp_level5_mgr_ldap,
employee.level6_mgr_id as emp_level6_mgr_id,
employee.level6_mgr_name as emp_level6_mgr_name,
employee.level6_mgr_ldap as emp_level6_mgr_ldap,
employee.level7_mgr_id as emp_level7_mgr_id,
employee.level7_mgr_name as emp_level7_mgr_name,
employee.level7_mgr_ldap as emp_level7_mgr_ldap,
coverage.product_group as anaplan_product_group
from
  (
    select 
    distinct
    dcp.ech_sub_id,
    dcp.ech_sub_name,
    dcp.ech_parent_id,
    dcp.ech_parent_name,
    dcp.sales_district,
    dcp.named_flag,
    country.geo_group, 
    country.geo_group_id --1 to many mapping since 1 sales_district has multiple geo_id
    from b2b.dme_customer_profile dcp
    left join 
      b2b_stg.geogroup_cntry_map country 
      on dcp.sales_district = country.geo_country_code
 --   where dcp.named_flag = 1
  ) base
join  --due to inner join, only available Geo ID for latest refreshed date will be present. Example: for sub ID 610844, there are 15 distinct salesdistrict in dcp table, but only 5 geo_group_id's matched with coverage table for latest refresh date hence, only 5 salesdistrict will be present in final table 
  b2b.sops_tap_prod_eu_dbo_vw_report_ml_coverage coverage
  on base.ech_sub_id = coverage.subsidiary_id
  and base.geo_group_id = coverage.geo_group_id
left join 
   (select * from  b2b.sops_tap_prod_eu_dbo_vw_td_employee employee where employee.as_of_date in (select max(as_of_date) from b2b.sops_tap_prod_eu_dbo_vw_td_employee)) employee
  on coverage.sales_rep_id = employee.emp_id
where coverage.as_of_date in (select max(as_of_date) from b2b.sops_tap_prod_eu_dbo_vw_report_ml_coverage)
--Example: 1 sub ID 10134 has 555 rows due to 555 distinct opp ID's. Similar cases for other Subs. 

-- COMMAND ----------

--ALL opportunities are being taken from P2S table
drop table b2b_tmp.p2s_mapping;
create table b2b_tmp.p2s_mapping as 

with opp as 
(
  select distinct opp.id,opp.accountid, account.salesdistrict, account.standardizedsubid, account.standardizedsub, account.standardizedparentid, account.standardizedparent, account.id as account_id, country.geo_group, country.geo_group_id, opp.stage
 FROM b2b.uda_replicn_sf_corp_uda_vw_Opportunity opp
LEFT JOIN b2b.uda_replicn_sf_corp_uda_vw_account account 
    ON opp.AccountId = account.id 
left join 
      b2b_stg.geogroup_cntry_map country 
      on account.salesdistrict = country.geo_country_code
WHERE opp.as_of_date in (select max(as_of_date) from b2b.uda_replicn_sf_corp_uda_vw_Opportunity)
AND account.as_of_date in (select max(as_of_date) from b2b.uda_replicn_sf_corp_uda_vw_account)
and account.flag = 'D'
and opp.flag = 'D'
)

select 
 distinct 
 p2s.opportunity,
 p2s.userid,
 p2s.fullname1,
 p2s.adoberoletype,
coverage_sales.rep_territory,

-- Switched to SFDC Parent/Sub ID Details. In majority of cases, the Anaplan Coverage table does
-- not match with SFDC, meaning alot of cases were NULL for these key values.
opp.standardizedsubid as ech_sub_id,
opp.standardizedsub as ech_sub_name,
opp.standardizedparentid as ech_parent_id,
opp.standardizedparent as ech_parent_name,
opp.geo_group_id,
opp.geo_group,
coverage_sales.sales_rep_id as coverage_sales_rep_id,
coverage_sales.sales_rep_name as coverage_sales_rep_name,
coverage_sales.sales_rep_ldap as coverage_sales_rep_ldap,
coverage_sales.sales_manager_id as coverage_sales_manager_id,
coverage_sales.sales_manager_name as coverage_sales_manager_name,
coverage_sales.sales_manager_ldap as coverage_sales_manager_ldap,
coverage_sales.coverage_role_type,
coverage_sales.product_group as anaplan_product_group,
opp.salesdistrict, -- new source for employee table does not have country_code
opp.stage, 
employee.emp_id,
employee.emp_ldap,
employee.mgr_id as emp_mgr_id,
employee.mgr_name as emp_mgr_name,
employee.mgr_ldap as emp_mgr_ldap,
employee.title as emp_title,
employee.hire_date as emp_hire_date,
employee.orig_hire_date as emp_orig_hire_date,
employee.termination_date as emp_termination_date ,
employee.level1_mgr_id as emp_level1_mgr_id,
employee.level1_mgr_name as emp_level1_mgr_name,
employee.level1_mgr_ldap as emp_level1_mgr_ldap,
employee.level2_mgr_id as emp_level2_mgr_id,
employee.level2_mgr_name as emp_level2_mgr_name,
employee.level2_mgr_ldap as emp_level2_mgr_ldap,
employee.level3_mgr_id as emp_level3_mgr_id,
employee.level3_mgr_name as emp_level3_mgr_name,
employee.level3_mgr_ldap as emp_level3_mgr_ldap,
employee.level4_mgr_id as emp_level4_mgr_id,
employee.level4_mgr_name as emp_level4_mgr_name,
employee.level4_mgr_ldap as emp_level4_mgr_ldap,
employee.level5_mgr_id as emp_level5_mgr_id,
employee.level5_mgr_name as emp_level5_mgr_name,
employee.level5_mgr_ldap as emp_level5_mgr_ldap,
employee.level6_mgr_id as emp_level6_mgr_id,
employee.level6_mgr_name as emp_level6_mgr_name,
employee.level6_mgr_ldap as emp_level6_mgr_ldap,
employee.level7_mgr_id as emp_level7_mgr_id,
employee.level7_mgr_name as emp_level7_mgr_name,
employee.level7_mgr_ldap as emp_level7_mgr_ldap,
--case when coverage_manager.sales_manager_name is null then 'P2S'
--     when coverage_sales.sales_rep_name is null then 'P2S'
--     else "ANAPLAN"
--end as assignment_source,
case when coverage_sales.sales_rep_id is not null then 'P2S_Coverage'
     else "P2S_SFDC"
end as assignment_source
from
  (select 
    distinct 
   p2s.opportunity,
   user.userid,
   user.fullname1,
   user.adoberoletype,
   user.employeenumber
   --user.email
    from  b2b.uda_replicn_sf_corp_uda_vw_adobeproducttosalesteamassignment p2s
    
    INNER JOIN (  SELECT DISTINCT userid, fullname1, adoberoletype, employeenumber
              FROM  b2b.uda_replicn_sf_corp_uda_vw_user  
              WHERE as_of_date=(SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_user) 
              ) user
    ON user.UserID = p2s.SalesTeamMember
    where p2s.as_of_date = (SELECT max(as_of_date) FROM b2b.uda_replicn_sf_corp_uda_vw_AdobeProductToSalesTeamAssignment)
  ) p2s
left join 
  (select * from  b2b.sops_tap_prod_eu_dbo_vw_td_employee employee where employee.as_of_date in (select max(as_of_date) from b2b.sops_tap_prod_eu_dbo_vw_td_employee)) employee
  on p2s.employeenumber = employee.emp_id
  --on lower(p2s.email) = lower(employee.emp_email)

--opportunity mapping
left join opp 
 on p2s.opportunity = opp.id

---sales_rep_mapping using Anaplan Coverage Source
left join 
  (select *  from  b2b.sops_tap_prod_eu_dbo_vw_report_ml_coverage coverage  where coverage.as_of_date in (select max(as_of_date) from b2b.sops_tap_prod_eu_dbo_vw_report_ml_coverage)) coverage_sales
  on opp.standardizedsubid = coverage_sales.subsidiary_id
  and opp.geo_group_id = coverage_sales.geo_group_id
  and employee.emp_id = coverage_sales.sales_rep_id

--manager_rep_mapping
--left join 
--  (select *  from  b2b.sops_tap_prod_eu_dbo_vw_report_ml_coverage coverage  where coverage.as_of_date in (select max(as_of_date) from b2b.sops_tap_prod_eu_dbo_vw_report_ml_coverage)) coverage_manager
--  on opp.standardizedsubid = coverage_manager.subsidiary_id
--  and opp.geo_group_id = coverage_manager.geo_group_id
--  and employee.mgr_id = coverage_manager.sales_manager_id

 


/* 
SW Comment - Thu 11 Jan 2024
There is a push from SOPS to switch to using P2S mapping ONLY for opportunities as the Anaplan approach using Sub_ID does not
support re-assignments between team members or across teams. At present if a case or client is re-assigned, there are no 
Business processes available to do this in Anaplan, meaning over time Anaplan will diverge from actual Business. 

For now, will keep this filter in place as nothing has been confirmed of this change-over, but if this is approved then this 
filter will need to be removed. - removed post discussion with Seby

Sales district is at the Account level and not at the staff level. 
*/
--where opp.standardizedsubid is null

-- COMMAND ----------

-- UNION TABLE of DCP and P2S
--To add a new column called data_source for DCP+coverage and P2S

drop table b2b.l2_sub_id_opp_rep_map;
create table b2b.l2_sub_id_opp_rep_map as 
select
--mapping_source,
assignment_source,
ech_sub_id,
ech_sub_name,
ech_parent_id,
ech_parent_name,
named_flag,
geo_group, 
geo_group_id, 
rep_territory,
coverage_sales_rep_id,
coverage_sales_rep_name,
coverage_sales_rep_ldap,
coverage_sales_manager_id,
coverage_sales_manager_name,
coverage_sales_manager_ldap,
coverage_role_type,
sales_district,
opportunity_stage,
emp_id,
emp_ldap,
emp_mgr_id,
emp_mgr_name,
emp_mgr_ldap,
emp_title,
emp_hire_date,
emp_orig_hire_date,
emp_termination_date ,
emp_level1_mgr_id,
emp_level1_mgr_name,
emp_level1_mgr_ldap,
emp_level2_mgr_id,
emp_level2_mgr_name,
emp_level2_mgr_ldap,
emp_level3_mgr_id,
emp_level3_mgr_name,
emp_level3_mgr_ldap,
emp_level4_mgr_id,
emp_level4_mgr_name,
emp_level4_mgr_ldap,
emp_level5_mgr_id,
emp_level5_mgr_name,
emp_level5_mgr_ldap,
emp_level6_mgr_id,
emp_level6_mgr_name,
emp_level6_mgr_ldap,
emp_level7_mgr_id,
emp_level7_mgr_name,
emp_level7_mgr_ldap,
anaplan_product_group,
null  as opportunity,
null  as userid,
null  as fullname1,
null  as adoberoletype,
current_date() as as_of_date
from b2b_tmp.rep_subid_dcp_mapping 

union all 

select 
--mapping_source,
assignment_source,
ech_sub_id,
ech_sub_name,
ech_parent_id,
ech_parent_name,
null as named_flag,
geo_group, 
geo_group_id, 
rep_territory,
coverage_sales_rep_id,
coverage_sales_rep_name,
coverage_sales_rep_ldap,
coverage_sales_manager_id,
coverage_sales_manager_name,
coverage_sales_manager_ldap,
coverage_role_type,
salesdistrict as sales_district,
stage as opportunity_stage,
emp_id,
emp_ldap,
emp_mgr_id,
emp_mgr_name,
emp_mgr_ldap,
emp_title,
emp_hire_date,
emp_orig_hire_date,
emp_termination_date ,
emp_level1_mgr_id,
emp_level1_mgr_name,
emp_level1_mgr_ldap,
emp_level2_mgr_id,
emp_level2_mgr_name,
emp_level2_mgr_ldap,
emp_level3_mgr_id,
emp_level3_mgr_name,
emp_level3_mgr_ldap,
emp_level4_mgr_id,
emp_level4_mgr_name,
emp_level4_mgr_ldap,
emp_level5_mgr_id,
emp_level5_mgr_name,
emp_level5_mgr_ldap,
emp_level6_mgr_id,
emp_level6_mgr_name,
emp_level6_mgr_ldap,
emp_level7_mgr_id,
emp_level7_mgr_name,
emp_level7_mgr_ldap,
anaplan_product_group,
opportunity,
userid,
fullname1,
adoberoletype,
current_date() as as_of_date

from b2b_tmp.p2s_mapping