# Databricks notebook source
# DBTITLE 1,Declare Shared Functions (to allow us to log these job events)
# MAGIC %run ../../sales_analytics_shared_functions/declare_shared_functions

# COMMAND ----------

# DBTITLE 1,Run Current MM Report
# MAGIC %python
# MAGIC # Declare Variables 
# MAGIC has_error = False
# MAGIC start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
# MAGIC myid = str(uuid.uuid4())
# MAGIC job_name = "EMEA MM Report"
# MAGIC logging_table = 'b2b.sales_analytics_job_log'
# MAGIC
# MAGIC # List what notebooks need to run in the job;
# MAGIC notebook_to_run = "../1.append_current_midmarket_emea_Report"
# MAGIC
# MAGIC # Log Job Start 
# MAGIC LogJobStart(myid,job_name,start_time,logging_table)
# MAGIC
# MAGIC try:    
# MAGIC     # Excute the current Job
# MAGIC     retValue = dbutils.notebook.run(notebook_to_run,0)
# MAGIC
# MAGIC    # Catch Exceptions
# MAGIC   except Exception as e:
# MAGIC     has_error = True
# MAGIC     err_msg = f"Error in {n} Err Msg: " + str(e).replace("'",'')
# MAGIC     LogJobEnd(myid,job_name,start_time,"Error",err_msg,logging_table)
# MAGIC     if has_error:
# MAGIC         raise Exception("An Error Has occured - Please Check the Logs")
# MAGIC
# MAGIC # Log Successful Job End
# MAGIC LogJobEnd(myid,job_name,start_time,"Success",'',logging_table)