# Databricks notebook source
from pyspark import SparkContext, SparkConf , StorageLevel
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging
from dateutil.rrule import rrule, MONTHLY
from datetime import datetime
import json
from pyspark.sql import functions
import sys
class main() :
    def __init__(self):
         try :
             spark = SparkSession.builder \
                 .enableHiveSupport() \
                 .config('hive.exec.dynamic.partition', 'true') \
                 .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                 .config('hive.exec.max.dynamic.partitions', '10000') \
                 .getOrCreate()
             log4j = spark._jvm.org.apache.log4j
             log4j.LogManager.getRootLogger().setLevel(log4j.Level.ERROR)
             spark.sql('SET hive.warehouse.data.skiptrash=true;')
             spark.sql('set hive.exec.dynamic.partition.mode=nonstrict')
             spark.conf.set('spark.sql.cbo.enabled', True)
             spark.conf.set('spark.sql.cbo.join reorder.enabled', True)
             spark.sql('set spark.sql.parquet.enableVectorizedReader=false')
             spark.sql('set spark.sql.sources.partitionOverwriteMode=dynamic')
             spark.sql("set spark.databricks.sql.files.prorateMaxPartitionBytes.enabled=false")
             spark.sql("set spark.sql.adaptive.coalescePartitions.enabled=false")
             spark.sql("set spark.sql.adaptive.enabled=false")
             spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
            
             dbutils.widgets.text("Custom_Settings", "")

             Settings = dbutils.widgets.get("Custom_Settings")

             Set_list = Settings.split(',')
             if len(Set_list)>0:
                 for i in Set_list:
                     if i != "":
                         print("spark.sql(+i+)")
                         spark.sql("""{i}""".format(i=i))

             spark.sql(""" SET hive.exec.parallel=true """)
             spark.sql(""" SET hive.exec.dynamic.partition=true """)
             spark.sql(""" SET hive.exec.dynamic.partition.mode=nonstrict """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions=10000 """)
             spark.sql(""" SET hive.exec.max.dynamic.partitions.pernode=10000 """)
             spark.sql(""" SET hive.optimize.sort.dynamic.partition=true """)
             spark.sql(""" SET hive.vectorized.execution.enabled=false """)
             spark.sql(""" SET hive.vectorized.execution.reduce.enabled=false """)
             spark.sql(""" SET mapreduce.input.fileinputformat.input.dir.recursive=true """)
             spark.sql(""" SET hive.mapred.supports.subdirectories=true """)
             spark.sql(""" SET hive.tez.auto.reducer.parallelism=true """)
             spark.sql(""" SET hive.tez.dynamic.partition.pruning=false """)
             spark.sql(""" SET hive.stats.autogather=true """)
             spark.sql(""" set hive.mapred.mode=nonstrict """)
             spark.sql(""" drop table if exists b2b.sp_sbst_6mo_expansion_contracts """)
             spark.sql(""" create table b2b.sp_sbst_6mo_expansion_contracts as
Select pivot.*
, sbst_first_purchase_date
, datediff(to_date(current_date()), to_date(sbst_first_purchase_date)) as days_from_sbst_first_purchase
, total_fwk_end_active
, total_fwk_end_arr
, sbst_fwk_end_active
, sbst_fwk_end_arr
, CASE WHEN mm_list.vip_contract='' OR mm_list.vip_contract is NULL then 'N' else 'Y' end as is_mm_flag
, mm_list.parent_name
, mm_list.sub_name as vip_name
, mm_list.3dae_name as 3dae_name
, mm_list.3dpsm_name as psm_name
, industry as industry
, employee_range as employee_range
, revenue_range as revenue_range
, renewal_date
, renewal_wk
, renewal_qtr
, end_user
, reseller
, distributor
, partner_level
, email_id
from
(
Select     
        CASE WHEN vip_contract is NULL or vip_contract='' THEN jem.contract_id ELSE vip_contract END AS pivot_contract_id
        , max(if(UPPER(p.entitlement_type) = 'CCE' or UPPER(p.product_config_description) like '%ENTRPRSE%','Y','N')) as enterprise_contract
        , sort_array(collect_set(subs_offer))subs_offer
        , sort_array(collect_set(p.product_name))product_name
        , sort_array(collect_set(p.product_name_description))product_name_description
        , sort_array(collect_set(p.cc_phone_vs_web))cc_phone_vs_web
        , sort_array(collect_set(p.market_segment))market_segment
        , sort_array(collect_set(p.route_to_market))route_to_market
        , sort_array(collect_set(p.geo))geo
        , sort_array(collect_set(p.market_area))market_area
        , sort_array(collect_set(p.market_area_description))market_area_description
        from csmb.vw_ccm_pivot4_all p
        left outer join (select subscription_account_guid, max(contract_id) as contract_id from ocf_analytics.dim_seat group by subscription_account_guid) jem on UPPER(jem.subscription_account_guid) = UPPER(p.subscription_account_guid)                
        where jem.contract_id is not null and jem.contract_id<>'' 
        and p.fwk_end_active>0
        and upper(stype) = 'TM'
        and p.product_name in ('SBTX', 'SBST', 'SRC')
        and TO_DATE(p.date_date) = TO_DATE(date_sub(CURRENT_DATE, cast(from_unixtime( unix_timestamp(CAST(current_timestamp() AS TIMESTAMP)), 'u') AS int) + 2))
        GROUP BY  
        CASE WHEN vip_contract is NULL or vip_contract='' THEN jem.contract_id ELSE vip_contract END
)pivot
        left outer join
        (
        Select     
        CASE WHEN vip_contract is NULL or vip_contract='' THEN jem.contract_id ELSE vip_contract END AS pivot_contract_id
        , CASE WHEN sum(p.init_purchase)>0 then 'Y' else 'N'end as is_initial_purchase_flag
        , min(date_date) as sbst_first_purchase_date
        from csmb.vw_ccm_pivot4_all p
        left outer join (select subscription_account_guid, max(contract_id) as contract_id from ocf_analytics.dim_seat group by subscription_account_guid) jem on UPPER(jem.subscription_account_guid) = UPPER(p.subscription_account_guid)                
        where jem.contract_id is not null and jem.contract_id<>''
        and upper(stype) = 'TM'
        and p.product_name in ('SBTX', 'SBST', 'SRC')
        GROUP BY
        CASE WHEN vip_contract is NULL or vip_contract='' THEN jem.contract_id ELSE vip_contract END
        )purchase_date on purchase_date.pivot_contract_id = pivot.pivot_contract_id
        left outer join
        (
        Select     
        CASE WHEN vip_contract is NULL or vip_contract='' THEN jem.contract_id ELSE vip_contract END AS pivot_contract_id
        , sum(p.fwk_end_active) as total_fwk_end_active 
        , sum(p.fwk_end_arr) as total_fwk_end_arr
        , SUM(if(product_name in ('SBTX', 'SBST', 'SRC'), p.fwk_end_active,0)) AS sbst_fwk_end_active
        , SUM(if(product_name in ('SBTX', 'SBST', 'SRC'), p.fwk_end_arr,0)) AS sbst_fwk_end_arr
        from csmb.vw_ccm_pivot4_all p
        left outer join (select subscription_account_guid, max(contract_id) as contract_id from ocf_analytics.dim_seat group by subscription_account_guid) jem on UPPER(jem.subscription_account_guid) = UPPER(p.subscription_account_guid)                
        where jem.contract_id is not null and jem.contract_id<>''
        and upper(stype) = 'TM'
        and TO_DATE(p.date_date) = TO_DATE(date_sub(CURRENT_DATE, cast(from_unixtime( unix_timestamp(CAST(current_timestamp() AS TIMESTAMP)), 'u') AS int) + 2)) 
        GROUP BY
        CASE WHEN vip_contract is NULL or vip_contract='' THEN jem.contract_id ELSE vip_contract END
        )all_seats on all_seats.pivot_contract_id = pivot.pivot_contract_id
        LEFT JOIN 
        (Select DISTINCT vip_contract, 3dae_name,3dpsm_name,parent_name,sub_name
        from b2b.agodah_mmviplist 
        )mm_list ON mm_list.vip_contract = pivot.pivot_contract_id
        LEFT JOIN 
            (
            Select unique_contract.* from
                (
                Select  contract_id
                        , firmo_db.domain
                        , coalesce(firmo_db.industry,sub_industry.industry)industry
                        , firmo_db.employee_range
                        , firmo_db.revenue_range
                        ,ROW_NUMBER() OVER(PARTITION BY contract_id ORDER BY revenue_range DESC) as rownum
                from b2b.sp_firmographics_smb_contract_details firmo_db
                left join (select * from b2b_stg.zi_industry_master where domain is not null and domain<>'' )sub_industry on upper(firmo_db.domain) = upper(sub_industry.domain)
                where contract_id is not null and contract_id<>''
                group by firmo_db.contract_id
                        , firmo_db.domain
                        , coalesce(firmo_db.industry,sub_industry.industry)
                        , firmo_db.employee_range
                        , firmo_db.revenue_range
                )unique_contract where rownum=1
            )firmo on pivot.pivot_contract_id=firmo.contract_id
LEFT JOIN
    (select * 
	from 
	(Select contract_id
        , to_date(renewal_date) as renewal_date
        , renewal_wk
        , renewal_qtr
        , end_user
        , reseller
        , distributor
        , partner_level
        , email_id
        , row_number() over(partition by contract_id order by renewal_date ASC) as rownum
        from b2b.smb_renewal_churn_deploy_firmo 
        where contract_id is not null and contract_id<>''
        and to_date(renewal_date) >= date_add(to_date(current_date()),-60)
        group by
        contract_id
        , renewal_date
        , renewal_wk
        , renewal_qtr
        , end_user
        , reseller
        , distributor
        , partner_level
        , email_id
    ) reseller_info_pre
WHERE rownum = 1
	) reseller_info
	on pivot.pivot_contract_id = reseller_info.contract_id """)

             try:
                 dbutils.notebook.exit("SUCCESS")
             except Exception as e:
                 print("exception:",e)
         except Exception as e:
             dbutils.notebook.exit(e)

if __name__ == '__main__':
        main()

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into table b2b.sp_sbst_6mo_expansion_contracts_snapshot
# MAGIC select *
# MAGIC from b2b.sp_sbst_6mo_expansion_contracts